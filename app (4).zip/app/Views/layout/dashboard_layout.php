<?php
// Helper untuk membaca URL
$uri = service('uri');
$segment1 = $uri->getSegment(1); // dashboard
$segment2 = $uri->getSegment(2); // news, products, etc.

// Grup untuk menu dropdown
$contentPages   = ['news', 'products', 'gallery', 'wisata'];
$adminPages     = ['apparatus', 'population', 'surat'];
$koperasiPages  = ['koperasi'];

$hukumPages     = ['jdih'];
$perencanaanPages = ['rkp'];
$transparansiPages = ['keuangan'];

// Cek apakah menu dropdown harus aktif/terbuka
$isContentActive = in_array($segment2, $contentPages);
$isAdminActive   = in_array($segment2, $adminPages);
$isKoperasiActive = in_array($segment2, $koperasiPages);

$isHukumActive   = in_array($segment2, $hukumPages);
$isPerencanaanActive = in_array($segment2, $perencanaanPages);
$isTransparansiActive = in_array($segment2, $transparansiPages);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?= esc($title ?? 'Dashboard'); ?> | Website Desa</title>

    <!-- Bootstrap 4 untuk Dashboard (JANGAN PAKAI BOOTSTRAP 5) -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    
    <!-- Bootstrap 4 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- SB Admin 2 CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/startbootstrap-sb-admin-2/4.1.4/css/sb-admin-2.min.css" rel="stylesheet">
    
    <!-- DataTables CSS -->
    <link href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    
    <style>
        /* Pastikan tidak ada style Bootstrap 5 di sini */
        /* Pastikan tidak ada style Bootstrap 5 di sini */
.sidebar .nav-item .nav-link[data-toggle="collapse"]::after {
    content: '\f107';
    font-family: 'Font Awesome 5 Free';
    font-weight: 900;
    float: right;
    transition: transform 0.3s ease;
}

.sidebar .nav-item .nav-link[data-toggle="collapse"].collapsed::after {
    transform: rotate(-90deg);
}

.sidebar .nav-item.active > .nav-link {
    color: #fff !important;
    background-color: rgba(255,255,255,0.1);
}

.sidebar-dark .sidebar-brand {
    color: #fff;
}

.sidebar-dark hr.sidebar-divider {
    border-color: rgba(255,255,255,0.15);
}

/* Override untuk btn-danger agar konsisten */
.btn-danger {
    background-color: #dc3545 !important;
    border-color: #dc3545 !important;
}

.btn-danger:hover {
    background-color: #c82333 !important;
    border-color: #c82333 !important;
}

/* Fix untuk card header */
.card-header {
    padding: 0.75rem 1.25rem;
    margin-bottom: 0;
    background-color: #f8f9fc;
    border-bottom: 1px solid #e3e6f0;
}
    </style>
</head>

<body id="page-top">
    <div id="wrapper">
        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= site_url('dashboard') ?>">
                <div class="sidebar-brand-icon">
                    <img src="<?= base_url('img/logo.png') ?>" alt="Logo Desa" style="height: 40px;" onerror="this.src='<?= base_url('img/default-company.png') ?>'">
                </div>
                <div class="sidebar-brand-text mx-2">Desa Kaliboja</div>
            </a>

            <hr class="sidebar-divider my-0">

            <!-- Dashboard -->
            <li class="nav-item <?= ($segment1 == 'dashboard' && empty($segment2)) ? 'active' : '' ?>">
                <a class="nav-link" href="<?= site_url('dashboard') ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>

            <hr class="sidebar-divider">

            <!-- Manajemen Konten -->
            <div class="sidebar-heading">Manajemen Konten</div>
            <li class="nav-item <?= $isContentActive ? 'active' : '' ?>">
                <a class="nav-link <?= !$isContentActive ? 'collapsed' : '' ?>" href="#" data-toggle="collapse" data-target="#collapseKonten">
                    <i class="fas fa-fw fa-pencil-alt"></i>
                    <span>Konten Website</span>
                </a>
                <div id="collapseKonten" class="collapse <?= $isContentActive ? 'show' : '' ?>" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item <?= ($segment2 == 'news') ? 'active' : '' ?>" href="<?= site_url('dashboard/news') ?>">
                            <i class="fas fa-fw fa-newspaper mr-2"></i>Berita Desa
                        </a>
                        <a class="collapse-item <?= ($segment2 == 'products') ? 'active' : '' ?>" href="<?= site_url('dashboard/products') ?>">
                            <i class="fas fa-fw fa-box mr-2"></i>Produk Unggulan
                        </a>
                        <a class="collapse-item <?= ($segment2 == 'gallery') ? 'active' : '' ?>" href="<?= site_url('dashboard/gallery') ?>">
                            <i class="fas fa-fw fa-images mr-2"></i>Galeri
                        </a>
                        <a class="collapse-item <?= ($segment2 == 'wisata') ? 'active' : '' ?>" href="<?= site_url('dashboard/wisata') ?>">
                            <i class="fas fa-fw fa-umbrella-beach mr-2"></i> Wisata Desa
                        </a>
                    </div>
                </div>
            </li>

            <!-- Administrasi Desa -->
            <div class="sidebar-heading">Administrasi Desa</div>
            <li class="nav-item <?= $isAdminActive ? 'active' : '' ?>">
                <a class="nav-link <?= !$isAdminActive ? 'collapsed' : '' ?>" href="#" data-toggle="collapse" data-target="#collapseAdministrasi">
                    <i class="fas fa-fw fa-landmark"></i>
                    <span>Administrasi</span>
                </a>
                <div id="collapseAdministrasi" class="collapse <?= $isAdminActive ? 'show' : '' ?>" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item <?= ($segment2 == 'apparatus') ? 'active' : '' ?>" href="<?= site_url('dashboard/apparatus') ?>">
                            <i class="fas fa-fw fa-users mr-2"></i>Aparatur Desa
                        </a>
                        <a class="collapse-item <?= ($segment2 == 'population') ? 'active' : '' ?>" href="<?= site_url('dashboard/population') ?>">
                            <i class="fas fa-fw fa-user-friends mr-2"></i>Data Penduduk
                        </a>
                        <a class="collapse-item <?= ($segment2 == 'surat') ? 'active' : '' ?>" href="<?= site_url('dashboard/surat') ?>">
                            <i class="fas fa-fw fa-envelope mr-2"></i>Layanan Surat
                        </a>
                    </div>
                </div>
            </li>

      <div class="sidebar-heading">Ekonomi Desa</div>
<li class="nav-item <?= $isKoperasiActive ? 'active' : '' ?>">
    <a class="nav-link <?= !$isKoperasiActive ? 'collapsed' : '' ?>" href="#" data-toggle="collapse" data-target="#collapseKoperasi">
        <i class="fas fa-fw fa-handshake"></i>
        <span>Koperasi Merah Putih</span>
    </a>
    <div id="collapseKoperasi" class="collapse <?= $isKoperasiActive ? 'show' : '' ?>" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item <?= ($segment2 == 'koperasi') ? 'active' : '' ?>" href="<?= site_url('dashboard/koperasi') ?>">
                <i class="fas fa-fw fa-cogs mr-2"></i>Manajemen Koperasi
            </a>
        </div>
    </div>
</li>

            <!-- Tambah di dalam sidebar setelah menu Ekonomi Desa -->
<div class="sidebar-heading">Kesehatan Desa</div>
<li class="nav-item <?= ($segment2 == 'posyandu' || $segment2 == 'posbindu') ? 'active' : '' ?>">
    <a class="nav-link <?= !($segment2 == 'posyandu' || $segment2 == 'posbindu') ? 'collapsed' : '' ?>" href="#" data-toggle="collapse" data-target="#collapseKesehatan">
        <i class="fas fa-fw fa-heartbeat"></i>
        <span>Kesehatan Desa</span>
    </a>
    <div id="collapseKesehatan" class="collapse <?= ($segment2 == 'posyandu' || $segment2 == 'posbindu') ? 'show' : '' ?>" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item <?= ($segment2 == 'posyandu') ? 'active' : '' ?>" href="<?= site_url('dashboard/posyandu') ?>">
                <i class="fas fa-fw fa-baby mr-2"></i>Data Posyandu
            </a>
            <a class="collapse-item <?= ($segment2 == 'posbindu') ? 'active' : '' ?>" href="<?= site_url('dashboard/posbindu') ?>">
                <i class="fas fa-fw fa-user-md mr-2"></i>Data Posbindu Lansia
            </a>
        </div>
    </div>
</li>
            
            <!-- Hukum & Peraturan -->
            <div class="sidebar-heading">Hukum & Peraturan</div>
            <li class="nav-item <?= $isHukumActive ? 'active' : '' ?>">
                <a class="nav-link <?= !$isHukumActive ? 'collapsed' : '' ?>" href="#" data-toggle="collapse" data-target="#collapseHukum">
                    <i class="fas fa-fw fa-gavel"></i>
                    <span>Hukum & Peraturan</span>
                </a>
                <div id="collapseHukum" class="collapse <?= $isHukumActive ? 'show' : '' ?>" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item <?= ($segment2 == 'jdih') ? 'active' : '' ?>" href="<?= site_url('dashboard/jdih') ?>">
                            <i class="fas fa-fw fa-balance-scale mr-2"></i>JDIH
                        </a>
                    </div>
                </div>
            </li>

            <!-- Perencanaan Desa -->
            <div class="sidebar-heading">Perencanaan Desa</div>
            <li class="nav-item <?= $isPerencanaanActive ? 'active' : '' ?>">
                <a class="nav-link <?= !$isPerencanaanActive ? 'collapsed' : '' ?>" href="#" data-toggle="collapse" data-target="#collapsePerencanaan">
                    <i class="fas fa-fw fa-chart-line"></i>
                    <span>Perencanaan</span>
                </a>
                <div id="collapsePerencanaan" class="collapse <?= $isPerencanaanActive ? 'show' : '' ?>" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item <?= ($segment2 == 'rkp') ? 'active' : '' ?>" href="<?= site_url('dashboard/rkp') ?>">
                            <i class="fas fa-fw fa-project-diagram mr-2"></i>RKP Desa
                        </a>
                    </div>
                </div>
            </li>

            
            <!-- Transparansi -->
            <div class="sidebar-heading">Transparansi</div>
            <li class="nav-item <?= $isTransparansiActive ? 'active' : '' ?>">
                <a class="nav-link <?= !$isTransparansiActive ? 'collapsed' : '' ?>" href="#" data-toggle="collapse" data-target="#collapseTransparansi">
                    <i class="fas fa-fw fa-coins"></i>
                    <span>Transparansi</span>
                </a>
                <div id="collapseTransparansi" class="collapse <?= $isTransparansiActive ? 'show' : '' ?>" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item <?= ($segment2 == 'keuangan') ? 'active' : '' ?>" href="<?= site_url('dashboard/keuangan') ?>">
                            <i class="fas fa-fw fa-chart-line mr-2"></i>Laporan Keuangan
                        </a>
                    </div>
                </div>
            </li>

            <hr class="sidebar-divider d-none d-md-block">
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>
        </ul>
        
        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <!-- Main Content -->
            <div id="content">
                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
                    
                    <!-- Page Title -->
                    <h5 class="m-0 font-weight-bold text-primary">
                        <?= esc($title ?? 'Dashboard'); ?>
                    </h5>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">
                                    <?= esc(session()->get('username') ?? 'Admin'); ?>
                                </span>
                                <img class="img-profile rounded-circle" src="https://ui-avatars.com/api/?name=<?= urlencode(session()->get('username') ?? 'Admin') ?>&background=4e73df&color=fff">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="<?= site_url('/') ?>" target="_blank">
                                    <i class="fas fa-external-link-alt fa-sm fa-fw mr-2 text-gray-400"></i>Lihat Website
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>Logout
                                </a>
                            </div>
                        </li>
                    </ul>
                </nav>

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Flash Messages -->
                    <?php if (session()->getFlashdata('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fas fa-check-circle mr-2"></i><?= session()->getFlashdata('success') ?>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <?php if (session()->getFlashdata('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="fas fa-exclamation-circle mr-2"></i><?= session()->getFlashdata('error') ?>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <?php if (session()->getFlashdata('errors')): ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <i class="fas fa-exclamation-triangle mr-2"></i>
                            <ul class="mb-0">
                                <?php foreach (session()->getFlashdata('errors') as $error): ?>
                                    <li><?= $error ?></li>
                                <?php endforeach; ?>
                            </ul>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <!-- Page Content -->
                    <?= $this->renderSection('content'); ?>
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>2025 Pemerintah Desa Kaliboja. All Rights Reserved. Dikembangkan oleh Tim IT KKN 4 Kelompok 7 Desa Kaliboja</span>
                    </div>
                </div>
            </footer>
        </div>
        <!-- End of Content Wrapper -->
    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Yakin ingin keluar?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Pilih "Logout" di bawah jika Anda siap untuk mengakhiri sesi.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    <a class="btn btn-primary" href="<?= site_url('logout'); ?>">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap 4 JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- SB Admin 2 JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/startbootstrap-sb-admin-2/4.1.4/js/sb-admin-2.min.js"></script>
    
    <!-- DataTables JavaScript -->
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap4.min.js"></script>
    
    <script>
    $(document).ready(function() {
        // Auto collapse other menus when one is opened
        $('.nav-link[data-toggle="collapse"]').on('click', function() {
            var target = $(this).data('target');
            $('.collapse').not(target).collapse('hide');
        });

        // Auto dismiss alerts after 5 seconds
        setTimeout(function() {
            $('.alert').alert('close');
        }, 5000);

        // Initialize DataTables jika ada table dengan class dataTable
        if ($.fn.DataTable.isDataTable('.dataTable')) {
            $('.dataTable').DataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.10.25/i18n/Indonesian.json"
                }
            });
        }
    });
    </script>
    
    <?= $this->renderSection('page-scripts') ?>
</body>
</html>