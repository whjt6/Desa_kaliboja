<?= $this->extend('layout/main_layout'); ?>

<?= $this->section('content'); ?>
<!-- Hero Section Kategori -->

<div class="container py-5">
    <!-- Statistik Kategori -->
    <div class="row mb-5">
        <div class="col-12">
            <div class="card border-0 shadow-sm" data-aos="fade-up">
                <div class="card-body p-4">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h3 class="text-primary mb-2"><?= esc($kategori['nama_kategori']); ?></h3>
                            <p class="text-muted mb-0">
                                <?php if (!empty($kategori['deskripsi'])): ?>
                                    <?= esc($kategori['deskripsi']); ?>
                                <?php else: ?>
                                    Kumpulan peraturan dalam kategori <?= esc($kategori['nama_kategori']); ?>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="col-md-4 text-end">
                            <div class="display-6 fw-bold text-primary"><?= count($peraturans); ?></div>
                            <p class="text-muted mb-0">Total Peraturan</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Daftar Peraturan -->
    <div class="row" id="peraturan">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="section-title m-0" data-aos="fade-up">
                    <i class="fas fa-file-contract me-2"></i>Daftar Peraturan
                </h2>
                <span class="badge bg-primary" data-aos="fade-up"><?= count($peraturans); ?> Peraturan</span>
            </div>

            <?php if (!empty($peraturans)): ?>
                <div class="row row-cols-1 row-cols-md-2 g-4">
                    <?php foreach ($peraturans as $p): ?>
                    <div class="col" data-aos="fade-up">
                        <div class="card product-card h-100">
                            <div class="product-image-container">
                                <div class="no-image d-flex flex-column align-items-center justify-content-center">
                                    <i class="fas fa-file-pdf fa-4x text-danger mb-3"></i>
                                    <span class="badge bg-primary position-absolute top-0 start-0 m-3">
                                        <?= esc($kategori['nama_kategori']); ?>
                                    </span>
                                    <span class="badge bg-success position-absolute top-0 end-0 m-3">
                                        <?= esc($p['tahun']); ?>
                                    </span>
                                </div>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title text-dark"><?= esc($p['jenis_peraturan']); ?></h5>
                                <p class="card-text text-muted small mb-2">
                                    No. <?= esc($p['nomor']); ?>/<?= esc($p['tahun']); ?>
                                </p>
                                <p class="card-text text-dark mb-3">
                                    <?= character_limiter(esc($p['tentang']), 120); ?>
                                </p>
                                
                                <div class="d-flex justify-content-between align-items-center">
                                    <small class="text-muted">
                                        <i class="fas fa-calendar-alt me-1"></i>
                                        <?= date('d M Y', strtotime($p['tanggal_ditetapkan'])); ?>
                                    </small>
                                    <div class="product-actions">
                                        <a href="<?= site_url('jdih/detail/' . $p['id']); ?>" 
                                           class="btn btn-sm btn-info me-1" title="Detail">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?= site_url('jdih/download/' . $p['id']); ?>" 
                                           class="btn btn-sm btn-success" title="Download">
                                            <i class="fas fa-download"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="text-center py-5" data-aos="fade-up">
                    <i class="fas fa-folder-open fa-4x text-muted mb-4"></i>
                    <h4 class="text-muted">Belum ada peraturan dalam kategori ini</h4>
                    <p class="text-muted mb-4">Peraturan akan segera diunggah</p>
                    <a href="<?= site_url('jdih'); ?>" class="btn btn-primary">
                        <i class="fas fa-arrow-left me-2"></i>Kembali ke JDIH
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Kategori Lainnya -->
<section class="bg-light py-5">
    <div class="container">
        <h3 class="section-title mb-4 text-center" data-aos="fade-up">
            <i class="fas fa-list me-2"></i>Kategori Lainnya
        </h3>
        
        <div class="row">
            <?php 
            // Contoh kategori lain (dalam implementasi nyata, ini akan diambil dari database)
            $kategoriLain = [
                ['id' => 1, 'nama_kategori' => 'Peraturan Desa', 'jumlah' => 15],
                ['id' => 2, 'nama_kategori' => 'Peraturan Bupati', 'jumlah' => 8],
                ['id' => 3, 'nama_kategori' => 'Peraturan Daerah', 'jumlah' => 12],
                ['id' => 4, 'nama_kategori' => 'Instruksi Bupati', 'jumlah' => 5]
            ];
            
            // Filter out current category
            $kategoriLain = array_filter($kategoriLain, function($k) use ($kategori) {
                return $k['id'] != $kategori['id'];
            });
            
            // Limit to 4 categories
            $kategoriLain = array_slice($kategoriLain, 0, 4);
            ?>
            
            <?php if (!empty($kategoriLain)): ?>
                <?php foreach ($kategoriLain as $kat): ?>
                <div class="col-md-3 col-6 mb-4" data-aos="fade-up">
                    <a href="<?= site_url('jdih/kategori/' . $kat['id']); ?>" class="text-decoration-none">
                        <div class="card border-0 shadow-sm h-100 hover-lift">
                            <div class="card-body text-center p-4">
                                <i class="fas fa-folder fa-3x text-primary mb-3"></i>
                                <h6 class="card-title text-dark mb-2"><?= esc($kat['nama_kategori']); ?></h6>
                                <p class="card-text text-muted">
                                    <?= $kat['jumlah']; ?> Peraturan
                                </p>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <div class="text-center mt-4" data-aos="fade-up">
            <a href="<?= site_url('jdih'); ?>" class="btn btn-outline-primary">
                <i class="fas fa-list me-2"></i>Lihat Semua Kategori
            </a>
        </div>
    </div>
</section>
<?= $this->endSection(); ?>