<?= $this->extend('layout/main_layout'); ?>

<?= $this->section('content'); ?>
<!-- Hero Section Pencarian -->


<div class="container py-5">
    <!-- Form Pencarian -->
    <div class="row mb-5">
        <div class="col-lg-8 mx-auto">
            <div class="card shadow border-0" data-aos="zoom-in">
                <div class="card-body p-4">
                    <h4 class="card-title text-center mb-4">
                        <i class="fas fa-search text-primary me-2"></i>Cari Peraturan Lainnya
                    </h4>
                    <form action="<?= site_url('jdih/search'); ?>" method="get" class="row g-3">
                        <div class="col-md-8">
                            <div class="input-group input-group-lg">
                                <span class="input-group-text bg-light border-end-0">
                                    <i class="fas fa-search text-muted"></i>
                                </span>
                                <input type="text" class="form-control border-start-0" name="q" 
                                       placeholder="Masukkan kata kunci peraturan..." 
                                       value="<?= esc($keyword); ?>">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary btn-lg w-100">
                                <i class="fas fa-search me-2"></i>Cari
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Hasil Pencarian -->
    <div class="row" id="hasil">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="section-title m-0" data-aos="fade-up">
                    <i class="fas fa-file-contract me-2"></i>Hasil Pencarian
                </h2>
                <span class="badge bg-primary" data-aos="fade-up">
                    <?= count($results); ?> Hasil ditemukan
                </span>
            </div>

            <?php if (!empty($results)): ?>
                <div class="row row-cols-1 row-cols-md-2 g-4">
                    <?php foreach ($results as $p): ?>
                    <div class="col" data-aos="fade-up">
                        <div class="card product-card h-100">
                            <div class="product-image-container">
                                <div class="no-image d-flex flex-column align-items-center justify-content-center">
                                    <i class="fas fa-file-pdf fa-4x text-danger mb-3"></i>
                                    <span class="badge bg-primary position-absolute top-0 start-0 m-3">
                                        <?= esc($p['nama_kategori']); ?>
                                    </span>
                                    <span class="badge bg-success position-absolute top-0 end-0 m-3">
                                        <?= esc($p['tahun']); ?>
                                    </span>
                                </div>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title text-dark"><?= esc($p['jenis_peraturan']); ?></h5>
                                <p class="card-text text-muted small mb-2">
                                    No. <?= esc($p['nomor']); ?>/<?= esc($p['tahun']); ?>
                                </p>
                                <p class="card-text text-dark mb-3">
                                    <?php
                                    // Highlight search term in result
                                    $text = esc($p['tentang']);
                                    if (!empty($keyword)) {
                                        $text = preg_replace("/($keyword)/i", '<span class="bg-warning">$1</span>', $text);
                                    }
                                    echo character_limiter($text, 120);
                                    ?>
                                </p>
                                
                                <div class="d-flex justify-content-between align-items-center">
                                    <small class="text-muted">
                                        <i class="fas fa-calendar-alt me-1"></i>
                                        <?= date('d M Y', strtotime($p['tanggal_ditetapkan'])); ?>
                                    </small>
                                    <div class="product-actions">
                                        <a href="<?= site_url('jdih/detail/' . $p['id']); ?>" 
                                           class="btn btn-sm btn-info me-1" title="Detail">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?= site_url('jdih/download/' . $p['id']); ?>" 
                                           class="btn btn-sm btn-success" title="Download">
                                            <i class="fas fa-download"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Pagination -->
                <nav aria-label="Page navigation" class="mt-5" data-aos="fade-up">
                    <ul class="pagination justify-content-center">
                        <li class="page-item <?= ($current_page <= 1) ? 'disabled' : ''; ?>">
                            <a class="page-link" href="?q=<?= urlencode($keyword); ?>&page=<?= $current_page - 1; ?>">Previous</a>
                        </li>
                        
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?= ($i == $current_page) ? 'active' : ''; ?>">
                                <a class="page-link" href="?q=<?= urlencode($keyword); ?>&page=<?= $i; ?>"><?= $i; ?></a>
                            </li>
                        <?php endfor; ?>
                        
                        <li class="page-item <?= ($current_page >= $total_pages) ? 'disabled' : ''; ?>">
                            <a class="page-link" href="?q=<?= urlencode($keyword); ?>&page=<?= $current_page + 1; ?>">Next</a>
                        </li>
                    </ul>
                </nav>
            <?php else: ?>
                <div class="text-center py-5" data-aos="fade-up">
                    <i class="fas fa-search fa-4x text-muted mb-4"></i>
                    <h4 class="text-muted">Tidak ditemukan hasil pencarian</h4>
                    <p class="text-muted mb-4">Tidak ada peraturan yang sesuai dengan kata kunci "<?= esc($keyword); ?>"</p>
                    
                    <div class="row justify-content-center">
                        <div class="col-md-6">
                            <div class="card border-0 shadow-sm">
                                <div class="card-body p-4">
                                    <h5 class="card-title text-primary mb-3">Tips Pencarian:</h5>
                                    <ul class="text-start text-muted">
                                        <li>Gunakan kata kunci yang lebih umum</li>
                                        <li>Coba cari berdasarkan nomor peraturan</li>
                                        <li>Gunakan kata kunci tunggal</li>
                                        <li>Periksa ejaan kata kunci</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-4">
                        <a href="<?= site_url('jdih'); ?>" class="btn btn-primary">
                            <i class="fas fa-list me-2"></i>Lihat Semua Peraturan
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Pencarian Populer -->
<section class="bg-light py-5">
    <div class="container">
        <h3 class="section-title mb-4 text-center" data-aos="fade-up">
            <i class="fas fa-fire me-2"></i>Pencarian Populer
        </h3>
        
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card border-0 shadow-sm" data-aos="fade-up">
                    <div class="card-body p-4">
                        <div class="d-flex flex-wrap justify-content-center gap-2">
                            <?php 
                            $popularSearches = [
                                'APBDes', 'Perdes', 'Bupati', 'Desa', 'Anggaran',
                                'Pajak', 'Retribusi', 'UMKM', 'Pembangunan', 'Layanan'
                            ];
                            ?>
                            
                            <?php foreach ($popularSearches as $search): ?>
                                <a href="<?= site_url('jdih/search?q=' . urlencode($search)); ?>" 
                                   class="badge bg-primary bg-opacity-10 text-primary text-decoration-none p-2 m-1">
                                    <?= esc($search); ?>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?= $this->endSection(); ?>