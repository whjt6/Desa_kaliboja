<?= $this->extend('layout/main_layout'); ?>

<?= $this->section('content'); ?>
<!-- Hero Section Filter Tahun -->
<div class="container py-5">
    <!-- Statistik Tahun -->
    <div class="row mb-5">
        <div class="col-12">
            <div class="card border-0 shadow-sm" data-aos="fade-up">
                <div class="card-body p-4">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h3 class="text-primary mb-2">Tahun <?= $tahun; ?></h3>
                            <p class="text-muted mb-0">
                                Peraturan perundang-undangan yang ditetapkan pada tahun <?= $tahun; ?>
                            </p>
                        </div>
                        <div class="col-md-4 text-end">
                            <div class="display-6 fw-bold text-primary"><?= count($peraturans); ?></div>
                            <p class="text-muted mb-0">Total Peraturan</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filter Kategori di Tahun Ini -->
    <div class="row mb-5">
        <div class="col-12">
            <div class="card border-0 shadow-sm" data-aos="fade-up">
                <div class="card-header bg-light">
                    <h5 class="mb-0"><i class="fas fa-filter me-2"></i>Filter Berdasarkan Kategori</h5>
                </div>
                <div class="card-body">
                    <div class="d-flex flex-wrap gap-2">
                        <a href="<?= site_url('jdih/tahun/' . $tahun); ?>" 
                           class="badge bg-primary text-white text-decoration-none p-2">
                            Semua (<?= count($peraturans); ?>)
                        </a>
                        
                        <?php 
                        // Group by kategori
                        $kategoriGroups = [];
                        foreach ($peraturans as $p) {
                            $kategoriName = $p['nama_kategori'] ?? 'Lainnya';
                            if (!isset($kategoriGroups[$kategoriName])) {
                                $kategoriGroups[$kategoriName] = 0;
                            }
                            $kategoriGroups[$kategoriName]++;
                        }
                        ?>
                        
                        <?php foreach ($kategoriGroups as $katName => $count): ?>
                            <a href="<?= site_url('jdih/tahun/' . $tahun . '?kategori=' . urlencode($katName)); ?>" 
                               class="badge bg-light text-dark text-decoration-none p-2 border">
                                <?= esc($katName); ?> (<?= $count; ?>)
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Daftar Peraturan -->
    <div class="row" id="peraturan">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="section-title m-0" data-aos="fade-up">
                    <i class="fas fa-file-contract me-2"></i>Daftar Peraturan Tahun <?= $tahun; ?>
                </h2>
                <div class="dropdown" data-aos="fade-up">
                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="fas fa-sort me-2"></i>Urutkan
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="?sort=terbaru">Terbaru</a></li>
                        <li><a class="dropdown-item" href="?sort=terlama">Terlama</a></li>
                        <li><a class="dropdown-item" href="?sort=a-z">A-Z</a></li>
                    </ul>
                </div>
            </div>

            <?php if (!empty($peraturans)): ?>
                <div class="table-responsive" data-aos="fade-up">
                    <table class="table table-hover">
                        <thead class="table-primary">
                            <tr>
                                <th>No</th>
                                <th>Jenis Peraturan</th>
                                <th>Nomor</th>
                                <th>Tentang</th>
                                <th>Kategori</th>
                                <th>Tanggal Ditetapkan</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            // Sort based on query parameter
                            if (isset($_GET['sort'])) {
                                usort($peraturans, function($a, $b) {
                                    if ($_GET['sort'] == 'terlama') {
                                        return strtotime($a['tanggal_ditetapkan']) - strtotime($b['tanggal_ditetapkan']);
                                    } elseif ($_GET['sort'] == 'a-z') {
                                        return strcmp($a['jenis_peraturan'], $b['jenis_peraturan']);
                                    } else {
                                        return strtotime($b['tanggal_ditetapkan']) - strtotime($a['tanggal_ditetapkan']);
                                    }
                                });
                            }
                            
                            $no = 1; 
                            ?>
                            <?php foreach ($peraturans as $p): ?>
                            <tr>
                                <td class="text-center"><?= $no++; ?></td>
                                <td class="text-dark"><?= esc($p['jenis_peraturan']); ?></td>
                                <td class="text-dark">
                                    <strong><?= esc($p['nomor']); ?>/<?= esc($p['tahun']); ?></strong>
                                </td>
                                <td class="text-dark">
                                    <?= character_limiter(esc($p['tentang']), 80); ?>
                                </td>
                                <td>
                                    <span class="badge bg-secondary"><?= esc($p['nama_kategori']); ?></span>
                                </td>
                                <td class="text-dark">
                                    <?= date('d M Y', strtotime($p['tanggal_ditetapkan'])); ?>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="<?= site_url('jdih/detail/' . $p['id']); ?>" 
                                           class="btn btn-info" title="Detail">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?= site_url('jdih/download/' . $p['id']); ?>" 
                                           class="btn btn-success" title="Download">
                                            <i class="fas fa-download"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-5" data-aos="fade-up">
                    <i class="fas fa-calendar-times fa-4x text-muted mb-4"></i>
                    <h4 class="text-muted">Belum ada peraturan pada tahun <?= $tahun; ?></h4>
                    <p class="text-muted mb-4">Peraturan akan segera diunggah</p>
                    <a href="<?= site_url('jdih'); ?>" class="btn btn-primary">
                        <i class="fas fa-arrow-left me-2"></i>Kembali ke JDIH
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Tahun Lainnya -->
<section class="bg-light py-5">
    <div class="container">
        <h3 class="section-title mb-4 text-center" data-aos="fade-up">
            <i class="fas fa-calendar me-2"></i>Tahun Lainnya
        </h3>
        
        <div class="row">
            <?php 
            // Contoh tahun lain (dalam implementasi nyata, ini akan diambil dari database)
            $tahunLain = [
               
            ];
            
            // Filter out current year
            $tahunLain = array_filter($tahunLain, function($t) use ($tahun) {
                return $t['tahun'] != $tahun;
            });
            
            // Sort by year descending
            usort($tahunLain, function($a, $b) {
                return $b['tahun'] - $a['tahun'];
            });
            
            // Limit to 6 years
            $tahunLain = array_slice($tahunLain, 0, 6);
            ?>
            
            <?php if (!empty($tahunLain)): ?>
                <?php foreach ($tahunLain as $t): ?>
                <div class="col-md-2 col-4 mb-3" data-aos="fade-up">
                    <a href="<?= site_url('jdih/tahun/' . $t['tahun']); ?>" class="text-decoration-none">
                        <div class="card border-0 shadow-sm h-100 hover-lift">
                            <div class="card-body text-center p-3">
                                <div class="display-6 fw-bold text-primary"><?= $t['tahun']; ?></div>
                                <small class="text-muted"><?= $t['jumlah']; ?> Peraturan</small>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <div class="text-center mt-4" data-aos="fade-up">
            <a href="<?= site_url('jdih'); ?>" class="btn btn-outline-primary">
                <i class="fas fa-list me-2"></i>Lihat Semua Tahun
            </a>
        </div>
    </div>
</section>
<?= $this->endSection(); ?>