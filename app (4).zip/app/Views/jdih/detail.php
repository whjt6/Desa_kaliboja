<?= $this->extend('layout/main_layout'); ?>

<?= $this->section('content'); ?>
<!-- Hero Section Detail Peraturan -->


<div class="container py-5">
    <div class="row">
        <!-- Detail Peraturan -->
        <div class="col-lg-8 mb-5" id="detail">
            <div class="card border-0 shadow-sm mb-4" data-aos="fade-up">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><i class="fas fa-info-circle me-2"></i>Informasi Peraturan</h4>
                </div>
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <th width="40%" class="text-dark">Jenis Peraturan</th>
                                    <td class="text-dark"><?= esc($peraturan['jenis_peraturan']); ?></td>
                                </tr>
                                <tr>
                                    <th class="text-dark">Nomor</th>
                                    <td class="text-dark"><?= esc($peraturan['nomor']); ?></td>
                                </tr>
                                <tr>
                                    <th class="text-dark">Tahun</th>
                                    <td class="text-dark"><?= esc($peraturan['tahun']); ?></td>
                                </tr>
                                <tr>
                                    <th class="text-dark">Kategori</th>
                                    <td>
                                        <span class="badge bg-secondary"><?= esc($peraturan['nama_kategori']); ?></span>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <th width="40%" class="text-dark">Tanggal Ditetapkan</th>
                                    <td class="text-dark"><?= date('d F Y', strtotime($peraturan['tanggal_ditetapkan'])); ?></td>
                                </tr>
                                <tr>
                                    <th class="text-dark">Tanggal Diundangkan</th>
                                    <td class="text-dark"><?= date('d F Y', strtotime($peraturan['tanggal_diundangkan'])); ?></td>
                                </tr>
                                <tr>
                                    <th class="text-dark">Status</th>
                                    <td>
                                        <?php 
                                        $status_badge = [
                                            'berlaku' => 'success',
                                            'dicabut' => 'danger',
                                            'perubahan' => 'warning'
                                        ];
                                        $status_text = [
                                            'berlaku' => 'Berlaku',
                                            'dicabut' => 'Dicabut',
                                            'perubahan' => 'Perubahan'
                                        ];
                                        ?>
                                        <span class="badge bg-<?= $status_badge[$peraturan['status']] ?? 'secondary'; ?>">
                                            <?= $status_text[$peraturan['status']] ?? $peraturan['status']; ?>
                                        </span>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <h5 class="text-primary mb-3">Tentang</h5>
                    <div class="alert alert-light">
                        <p class="mb-0 text-dark"><?= nl2br(esc($peraturan['tentang'])); ?></p>
                    </div>

                    <?php if (!empty($peraturan['abstrak'])): ?>
                    <h5 class="text-primary mb-3 mt-4">Abstrak</h5>
                    <div class="alert alert-info">
                        <p class="mb-0 text-dark"><?= nl2br(esc($peraturan['abstrak'])); ?></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Dokumen dan Aksi -->
        <div class="col-lg-4 mb-5" id="dokumen">
            <div class="sticky-top" style="top: 100px;">
                <div class="card border-0 shadow-sm mb-4" data-aos="fade-up">
                    <div class="card-body text-center p-4">
                        <i class="fas fa-file-pdf fa-4x text-danger mb-3"></i>
                        <h5 class="card-title text-dark mb-3">Dokumen Peraturan</h5>
                        <p class="card-text text-muted mb-4">
                            Dokumen tersedia dalam format PDF yang dapat diunduh secara gratis.
                        </p>
                        <a href="<?= site_url('jdih/download/' . $peraturan['id']); ?>" 
                           class="btn btn-danger btn-lg w-100 mb-3">
                            <i class="fas fa-download me-2"></i>Download PDF
                        </a>
                        <div class="text-muted small">
                            <i class="fas fa-info-circle me-1"></i>
                            <?php 
                            $filePath = ROOTPATH . 'public/uploads/jdih/' . $peraturan['file_dokumen'];
                            if (file_exists($filePath)) {
                                $fileSize = filesize($filePath);
                                echo 'Ukuran file: ' . round($fileSize / 1024, 2) . ' KB';
                            } else {
                                echo 'Ukuran file: Tidak diketahui';
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div class="card border-0 shadow-sm" data-aos="fade-up" data-aos-delay="100">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-share-alt me-2"></i>Bagikan</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-center gap-3">
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?= urlencode(current_url()); ?>" 
                               target="_blank" class="btn btn-outline-primary btn-sm">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="https://twitter.com/intent/tweet?url=<?= urlencode(current_url()); ?>&text=<?= urlencode($peraturan['tentang']); ?>" 
                               target="_blank" class="btn btn-outline-info btn-sm">
                                <i class="fab fa-twitter"></i>
                            </a>
                            <a href="https://wa.me/?text=<?= urlencode($peraturan['tentang'] . ' - ' . current_url()); ?>" 
                               target="_blank" class="btn btn-outline-success btn-sm">
                                <i class="fab fa-whatsapp"></i>
                            </a>
                            <button onclick="copyToClipboard('<?= current_url(); ?>')" 
                                    class="btn btn-outline-secondary btn-sm" title="Salin tautan">
                                <i class="fas fa-link"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Peraturan Terkait -->
    <div class="row">
        <div class="col-12">
            <h3 class="section-title mb-4" data-aos="fade-up">
                <i class="fas fa-file-alt me-2"></i>Peraturan Terkait
            </h3>
            
            <div class="row row-cols-1 row-cols-md-2 g-4">
                <?php 
                // Contoh peraturan terkait (dalam implementasi nyata, ini akan diambil dari database)
                $peraturanTerkait = [
                    [
                        'id' => 1,
                        'jenis_peraturan' => 'Peraturan Desa',
                        'nomor' => '2',
                        'tahun' => '2024',
                        'tentang' => 'Perubahan atas Peraturan Desa Nomor 1 Tahun 2023'
                    ],
                    [
                        'id' => 2,
                        'jenis_peraturan' => 'Peraturan Bupati',
                        'nomor' => '15',
                        'tahun' => '2024',
                        'tentang' => 'Petunjuk Teknis Pengelolaan Dana Desa'
                    ]
                ];
                ?>
                
                <?php foreach ($peraturanTerkait as $pt): ?>
                <div class="col" data-aos="fade-up">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body">
                            <h5 class="card-title text-primary"><?= esc($pt['jenis_peraturan']); ?></h5>
                            <p class="card-text text-muted small mb-2">
                                No. <?= esc($pt['nomor']); ?>/<?= esc($pt['tahun']); ?>
                            </p>
                            <p class="card-text text-dark mb-3">
                                <?= character_limiter(esc($pt['tentang']), 100); ?>
                            </p>
                            <a href="<?= site_url('jdih/detail/' . $pt['id']); ?>" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-eye me-1"></i>Lihat Detail
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<script>
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(function() {
        alert('Tautan berhasil disalin!');
    }, function(err) {
        console.error('Gagal menyalin tautan: ', err);
    });
}
</script>
<?= $this->endSection(); ?>