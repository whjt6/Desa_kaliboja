<?= $this->extend('layout/main_layout'); ?>

<?= $this->section('content'); ?>
<!-- Hero Section JDIH -->

<div class="container py-5">
    <!-- Pencarian -->
    <div class="row mb-5">
        <div class="col-lg-8 mx-auto">
            <div class="card shadow border-0" data-aos="zoom-in">
                <div class="card-body p-4">
                    <h4 class="card-title text-center mb-4">
                        <i class="fas fa-search text-primary me-2"></i>Cari Peraturan
                    </h4>
                    <form action="<?= site_url('jdih/search'); ?>" method="get" class="row g-3">
                        <div class="col-md-8">
                            <div class="input-group input-group-lg">
                                <span class="input-group-text bg-light border-end-0">
                                    <i class="fas fa-search text-muted"></i>
                                </span>
                                <input type="text" class="form-control border-start-0" name="q" 
                                       placeholder="Masukkan kata kunci peraturan..." 
                                       value="<?= esc($keyword ?? ''); ?>">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary btn-lg w-100">
                                <i class="fas fa-search me-2"></i>Cari
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Sidebar Kategori -->
        <div class="col-lg-3 mb-4" id="kategori">
            <div class="sticky-top" style="top: 100px;">
                <div class="card border-0 shadow-sm mb-4" data-aos="fade-right">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-filter me-2"></i>Filter</h5>
                    </div>
                    <div class="card-body">
                        <h6 class="text-primary mb-3"><i class="fas fa-list me-2"></i>Kategori</h6>
                        <div class="list-group list-group-flush">
                            <a href="<?= site_url('jdih'); ?>" 
                               class="list-group-item list-group-item-action d-flex justify-content-between align-items-center <?= !isset($kategori) ? 'active' : ''; ?>">
                                Semua Kategori
                                <span class="badge bg-primary rounded-pill"><?= count($peraturans); ?></span>
                            </a>
                            <?php foreach ($kategories as $kat): ?>
                            <a href="<?= site_url('jdih/kategori/' . $kat['id']); ?>" 
                               class="list-group-item list-group-item-action d-flex justify-content-between align-items-center <?= isset($kategori) && $kategori['id'] == $kat['id'] ? 'active' : ''; ?>">
                                <?= esc($kat['nama_kategori']); ?>
                                <span class="badge bg-primary rounded-pill"><?= count(array_filter($peraturans, function($p) use ($kat) { return $p['kategori_id'] == $kat['id']; })); ?></span>
                            </a>
                            <?php endforeach; ?>
                        </div>

                        <hr class="my-4">

                        <h6 class="text-primary mb-3"><i class="fas fa-calendar me-2"></i>Tahun</h6>
                        <div class="d-flex flex-wrap gap-2">
                            <?php foreach ($tahun as $th): ?>
                            <a href="<?= site_url('jdih/tahun/' . $th['tahun']); ?>" 
                               class="badge bg-light text-dark text-decoration-none p-2 border">
                                <?= esc($th['tahun']); ?>
                            </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <div class="card border-0 shadow-sm" data-aos="fade-right" data-aos-delay="100">
                    <div class="card-body text-center">
                        <i class="fas fa-file-pdf fa-3x text-danger mb-3"></i>
                        <h6 class="text-primary">Format Dokumen</h6>
                        <p class="small text-muted mb-0">Semua peraturan tersedia dalam format PDF yang mudah diunduh.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Daftar Peraturan -->
        <div class="col-lg-9" id="peraturan">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="section-title m-0" data-aos="fade-up">
                    <i class="fas fa-file-contract me-2"></i>Daftar Peraturan
                </h2>
                <div class="dropdown" data-aos="fade-up">
                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="fas fa-sort me-2"></i>Urutkan
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="?sort=terbaru">Terbaru</a></li>
                        <li><a class="dropdown-item" href="?sort=terlama">Terlama</a></li>
                        <li><a class="dropdown-item" href="?sort=a-z">A-Z</a></li>
                    </ul>
                </div>
            </div>

            <?php if (!empty($peraturans)): ?>
                <div class="row row-cols-1 row-cols-md-2 g-4">
                    <?php foreach ($peraturans as $p): ?>
                    <div class="col" data-aos="fade-up">
                        <div class="card product-card h-100">
                            <div class="product-image-container">
                                <div class="no-image d-flex flex-column align-items-center justify-content-center">
                                    <i class="fas fa-file-pdf fa-4x text-danger mb-3"></i>
                                    <span class="badge bg-primary position-absolute top-0 start-0 m-3">
                                        <?= esc($p['nama_kategori']); ?>
                                    </span>
                                    <span class="badge bg-success position-absolute top-0 end-0 m-3">
                                        <?= esc($p['tahun']); ?>
                                    </span>
                                </div>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title text-primary"><?= esc($p['jenis_peraturan']); ?></h5>
                                <p class="card-text text-muted small mb-2">
                                    No. <?= esc($p['nomor']); ?>/<?= esc($p['tahun']); ?>
                                </p>
                                <p class="card-text mb-3">
                                    <?= character_limiter(esc($p['tentang']), 120); ?>
                                </p>
                                
                                <div class="d-flex justify-content-between align-items-center">
                                    <small class="text-muted">
                                        <i class="fas fa-calendar-alt me-1"></i>
                                        <?= date('d M Y', strtotime($p['tanggal_ditetapkan'])); ?>
                                    </small>
                                    <div class="product-actions">
                                        <a href="<?= site_url('jdih/detail/' . $p['id']); ?>" 
                                           class="btn btn-sm btn-info me-1" title="Detail">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?= site_url('jdih/download/' . $p['id']); ?>" 
                                           class="btn btn-sm btn-success" title="Download">
                                            <i class="fas fa-download"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <!-- Pagination -->
                <nav aria-label="Page navigation" class="mt-5" data-aos="fade-up">
                    <ul class="pagination justify-content-center">
                        <li class="page-item disabled">
                            <a class="page-link" href="#" tabindex="-1">Previous</a>
                        </li>
                        <li class="page-item active"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item">
                            <a class="page-link" href="#">Next</a>
                        </li>
                    </ul>
                </nav>
            <?php else: ?>
                <div class="text-center py-5" data-aos="fade-up">
                    <i class="fas fa-file-alt fa-4x text-muted mb-4"></i>
                    <h4 class="text-muted">Belum ada peraturan tersedia</h4>
                    <p class="text-muted mb-4">Peraturan desa akan segera diunggah</p>
                    <a href="<?= site_url('jdih'); ?>" class="btn btn-primary">
                        <i class="fas fa-redo me-2"></i>Refresh
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Informasi Tambahan -->
<section class="bg-light py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 mb-4" data-aos="fade-up">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body text-center p-4">
                        <i class="fas fa-info-circle fa-3x text-primary mb-3"></i>
                        <h5 class="card-title">Apa itu JDIH?</h5>
                        <p class="card-text">
                            JDIH (Jaringan Dokumentasi dan Informasi Hukum) adalah sistem informasi hukum 
                            yang memudahkan masyarakat mengakses peraturan perundang-undangan.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 mb-4" data-aos="fade-up" data-aos-delay="100">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body text-center p-4">
                        <i class="fas fa-download fa-3x text-success mb-3"></i>
                        <h5 class="card-title">Download Gratis</h5>
                        <p class="card-text">
                            Semua dokumen peraturan dapat diunduh secara gratis dalam format PDF 
                            untuk keperluan studi atau referensi hukum.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 mb-4" data-aos="fade-up" data-aos-delay="200">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body text-center p-4">
                        <i class="fas fa-search fa-3x text-warning mb-3"></i>
                        <h5 class="card-title">Pencarian Mudah</h5>
                        <p class="card-text">
                            Temukan peraturan yang Anda cari dengan cepat menggunakan fitur pencarian 
                            dan filter berdasarkan kategori atau tahun.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?= $this->endSection(); ?>