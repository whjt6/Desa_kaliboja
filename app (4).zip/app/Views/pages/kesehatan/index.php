<?= $this->extend('layout/main_layout') ?>

<?= $this->section('content') ?>
<!-- Hero Section -->
<section class="hero-section py-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h1 class="display-4 fw-bold mb-4">Layanan Kesehatan Desa Kaliboja</h1>
                <p class="lead mb-4">Pelayanan kesehatan terpadu untuk ibu, anak, dan lansia di 4 dusun Desa Kaliboja.</p>
                <div class="d-flex flex-wrap gap-3">
                    <a href="#posyandu" class="btn btn-light btn-lg">
                        <i class="fas fa-baby me-2"></i>Posyandu
                    </a>
                    <a href="#posbindu" class="btn btn-light btn-lg">
                        <i class="fas fa-user-md me-2"></i>Posbindu Lansia
                    </a>
                    <a href="#dusun" class="btn btn-outline-light btn-lg">
                        <i class="fas fa-map-marker-alt me-2"></i>Data per Dusun
                    </a>
                </div>
            </div>
            <div class="col-lg-4 text-center">
                <div class="icon-hero">
                    <i class="fas fa-heartbeat fa-6x text-white opacity-75"></i>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Statistik Utama -->
<section class="py-5 bg-white">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body text-center p-5">
                        <div class="icon-stat mb-3">
                            <i class="fas fa-baby fa-3x text-primary"></i>
                        </div>
                        <h2 class="text-primary mb-2"><?= number_format($posyanduStatistik['total_balita'] ?? 0) ?></h2>
                        <h5 class="mb-3">Total Balita</h5>
                        <p class="text-muted mb-0">Dilayani di Posyandu 4 dusun</p>
                        <a href="#posyandu" class="btn btn-outline-primary mt-3">Lihat Detail Posyandu</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body text-center p-5">
                        <div class="icon-stat mb-3">
                            <i class="fas fa-user-md fa-3x text-success"></i>
                        </div>
                        <h2 class="text-success mb-2"><?= number_format($posbinduStatistik['total_lansia'] ?? 0) ?></h2>
                        <h5 class="mb-3">Total Lansia</h5>
                        <p class="text-muted mb-0">Dilayani di Posbindu 4 dusun</p>
                        <a href="#posbindu" class="btn btn-outline-success mt-3">Lihat Detail Posbindu</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Posyandu Section -->
<section id="posyandu" class="py-5 bg-light">
    <div class="container">
        <div class="row mb-5">
            <div class="col-lg-8 mx-auto text-center">
                <h2 class="section-title mb-3">Posyandu Desa Kaliboja</h2>
                <p class="lead text-muted mb-4">Pelayanan kesehatan ibu dan anak terpadu dengan fokus pada peningkatan gizi, imunisasi, dan pemantauan tumbuh kembang.</p>
            </div>
        </div>
        
        <div class="row g-4 mb-5">
            <!-- Statistik Posyandu -->
            <div class="col-md-4">
                <div class="stat-card">
                    <i class="fas fa-baby text-primary mb-3"></i>
                    <h3 class="counter" data-target="<?= $posyanduStatistik['total_balita'] ?? 0 ?>">0</h3>
                    <p class="mb-0 fw-bold">Total Balita</p>
                    <small class="text-muted">Tahun <?= $tahun ?></small>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <i class="fas fa-female text-primary mb-3"></i>
                    <h3 class="counter" data-target="<?= $posyanduStatistik['total_ibu_hamil'] ?? 0 ?>">0</h3>
                    <p class="mb-0 fw-bold">Ibu Hamil</p>
                    <small class="text-muted">Dalam perawatan</small>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <i class="fas fa-baby-carriage text-primary mb-3"></i>
                    <h3 class="counter" data-target="<?= $posyanduStatistik['total_kelahiran'] ?? 0 ?>">0</h3>
                    <p class="mb-0 fw-bold">Kelahiran</p>
                    <small class="text-muted">Tahun <?= $tahun ?></small>
                </div>
            </div>
        </div>
        
        <!-- Layanan Posyandu -->
        <div class="row g-4">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-primary text-white py-3">
                        <h4 class="mb-0"><i class="fas fa-list-alt me-2"></i>Layanan Posyandu</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="text-center mb-4">
                                    <div class="icon-service rounded-circle bg-primary-light text-primary d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                                        <i class="fas fa-weight fa-2x"></i>
                                    </div>
                                    <h6>Penimbangan Balita</h6>
                                    <p class="small text-muted">Pemantauan berat badan bulanan</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="text-center mb-4">
                                    <div class="icon-service rounded-circle bg-primary-light text-primary d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                                        <i class="fas fa-syringe fa-2x"></i>
                                    </div>
                                    <h6>Imunisasi</h6>
                                    <p class="small text-muted">Imunisasi dasar dan lanjutan</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="text-center mb-4">
                                    <div class="icon-service rounded-circle bg-primary-light text-primary d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                                        <i class="fas fa-pills fa-2x"></i>
                                    </div>
                                    <h6>Vitamin A</h6>
                                    <p class="small text-muted">Suplementasi vitamin A</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="text-center mb-4">
                                    <div class="icon-service rounded-circle bg-primary-light text-primary d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                                        <i class="fas fa-user-nurse fa-2x"></i>
                                    </div>
                                    <h6>Konseling Gizi</h6>
                                    <p class="small text-muted">Pendampingan gizi balita</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Posbindu Section -->
<section id="posbindu" class="py-5 bg-white">
    <div class="container">
        <div class="row mb-5">
            <div class="col-lg-8 mx-auto text-center">
                <h2 class="section-title mb-3">Posbindu Lansia Desa Kaliboja</h2>
                <p class="lead text-muted mb-4">Pemeriksaan kesehatan berkala untuk lansia dengan deteksi dini penyakit degeneratif seperti hipertensi, diabetes, dan obesitas.</p>
            </div>
        </div>
        
        <div class="row g-4 mb-5">
            <!-- Statistik Posbindu -->
            <div class="col-md-3">
                <div class="stat-card">
                    <i class="fas fa-user-md text-success mb-3"></i>
                    <h3 class="counter" data-target="<?= $posbinduStatistik['total_lansia'] ?? 0 ?>">0</h3>
                    <p class="mb-0 fw-bold">Total Lansia</p>
                    <small class="text-muted">Usia ≥60 tahun</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <i class="fas fa-heartbeat text-danger mb-3"></i>
                    <h3 class="counter" data-target="<?= $posbinduStatistik['total_hipertensi'] ?? 0 ?>">0</h3>
                    <p class="mb-0 fw-bold">Hipertensi</p>
                    <small class="text-muted">Tekanan darah tinggi</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <i class="fas fa-tint text-warning mb-3"></i>
                    <h3 class="counter" data-target="<?= $posbinduStatistik['total_diabetes'] ?? 0 ?>">0</h3>
                    <p class="mb-0 fw-bold">Diabetes</p>
                    <small class="text-muted">Gula darah tinggi</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <i class="fas fa-ambulance text-info mb-3"></i>
                    <h3 class="counter" data-target="<?= $posbinduStatistik['total_rujukan'] ?? 0 ?>">0</h3>
                    <p class="mb-0 fw-bold">Rujukan</p>
                    <small class="text-muted">Ke puskesmas/RS</small>
                </div>
            </div>
        </div>
        
        <!-- Pemeriksaan Posbindu -->
        <div class="row g-4">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-success text-white py-3">
                        <h4 class="mb-0"><i class="fas fa-stethoscope me-2"></i>Pemeriksaan di Posbindu</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4">
                                <ul class="list-unstyled">
                                    <li class="mb-3">
                                        <i class="fas fa-check-circle text-success me-2"></i>
                                        <strong>Tekanan Darah</strong>
                                        <p class="small text-muted mb-0">Deteksi dini hipertensi</p>
                                    </li>
                                    <li class="mb-3">
                                        <i class="fas fa-check-circle text-success me-2"></i>
                                        <strong>Gula Darah</strong>
                                        <p class="small text-muted mb-0">Skrining diabetes</p>
                                    </li>
                                    <li class="mb-3">
                                        <i class="fas fa-check-circle text-success me-2"></i>
                                        <strong>Berat & Tinggi Badan</strong>
                                        <p class="small text-muted mb-0">Perhitungan IMT</p>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-4">
                                <ul class="list-unstyled">
                                    <li class="mb-3">
                                        <i class="fas fa-check-circle text-success me-2"></i>
                                        <strong>Lingkar Perut</strong>
                                        <p class="small text-muted mb-0">Indikator obesitas sentral</p>
                                    </li>
                                    <li class="mb-3">
                                        <i class="fas fa-check-circle text-success me-2"></i>
                                        <strong>Pemeriksaan Urin</strong>
                                        <p class="small text-muted mb-0">Deteksi protein urin</p>
                                    </li>
                                    <li class="mb-3">
                                        <i class="fas fa-check-circle text-success me-2"></i>
                                        <strong>Konseling Gizi</strong>
                                        <p class="small text-muted mb-0">Pola makan sehat</p>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-4">
                                <div class="alert alert-info">
                                    <h6><i class="fas fa-info-circle me-2"></i>Jadwal Posbindu</h6>
                                    <p class="mb-1">Setiap bulan di setiap dusun:</p>
                                    <ul class="small mb-0">
                                        <li>Semboja Barat: Minggu ke-1</li>
                                        <li>Semboja Timur: Minggu ke-2</li>
                                        <li>Kaligenteng: Minggu ke-3</li>
                                        <li>Silemud: Minggu ke-4</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Data per Dusun -->
<section id="dusun" class="py-5 bg-light">
    <div class="container">
        <div class="row mb-5">
            <div class="col-lg-8 mx-auto text-center">
                <h2 class="section-title mb-3">Data Kesehatan per Dusun</h2>
                <p class="lead text-muted mb-4">Distribusi layanan kesehatan di 4 dusun Desa Kaliboja</p>
            </div>
        </div>
        
        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead class="bg-primary text-white">
                                    <tr>
                                        <th>Dusun</th>
                                        <th class="text-center">Balita</th>
                                        <th class="text-center">Ibu Hamil</th>
                                        <th class="text-center">Lansia</th>
                                        <th class="text-center">Hipertensi</th>
                                        <th class="text-center">Diabetes</th>
                                        <th class="text-center">Detail</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($dusunList as $key => $dusunName): ?>
                                    <?php 
                                    // Cari data posyandu untuk dusun ini
                                    $posyanduDusun = array_filter($posyanduByDusun, function($item) use ($key) {
                                        return $item['dusun'] === $key;
                                    });
                                    $posyanduData = !empty($posyanduDusun) ? array_values($posyanduDusun)[0] : null;
                                    
                                    // Cari data posbindu untuk dusun ini
                                    $posbinduDusun = array_filter($posbinduByDusun, function($item) use ($key) {
                                        return $item['dusun'] === $key;
                                    });
                                    $posbinduData = !empty($posbinduDusun) ? array_values($posbinduDusun)[0] : null;
                                    ?>
                                    <tr>
                                        <td><strong><?= $dusunName ?></strong></td>
                                        <td class="text-center"><?= number_format($posyanduData['total_balita'] ?? 0) ?></td>
                                        <td class="text-center"><?= number_format($posyanduData['total_ibu_hamil'] ?? 0) ?></td>
                                        <td class="text-center"><?= number_format($posbinduData['total_lansia'] ?? 0) ?></td>
                                        <td class="text-center"><?= number_format($posbinduData['total_hipertensi'] ?? 0) ?></td>
                                        <td class="text-center"><?= number_format($posbinduData['total_diabetes'] ?? 0) ?></td>
                                        <td class="text-center">
                                            <a href="<?= site_url('kesehatan/dusun/' . $key) ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-eye me-1"></i> Lihat
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                                <tfoot class="bg-light">
                                    <tr>
                                        <td><strong>TOTAL</strong></td>
                                        <td class="text-center"><strong><?= number_format($posyanduStatistik['total_balita'] ?? 0) ?></strong></td>
                                        <td class="text-center"><strong><?= number_format($posyanduStatistik['total_ibu_hamil'] ?? 0) ?></strong></td>
                                        <td class="text-center"><strong><?= number_format($posbinduStatistik['total_lansia'] ?? 0) ?></strong></td>
                                        <td class="text-center"><strong><?= number_format($posbinduStatistik['total_hipertensi'] ?? 0) ?></strong></td>
                                        <td class="text-center"><strong><?= number_format($posbinduStatistik['total_diabetes'] ?? 0) ?></strong></td>
                                        <td></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Informasi Kontak -->
        <div class="row mt-5">
            <div class="col-lg-8 mx-auto">
                <div class="card border-0 shadow-sm bg-primary text-white">
                    <div class="card-body text-center p-4">
                        <h4 class="mb-3"><i class="fas fa-phone-alt me-2"></i>Informasi & Kontak</h4>
                        <p class="mb-4">Untuk informasi lebih lanjut tentang jadwal dan pelayanan kesehatan, hubungi:</p>
                        <div class="row">
                            <div class="col-md-6">
                                <p class="mb-2">
                                    <i class="fas fa-user-nurse me-2"></i>
                                    <strong>Bidan Desa:</strong> 0812-3456-7890
                                </p>
                            </div>
                            <div class="col-md-6">
                                <p class="mb-2">
                                    <i class="fas fa-calendar-alt me-2"></i>
                                    <strong>Jadwal:</strong> Setiap bulan sesuai dusun
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?= $this->section('scripts') ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Counter animation
    function animateCounters() {
        document.querySelectorAll('.counter').forEach(counter => {
            const target = +counter.dataset.target || 0;
            if (target > 0) {
                let current = 0;
                const step = Math.max(1, Math.floor(target / 50));
                const timer = setInterval(() => {
                    current += step;
                    if (current >= target) {
                        current = target;
                        clearInterval(timer);
                    }
                    counter.textContent = current.toLocaleString('id-ID');
                }, 30);
            }
        });
    }
    
    setTimeout(animateCounters, 1000);
});
</script>
<?= $this->endSection() ?>
<?= $this->endSection() ?>