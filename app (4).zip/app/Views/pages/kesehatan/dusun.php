<?= $this->extend('layout/main_layout') ?>

<?= $this->section('content') ?>
<!-- Breadcrumb -->
<nav aria-label="breadcrumb" class="bg-light py-2">
    <div class="container">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="<?= site_url('/') ?>">Beranda</a></li>
            <li class="breadcrumb-item"><a href="<?= site_url('kesehatan') ?>">Kesehatan</a></li>
            <li class="breadcrumb-item active"><?= $dusunName ?></li>
        </ol>
    </div>
</nav>

<!-- Hero Section -->
<section class="py-5" style="background: linear-gradient(135deg, var(--primary), var(--primary-dark));">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h1 class="display-5 fw-bold text-white mb-3">Data Kesehatan Dusun <?= $dusunName ?></h1>
                <p class="lead text-white mb-4">Statistik kesehatan Posyandu dan Posbindu Tahun <?= $tahun ?></p>
                <div class="d-flex flex-wrap gap-2">
                    <span class="badge bg-light text-primary p-2">
                        <i class="fas fa-calendar-alt me-1"></i> Tahun <?= $tahun ?>
                    </span>
                    <span class="badge bg-light text-primary p-2">
                        <i class="fas fa-map-marker-alt me-1"></i> <?= $dusunName ?>
                    </span>
                    <span class="badge bg-light text-primary p-2">
                        <i class="fas fa-user-friends me-1"></i> Masyarakat
                    </span>
                </div>
            </div>
            <div class="col-lg-4 text-center">
                <div class="icon-hero">
                    <i class="fas fa-home fa-6x text-white opacity-75"></i>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Quick Stats -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row g-4">
            <!-- Statistik Posyandu -->
            <div class="col-md-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">
                            <i class="fas fa-baby me-2"></i>
                            Statistik Posyandu
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="row text-center">
                            <div class="col-6 mb-4">
                                <h2 class="text-primary"><?= number_format($posyanduStatistik['total_balita'] ?? 0) ?></h2>
                                <p class="mb-0 fw-bold">Balita</p>
                                <small class="text-muted">Usia 0-5 tahun</small>
                            </div>
                            <div class="col-6 mb-4">
                                <h2 class="text-success"><?= number_format($posyanduStatistik['total_ibu_hamil'] ?? 0) ?></h2>
                                <p class="mb-0 fw-bold">Ibu Hamil</p>
                                <small class="text-muted">Dalam perawatan</small>
                            </div>
                            <div class="col-6">
                                <h2 class="text-info"><?= number_format($posyanduStatistik['total_ibu_menyusui'] ?? 0) ?></h2>
                                <p class="mb-0 fw-bold">Ibu Menyusui</p>
                                <small class="text-muted">0-6 bulan</small>
                            </div>
                            <div class="col-6">
                                <h2 class="text-warning"><?= number_format($posyanduStatistik['total_kelahiran'] ?? 0) ?></h2>
                                <p class="mb-0 fw-bold">Kelahiran</p>
                                <small class="text-muted">Tahun <?= $tahun ?></small>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer bg-transparent">
                        <a href="#posyandu-detail" class="btn btn-outline-primary w-100">
                            <i class="fas fa-arrow-down me-2"></i>Lihat Detail Posyandu
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Statistik Posbindu -->
            <div class="col-md-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-success text-white">
                        <h4 class="mb-0">
                            <i class="fas fa-user-md me-2"></i>
                            Statistik Posbindu
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="row text-center">
                            <div class="col-6 mb-4">
                                <h2 class="text-success"><?= number_format($posbinduStatistik['total_lansia'] ?? 0) ?></h2>
                                <p class="mb-0 fw-bold">Lansia</p>
                                <small class="text-muted">Usia ≥60 tahun</small>
                            </div>
                            <div class="col-6 mb-4">
                                <h2 class="text-danger"><?= number_format($posbinduStatistik['total_hipertensi'] ?? 0) ?></h2>
                                <p class="mb-0 fw-bold">Hipertensi</p>
                                <small class="text-muted">Tekanan darah tinggi</small>
                            </div>
                            <div class="col-6">
                                <h2 class="text-warning"><?= number_format($posbinduStatistik['total_diabetes'] ?? 0) ?></h2>
                                <p class="mb-0 fw-bold">Diabetes</p>
                                <small class="text-muted">Gula darah tinggi</small>
                            </div>
                            <div class="col-6">
                                <h2 class="text-info"><?= number_format($posbinduStatistik['total_obesitas'] ?? 0) ?></h2>
                                <p class="mb-0 fw-bold">Obesitas</p>
                                <small class="text-muted">IMT ≥30</small>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer bg-transparent">
                        <a href="#posbindu-detail" class="btn btn-outline-success w-100">
                            <i class="fas fa-arrow-down me-2"></i>Lihat Detail Posbindu
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Detail Posyandu -->
<section id="posyandu-detail" class="py-5 bg-white">
    <div class="container">
        <div class="row mb-4">
            <div class="col-lg-12">
                <h2 class="section-title">
                    <i class="fas fa-baby me-2"></i>
                    Data Posyandu <?= $dusunName ?> Tahun <?= $tahun ?>
                </h2>
                <p class="text-muted">Rekap data bulanan Posyandu</p>
            </div>
        </div>
        
        <?php if(empty($posyanduData)): ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    Belum ada data Posyandu untuk Dusun <?= $dusunName ?> Tahun <?= $tahun ?>
                </div>
            </div>
        </div>
        <?php else: ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead class="bg-primary text-white">
                                    <tr>
                                        <th>Bulan</th>
                                        <th class="text-center">Balita L</th>
                                        <th class="text-center">Balita P</th>
                                        <th class="text-center">Total Balita</th>
                                        <th class="text-center">Ibu Hamil</th>
                                        <th class="text-center">Ibu Menyusui</th>
                                        <th class="text-center">Kelahiran</th>
                                        <th class="text-center">Imunisasi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($posyanduData as $data): ?>
                                    <tr>
                                        <td>
                                            <?= date('F Y', strtotime($data['bulan'] . '-01')) ?>
                                        </td>
                                        <td class="text-center"><?= number_format($data['jumlah_balita_l']) ?></td>
                                        <td class="text-center"><?= number_format($data['jumlah_balita_p']) ?></td>
                                        <td class="text-center">
                                            <strong><?= number_format($data['jumlah_balita_l'] + $data['jumlah_balita_p']) ?></strong>
                                        </td>
                                        <td class="text-center"><?= number_format($data['jumlah_ibu_hamil']) ?></td>
                                        <td class="text-center"><?= number_format($data['jumlah_ibu_menyusui']) ?></td>
                                        <td class="text-center">
                                            <?= number_format($data['kelahiran_l'] + $data['kelahiran_p']) ?><br>
                                            <small class="text-muted">L:<?= $data['kelahiran_l'] ?> P:<?= $data['kelahiran_p'] ?></small>
                                        </td>
                                        <td class="text-center">
                                            <?= number_format($data['imunisasi_dasar_lengkap']) ?>
                                            <?php 
                                            $totalBalita = $data['jumlah_balita_l'] + $data['jumlah_balita_p'];
                                            if($totalBalita > 0):
                                            ?>
                                            <br>
                                            <small class="text-muted">
                                                <?= round($data['imunisasi_dasar_lengkap'] / $totalBalita * 100, 1) ?>%
                                            </small>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Grafik Trend (placeholder) -->
        <div class="row mt-4">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">
                            <i class="fas fa-chart-line me-2"></i>
                            Trend Bulanan Posyandu <?= $dusunName ?>
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            Fitur grafik visualisasi data akan segera tersedia. Untuk saat ini data dapat dilihat dalam bentuk tabel di atas.
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- Detail Posbindu -->
<section id="posbindu-detail" class="py-5 bg-light">
    <div class="container">
        <div class="row mb-4">
            <div class="col-lg-12">
                <h2 class="section-title">
                    <i class="fas fa-user-md me-2"></i>
                    Data Posbindu <?= $dusunName ?> Tahun <?= $tahun ?>
                </h2>
                <p class="text-muted">Rekap data bulanan pemeriksaan lansia</p>
            </div>
        </div>
        
        <?php if(empty($posbinduData)): ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    Belum ada data Posbindu untuk Dusun <?= $dusunName ?> Tahun <?= $tahun ?>
                </div>
            </div>
        </div>
        <?php else: ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead class="bg-success text-white">
                                    <tr>
                                        <th>Bulan</th>
                                        <th class="text-center">Lansia L</th>
                                        <th class="text-center">Lansia P</th>
                                        <th class="text-center">Total Lansia</th>
                                        <th class="text-center">Hipertensi</th>
                                        <th class="text-center">Diabetes</th>
                                        <th class="text-center">Obesitas</th>
                                        <th class="text-center">Rujukan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($posbinduData as $data): ?>
                                    <tr>
                                        <td>
                                            <?= date('F Y', strtotime($data['bulan'] . '-01')) ?>
                                        </td>
                                        <td class="text-center"><?= number_format($data['jumlah_lansia_l']) ?></td>
                                        <td class="text-center"><?= number_format($data['jumlah_lansia_p']) ?></td>
                                        <td class="text-center">
                                            <strong><?= number_format($data['jumlah_lansia_total']) ?></strong>
                                        </td>
                                        <td class="text-center">
                                            <?php 
                                            $hipertensi = $data['tekanan_darah_tingkat2'] + $data['tekanan_darah_tingkat3'];
                                            echo number_format($hipertensi);
                                            ?>
                                            <?php if($data['jumlah_lansia_total'] > 0): ?>
                                            <br>
                                            <small class="text-muted">
                                                <?= round($hipertensi / $data['jumlah_lansia_total'] * 100, 1) ?>%
                                            </small>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <?= number_format($data['gula_darah_diabetes']) ?>
                                            <?php if($data['jumlah_lansia_total'] > 0): ?>
                                            <br>
                                            <small class="text-muted">
                                                <?= round($data['gula_darah_diabetes'] / $data['jumlah_lansia_total'] * 100, 1) ?>%
                                            </small>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <?= number_format($data['imt_obesitas']) ?>
                                            <?php if($data['jumlah_lansia_total'] > 0): ?>
                                            <br>
                                            <small class="text-muted">
                                                <?= round($data['imt_obesitas'] / $data['jumlah_lansia_total'] * 100, 1) ?>%
                                            </small>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge <?= $data['jumlah_rujukan'] > 0 ? 'badge-danger' : 'badge-success' ?>">
                                                <?= number_format($data['jumlah_rujukan']) ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- Informasi Dusun -->
<section class="py-5 bg-white">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">
                            <i class="fas fa-info-circle me-2"></i>
                            Informasi Layanan Kesehatan <?= $dusunName ?>
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h6><i class="fas fa-baby me-2 text-primary"></i>Posyandu</h6>
                                <p class="small mb-3">
                                    <strong>Jadwal:</strong> Minggu ke-<?= $dusun == 'semboja_barat' ? '1' : ($dusun == 'semboja_timur' ? '2' : ($dusun == 'kaligenteng' ? '3' : '4')) ?> setiap bulan<br>
                                    <strong>Waktu:</strong> 08:00 - 12:00 WIB<br>
                                    <strong>Lokasi:</strong> Balai Dusun <?= $dusunName ?><br>
                                    <strong>Penanggung Jawab:</strong> Kader Posyandu <?= $dusunName ?>
                                </p>
                            </div>
                            <div class="col-md-6">
                                <h6><i class="fas fa-user-md me-2 text-success"></i>Posbindu Lansia</h6>
                                <p class="small mb-3">
                                    <strong>Jadwal:</strong> Minggu ke-<?= $dusun == 'semboja_barat' ? '1' : ($dusun == 'semboja_timur' ? '2' : ($dusun == 'kaligenteng' ? '3' : '4')) ?> setiap bulan<br>
                                    <strong>Waktu:</strong> 08:00 - 12:00 WIB<br>
                                    <strong>Lokasi:</strong> Balai Dusun <?= $dusunName ?><br>
                                    <strong>Penanggung Jawab:</strong> Kader Kesehatan <?= $dusunName ?>
                                </p>
                            </div>
                        </div>
                        
                        <div class="alert alert-warning mt-3">
                            <h6><i class="fas fa-exclamation-triangle me-2"></i>Catatan Penting:</h6>
                            <ul class="small mb-0">
                                <li>Bawa buku KIA/KMS untuk balita dan buku KMS lansia</li>
                                <li>Pelayanan diberikan secara gratis</li>
                                <li>Imunisasi hanya diberikan pada jadwal yang ditentukan</li>
                                <li>Untuk informasi lebih lanjut, hubungi kader kesehatan setempat</li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-footer bg-transparent">
                        <div class="d-flex justify-content-between">
                            <a href="<?= site_url('kesehatan') ?>" class="btn btn-outline-secondary">
                                <i class="fas fa-arrow-left me-2"></i>Kembali ke Kesehatan
                            </a>
                            <a href="<?= site_url('/') ?>" class="btn btn-primary">
                                <i class="fas fa-home me-2"></i>Beranda
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?= $this->endSection() ?>