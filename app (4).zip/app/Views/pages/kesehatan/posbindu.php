<?= $this->extend('layout/main_layout') ?>

<?= $this->section('content') ?>
<!-- Hero Section -->
<section class="hero-section py-5" style="background: linear-gradient(135deg, #28a745, #1e7e34);">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h1 class="display-5 fw-bold text-white mb-3">Posbindu Lansia Desa Kaliboja</h1>
                <p class="lead text-white mb-4">Pemeriksaan kesehatan berkala untuk lansia usia ≥60 tahun.</p>
                <div class="d-flex flex-wrap gap-2">
                    <span class="badge bg-light text-success p-2">
                        <i class="fas fa-calendar-alt me-1"></i> Setiap bulan
                    </span>
                    <span class="badge bg-light text-success p-2">
                        <i class="fas fa-map-marker-alt me-1"></i> 4 dusun
                    </span>
                    <span class="badge bg-light text-success p-2">
                        <i class="fas fa-user-md me-1"></i> Gratis
                    </span>
                    <span class="badge bg-light text-success p-2">
                        <i class="fas fa-heartbeat me-1"></i> Deteksi dini
                    </span>
                </div>
            </div>
            <div class="col-lg-4 text-center">
                <div class="icon-hero">
                    <i class="fas fa-user-md fa-6x text-white opacity-75"></i>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Filter -->
<section class="py-4 bg-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <form method="get" class="row g-3 align-items-end">
                            <div class="col-md-8">
                                <label class="form-label">Lihat data tahun:</label>
                                <div class="input-group">
                                    <input type="number" name="tahun" class="form-control" 
                                           value="<?= $tahun ?>" min="2020" max="<?= date('Y') ?>">
                                    <button type="submit" class="btn btn-success">
                                        <i class="fas fa-search me-2"></i>Lihat
                                    </button>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <a href="<?= site_url('kesehatan') ?>" class="btn btn-outline-secondary w-100">
                                    <i class="fas fa-arrow-left me-2"></i>Kembali
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Statistik Utama -->
<section class="py-5 bg-white">
    <div class="container">
        <h2 class="section-title text-center mb-5">Statistik Posbindu Tahun <?= $tahun ?></h2>
        
        <div class="row g-4 mb-5">
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <i class="fas fa-user-md text-success mb-3 fa-3x"></i>
                    <h2 class="text-success mb-2"><?= number_format($statistik['total_lansia'] ?? 0) ?></h2>
                    <h5>Total Lansia</h5>
                    <p class="text-muted mb-0">Usia ≥60 tahun</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <i class="fas fa-heartbeat text-danger mb-3 fa-3x"></i>
                    <h2 class="text-danger mb-2"><?= number_format($statistik['total_hipertensi'] ?? 0) ?></h2>
                    <h5>Hipertensi</h5>
                    <p class="text-muted mb-0">Tekanan darah tinggi</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <i class="fas fa-tint text-warning mb-3 fa-3x"></i>
                    <h2 class="text-warning mb-2"><?= number_format($statistik['total_diabetes'] ?? 0) ?></h2>
                    <h5>Diabetes</h5>
                    <p class="text-muted mb-0">Gula darah tinggi</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <i class="fas fa-ambulance text-info mb-3 fa-3x"></i>
                    <h2 class="text-info mb-2"><?= number_format($statistik['total_rujukan'] ?? 0) ?></h2>
                    <h5>Rujukan</h5>
                    <p class="text-muted mb-0">Ke puskesmas/RS</p>
                </div>
            </div>
        </div>
        
        <!-- Distribusi Risiko -->
        <div class="row mb-5">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-success text-white">
                        <h4 class="mb-0">
                            <i class="fas fa-chart-pie me-2"></i>
                            Distribusi Risiko Kesehatan Lansia
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead class="bg-light">
                                            <tr>
                                                <th>Parameter Kesehatan</th>
                                                <th class="text-center">Normal</th>
                                                <th class="text-center">Berisiko</th>
                                                <th class="text-center">Persentase</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Tekanan Darah</td>
                                                <td class="text-center"><?= number_format($riskDistribution['tekanan_normal'] ?? 0) ?></td>
                                                <td class="text-center"><?= number_format($riskDistribution['tekanan_tinggi'] ?? 0) ?></td>
                                                <td class="text-center">
                                                    <?php 
                                                    $totalTekanan = ($riskDistribution['tekanan_normal'] ?? 0) + ($riskDistribution['tekanan_tinggi'] ?? 0);
                                                    $percent = $totalTekanan > 0 ? round(($riskDistribution['tekanan_tinggi'] ?? 0) / $totalTekanan * 100, 1) : 0;
                                                    ?>
                                                    <span class="badge <?= $percent > 30 ? 'bg-danger' : ($percent > 20 ? 'bg-warning' : 'bg-success') ?>">
                                                        <?= $percent ?>%
                                                    </span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Gula Darah</td>
                                                <td class="text-center"><?= number_format($riskDistribution['gula_normal'] ?? 0) ?></td>
                                                <td class="text-center"><?= number_format($riskDistribution['gula_tinggi'] ?? 0) ?></td>
                                                <td class="text-center">
                                                    <?php 
                                                    $totalGula = ($riskDistribution['gula_normal'] ?? 0) + ($riskDistribution['gula_tinggi'] ?? 0);
                                                    $percent = $totalGula > 0 ? round(($riskDistribution['gula_tinggi'] ?? 0) / $totalGula * 100, 1) : 0;
                                                    ?>
                                                    <span class="badge <?= $percent > 20 ? 'bg-danger' : ($percent > 10 ? 'bg-warning' : 'bg-success') ?>">
                                                        <?= $percent ?>%
                                                    </span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Indeks Massa Tubuh</td>
                                                <td class="text-center"><?= number_format($riskDistribution['imt_normal'] ?? 0) ?></td>
                                                <td class="text-center"><?= number_format($riskDistribution['imt_tidak_normal'] ?? 0) ?></td>
                                                <td class="text-center">
                                                    <?php 
                                                    $totalIMT = ($riskDistribution['imt_normal'] ?? 0) + ($riskDistribution['imt_tidak_normal'] ?? 0);
                                                    $percent = $totalIMT > 0 ? round(($riskDistribution['imt_tidak_normal'] ?? 0) / $totalIMT * 100, 1) : 0;
                                                    ?>
                                                    <span class="badge <?= $percent > 40 ? 'bg-danger' : ($percent > 30 ? 'bg-warning' : 'bg-success') ?>">
                                                        <?= $percent ?>%
                                                    </span>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="alert alert-info h-100">
                                    <h6><i class="fas fa-info-circle me-2"></i>Interpretasi Data</h6>
                                    <p class="small mb-2">
                                        <span class="badge bg-success me-1">Hijau</span> Risiko rendah (&lt;20%)
                                    </p>
                                    <p class="small mb-2">
                                        <span class="badge bg-warning me-1">Kuning</span> Risiko sedang (20-30%)
                                    </p>
                                    <p class="small mb-2">
                                        <span class="badge bg-danger me-1">Merah</span> Risiko tinggi (&gt;30%)
                                    </p>
                                    <hr>
                                    <p class="small mb-0">
                                        Data ini membantu dalam perencanaan intervensi kesehatan lansia di desa.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Data per Dusun -->
        <div class="row mb-5">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-success text-white">
                        <h4 class="mb-0">
                            <i class="fas fa-map-marked-alt me-2"></i>
                            Data per Dusun
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead class="bg-light">
                                    <tr>
                                        <th>Dusun</th>
                                        <th class="text-center">Total Lansia</th>
                                        <th class="text-center">Hipertensi</th>
                                        <th class="text-center">Diabetes</th>
                                        <th class="text-center">Obesitas</th>
                                        <th class="text-center">Rujukan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(empty($statistikDusun)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-4 text-muted">
                                            <i class="fas fa-database fa-2x mb-3"></i><br>
                                            Belum ada data untuk tahun <?= $tahun ?>
                                        </td>
                                    </tr>
                                    <?php else: ?>
                                    <?php foreach($statistikDusun as $data): ?>
                                    <tr>
                                        <td>
                                            <?php 
                                            $dusunNames = [
                                                'semboja_barat' => 'Semboja Barat',
                                                'semboja_timur' => 'Semboja Timur',
                                                'kaligenteng' => 'Kaligenteng',
                                                'silemud' => 'Silemud'
                                            ];
                                            echo $dusunNames[$data['dusun']] ?? $data['dusun'];
                                            ?>
                                        </td>
                                        <td class="text-center"><?= number_format($data['total_lansia']) ?></td>
                                        <td class="text-center">
                                            <?= number_format($data['total_hipertensi']) ?>
                                            <?php if($data['total_lansia'] > 0): ?>
                                            <br>
                                            <small class="text-muted">
                                                (<?= round($data['total_hipertensi'] / $data['total_lansia'] * 100, 1) ?>%)
                                            </small>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <?= number_format($data['total_diabetes']) ?>
                                            <?php if($data['total_lansia'] > 0): ?>
                                            <br>
                                            <small class="text-muted">
                                                (<?= round($data['total_diabetes'] / $data['total_lansia'] * 100, 1) ?>%)
                                            </small>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <?= number_format($data['total_obesitas'] ?? 0) ?>
                                            <?php if($data['total_lansia'] > 0): ?>
                                            <br>
                                            <small class="text-muted">
                                                (<?= round(($data['total_obesitas'] ?? 0) / $data['total_lansia'] * 100, 1) ?>%)
                                            </small>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge <?= ($data['total_rujukan'] ?? 0) > 0 ? 'badge-danger' : 'badge-success' ?>">
                                                <?= number_format($data['total_rujukan'] ?? 0) ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Layanan dan Pemeriksaan -->
        <div class="row">
            <div class="col-lg-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">
                            <i class="fas fa-stethoscope me-2"></i>
                            Pemeriksaan di Posbindu
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <ul class="list-unstyled">
                                    <li class="mb-3">
                                        <i class="fas fa-check text-success me-2"></i>
                                        <strong>Tekanan Darah</strong>
                                        <p class="small text-muted mb-0">Deteksi hipertensi</p>
                                    </li>
                                    <li class="mb-3">
                                        <i class="fas fa-check text-success me-2"></i>
                                        <strong>Gula Darah</strong>
                                        <p class="small text-muted mb-0">Skrining diabetes</p>
                                    </li>
                                    <li class="mb-3">
                                        <i class="fas fa-check text-success me-2"></i>
                                        <strong>Berat Badan</strong>
                                        <p class="small text-muted mb-0">Pengukuran berat</p>
                                    </li>
                                    <li class="mb-3">
                                        <i class="fas fa-check text-success me-2"></i>
                                        <strong>Tinggi Badan</strong>
                                        <p class="small text-muted mb-0">Pengukuran tinggi</p>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <ul class="list-unstyled">
                                    <li class="mb-3">
                                        <i class="fas fa-check text-success me-2"></i>
                                        <strong>Lingkar Perut</strong>
                                        <p class="small text-muted mb-0">Indikator obesitas</p>
                                    </li>
                                    <li class="mb-3">
                                        <i class="fas fa-check text-success me-2"></i>
                                        <strong>Pemeriksaan Urin</strong>
                                        <p class="small text-muted mb-0">Deteksi protein</p>
                                    </li>
                                    <li class="mb-3">
                                        <i class="fas fa-check text-success me-2"></i>
                                        <strong>Konseling Gizi</strong>
                                        <p class="small text-muted mb-0">Pola makan sehat</p>
                                    </li>
                                    <li class="mb-3">
                                        <i class="fas fa-check text-success me-2"></i>
                                        <strong>Edukasi Kesehatan</strong>
                                        <p class="small text-muted mb-0">Pencegahan penyakit</p>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-warning text-white">
                        <h4 class="mb-0">
                            <i class="fas fa-calendar-check me-2"></i>
                            Jadwal Posbindu
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="list-group list-group-flush">
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1 text-success">Semboja Barat</h6>
                                        <small class="text-muted">Minggu ke-1 setiap bulan</small><br>
                                        <small><i class="fas fa-clock me-1"></i> 08:00 - 12:00 WIB</small>
                                    </div>
                                    <span class="badge bg-success">Aktif</span>
                                </div>
                            </div>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1 text-success">Semboja Timur</h6>
                                        <small class="text-muted">Minggu ke-2 setiap bulan</small><br>
                                        <small><i class="fas fa-clock me-1"></i> 08:00 - 12:00 WIB</small>
                                    </div>
                                    <span class="badge bg-success">Aktif</span>
                                </div>
                            </div>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1 text-success">Kaligenteng</h6>
                                        <small class="text-muted">Minggu ke-3 setiap bulan</small><br>
                                        <small><i class="fas fa-clock me-1"></i> 08:00 - 12:00 WIB</small>
                                    </div>
                                    <span class="badge bg-success">Aktif</span>
                                </div>
                            </div>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1 text-success">Silemud</h6>
                                        <small class="text-muted">Minggu ke-4 setiap bulan</small><br>
                                        <small><i class="fas fa-clock me-1"></i> 08:00 - 12:00 WIB</small>
                                    </div>
                                    <span class="badge bg-success">Aktif</span>
                                </div>
                            </div>
                        </div>
                        <div class="alert alert-info mt-3 mb-0">
                            <p class="small mb-0">
                                <i class="fas fa-info-circle me-2"></i>
                                Bawa buku KMS lansia atau catatan kesehatan pribadi saat berkunjung ke Posbindu.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Tips Kesehatan Lansia -->
<section class="py-5 bg-light">
    <div class="container">
        <h2 class="section-title text-center mb-5">Tips Kesehatan untuk Lansia</h2>
        
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body text-center p-4">
                        <div class="icon-tips mb-3">
                            <i class="fas fa-utensils fa-3x text-primary"></i>
                        </div>
                        <h5 class="mb-3">Pola Makan Sehat</h5>
                        <p class="text-muted">
                            Konsumsi makanan bergizi seimbang, rendah garam, rendah gula, dan tinggi serat.
                            Perbanyak sayur, buah, dan protein.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body text-center p-4">
                        <div class="icon-tips mb-3">
                            <i class="fas fa-walking fa-3x text-success"></i>
                        </div>
                        <h5 class="mb-3">Aktif Bergerak</h5>
                        <p class="text-muted">
                            Lakukan aktivitas fisik ringan secara rutin seperti jalan kaki 30 menit sehari.
                            Hindari duduk atau berbaring terlalu lama.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body text-center p-4">
                        <div class="icon-tips mb-3">
                            <i class="fas fa-pills fa-3x text-warning"></i>
                        </div>
                        <h5 class="mb-3">Patuh Minum Obat</h5>
                        <p class="text-muted">
                            Minum obat sesuai anjuran dokter jika memiliki penyakit kronis.
                            Jangan menghentikan obat tanpa konsultasi dokter.
                        </p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row mt-4">
            <div class="col-lg-8 mx-auto">
                <div class="alert alert-warning">
                    <h6><i class="fas fa-exclamation-triangle me-2"></i>Peringatan:</h6>
                    <p class="mb-0 small">
                        Segera periksakan diri ke puskesmas atau dokter jika mengalami gejala seperti: nyeri dada, sesak napas mendadak, 
                        kelemahan tubuh separuh, bicara pelo, atau penurunan kesadaran.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<?= $this->endSection() ?>