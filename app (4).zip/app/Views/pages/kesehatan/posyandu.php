<?= $this->extend('layout/main_layout') ?>

<?= $this->section('content') ?>
<!-- Hero Section -->
<section class="hero-section py-5" style="background: linear-gradient(135deg, var(--primary), var(--primary-dark));">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h1 class="display-5 fw-bold text-white mb-3">Posyandu Desa Kaliboja</h1>
                <p class="lead text-white mb-4">Pelayanan kesehatan terpadu untuk ibu dan anak usia 0-5 tahun.</p>
                <div class="d-flex flex-wrap gap-2">
                    <span class="badge bg-light text-primary p-2">
                        <i class="fas fa-calendar-alt me-1"></i> Setiap bulan
                    </span>
                    <span class="badge bg-light text-primary p-2">
                        <i class="fas fa-map-marker-alt me-1"></i> 4 dusun
                    </span>
                    <span class="badge bg-light text-primary p-2">
                        <i class="fas fa-users me-1"></i> Gratis
                    </span>
                </div>
            </div>
            <div class="col-lg-4 text-center">
                <div class="icon-hero">
                    <i class="fas fa-baby fa-6x text-white opacity-75"></i>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Filter -->
<section class="py-4 bg-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <form method="get" class="row g-3 align-items-end">
                            <div class="col-md-8">
                                <label class="form-label">Lihat data tahun:</label>
                                <div class="input-group">
                                    <input type="number" name="tahun" class="form-control" 
                                           value="<?= $tahun ?>" min="2020" max="<?= date('Y') ?>">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-search me-2"></i>Lihat
                                    </button>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <a href="<?= site_url('kesehatan') ?>" class="btn btn-outline-secondary w-100">
                                    <i class="fas fa-arrow-left me-2"></i>Kembali
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Statistik Utama -->
<section class="py-5 bg-white">
    <div class="container">
        <h2 class="section-title text-center mb-5">Statistik Posyandu Tahun <?= $tahun ?></h2>
        
        <div class="row g-4 mb-5">
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <i class="fas fa-baby text-primary mb-3 fa-3x"></i>
                    <h2 class="text-primary mb-2"><?= number_format($statistik['total_balita'] ?? 0) ?></h2>
                    <h5>Total Balita</h5>
                    <p class="text-muted mb-0">Usia 0-5 tahun</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <i class="fas fa-female text-success mb-3 fa-3x"></i>
                    <h2 class="text-success mb-2"><?= number_format($statistik['total_ibu_hamil'] ?? 0) ?></h2>
                    <h5>Ibu Hamil</h5>
                    <p class="text-muted mb-0">Dalam perawatan</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <i class="fas fa-child text-info mb-3 fa-3x"></i>
                    <h2 class="text-info mb-2"><?= number_format($statistik['total_ibu_menyusui'] ?? 0) ?></h2>
                    <h5>Ibu Menyusui</h5>
                    <p class="text-muted mb-0">0-6 bulan</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <i class="fas fa-baby-carriage text-warning mb-3 fa-3x"></i>
                    <h2 class="text-warning mb-2"><?= number_format($statistik['total_kelahiran'] ?? 0) ?></h2>
                    <h5>Kelahiran</h5>
                    <p class="text-muted mb-0">Tahun <?= $tahun ?></p>
                </div>
            </div>
        </div>
        
        <!-- Data per Dusun -->
        <div class="row mb-5">
            <div class="col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">
                            <i class="fas fa-chart-bar me-2"></i>
                            Distribusi Data per Dusun
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead class="bg-light">
                                    <tr>
                                        <th>Dusun</th>
                                        <th class="text-center">Balita</th>
                                        <th class="text-center">Ibu Hamil</th>
                                        <th class="text-center">Ibu Menyusui</th>
                                        <th class="text-center">Kelahiran</th>
                                        <th class="text-center">Imunisasi Lengkap</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(empty($statistikDusun)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-4 text-muted">
                                            <i class="fas fa-database fa-2x mb-3"></i><br>
                                            Belum ada data untuk tahun <?= $tahun ?>
                                        </td>
                                    </tr>
                                    <?php else: ?>
                                    <?php foreach($statistikDusun as $data): ?>
                                    <tr>
                                        <td>
                                            <?php 
                                            $dusunNames = [
                                                'semboja_barat' => 'Semboja Barat',
                                                'semboja_timur' => 'Semboja Timur',
                                                'kaligenteng' => 'Kaligenteng',
                                                'silemud' => 'Silemud'
                                            ];
                                            echo $dusunNames[$data['dusun']] ?? $data['dusun'];
                                            ?>
                                        </td>
                                        <td class="text-center"><?= number_format($data['total_balita']) ?></td>
                                        <td class="text-center"><?= number_format($data['total_ibu_hamil']) ?></td>
                                        <td class="text-center"><?= number_format($data['total_ibu_menyusui'] ?? 0) ?></td>
                                        <td class="text-center"><?= number_format($data['total_kelahiran']) ?></td>
                                        <td class="text-center">
                                            <?= number_format($data['total_imunisasi']) ?>
                                            <?php if($data['total_balita'] > 0): ?>
                                            <br>
                                            <small class="text-muted">
                                                (<?= round($data['total_imunisasi'] / $data['total_balita'] * 100, 1) ?>%)
                                            </small>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Jadwal dan Layanan -->
        <div class="row">
            <div class="col-lg-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-info text-white">
                        <h4 class="mb-0">
                            <i class="fas fa-calendar-alt me-2"></i>
                            Jadwal Posyandu
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="list-group list-group-flush">
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1">Semboja Barat</h6>
                                        <small class="text-muted">Minggu ke-1 setiap bulan</small>
                                    </div>
                                    <span class="badge bg-primary">08:00 - 12:00</span>
                                </div>
                            </div>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1">Semboja Timur</h6>
                                        <small class="text-muted">Minggu ke-2 setiap bulan</small>
                                    </div>
                                    <span class="badge bg-primary">08:00 - 12:00</span>
                                </div>
                            </div>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1">Kaligenteng</h6>
                                        <small class="text-muted">Minggu ke-3 setiap bulan</small>
                                    </div>
                                    <span class="badge bg-primary">08:00 - 12:00</span>
                                </div>
                            </div>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1">Silemud</h6>
                                        <small class="text-muted">Minggu ke-4 setiap bulan</small>
                                    </div>
                                    <span class="badge bg-primary">08:00 - 12:00</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-success text-white">
                        <h4 class="mb-0">
                            <i class="fas fa-hand-holding-medical me-2"></i>
                            Layanan yang Diberikan
                        </h4>
                    </div>
                    <div class="card-body">
                        <ul class="list-unstyled">
                            <li class="mb-3">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                <strong>Penimbangan Balita</strong>
                                <p class="small text-muted mb-0">Pemantauan berat badan dan tinggi badan bulanan</p>
                            </li>
                            <li class="mb-3">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                <strong>Imunisasi</strong>
                                <p class="small text-muted mb-0">BCG, DPT, Polio, Campak, Hepatitis B</p>
                            </li>
                            <li class="mb-3">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                <strong>Vitamin A</strong>
                                <p class="small text-muted mb-0">Suplementasi vitamin A setiap Februari dan Agustus</p>
                            </li>
                            <li class="mb-3">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                <strong>Konseling Gizi</strong>
                                <p class="small text-muted mb-0">Pendampingan gizi untuk balita dan ibu hamil</p>
                            </li>
                            <li class="mb-3">
                                <i class="fas fa-check-circle text-success me-2"></i>
                                <strong>Pemeriksaan Ibu Hamil</strong>
                                <p class="small text-muted mb-0">Pemantauan kesehatan ibu dan janin</p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Informasi Penting -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <h4 class="mb-3 text-primary">
                            <i class="fas fa-info-circle me-2"></i>
                            Informasi Penting
                        </h4>
                        <p class="mb-4">Posyandu merupakan layanan kesehatan dasar yang sangat penting untuk memantau tumbuh kembang anak. Kehadiran rutin di Posyandu dapat membantu:</p>
                        
                        <div class="row text-start">
                            <div class="col-md-6">
                                <ul class="list-unstyled">
                                    <li class="mb-2">
                                        <i class="fas fa-arrow-right text-primary me-2"></i>
                                        Deteksi dini gangguan pertumbuhan
                                    </li>
                                    <li class="mb-2">
                                        <i class="fas fa-arrow-right text-primary me-2"></i>
                                        Pencegahan penyakit melalui imunisasi
                                    </li>
                                    <li class="mb-2">
                                        <i class="fas fa-arrow-right text-primary me-2"></i>
                                        Edukasi gizi untuk orang tua
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <ul class="list-unstyled">
                                    <li class="mb-2">
                                        <i class="fas fa-arrow-right text-primary me-2"></i>
                                        Pemantauan kesehatan ibu hamil
                                    </li>
                                    <li class="mb-2">
                                        <i class="fas fa-arrow-right text-primary me-2"></i>
                                        Rujukan ke puskesmas jika diperlukan
                                    </li>
                                    <li class="mb-2">
                                        <i class="fas fa-arrow-right text-primary me-2"></i>
                                        Pencatatan kesehatan terpadu
                                    </li>
                                </ul>
                            </div>
                        </div>
                        
                        <div class="alert alert-warning mt-4">
                            <h6><i class="fas fa-exclamation-triangle me-2"></i>Catatan:</h6>
                            <p class="mb-0 small">
                                Bawa buku KIA/KMS setiap ke Posyandu. Imunisasi dasar lengkap sangat penting untuk melindungi anak dari penyakit berbahaya.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?= $this->endSection() ?>