<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login Admin | Website Desa</title>
  <link rel="icon" href="/img/logo.png" type="image/png">

  <!-- Google Font: Poppins -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
  
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
  <!-- Theme style -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">

  <style>
  html, body {
    height: 100%;
    margin: 0;
    padding: 0;
  }

  body.login-page {
    font-family: 'Poppins', sans-serif;
    background-image:
      linear-gradient(
        rgba(0, 0, 0, 0.35),
        rgba(0, 0, 0, 0.35)
      ),
      url('/img/bg-desa.jpg');
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    background-attachment: fixed; /* Agar background tetap saat scroll */
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
  }

  /* Kontainer utama */
  .login-box {
    width: 100%;
    max-width: 450px; /* Maksimal lebar di desktop */
    margin: 0 auto;
  }

  /* Untuk tablet */
  @media (min-width: 768px) and (max-width: 1024px) {
    .login-box {
      max-width: 400px;
    }
  }

  /* Untuk ponsel */
  @media (max-width: 767px) {
    body.login-page {
      padding: 15px;
      background-attachment: scroll; /* Fixed background bisa bermasalah di mobile */
    }
    
    .login-box {
      max-width: 100%;
    }
    
    .login-logo img {
      max-width: 70px !important;
      margin-bottom: 10px !important;
    }
    
    .login-logo h3 {
      font-size: 1.4rem !important;
    }
    
    .login-card-body {
      padding: 1.5rem !important;
    }
    
    .card {
      border-radius: 12px !important;
    }
    
    .btn-primary {
      padding: 12px !important;
      font-size: 1rem;
    }
  }

  /* Untuk ponsel sangat kecil */
  @media (max-width: 480px) {
    body.login-page {
      padding: 10px;
    }
    
    .login-logo img {
      max-width: 60px !important;
    }
    
    .login-logo h3 {
      font-size: 1.3rem !important;
    }
    
    .login-card-body {
      padding: 1.25rem !important;
    }
    
    .login-box-msg {
      font-size: 0.9rem;
      margin-bottom: 1rem !important;
    }
    
    .input-group {
      margin-bottom: 1rem !important;
    }
    
    .input-group-text {
      width: 40px;
    }
    
    .form-control {
      font-size: 0.95rem;
      padding: 0.75rem;
    }
    
    .alert {
      font-size: 0.85rem;
      padding: 0.5rem 0.75rem;
    }
  }

  /* Untuk desktop besar */
  @media (min-width: 1200px) {
    .login-box {
      max-width: 480px;
    }
    
    .card {
      border-radius: 20px;
    }
  }

  /* Styling card */
  .login-box .card {
    border-radius: 16px;
    background-color: rgba(255, 255, 255, 0.96);
    box-shadow: 0 15px 35px rgba(0,0,0,0.25);
    border: none;
    overflow: hidden;
  }

  .login-card-body {
    padding: 2rem;
  }

  /* Logo styling */
  .login-logo {
    text-align: center;
    margin-bottom: 1.5rem;
  }

  .login-logo img {
    max-width: 90px;
    margin-bottom: 15px;
    transition: transform 0.3s ease;
  }

  .login-logo h3 {
    color: #2c3e50;
    font-weight: 600;
    margin: 0;
  }

  /* Pesan login */
  .login-box-msg {
    margin: 0 0 1.5rem 0;
    text-align: center;
    color: #6c757d;
    font-size: 0.95rem;
  }

  /* Form styling */
  .input-group {
    margin-bottom: 1.5rem;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 3px 10px rgba(0,0,0,0.08);
  }

  .input-group-text {
    width: 42px;
    justify-content: center;
    background-color: #f8f9fa;
    border: none;
    color: #495057;
  }

  .form-control {
    border: none;
    background-color: #f8f9fa;
    padding: 1rem;
    font-size: 1rem;
  }

  .form-control:focus {
    box-shadow: none;
    background-color: #ffffff;
  }

  /* Button styling */
  .btn-primary {
    background-color: #2e6da4;
    border: none;
    border-radius: 10px;
    padding: 14px;
    font-weight: 500;
    font-size: 1.1rem;
    transition: all 0.3s ease;
    letter-spacing: 0.5px;
  }

  .btn-primary:hover {
    background-color: #245580;
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(46, 109, 164, 0.3);
  }

  .btn-primary:active {
    transform: translateY(0);
  }

  /* Alert styling */
  .alert {
    border-radius: 10px;
    border: none;
    margin-bottom: 1.5rem;
  }

  /* Efek hover untuk card */
  .card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
  }

  .card:hover {
    transform: translateY(-5px);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
  }

  /* Loading state untuk button */
  .btn-primary:disabled {
    opacity: 0.7;
    cursor: not-allowed;
  }
</style>

</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="card">
    <div class="card-body login-card-body">
      
      <div class="login-logo mb-4 text-center">
        <img src="/img/logo.png" alt="Logo Desa" class="logo-img">
        <h3 class="text-dark"><b>Admin</b> Desa</h3>
      </div>

      <p class="login-box-msg">Silakan masuk untuk memulai sesi Anda</p>

      <?php if(session()->getFlashdata('msg')):?>
        <div class="alert alert-danger py-2"><?= session()->getFlashdata('msg') ?></div>
      <?php endif;?>

      <?php if(session()->has('errors')): ?>
          <div class="alert alert-danger py-2">
              <ul class="mb-0 ps-3">
              <?php foreach (session('errors') as $error): ?>
                  <li><?= esc($error) ?></li>
              <?php endforeach ?>
              </ul>
          </div>
      <?php endif; ?>

      <form action="/auth/login" method="post" id="loginForm">
        <?= csrf_field(); ?>
        <div class="input-group mb-3">
          <span class="input-group-text"><i class="fas fa-envelope"></i></span>
          <input type="email" name="email" class="form-control" placeholder="Email" value="<?= old('email') ?>" required>
        </div>
        <div class="input-group mb-3">
          <span class="input-group-text"><i class="fas fa-lock"></i></span>
          <input type="password" name="password" class="form-control" placeholder="Password" required>
        </div>
        <div class="row mt-4">
          <div class="col-12">
            <button type="submit" class="btn btn-primary btn-block" id="loginBtn">Masuk</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>

<script>
  // Menambahkan efek loading pada tombol submit
  $(document).ready(function() {
    $('#loginForm').on('submit', function() {
      var btn = $('#loginBtn');
      btn.prop('disabled', true);
      btn.html('<span class="spinner-border spinner-border-sm mr-2" role="status" aria-hidden="true"></span>Memproses...');
    });
    
    // Efek hover untuk logo
    $('.logo-img').hover(
      function() {
        $(this).css('transform', 'scale(1.1)');
      },
      function() {
        $(this).css('transform', 'scale(1)');
      }
    );
  });
</script>
</body>
</html>