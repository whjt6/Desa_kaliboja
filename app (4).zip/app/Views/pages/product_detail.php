<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Produk - Desa Kaliboja</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <style>
    :root {
        --primary: #4A6C6F;
        --primary-dark: #3a5659;
        --secondary: #F4EAD5;
        --accent: #D6A25B;
        --accent-light: #e6b877;
        --light: #F9F7F3;
        --text-dark: #333;
        --text-light: #6c757d;
        --shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        --shadow-hover: 0 10px 25px rgba(0, 0, 0, 0.15);
        --border-radius: 0.75rem;
    }

    body {
        background: var(--light);
        color: var(--text-dark);
        font-family: 'Inter', sans-serif;
        line-height: 1.6;
        scroll-behavior: smooth;
        padding-top: 80px;
    }

    h1, h2, h3, h4, h5, h6,
    .navbar-brand {
        font-family: 'Poppins', sans-serif;
        font-weight: 700;
    }

    .navbar {
        box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
        padding: 0.8rem 0;
        transition: all 0.3s ease;
        background: white !important;
    }

    .navbar.scrolled {
        padding: 0.5rem 0;
    }

    .nav-link {
        font-weight: 500;
        position: relative;
        padding: 0.5rem 0.8rem !important;
        margin: 0 0.2rem;
        transition: all 0.3s ease;
    }

    .nav-link::before {
        content: '';
        position: absolute;
        bottom: 0;
        left: 50%;
        width: 0;
        height: 2px;
        background: var(--accent);
        transition: all 0.3s ease;
        transform: translateX(-50%);
    }

    .nav-link:hover::before,
    .nav-link.active::before {
        width: 70%;
    }

    .btn-primary {
        background: var(--primary);
        border-color: var(--primary);
        padding: 0.6rem 1.5rem;
        font-weight: 500;
        transition: all 0.3s ease;
    }

    .btn-primary:hover {
        background: var(--primary-dark);
        border-color: var(--primary-dark);
        transform: translateY(-2px);
        box-shadow: var(--shadow-hover);
    }

    .btn-outline-primary {
        color: var(--primary);
        border-color: var(--primary);
        font-weight: 500;
        transition: all 0.3s ease;
    }

    .btn-outline-primary:hover {
        background: var(--primary);
        border-color: var(--primary);
        transform: translateY(-2px);
    }

    .btn-success {
        background: var(--accent);
        border-color: var(--accent);
        transition: all 0.3s ease;
    }

    .btn-success:hover {
        background: var(--accent-light);
        border-color: var(--accent-light);
        transform: translateY(-2px);
        box-shadow: var(--shadow-hover);
    }

    /* Product Detail Styles */
    .product-detail-section {
        padding: 3rem 0;
    }

    .product-image-container {
        border-radius: var(--border-radius);
        overflow: hidden;
        box-shadow: var(--shadow);
        transition: all 0.3s ease;
    }

    .product-image-container:hover {
        box-shadow: var(--shadow-hover);
    }

    .product-image {
        width: 100%;
        height: 400px;
        object-fit: cover;
    }

    .product-title {
        font-size: 2.2rem;
        font-weight: 700;
        color: var(--primary);
        margin-bottom: 0.5rem;
    }

    .product-category {
        background: var(--accent);
        color: white;
        padding: 0.4rem 1rem;
        border-radius: 2rem;
        font-size: 0.9rem;
        font-weight: 600;
        display: inline-block;
        margin-bottom: 1.5rem;
    }

    .product-price {
        font-size: 1.8rem;
        font-weight: 700;
        color: var(--primary);
        margin-bottom: 1.5rem;
    }

    .product-description {
        font-size: 1.1rem;
        line-height: 1.7;
        margin-bottom: 2rem;
        color: var(--text-dark);
    }

    .contact-info {
        background: rgba(74, 108, 111, 0.05);
        padding: 1.5rem;
        border-radius: var(--border-radius);
        border-left: 4px solid var(--accent);
        margin-bottom: 2rem;
    }

    .contact-title {
        font-weight: 600;
        color: var(--primary);
        margin-bottom: 0.5rem;
    }

    .contact-detail {
        font-size: 1.2rem;
        font-weight: 500;
        color: var(--primary-dark);
    }

    .action-buttons {
        display: flex;
        gap: 1rem;
        flex-wrap: wrap;
    }

    /* Breadcrumb */
    .breadcrumb {
        background-color: transparent;
        padding: 0.75rem 0;
        margin-bottom: 2rem;
    }

    .breadcrumb-item a {
        color: var(--primary);
        text-decoration: none;
        transition: color 0.3s ease;
    }

    .breadcrumb-item a:hover {
        color: var(--primary-dark);
    }

    /* Footer */
    footer {
        background: linear-gradient(to right, #0a1920, #111);
        color: #bbb;
        position: relative;
        overflow: hidden;
        margin-top: 4rem;
    }

    footer::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 4px;
        background: linear-gradient(to right, var(--accent), var(--primary));
    }

    .footer-title {
        font-weight: 600;
        color: white;
        margin-bottom: 1.5rem;
        font-size: 1.2rem;
    }

    .footer-links {
        list-style: none;
        padding: 0;
    }

    .footer-links li {
        margin-bottom: 0.8rem;
    }

    .footer-links a {
        color: #bbb;
        text-decoration: none;
        transition: all 0.3s ease;
    }

    .footer-links a:hover {
        color: white;
        padding-left: 5px;
    }

    .social-icons {
        margin-top: 1.5rem;
    }

    .social-icons a {
        color: white;
        background: rgba(255, 255, 255, 0.1);
        width: 40px;
        height: 40px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        margin-right: 0.8rem;
        transition: all 0.3s ease;
    }

    .social-icons a:hover {
        background: var(--accent);
        transform: translateY(-3px);
    }

    .copyright {
        margin-top: 3rem;
        padding-top: 1.5rem;
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        text-align: center;
        font-size: 0.9rem;
    }

    /* Responsive Styles */
    @media (max-width: 992px) {
        .product-title {
            font-size: 1.9rem;
        }
        
        .product-price {
            font-size: 1.6rem;
        }
        
        .product-image {
            height: 350px;
        }
    }

    @media (max-width: 768px) {
        body {
            padding-top: 70px;
        }
        
        .product-detail-section {
            padding: 2rem 0;
        }
        
        .product-title {
            font-size: 1.7rem;
        }
        
        .product-price {
            font-size: 1.5rem;
        }
        
        .product-image {
            height: 300px;
        }
        
        .action-buttons {
            flex-direction: column;
        }
        
        .action-buttons .btn {
            width: 100%;
            justify-content: center;
        }
    }

    @media (max-width: 576px) {
        .product-title {
            font-size: 1.5rem;
        }
        
        .product-price {
            font-size: 1.3rem;
        }
        
        .product-description {
            font-size: 1rem;
        }
        
        .contact-detail {
            font-size: 1.1rem;
        }
    }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="/">
                <img src="/img/logo.png" class="me-2" alt="Logo Desa Kaliboja" width="40" height="40">Desa Kaliboja
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu"
                aria-controls="navMenu" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navMenu">
                <ul class="navbar-nav ms-auto align-items-lg-center">
                    
                </ul>
            </div>
        </div>
    </nav>
    <!-- Breadcrumb -->
    <div class="container mt-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item"><a href="/products">Produk</a></li>
                <li class="breadcrumb-item active"><?= esc($product['name']); ?></li>
            </ol>
        </nav>
    </div>

    <!-- Product Detail Section -->
    <section class="product-detail-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 mb-5" data-aos="fade-right">
                    <div class="product-image-container">
                        <?php 
                        $imagePath = 'uploads/products/' . esc($product['image']);
                        $imageExists = !empty($product['image']) && file_exists(ROOTPATH . 'public/' . $imagePath);
                        ?>
                        <?php if($imageExists) : ?>
                            <img src="<?= base_url($imagePath); ?>" class="product-image" alt="<?= esc($product['name']); ?>">
                        <?php else : ?>
                            <div class="d-flex align-items-center justify-content-center bg-light" style="height: 400px;">
                                <div class="text-center text-muted">
                                    <i class="fas fa-image fa-4x mb-3"></i>
                                    <p>Gambar tidak tersedia</p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="col-lg-6" data-aos="fade-left">
                    <span class="product-category"><?= esc($product['category']); ?></span>
                    <h1 class="product-title"><?= esc($product['name']); ?></h1>
                    
                    <div class="product-description">
                        <h4 class="mb-3" style="color: var(--primary);">Deskripsi Produk</h4>
                        <p><?= nl2br(esc($product['description'])); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Related Products (Optional) -->
    <section class="py-5 bg-light">
        <div class="container">
            <h3 class="text-center mb-4" style="color: var(--primary);">Produk Lainnya</h3>
            <div class="row">
                <!-- You can add related products here -->
                <div class="col-12 text-center">
                    <p class="text-muted">Jelajahi lebih banyak produk unggulan dari Desa Kaliboja</p>
                    <a href="/products" class="btn btn-primary">
                        <i class="fas fa-shopping-bag me-2"></i>Lihat Semua Produk
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="mt-0">
        <div class="container py-5">
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <h5 class="text-white mb-4">Desa Kaliboja</h5>
                    <p class="mb-4">Portal resmi desa untuk transparansi informasi, promosi potensi, dan
                        pelayanan digital kepada masyarakat.</p>
                    <div class="d-flex">
                        <a href="https://www.facebook.com/share/17fpGKh173/" target="_blank"
                            class="text-white me-3 hover-lift">
                            <div class="social-icon">
                                <i class="fa-brands fa-facebook-f"></i>
                            </div>
                        </a>
                        <a href="https://www.instagram.com/desa_kaliboja?igsh=MTB2enB2N3I4dGp2OA==" target="_blank"
                            class="text-white me-3 hover-lift">
                            <div class="social-icon">
                                <i class="fa-brands fa-instagram"></i>
                            </div>
                        </a>
                        <a href="https://x.com/desa_kaliboja?t=taTDsUWdhSoPbIiqADFfyQ&s=09&fbclid=PAdGRjcAMvYX1leHRuA2FlbQIxMQABp9AdVHP8awNqQGOky0UFUiiEt9za1hiL0Wldzmpg5X_LPj7CyczURUw5Jk2f_aem_r-xoS5uVycPxEOxfhEjr2A"
                            target="_blank" class="text-white me-3 hover-lift">
                            <div class="social-icon">
                                <i class="fa-brands fa-x-twitter"></i>
                            </div>
                        </a>
                        <a href="https://www.tiktok.com/@desa_kaliboja?fbclid=PAdGRjcAMvYeNleHRuA2FlbQIxMQABp-jUXBxjp43fgoeGN6x01EfX3g1Nj10GpaTEukdsoluv5Zt4yNimvhdrphwe_aem_5lvWmF8h8HUWv1miYT-y0A"
                            target="_blank" class="text-white hover-lift">
                            <div class="social-icon">
                                <i class="fa-brands fa-tiktok"></i>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <h5 class="text-white mb-4">Kontak</h5>
                    <ul class="list-unstyled small">
                        <li class="mb-2"><i class="fa-solid fa-location-dot me-2"></i>Desa Kaliboja,
                            Kec. Paninggaran,
                            Kabupaten Pekalongan, Jawa Tengah</li>
                        <li class="mb-2"><i class="fa-solid fa-envelope me-2"></i>kalibojadesa@gmail.com
                        </li>
                        <li><i class="fa-solid fa-clock me-2"></i>Senin - Jumat: 08:00 - 16:00</li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-12">
                    <h5 class="text-white mb-4">Tautan Cepat</h5>
                    <div class="row">
                        <div class="col-6">
                            <ul class="list-unstyled small">
                                <li class="mb-2"><a href="#berita"
                                        class="hover-lift text-white text-decoration-none">Berita</a></li>
                                <li class="mb-2"><a href="#wisata"
                                        class="hover-lift text-white text-decoration-none">Wisata</a></li>
                                <li class="mb-2"><a href="#produk"
                                        class="hover-lift text-white text-decoration-none">Produk</a></li>
                                <li class="mb-2"><a href="#layanan"
                                        class="hover-lift text-white text-decoration-none">Layanan</a></li>
                                <li class="mb-2"><a href="#jdih"
                                        class="hover-lift text-white text-decoration-none">JDIH</a></li>
                            </ul>
                        </div>
                        <div class="col-6">
                            <ul class="list-unstyled small">
                                <li class="mb-2"><a href="#rkp"
                                        class="hover-lift text-white text-decoration-none">RKP</a></li>
                                <li class="mb-2"><a href="#koperasi"
                                        class="hover-lift text-white text-decoration-none">Koperasi</a></li>
                                <li class="mb-2"><a href="#profil"
                                        class="hover-lift text-white text-decoration-none">Profil</a></li>
                                <li class="mb-2"><a href="#galeri"
                                        class="hover-lift text-white text-decoration-none">Galeri</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <hr class="border-secondary my-4">
            <div class="text-center small">
                <div class="mb-2">&copy; 2025 Pemerintah Desa Kaliboja. All Rights Reserved.
                </div>
                <div>Dikembangkan oleh <a href="#" class="text-white hover-lift text-decoration-none">Tim IT KKN 4
                        Kelompok 7
                        Desa Kaliboja</a></div>
            </div>
        </div>
    </footer>

    <!-- Floating WhatsApp -->
    <a class="wa-float btn btn-success rounded-circle shadow" href="https://wa.me/628123456789" target="_blank"
        title="Hubungi via WhatsApp" style="position: fixed; right: 20px; bottom: 20px; z-index: 1030; width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
        <i class="fab fa-whatsapp fa-lg"></i>
    </a>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize AOS
        AOS.init({
            duration: 800,
            easing: 'ease-in-out',
            once: true
        });
        
        // Navbar scroll effect
        const navbar = document.querySelector('.navbar');
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });
        
        // Handle image errors
        document.querySelectorAll('.product-image').forEach(img => {
            img.addEventListener('error', function() {
                this.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjhmOWZhIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxOCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZG9taW5hbnQtYmFzZWxpbmU9Im1pZGRsZSIgZmlsbD0iIzk5OSI+R2FtYmFyIHRpZGFrIHRlcnNlZGlhPC90ZXh0Pjwvc3ZnPg==';
            });
        });
    });
    </script>
</body>
</html>