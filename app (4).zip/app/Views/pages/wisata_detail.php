<?= $this->extend('layout/main_layout'); ?>
<?= $this->section('content'); ?>

<!-- Header Section - DIPERBAIKI: Kontras tombol diperbaiki -->
<section class="hero-section-detail" style="background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('<?= !empty($wisata['gambar']) ? base_url('uploads/wisata/' . $wisata['gambar']) : base_url('assets/img/wisata-default.jpg') ?>') center/cover no-repeat;">
    <div class="container py-5">
        <div class="row">
            <div class="col-lg-12 text-center text-white">
                <!-- Judul dengan teks putih bersih -->
                <h1 class="display-4 fw-bold mb-3 text-white" data-aos="fade-down" style="color: #ffffff !important; text-shadow: 2px 2px 8px rgba(0,0,0,0.5);">
                    <?= esc($wisata['nama']); ?>
                </h1>
                
                <!-- Lokasi dengan teks putih bersih -->
                <p class="lead mb-4 text-white" data-aos="fade-up" data-aos-delay="200" style="color: #ffffff !important; text-shadow: 1px 1px 4px rgba(0,0,0,0.4);">
                    <i class="fas fa-map-marker-alt me-2" style="color: #ffffff;"></i>
                    <?= esc($wisata['lokasi']); ?>
                </p>
                
                <!-- Tombol dengan kontras yang baik -->
                
                    
            </div>
        </div>
    </div>
</section>

<!-- Breadcrumb -->
<section class="py-3 bg-light">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?= base_url('/'); ?>" class="text-decoration-none text-dark">Beranda</a></li>
                <li class="breadcrumb-item"><a href="<?= base_url('wisata'); ?>" class="text-decoration-none text-dark">Wisata</a></li>
                <li class="breadcrumb-item active text-primary" aria-current="page"><?= esc($wisata['nama']); ?></li>
            </ol>
        </nav>
    </div>
</section>

<!-- Detail Wisata Section -->
<section id="wisata-detail" class="py-5">
    <div class="container">
        <div class="row">
            <!-- Gallery Section -->
            <div class="col-lg-8 mb-5">
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-body p-0 overflow-hidden rounded-3">
                        <?php 
                        $gambar = !empty($wisata['gambar']) ? base_url('uploads/wisata/' . $wisata['gambar']) : base_url('assets/img/no-image.png');
                        ?>
                        <img src="<?= $gambar; ?>" alt="<?= esc($wisata['nama']); ?>" class="img-fluid w-100" style="height: 400px; object-fit: cover;">
                    </div>
                </div>
                
                <!-- Info Boxes -->
                <div class="row mb-4">
                    <?php if (!empty($wisata['tiket'])): ?>
                    <div class="col-md-4 mb-3">
                        <div class="card bg-primary text-white text-center p-3 rounded-3 shadow-sm">
                            <i class="fas fa-ticket-alt fa-2x mb-2" style="color: #ffffff;"></i>
                            <h5 class="mb-1 text-white" style="color: #ffffff;">Harga Tiket</h5>
                            <p class="mb-0 fs-5 fw-bold text-white" style="color: #ffffff;">Rp <?= number_format($wisata['tiket'], 0, ',', '.'); ?></p>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Deskripsi -->
                <div class="card shadow-sm border-0 rounded-3 mb-4">
                    <div class="card-header bg-transparent border-0 pt-4">
                        <h3 class="card-title mb-0 text-dark">Tentang <?= esc($wisata['nama']); ?></h3>
                    </div>
                    <div class="card-body">
                        <p class="text-justify fs-5 lh-lg text-dark"><?= nl2br(esc($wisata['deskripsi'])); ?></p>
                    </div>
                </div>
            </div>
            
            <!-- Sidebar -->
            <div class="col-lg-4">
                <!-- Card Informasi -->
                <div class="card shadow-sm border-0 rounded-3 sticky-top" style="top: 100px;">
                    <div class="card-header bg-primary text-white py-3 rounded-top">
                        <h5 class="mb-0 text-white" style="color: #ffffff;"><i class="fas fa-info-circle me-2" style="color: #ffffff;"></i>Informasi Wisata</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-primary p-3 rounded-circle me-3">
                                <i class="fas fa-map-marker-alt text-white" style="color: #ffffff;"></i>
                            </div>
                            <div>
                                <h6 class="mb-0 text-dark">Lokasi</h6>
                                <p class="mb-0 text-dark"><?= esc($wisata['lokasi']); ?></p>
                            </div>
                        </div>
                        
                        <?php if (!empty($wisata['tiket'])): ?>
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-primary p-3 rounded-circle me-3">
                                <i class="fas fa-ticket-alt text-white" style="color: #ffffff;"></i>
                            </div>
                            <div>
                                <h6 class="mb-0 text-dark">Harga Tiket</h6>
                                <p class="mb-0 text-dark">Rp <?= number_format($wisata['tiket'], 0, ',', '.'); ?></p>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <hr>
                        
                        <div class="text-center mt-4">
                            <a href="https://www.google.com/maps/search/<?= urlencode($wisata['nama'] . ' ' . $wisata['lokasi']); ?>" 
                               target="_blank" class="btn btn-primary btn-lg w-100 mb-3">
                                <i class="fas fa-directions me-2 text-white"></i> 
                                <span class="text-white" style="color: #ffffff;">Dapatkan Petunjuk</span>
                            </a>
                            <a href="<?= base_url('wisata'); ?>" class="btn btn-outline-primary btn-lg w-100">
                                <i class="fas fa-arrow-left me-2"></i> 
                                <span class="text-dark">Kembali ke Daftar Wisata</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
    /* Custom CSS untuk meningkatkan tampilan */
    .hero-section-detail {
        padding: 7rem 0;
        background-position: center;
        background-size: cover;
    }
    
    /* PERBAIKAN UTAMA: Pastikan semua teks di hero section berwarna putih */
    .hero-section-detail h1,
    .hero-section-detail h2,
    .hero-section-detail h3,
    .hero-section-detail h4,
    .hero-section-detail h5,
    .hero-section-detail h6,
    .hero-section-detail p,
    .hero-section-detail span,
    .hero-section-detail div,
    .hero-section-detail .lead,
    .hero-section-detail .display-4 {
        color: #ffffff !important;
        text-shadow: 1px 1px 3px rgba(0,0,0,0.5);
    }
    
    /* Tombol Jelajahi Wisata - Background putih, teks biru */
    .btn-explore {
        background-color: #ffffff !important;
        color: #0d6efd !important;
        border: 2px solid #ffffff !important;
        font-weight: 600;
    }
    
    .btn-explore:hover {
        background-color: #f8f9fa !important;
        color: #0a58ca !important;
        border-color: #f8f9fa !important;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }
    
    /* Tombol Petunjuk Arah - Outline putih */
    .btn-directions {
        color: #ffffff !important;
        border: 2px solid #ffffff !important;
        background-color: rgba(255, 255, 255, 0.1);
    }
    
    .btn-directions:hover {
        background-color: #ffffff !important;
        color: #0d6efd !important;
        border-color: #ffffff !important;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }
    
    .card {
        transition: transform 0.3s ease;
    }
    
    .card:hover {
        transform: translateY(-5px);
    }
    
    .gallery-item {
        position: relative;
        overflow: hidden;
    }
    
    .gallery-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(transparent 70%, rgba(0,0,0,0.7));
        opacity: 0;
        transition: opacity 0.3s ease;
    }
    
    .gallery-item:hover .gallery-overlay {
        opacity: 1;
    }
    
    .sticky-top {
        z-index: 99;
    }
    
    .breadcrumb {
        padding: 0.75rem 1rem;
        border-radius: 0.5rem;
    }
    
    /* Memastikan warna teks konsisten */
    .text-dark {
        color: #212529 !important;
    }
    
    .text-white {
        color: #ffffff !important;
    }
    
    .text-primary {
        color: #0d6efd !important;
    }
    
    /* Override untuk kontras yang lebih baik */
    .bg-primary h1,
    .bg-primary h2,
    .bg-primary h3,
    .bg-primary h4,
    .bg-primary h5,
    .bg-primary h6,
    .bg-primary p,
    .bg-primary span,
    .bg-primary i,
    .bg-primary .fa {
        color: #ffffff !important;
    }
    
    .bg-info h1,
    .bg-info h2,
    .bg-info h3,
    .bg-info h4,
    .bg-info h5,
    .bg-info h6,
    .bg-info p,
    .bg-info span,
    .bg-info i {
        color: #ffffff !important;
    }
    
    .bg-success h1,
    .bg-success h2,
    .bg-success h3,
    .bg-success h4,
    .bg-success h5,
    .bg-success h6,
    .bg-success p,
    .bg-success span,
    .bg-success i {
        color: #ffffff !important;
    }
    
    /* Hero gradient lebih gelap untuk kontras teks */
    .hero-gradient {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.6));
        z-index: 1;
    }
    
    .hero-content {
        position: relative;
        z-index: 2;
    }
    
    /* Efek hover untuk semua tombol */
    .btn {
        transition: all 0.3s ease;
    }
    
    /* Responsif */
    @media (max-width: 768px) {
        .hero-section-detail {
            padding: 5rem 0;
        }
        
        .display-4 {
            font-size: 2.5rem !important;
        }
        
        .lead {
            font-size: 1.1rem !important;
        }
        
        .btn-lg {
            padding: 0.75rem 1.5rem;
            font-size: 1rem;
            display: block;
            width: 100%;
            margin-bottom: 1rem;
        }
        
        .btn-lg.me-2 {
            margin-right: 0 !important;
        }
    }
    
    @media (max-width: 576px) {
        .hero-section-detail {
            padding: 4rem 0;
        }
        
        .display-4 {
            font-size: 2rem !important;
        }
        
        .lead {
            font-size: 1rem !important;
        }
    }
</style>

<script>
// JavaScript untuk memastikan teks tetap putih
document.addEventListener('DOMContentLoaded', function() {
    // Force all text in hero section to be white
    const heroSection = document.querySelector('.hero-section-detail');
    if (heroSection) {
        const allElements = heroSection.querySelectorAll('*');
        allElements.forEach(element => {
            if (!element.classList.contains('btn-explore')) {
                element.style.color = '#ffffff';
                element.style.textShadow = '1px 1px 2px rgba(0,0,0,0.5)';
            }
        });
    }
});
</script>

<?= $this->endSection(); ?>