<!doctype html>
<html lang="id">

<head>
    <!-- Polyfill untuk browser lama -->
<script src="https://cdn.jsdelivr.net/npm/es6-promise@4/dist/es6-promise.auto.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/whatwg-fetch@3.6.2/dist/fetch.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/3.21.1/minified.min.js"></script>

<!-- Memaksa IE menggunakan mode rendering terbaru -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Profil Desa Kaliboja | Website Resmi</title>
    <meta name="description"
        content="Website resmi Desa Kaliboja - Portal digital untuk transparansi informasi, promosi potensi, dan pelayanan digital kepada masyarakat.">
    <link rel="icon" href="/img/logo.png" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600&display=swap"
        rel="stylesheet">
    <style>
    /* Variabel CSS */
    :root {
        --primary: #4A6C6F;
        --primary-dark: #3a5659;
        --secondary: #F4EAD5;
        --accent: #D6A25B;
        --accent-light: #e6b877;
        --dark: #1f2937;
        --light: #F9F7F3;
        --success: #28a745;
        --text-dark: #333;
        --text-light: #6c757d;
        --shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        --shadow-hover: 0 10px 25px rgba(0, 0, 0, 0.15);
        --border-radius: 0.75rem;
    }

    /* Dasar Typography */
    body {
        background: var(--light);
        color: var(--text-dark);
        font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Ubuntu, 'Helvetica Neue', Arial, sans-serif;
        line-height: 1.6;
        font-size: 1rem;
        scroll-behavior: smooth;
    }

    h1, h2, h3, h4, h5, h6,
    .navbar-brand {
        font-family: 'Poppins', sans-serif;
        font-weight: 700;
        line-height: 1.3;
    }

    h1 { font-size: 2.5rem; }
    h2 { font-size: 2rem; }
    h3 { font-size: 1.75rem; }
    h4 { font-size: 1.5rem; }
    h5 { font-size: 1.25rem; }
    h6 { font-size: 1.1rem; }

    p, li, td, th {
        font-size: 1rem;
        line-height: 1.6;
    }

    .lead {
        font-size: 1.2rem;
        font-weight: 400;
    }

    /* Navbar */
    .navbar {
        box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
        padding: 0.8rem 0;
        transition: all 0.3s ease;
    }

    .navbar.scrolled {
        padding: 0.5rem 0;
        background: rgba(255, 255, 255, 0.95) !important;
        backdrop-filter: blur(10px);
    }

    .navbar-brand img {
        height: 40px;
        transition: all 0.3s ease;
    }

    .navbar.scrolled .navbar-brand img {
        height: 36px;
    }

    .nav-link {
        font-weight: 500;
        position: relative;
        padding: 0.5rem 0.8rem !important;
        margin: 0 0.2rem;
        transition: all 0.3s ease;
        font-size: 0.95rem;
    }

    .nav-link::before {
        content: '';
        position: absolute;
        bottom: 0;
        left: 50%;
        width: 0;
        height: 2px;
        background: var(--accent);
        transition: all 0.3s ease;
        transform: translateX(-50%);
    }

    .nav-link:hover::before,
    .nav-link.active::before {
        width: 70%;
    }

    /* Tombol */
    .btn-primary {
        background: var(--primary);
        border-color: var(--primary);
        padding: 0.6rem 1.5rem;
        font-weight: 500;
        transition: all 0.3s ease;
        font-size: 0.95rem;
    }

    .btn-primary:hover {
        background: var(--primary-dark);
        border-color: var(--primary-dark);
        transform: translateY(-2px);
        box-shadow: var(--shadow-hover);
    }

    .btn-outline-primary {
        color: var(--primary);
        border-color: var(--primary);
        font-weight: 500;
        transition: all 0.3s ease;
        font-size: 0.95rem;
    }

    .btn-outline-primary:hover {
        background: var(--primary);
        border-color: var(--primary);
        transform: translateY(-2px);
    }

    .btn-success {
        background: var(--success);
        border-color: var(--success);
        transition: all 0.3s ease;
        font-size: 0.95rem;
    }

    .btn-success:hover {
        transform: translateY(-2px);
        box-shadow: var(--shadow-hover);
    }

    /* Section Title */
    .section-title {
        font-weight: 700;
        color: var(--primary);
        text-align: center;
        margin-bottom: 2.4rem;
        position: relative;
    }

    .section-title::after {
        content: '';
        display: block;
        width: 84px;
        height: 4px;
        background: var(--accent);
        margin: 0.8rem auto 0;
        border-radius: 2px;
    }

    /* Hero Section */
    .hero-section {
        background: linear-gradient(135deg, var(--primary-dark), var(--primary));
        color: white;
        position: relative;
        overflow: hidden;
        padding: 6rem 0 4rem;
    }

    .hero-section::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: url("data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 0h20L0 20z' fill='%23ffffff' fill-opacity='0.05'/%3E%3C/svg%3E");
        opacity: 0.1;
    }

    /* Cards */
    .card-elev {
        border: none;
        border-radius: var(--border-radius);
        overflow: hidden;
        box-shadow: var(--shadow);
        transition: all 0.3s ease;
        height: 100%;
    }

    .card-elev:hover {
        transform: translateY(-8px);
        box-shadow: var(--shadow-hover);
    }

    .card-body {
        padding: 2rem;
    }

    /* Warna khusus desa */
    .text-desa {
        color: #4E6E6E !important;
    }

    .bg-desa {
        background-color: #4E6E6E !important;
        color: #fff !important;
    }

    /* Kotakan seragam */
    .box-desa {
        border: 2px solid #4E6E6E;
        border-radius: 10px;
        padding: 15px;
        background-color: #fff;
        transition: all 0.3s ease;
    }

    .box-desa:hover {
        transform: scale(1.02);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }

    /* Footer */
    footer {
        background: linear-gradient(to right, #0a1920, #111);
        color: #bbb;
        position: relative;
        overflow: hidden;
    }

    footer::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 4px;
        background: linear-gradient(to right, var(--accent), var(--primary));
    }

    footer a {
        color: #bbb;
        text-decoration: none;
        transition: all 0.3s ease;
    }

    footer a:hover {
        color: #fff;
        padding-left: 5px;
    }

    /* Floating buttons */
    .wa-float {
        position: fixed;
        right: 20px;
        bottom: 20px;
        z-index: 1030;
        animation: pulse 2s infinite, float 3s ease-in-out infinite;
    }

    .to-top {
        position: fixed;
        right: 20px;
        bottom: 80px;
        z-index: 1030;
        display: none;
        animation: fadeIn 0.5s ease;
    }

    /* Animations */
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }

    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        to { transform: scale(1); }
    }

    @keyframes float {
        0% { transform: translateY(0px); }
        50% { transform: translateY(-10px); }
        to { transform: translateY(0px); }
    }

    /* Timeline Styles */
    .timeline {
        position: relative;
        padding-left: 3rem;
        margin: 2rem 0;
    }

    .timeline::before {
        content: '';
        position: absolute;
        left: 1rem;
        top: 0;
        bottom: 0;
        width: 2px;
        background: var(--primary);
    }

    .timeline-item {
        position: relative;
        margin-bottom: 2rem;
    }

    .timeline-date {
        position: absolute;
        left: -3rem;
        top: 0;
        background: var(--primary);
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 1rem;
        font-weight: bold;
        font-size: 0.9rem;
        z-index: 2;
    }

    .timeline-content {
        background: white;
        padding: 1.5rem;
        border-radius: 0.5rem;
        box-shadow: var(--shadow);
        margin-left: 2rem;
        border-left: 3px solid var(--accent);
    }

    .timeline-content h5 {
        color: var(--primary);
        margin-bottom: 0.5rem;
    }

    /* Tabel styles */
    .table-responsive {
        border-radius: 0.5rem;
        overflow: hidden;
        box-shadow: var(--shadow);
    }

    .table th {
        background-color: var(--primary);
        color: white;
        font-weight: 500;
        font-size: 1rem;
        padding: 0.75rem;
    }

    .table td {
        padding: 0.75rem;
        vertical-align: middle;
        font-size: 0.95rem;
    }

    .table-striped tbody tr:nth-of-type(odd) {
        background-color: rgba(0, 0, 0, 0.02);
    }

    .table-hover tbody tr:hover {
        background-color: rgba(74, 108, 111, 0.05);
    }

    .data-card {
        border-radius: 0.5rem;
        box-shadow: var(--shadow);
        transition: all 0.3s ease;
        height: 100%;
    }

    .data-card:hover {
        transform: translateY(-5px);
        box-shadow: var(--shadow-hover);
    }

    .stat-number {
        font-size: 2rem;
        font-weight: 700;
        color: var(--primary);
    }

    .nav-pills .nav-link.active {
        background-color: var(--primary);
    }

    .nav-pills .nav-link {
        color: var(--text-dark);
    }

    /* Announcement bar */
    .announcement-bar {
        background-color: var(--primary);
        color: white;
        padding: 8px 0;
        font-size: 0.9rem;
    }

    /* Sarana prasarana styles */
    .sarana-icon {
        font-size: 1.2rem;
        color: var(--primary);
        margin-right: 0.5rem;
        width: 30px;
        height: 30px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: rgba(74, 108, 111, 0.1);
        border-radius: 50%;
    }

    .category-header {
        background-color: rgba(74, 108, 111, 0.1);
        padding: 0.75rem;
        border-left: 4px solid var(--primary);
        margin-bottom: 0.5rem;
        font-weight: 600;
        color: var(--primary);
        display: flex;
        align-items: center;
    }

    /* Breadcrumb */
    .breadcrumb {
        background-color: transparent;
        padding: 0.75rem 0;
        margin-bottom: 0;
    }

    .breadcrumb-item a {
        color: var(--primary);
        text-decoration: none;
    }

    /* Dark mode */
    .dark body {
        background: #0b1220;
        color: #e5e7eb;
    }

    .dark .navbar {
        background: #0f172a !important;
    }

    .dark .card-elev {
        background: #1e293b;
        color: #e5e7eb;
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.35);
    }

    .dark footer {
        background: #020617;
    }

    .dark .timeline-content,
    .dark .table,
    .dark .data-card {
        background: #1e293b;
        color: #e5e7eb;
    }

    .dark .table th {
        background-color: var(--primary-dark);
    }

    .dark .table-striped tbody tr:nth-of-type(odd) {
        background-color: rgba(255, 255, 255, 0.05);
    }

    /* Perbaikan responsivitas */
    @media (max-width: 1200px) {
        h1 { font-size: 2.3rem; }
        .display-4 { font-size: 2.5rem; }
    }

    @media (max-width: 992px) {
        h1 { font-size: 2.1rem; }
        h2 { font-size: 1.8rem; }
        .display-4 { font-size: 2.2rem; }
        .lead { font-size: 1.15rem; }
        
        .card-body {
            padding: 1.75rem !important;
        }
        
        .section-title {
            font-size: 1.8rem;
            margin-bottom: 2rem;
        }
    }

    @media (max-width: 768px) {
        body {
            font-size: 0.95rem;
        }
        
        h1 { font-size: 1.9rem; }
        h2 { font-size: 1.65rem; }
        h3 { font-size: 1.5rem; }
        
        .display-4 { font-size: 2rem; }
        .lead { font-size: 1.1rem; }
        
        .navbar .nav-link {
            padding: 0.8rem 0.5rem !important;
            margin: 0.1rem 0;
            font-size: 0.9rem;
        }

        .navbar .btn {
            margin-top: 0.5rem;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }

        .section-title {
            font-size: 1.7rem;
            margin-bottom: 1.8rem;
        }
        
        .card-body {
            padding: 1.5rem !important;
        }
        
        .hero-section {
            padding: 5rem 0 3rem !important;
        }
        
        .timeline {
            padding-left: 2rem;
        }

        .timeline-date {
            left: -2.5rem;
            padding: 0.4rem 0.8rem;
            font-size: 0.8rem;
        }

        .timeline-content {
            margin-left: 1.5rem;
            padding: 1rem;
        }
        
        /* Table adjustments */
        .table th, .table td {
            padding: 0.6rem;
            font-size: 0.9rem;
        }
        
        .category-header {
            font-size: 0.95rem;
            padding: 0.6rem;
        }
        
        .sarana-icon {
            font-size: 1rem;
            width: 25px;
            height: 25px;
            margin-right: 0.4rem;
        }
        
        .stat-number {
            font-size: 1.75rem;
        }
    }

    @media (max-width: 576px) {
        body {
            font-size: 0.9rem;
        }
        
        h1 { font-size: 1.7rem; }
        h2 { font-size: 1.5rem; }
        h3 { font-size: 1.35rem; }
        h4 { font-size: 1.2rem; }
        
        .display-4 { font-size: 1.8rem; }
        .lead { font-size: 1rem; }
        
        .section-title {
            font-size: 1.6rem;
            margin-bottom: 1.5rem;
        }

        .section-title::after {
            width: 60px;
            height: 3px;
        }

        .btn, .btn-sm {
            padding: 0.5rem 1rem;
            font-size: 0.85rem;
        }
        
        .card-body {
            padding: 1.25rem !important;
        }
        
        .hero-section {
            padding: 4.5rem 0 2.5rem !important;
        }
        
        .breadcrumb {
            font-size: 0.9rem;
        }
        
        .stat-number {
            font-size: 1.6rem;
        }
        
        .timeline {
            padding-left: 1.5rem;
        }

        .timeline-date {
            position: relative;
            left: 0;
            margin-bottom: 0.5rem;
            display: inline-block;
        }

        .timeline-content {
            margin-left: 0;
            padding: 1rem;
        }

        .timeline::before {
            left: 0.5rem;
        }
        
        /* Table adjustments for mobile */
        .table th, .table td {
            padding: 0.5rem;
            font-size: 0.85rem;
        }
        
        .category-header {
            font-size: 0.9rem;
            padding: 0.5rem;
        }
        
        .sarana-icon {
            font-size: 0.9rem;
            width: 22px;
            height: 22px;
            margin-right: 0.3rem;
        }
        
        /* Make some table cells stack on mobile */
        .table-responsive table {
            font-size: 0.8rem;
        }
        
        /* Improve mobile layout for data cards */
        .data-card {
            margin-bottom: 1rem;
        }
    }
    </style>
</head>

<body>
     <!-- Announcement Bar -->
    <div class="announcement-bar text-center">
        <div class="container">
            <p class="mb-0"><i class="fas fa-bullhorn me-2"></i> Selamat datang di Galeri Desa Kaliboja! <a
                    href="/berita" class="text-white fw-bold ms-2">Lihat berita terbaru &rarr;</a></p>
        </div>
    </div>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="/">
                <img src="/img/logo.png" class="me-2" alt="Logo">Desa Kaliboja
            </a>
            
        </div>
    </nav>

    <!-- Header Profil -->
    <section class="hero-section">
        <div class="container py-5">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h1 class="display-4 fw-bold mb-3" data-aos="fade-down">Profil Desa Kaliboja</h1>
                    <p class="lead" data-aos="fade-up" data-aos-delay="200">Mengenal lebih dalam tentang Desa Kaliboja
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="bg-light py-3">
        <div class="container">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item active">Profil Desa</li>
            </ol>
        </div>
    </nav>
    <section id="statistik" class="py-5">
        <div class="container text-center">
            <h2 class="section-title mb-4" data-aos="zoom-in">Statistik Desa</h2>
            <div class="row g-4 justify-content-center">
                <!-- Total Penduduk -->
                <div class="col-6 col-md-4" data-aos="flip-left" data-aos-delay="100">
                    <div class="stat-card shadow-sm p-3 rounded h-100 hover-lift">
                        <i class="fas fa-users fa-2x text-primary mb-2"></i>
                        <div class="h6 mb-1 text-uppercase">Total Penduduk</div>
                        <div class="counter fw-bold"
                            data-target="<?= isset($population['total']) && is_numeric($population['total']) && $population['total'] > 0 ? (int)$population['total'] : 0 ?>">
                            <?= isset($population['total']) && is_numeric($population['total']) && $population['total'] > 0 ? number_format($population['total']) : '<span class="no-data">Data belum tersedia</span>' ?>
                        </div>
                    </div>
                </div>
                <!-- Laki-laki -->
                <div class="col-6 col-md-4" data-aos="flip-left" data-aos-delay="200">
                    <div class="stat-card shadow-sm p-3 rounded h-100 hover-lift">
                        <i class="fas fa-male fa-2x text-success mb-2"></i>
                        <div class="h6 mb-1 text-uppercase">Laki-laki</div>
                        <div class="counter fw-bold"
                            data-target="<?= isset($population['male']) && is_numeric($population['male']) && $population['male'] > 0 ? (int)$population['male'] : 0 ?>">
                            <?= isset($population['male']) && is_numeric($population['male']) && $population['male'] > 0 ? number_format($population['male']) : '<span class="no-data">Data belum tersedia</span>' ?>
                        </div>
                    </div>
                </div>
                <!-- Perempuan -->
                <div class="col-6 col-md-4" data-aos="flip-left" data-aos-delay="300">
                    <div class="stat-card shadow-sm p-3 rounded h-100 hover-lift">
                        <i class="fas fa-female fa-2x text-info mb-2"></i>
                        <div class="h6 mb-1 text-uppercase">Perempuan</div>
                        <div class="counter fw-bold"
                            data-target="<?= isset($population['female']) && is_numeric($population['female']) && $population['female'] > 0 ? (int)$population['female'] : 0 ?>">
                            <?= isset($population['female']) && is_numeric($population['female']) && $population['female'] > 0 ? number_format($population['female']) : '<span class="no-data">Data belum tersedia</span>' ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Visi Misi -->
    <section id="visi-misi" class="py-5">
        <div class="container">
            <h2 class="section-title text-center mb-5">Visi & Misi Desa</h2>

            <!-- Visi -->
            <div class="row mb-4" data-aos="fade-up">
                <div class="col-lg-12">
                    <div class="card card-elev">
                        <div class="card-body">
                            <h3 class="text-primary mb-4"><i class="fas fa-bullseye me-2"></i>Visi</h3>
                            <blockquote class="blockquote text-center fst-italic fs-5 fs-md-4">
                                "Terwujudnya Pemerintahan Desa yang Baik dan Bersih Guna Mewujudkan Desa Kaliboja yang
                                Adil, Makmur, Sejahtera, dan Bermasyarakat"
                            </blockquote>
                        </div>
                    </div>
                </div>
            </div>
            

            <!-- Misi -->
            <div class="row" data-aos="fade-up" data-aos-delay="200">
                <div class="col-lg-12">
                    <div class="card card-elev">
                        <div class="card-body">
                            <h3 class="text-primary mb-4"><i class="fas fa-tasks me-2"></i>Misi</h3>
                            <ol class="list-group list-group-numbered">
                                <li class="list-group-item border-0">Meningkatkan kualitas pelayanan kepada masyarakat.
                                </li>
                                <li class="list-group-item border-0">Menyelenggarakan pemerintahan yang bersih, terbebas
                                    dari korupsi serta bentuk-bentuk penyelewengan lainnya.</li>
                                <li class="list-group-item border-0">Meningkatkan partisipasi aktif dan peran serta
                                    masyarakat dalam penyelenggarakan pemerintahan, pembangunan, keagamaan, kepemudaan,
                                    dan kehidupan bermasyarakat.</li>
                                <li class="list-group-item border-0">Mewujudkan kehidupan masyarakat yang aman, tentram,
                                    dan tertib sehingga tercipta iklim yang kondusif.</li>
                                <li class="list-group-item border-0">Meningkatkan jumlah и mutu sarana prasarana serta
                                    sumber daya yang dimiliki Pemerintah Desa Kaliboja Kecamatan Paninggaran dalam
                                    rangka mendukung tercapainya pemerintahan profesional.</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Struktur Organisasi -->
    <section id="struktur" class="py-5 bg-light">
        <div class="container">
            <h2 class="section-title text-center mb-5">Struktur Organisasi</h2>

            <div class="text-center mb-4">
                <!-- Gambar struktur organisasi -->
                <img src="img/sss.jpg" alt="Struktur Organisasi Desa Kaliboja" class="img-fluid rounded shadow"
                    data-aos="zoom-in"
                    onerror="this.src='https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80'">
            </div>
        </div>
    </section>

    <!-- Sejarah Desa -->
    <section id="sejarah" class="py-5">
        <div class="container">
            <h2 class="section-title text-center mb-5">Sejarah Desa</h2>

            <div class="row" data-aos="fade-up">
                <div class="col-lg-12">
                    <div class="card card-elev">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <h3 class="text-primary mb-4"><i class="fas fa-landmark me-2"></i>Asal Usul Nama
                                        Kaliboja</h3>
                                    <p class="lead">
                                        Desa Kaliboja memiliki sejarah panjang yang bermula dari penamaan yang berasal
                                        dari kondisi alam sekitar.
                                    </p>
                                    <p>
                                        Nama "Kaliboja" dapat diartikan sebagai "Sungai (yang di tepinya tumbuh) Bunga
                                        Samboja". Penafsiran ini sangat kuat didasarkan pada beberapa alasan berikut:
                                    </p>

                                    <h4 class="text-primary mt-4"><i class="fas fa-leaf me-2"></i>Alasan Penafsiran</h4>

                                    <div class="d-flex align-items-start mb-4">
                                        <div class="me-3 mt-2">
                                            <i class="fas fa-tree fa-2x text-desa"></i>
                                        </div>
                                        <div>
                                            <h5 class="text-desa">Iklim dan Ekosistem</h5>
                                            <p>Desa Kaliboja yang terletak di daerah perbukitan Paninggaran memiliki
                                                iklim yang cocok untuk tumbuhnya bunga samboja (Plumeria). Pohon samboja
                                                sering ditanam di area pemakaman, pura (di Bali), dan juga tumbuh liar
                                                di tepi-tepi sungai.</p>
                                        </div>
                                    </div>

                                    <div class="d-flex align-items-start mb-4">
                                        <div class="me-3 mt-2">
                                            <i class="fas fa-water fa-2x text-desa"></i>
                                        </div>
                                        <div>
                                            <h5 class="text-desa">Fenomena Alam</h5>
                                            <p>Sangut mungkin bahwa pada masa lalu, di sepanjang aliran sungai yang
                                                melintasi daerah tersebut tumbuh subur pohon-pohon samboja. Keindahan
                                                bunga-bunga yang berguguran di sekitar sungai atau menghiasi tepiannya
                                                bisa menjadi pemandangan yang sangat mencolok, sehingga masyarakat
                                                menamai daerah tersebut berdasarkan ciri alam yang mudah dikenali itu.
                                            </p>
                                        </div>
                                    </div>

                                    <div class="d-flex align-items-start mb-4">
                                        <div class="me-3 mt-2">
                                            <i class="fas fa-history fa-2x text-desa"></i>
                                        </div>
                                        <div>
                                            <h5 class="text-desa">Kearifan Lokal</h5>
                                            <p>Masyarakat Jawa memiliki tradisi kuat dalam menamai suatu tempat
                                                berdasarkan fenomena alam yang ada di sekitarnya, seperti flora, fauna,
                                                atau kondisi geografis. Penamaan berdasarkan tumbuhan (seperti:
                                                Banyuwangi, Kebonagung, Cimanggu) adalah hal yang sangat umum.</p>
                                        </div>
                                    </div>

                                    <div class="text-center mt-4">
                                        <img src="img/kaliboja.jpg" alt="Pemandangan Desa Kaliboja"
                                            class="img-fluid rounded shadow"
                                            onerror="this.src='https://images.unsplash.com/photo-1589652717521-10c0d092dea9?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'">
                                        <p class="text-muted mt-2">Pemandangan alam Desa Kaliboja yang asri</p>
                                    </div>
                                </div>
                            </div>

                            <div class="mt-5">
                                <h4 class="text-primary mb-3">Perkembangan Desa</h4>
                                <div class="timeline">
                                    <div class="timeline-item">
                                        <div class="timeline-date">1950</div>
                                        <div class="timeline-content">
                                            <h5>Pembentukan Desa</h5>
                                            <p>Desa Kaliboja secara resmi dibentuk sebagai bagian dari Kecamatan
                                                Paninggaran</p>
                                        </div>
                                    </div>
                                    <div class="timeline-item">
                                        <div class="timeline-date">1980</div>
                                        <div class="timeline-content">
                                            <h5>Pengembangan Pertanian</h5>
                                            <p>Program intensifikasi pertanian mulai diterapkan</p>
                                        </div>
                                    </div>
                                    <div class="timeline-item">
                                        <div class="timeline-date">2000</div>
                                        <div class="timeline-content">
                                            <h5>Era Modernisasi</h5>
                                            <p>Pembangunan infrastruktur dan akses jalan diperbaiki</p>
                                        </div>
                                    </div>
                                    <div class="timeline-item">
                                        <div class="timeline-date">2020</div>
                                        <div class="timeline-content">
                                            <h5>Digitalisasi Desa</h5>
                                            <p>Penerapan teknologi informasi dalam pelayanan masyarakat</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Data Umum -->
    <section id="data-umum" class="py-5 bg-light">
        <div class="container">
            <h2 class="section-title text-center mb-5">Data Umum Desa</h2>

            <div class="row" data-aos="fade-up">
                <div class="col-lg-12">
                    <div class="card card-elev">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6 mb-4 mb-md-0">
                                    <h4 class="text-primary mb-4"><i class="fas fa-info-circle me-2"></i>Informasi Umum
                                    </h4>
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <tr>
                                                <th>Nama Desa</th>
                                                <td>Kaliboja</td>
                                            </tr>
                                            <tr>
                                                <th>Kecamatan</th>
                                                <td>Paninggaran</td>
                                            </tr>
                                            <tr>
                                                <th>Kabupaten</th>
                                                <td>Pekalongan</td>
                                            </tr>
                                            <tr>
                                                <th>Provinsi</th>
                                                <td>Jawa Tengah</td>
                                            </tr>
                                            <tr>
                                                <th>Kode Pos</th>
                                                <td>51164</td>
                                            </tr>
                                            <tr>
                                                <th>Kode Desa (Kode PUM)</th>
                                                <td>33.26.02.2006</td>
                                            </tr>
                                            <tr>
                                                <th>Koordinat</th>
                                                <td>Bujur: 109.61055, Lintang: -7.196981</td>
                                            </tr>
                                            <tr>
                                                <th>Luas Wilayah</th>
                                                <td>449.208 Ha</td>
                                            </tr>
                                            <tr>
                                                <th>Tipologi Desa</th>
                                                <td>Perladangan</td>
                                            </tr>
                                            <tr>
                                                <th>Klasifikasi Desa</th>
                                                <td>Swadaya</td>
                                            </tr>
                                            <tr>
                                                <th>Kategori Desa</th>
                                                <td>Lanjut</td>
                                            </tr>
                                            <tr>
                                                <th>Komoditas Unggulan</th>
                                                <td>Teh</td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <h4 class="text-primary mb-4"><i class="fas fa-map-marker-alt me-2"></i>Data
                                        Geografis</h4>
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <tr>
                                                <th>Batas Utara</th>
                                                <td>Desa Kaliombo, Paninggaran, Pekalongan</td>
                                            </tr>
                                            <tr>
                                                <th>Batas Selatan</th>
                                                <td>Hutan Negara</td>
                                            </tr>
                                            <tr>
                                                <th>Batas Barat</th>
                                                <td>Desa Lumeneng, Paninggaran, Pekalongan</td>
                                            </tr>
                                            <tr>
                                                <th>Batas Timur</th>
                                                <td>Desa Gunung Langit, Kalibening, Banjarnegara</td>
                                            </tr>
                                            <tr>
                                                <th>Orbitasi</th>
                                                <td>
                                                    <ul class="list-unstyled mb-0">
                                                        <li>Jarak ke Pusat Kecamatan: 11 Km</li>
                                                        <li>Jarak ke Pusat Kabupaten: 37 Km</li>
                                                        <li>Jarak ke Pusat Provinsi: 161 Km</li>
                                                    </ul>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th>Penggunaan Lahan</th>
                                                <td>
                                                    <ul class="list-unstyled mb-0">
                                                        <li>Lahan Sawah: 0 Ha</li>
                                                        <li>Lahan Ladang: 68.520 Ha</li>
                                                        <li>Lahan Perkebunan: 324.760 Ha</li>
                                                        <li>Hutan: 28.430 Ha</li>
                                                        <li>Lahan Lainnya: 27.290 Ha</li>
                                                    </ul>
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Data Kependudukan -->
    <section id="kependudukan" class="py-5">
        <div class="container">
            <h2 class="section-title text-center mb-5">Data Kependudukan</h2>

            <div class="row" data-aos="fade-up">
                <div class="col-lg-12">
                    <div class="card card-elev">
                        <div class="card-body">
                            <div class="row mb-4">
                                <div class="col-md-6 mb-4 mb-md-0">
                                    <div class="data-card bg-light p-4 text-center rounded">
                                        <h3 class="stat-number">512</h3>
                                        <p class="mb-0">Kepala Keluarga</p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="data-card bg-light p-4 text-center rounded">
                                        <h3 class="stat-number">1.792</h3>
                                        <p class="mb-0">Jiwa</p>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-4 mb-md-0">
                                    <h4 class="text-primary mb-4"><i class="fas fa-users me-2"></i>Komposisi Penduduk
                                    </h4>
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <tr>
                                                <th>Laki-laki</th>
                                                <td>894 Jiwa</td>
                                            </tr>
                                            <tr>
                                                <th>Perempuan</th>
                                                <td>904 Jiwa</td>
                                            </tr>
                                            <tr>
                                                <th>Usia 0-17 tahun</th>
                                                <td>454 Jiwa</td>
                                            </tr>
                                            <tr>
                                                <th>Usia 18-56 tahun</th>
                                                <td>1.027 Jiwa</td>
                                            </tr>
                                            <tr>
                                                <th>Usia 56+ tahun</th>
                                                <td>332 Jiwa</td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <h4 class="text-primary mb-4"><i class="fas fa-chart-pie me-2"></i>Tingkat
                                        Kesejahteraan</h4>
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <tr>
                                                <th>Desil Kesejahteraan I</th>
                                                <td>70 KK</td>
                                            </tr>
                                            <tr>
                                                <th>Desil Kesejahteraan II</th>
                                                <td>74 KK</td>
                                            </tr>
                                            <tr>
                                                <th>Desil Kesejahteraan III</th>
                                                <td>66 KK</td>
                                            </tr>
                                            <tr>
                                                <th>Desil Kesejahteraan IV</th>
                                                <td>51 KK</td>
                                            </tr>
                                            <tr>
                                                <th>Desil Kesejahteraan V</th>
                                                <td>61 KK</td>
                                            </tr>
                                            <tr>
                                                <th>Desil Kesejahteraan VI-IX</th>
                                                <td>229 KK</td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <div class="mt-5">
                                <h4 class="text-primary mb-4"><i class="fas fa-briefcase me-2"></i>Mata Pencaharian
                                </h4>
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Jenis Pekerjaan</th>
                                                <th>Jumlah</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Karyawan (PNS)</td>
                                                <td>3 Orang</td>
                                            </tr>
                                            <tr>
                                                <td>Wiraswasta/Pedagang</td>
                                                <td>227 Orang</td>
                                            </tr>
                                            <tr>
                                                <td>Petani</td>
                                                <td>484 Orang</td>
                                            </tr>
                                            <tr>
                                                <td>Buruh Tani</td>
                                                <td>27 Orang</td>
                                            </tr>
                                            <tr>
                                                <td>Peternak</td>
                                                <td>484 Orang</td>
                                            </tr>
                                            <tr>
                                                <td>Jasa</td>
                                                <td>30 Orang</td>
                                            </tr>
                                            <tr>
                                                <td>Pengrajin</td>
                                                <td>13 Orang</td>
                                            </tr>
                                            <tr>
                                                <td>Pensiunan</td>
                                                <td>6 Orang</td>
                                            </tr>
                                            <tr>
                                                <td>Lainnya</td>
                                                <td>35 Orang</td>
                                            </tr>
                                            <tr>
                                                <td>Tidak Bekerja/Penganggur</td>
                                                <td>3 Orang</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Data Aparatur Desa -->
    <section id="aparatur" class="py-5 bg-light">
        <div class="container">
            <h2 class="section-title text-center mb-5">Aparatur Desa</h2>

            <div class="row" data-aos="fade-up">
                <div class="col-lg-12">
                    <div class="card card-elev">
                        <div class="card-body">
                            <h4 class="text-primary mb-4"><i class="fas fa-user-tie me-2"></i>Perangkat Desa</h4>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Jabatan</th>
                                            <th>Nama</th>
                                            <th>Pendidikan</th>
                                            <th>Alamat</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Kepala Desa</td>
                                            <td>ABDULLAH</td>
                                            <td>SLTA</td>
                                            <td>Dk. Kaligenteng, Ds. Kaliboja</td>
                                        </tr>
                                        <tr>
                                            <td>Sekretaris Desa</td>
                                            <td>IWAN NUARI PRASETYO</td>
                                            <td>SLTA</td>
                                            <td>Dk. Semboja Barat, Desa Kaliboja</td>
                                        </tr>
                                        <tr>
                                            <td>Kepala Urusan Keuangan</td>
                                            <td>MOHAMMAD SUBAGYO ZAINUDIN</td>
                                            <td>SLTA</td>
                                            <td>Dk. Semboja Barat, Desa Kaliboja</td>
                                        </tr>
                                        <tr>
                                            <td>Staf Kepala Urusan Keuangan</td>
                                            <td>SUTOPO</td>
                                            <td>SLTA</td>
                                            <td>Dk. Kaligenteng, Desa Kaliboja</td>
                                        </tr>
                                        <tr>
                                            <td>Kepala Urusan Perencanaan dan Umum</td>
                                            <td>BAGUS WALUYO</td>
                                            <td>SLTA</td>
                                            <td>Dk. Silemud, Desa Kaliboja</td>
                                        </tr>
                                        <tr>
                                            <td>Staf Kepala Urusan Perencanaan dan Umum</td>
                                            <td>KATUNG</td>
                                            <td>SLTA</td>
                                            <td>Dk. Kaligenteng, Desa Kaliboja</td>
                                        </tr>
                                        <tr>
                                            <td>Kepala Seksi Pemerintahan</td>
                                            <td>AGUS WIDODO</td>
                                            <td>SLTA</td>
                                            <td>Dk. Semboja Timur, Desa Kaliboja</td>
                                        </tr>
                                        <tr>
                                            <td>Staf Kepala Seksi Pemerintahan</td>
                                            <td>M. WAKHIRI</td>
                                            <td>SLTA</td>
                                            <td>Dk. Kaligenteng, Desa Kaliboja</td>
                                        </tr>
                                        <tr>
                                            <td>Kepala Seksi Kesejahteraan</td>
                                            <td>MUHAMMAD YAHYA</td>
                                            <td>SLTP</td>
                                            <td>Dk. Kaligenteng, Desa Kaliboja</td>
                                        </tr>
                                        <tr>
                                            <td>Staf Kepala Seksi Kesejahteraan</td>
                                            <td>TAMBAS</td>
                                            <td>SLTP</td>
                                            <td>Dk. Silemud, Desa Kaliboja</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <h4 class="text-primary mt-5 mb-4"><i class="fas fa-user-friends me-2"></i>Kepala Dusun
                            </h4>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Dusun</th>
                                            <th>Nama</th>
                                            <th>Pendidikan</th>
                                            <th>Alamat</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Dusun 1</td>
                                            <td>MUZAMIL</td>
                                            <td>SLTA</td>
                                            <td>Dk. Semboja Timur, Desa Kaliboja</td>
                                        </tr>
                                        <tr>
                                            <td>Dusun 2</td>
                                            <td>NIKMAT</td>
                                            <td>SLTA</td>
                                            <td>Dk. Semboja Barat, Desa Kaliboja</td>
                                        </tr>
                                        <tr>
                                            <td>Dusun 3</td>
                                            <td>SRI WARYUTI</td>
                                            <td>SLTA</td>
                                            <td>Dk. Kaligenteng, Desa Kaliboja</td>
                                        </tr>
                                        <tr>
                                            <td>Dusun 4</td>
                                            <td>KOSIM</td>
                                            <td>SLTP</td>
                                            <td>Dk. Silemud, Desa Kaliboja</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <h4 class="text-primary mt-5 mb-4"><i class="fas fa-users-cog me-2"></i>Badan
                                Permusyawaratan
                                Desa (BPD)</h4>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Jabatan</th>
                                            <th>Nama</th>
                                            <th>Pendidikan</th>
                                            <th>Alamat</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Ketua BPD</td>
                                            <td>ISMAN EFENDI</td>
                                            <td>SLTA</td>
                                            <td>Dk. Semboja Barat, Desa Kaliboja</td>
                                        </tr>
                                        <tr>
                                            <td>Wakil Ketua BPD</td>
                                            <td>SOLEMAN</td>
                                            <td>S1 / Sarjana 1</td>
                                            <td>Dk. Kaligenteng, Desa Kaliboja</td>
                                        </tr>
                                        <tr>
                                            <td>Sekretaris BPD</td>
                                            <td>AHMAD ZAINUDIN</td>
                                            <td>SLTA</td>
                                            <td>Dk. Semboja Barat, Desa Kaliboja</td>
                                        </tr>
                                        <tr>
                                            <td>Anggota BPD</td>
                                            <td>M. KHOIRUL IMAM</td>
                                            <td>SLTA</td>
                                            <td>Dk. Semboja Timur, Desa Kaliboja</td>
                                        </tr>
                                        <tr>
                                            <td>Anggota BPD</td>
                                            <td>SRI HIDAYATI</td>
                                            <td>SLTA</td>
                                            <td>Dk. Semboja Timur, Desa Kaliboja</td>
                                        </tr>
                                        <tr>
                                            <td>Anggota BPD</td>
                                            <td>NURUL FALAH</td>
                                            <td>S1 / Sarjana 1</td>
                                            <td>Dk. Kaligenteng, Desa Kaliboja</td>
                                        </tr>
                                        <tr>
                                            <td>Anggota BPD</td>
                                            <td>WARDOTO</td>
                                            <td>SLTA</td>
                                            <td>Dk. Silemud, Desa Kaliboja</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Data Sarana dan Prasarana -->
    <section id="sarana" class="py-5">
        <div class="container">
            <h2 class="section-title text-center mb-5">Sarana dan Prasarana</h2>

            <div class="row" data-aos="fade-up">
                <div class="col-lg-12">
                    <div class="card card-elev">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th width="60%">Jenis Sarana/Prasarana</th>
                                            <th width="40%">Jumlah</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Kesehatan -->
                                        <tr>
                                            <td colspan="2" class="p-0">
                                                <div class="category-header">
                                                    <div class="sarana-icon">
                                                        <i class="fas fa-hospital"></i>
                                                    </div>
                                                    Prasarana Kesehatan
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Poskesdes</td>
                                            <td>1 Unit</td>
                                        </tr>
                                        <tr>
                                            <td>Posyandu dan Polindes</td>
                                            <td>4 Unit</td>
                                        </tr>
                                        
                                        <!-- Pendidikan -->
                                        <tr>
                                            <td colspan="2" class="p-0">
                                                <div class="category-header">
                                                    <div class="sarana-icon">
                                                        <i class="fas fa-school"></i>
                                                    </div>
                                                    Prasarana Pendidikan
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>PAUD</td>
                                            <td>2 Unit</td>
                                        </tr>
                                        <tr>
                                            <td>TK</td>
                                            <td>2 Unit</td>
                                        </tr>
                                        <tr>
                                            <td>SD</td>
                                            <td>1 Unit</td>
                                        </tr>
                                        
                                        <!-- Ibadah -->
                                        <tr>
                                            <td colspan="2" class="p-0">
                                                <div class="category-header">
                                                    <div class="sarana-icon">
                                                        <i class="fas fa-place-of-worship"></i>
                                                    </div>
                                                    Prasarana Ibadah
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Masjid</td>
                                            <td>4 Unit</td>
                                        </tr>
                                        <tr>
                                            <td>Mushola</td>
                                            <td>5 Unit</td>
                                        </tr>
                                        
                                        <!-- Transportasi -->
                                        <tr>
                                            <td colspan="2" class="p-0">
                                                <div class="category-header">
                                                    <div class="sarana-icon">
                                                        <i class="fas fa-road"></i>
                                                    </div>
                                                    Prasarana Transportasi
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Jalan Desa (Aspal/Beton)</td>
                                            <td>3,4 Km</td>
                                        </tr>
                                        
                                        <!-- Air Bersih -->
                                        <tr>
                                            <td colspan="2" class="p-0">
                                                <div class="category-header">
                                                    <div class="sarana-icon">
                                                        <i class="fas fa-tint"></i>
                                                    </div>
                                                    Prasarana Air Bersih
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>PAMSIMAS</td>
                                            <td>4 Unit</td>
                                        </tr>
                                        <tr>
                                            <td>Tangki Air Bersih</td>
                                            <td>3 Unit</td>
                                        </tr>
                                        
                                        <!-- Sanitasi -->
                                        <tr>
                                            <td colspan="2" class="p-0">
                                                <div class="category-header">
                                                    <div class="sarana-icon">
                                                        <i class="fas fa-shower"></i>
                                                    </div>
                                                    Prasarana Sanitasi
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>MCK Umum</td>
                                            <td>1 Unit</td>
                                        </tr>
                                        <tr>
                                            <td>Jamban Keluarga</td>
                                            <td>2 Unit</td>
                                        </tr>
                                        <tr>
                                            <td>Saluran Drainase</td>
                                            <td>4 Unit</td>
                                        </tr>
                                        
                                        <!-- Umum -->
                                        <tr>
                                            <td colspan="2" class="p-0">
                                                <div class="category-header">
                                                    <div class="sarana-icon">
                                                        <i class="fas fa-utensils"></i>
                                                    </div>
                                                    Prasarana Umum
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Olahraga</td>
                                            <td>3 Unit</td>
                                        </tr>
                                        <tr>
                                            <td>Balai Pertemuan</td>
                                            <td>1 Unit</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="mt-0">
        <div class="container py-5">
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <h5 class="text-white mb-4">Desa Kaliboja</h5>
                    <p class="mb-4">Portal resmi desa untuk transparansi informasi, promosi potensi, dan
                        pelayanan digital kepada masyarakat.</p>
                    <div class="d-flex">
                        <a href="https://www.facebook.com/share/17fpGKh173/" target="_blank"
                            class="text-white me-3 hover-lift">
                            <div class="social-icon">
                                <i class="fa-brands fa-facebook-f"></i>
                            </div>
                        </a>
                        <a href="https://www.instagram.com/desa_kaliboja?igsh=MTB2enB2N3I4dGp2OA==" target="_blank"
                            class="text-white me-3 hover-lift">
                            <div class="social-icon">
                                <i class="fa-brands fa-instagram"></i>
                            </div>
                        </a>
                        <a href="https://x.com/desa_kaliboja?t=taTDsUWdhSoPbIiqADFfyQ&s=09&fbclid=PAdGRjcAMvYX1leHRuA2FlbQIxMQABp9AdVHP8awNqQGOky0UFUiiEt9za1hiL0Wldzmpg5X_LPj7CyczURUw5Jk2f_aem_r-xoS5uVycPxEOxfhEjr2A"
                            target="_blank" class="text-white me-3 hover-lift">
                            <div class="social-icon">
                                <i class="fa-brands fa-x-twitter"></i>
                            </div>
                        </a>
                        <a href="https://www.tiktok.com/@desa_kaliboja?fbclid=PAdGRjcAMvYeNleHRuA2FlbQIxMQABp-jUXBxjp43fgoeGN6x01EfX3g1Nj10GpaTEukdsoluv5Zt4yNimvhdrphwe_aem_5lvWmF8h8HUWv1miYT-y0A"
                            target="_blank" class="text-white hover-lift">
                            <div class="social-icon">
                                <i class="fa-brands fa-tiktok"></i>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <h5 class="text-white mb-4">Kontak</h5>
                    <ul class="list-unstyled small">
                        <li class="mb-2"><i class="fa-solid fa-location-dot me-2"></i>Desa Kaliboja,
                            Kec. Paninggaran,
                            Kabupaten Pekalongan, Jawa Tengah</li>
                        <li class="mb-2"><i class="fa-solid fa-envelope me-2"></i>kalibojadesa@gmail.com
                        </li>
                        <li><i class="fa-solid fa-clock me-2"></i>Senin - Jumat: 08:00 - 16:00</li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-12">
                    <h5 class="text-white mb-4">Tautan Cepat</h5>
                    <div class="row">
                        <div class="col-6">
                            <ul class="list-unstyled small">
                                <li class="mb-2"><a href="#berita"
                                        class="hover-lift text-white text-decoration-none">Berita</a></li>
                                <li class="mb-2"><a href="#wisata"
                                        class="hover-lift text-white text-decoration-none">Wisata</a></li>
                                <li class="mb-2"><a href="#produk"
                                        class="hover-lift text-white text-decoration-none">Produk</a></li>
                                <li class="mb-2"><a href="#layanan"
                                        class="hover-lift text-white text-decoration-none">Layanan</a></li>
                                <li class="mb-2"><a href="#jdih"
                                        class="hover-lift text-white text-decoration-none">JDIH</a></li>
                            </ul>
                        </div>
                        <div class="col-6">
                            <ul class="list-unstyled small">
                                <li class="mb-2"><a href="#rkp"
                                        class="hover-lift text-white text-decoration-none">RKP</a></li>
                                <li class="mb-2"><a href="#koperasi"
                                        class="hover-lift text-white text-decoration-none">Koperasi</a></li>
                                <li class="mb-2"><a href="#profil"
                                        class="hover-lift text-white text-decoration-none">Profil</a></li>
                                <li class="mb-2"><a href="#galeri"
                                        class="hover-lift text-white text-decoration-none">Galeri</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <hr class="border-secondary my-4">
            <div class="text-center small">
                <div class="mb-2">&copy; 2025 Pemerintah Desa Kaliboja. All Rights Reserved.
                </div>
                <div>Dikembangkan oleh <a href="#" class="text-white hover-lift text-decoration-none">Tim IT KKN 4
                        Kelompok 7
                        Desa Kaliboja</a></div>
            </div>
        </div>
    </footer>

    <!-- Floating WA & To Top -->
    <a class="wa-float btn btn-success rounded-circle shadow" href="https://wa.me/" target="_blank"
        title="Hubungi via WhatsApp">
        <i class="fa-brands fa-whatsapp fa-lg"></i>
    </a>

    <button id="toTop" class="to-top btn btn-primary rounded-circle shadow" title="Kembali ke atas">
        <i class="fa-solid fa-arrow-up"></i>
    </button>

    <!-- Loading Spinner -->
    <div class="loading-spinner"
        style="position:fixed;top:0;left:0;width:100%;height:100%;background:white;z-index:9999;display:flex;align-items:center;justify-content:center;transition:opacity 0.5s ease">
        <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
    // Inisialisasi AOS dengan konfigurasi yang benar
    document.addEventListener('DOMContentLoaded', function() {
        // Inisialisasi AOS
        AOS.init({
            once: true,
            duration: 1000,
            offset: 100,
            easing: 'ease-out-back'
        });

        // Loading spinner
        window.addEventListener('load', function() {
            const spinner = document.querySelector('.loading-spinner');
            if (spinner) {
                spinner.style.opacity = '0';
                setTimeout(function() {
                    spinner.style.display = 'none';
                }, 500);
            }
        });

        // Scroll effects & to top
        const toTop = document.getElementById('toTop');
        const navbar = document.querySelector('.navbar');

        if (toTop && navbar) {
            window.addEventListener('scroll', () => {
                toTop.style.display = window.scrollY > 400 ? 'block' : 'none';
                if (window.scrollY > 100) {
                    navbar.classList.add('scrolled');
                } else {
                    navbar.classList.remove('scrolled');
                }
            });

            toTop.addEventListener('click', (e) => {
                e.preventDefault();
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            });
        }

        // Dark mode toggle
        const darkToggle = document.getElementById('darkToggle');
        if (darkToggle) {
            darkToggle.addEventListener('click', () => {
                document.body.classList.toggle('dark');
                const icon = darkToggle.querySelector('i');
                if (document.body.classList.contains('dark')) {
                    icon.classList.remove('fa-moon');
                    icon.classList.add('fa-sun');
                } else {
                    icon.classList.remove('fa-sun');
                    icon.classList.add('fa-moon');
                }
            });
        }

        // Smooth scroll untuk navigasi
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                const targetId = this.getAttribute('href');
                if (targetId === '#' || targetId === '#!') return;

                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    e.preventDefault();
                    const navbarHeight = document.querySelector('.navbar').offsetHeight;
                    const targetPosition = targetElement.getBoundingClientRect().top + window
                        .pageYOffset - navbarHeight;

                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                }
            });
        });

        // Close mobile menu when clicking on a nav link
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                const navbarCollapse = document.getElementById('navMenu');
                if (navbarCollapse && navbarCollapse.classList.contains('show')) {
                    const navbarToggler = document.querySelector('.navbar-toggler');
                    if (navbarToggler) navbarToggler.click();
                }
            });
        });

        // Cegah horizontal scrolling pada mobile
        function checkMobileWidth() {
            if (window.innerWidth <= 576) {
                document.body.style.overflowX = 'hidden';
            } else {
                document.body.style.overflowX = 'visible';
            }
        }

        window.addEventListener('resize', checkMobileWidth);
        checkMobileWidth();
    });
    </script>
    <script>
// Deteksi Internet Explorer
function isIE() {
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf('MSIE ');
    var trident = ua.indexOf('Trident/');
    return (msie > 0 || trident > 0);
}

// Tampilkan peringatan jika menggunakan IE
if (isIE()) {
    alert('Website ini bekerja paling baik dengan browser modern. Silakan pertimbangkan untuk menggunakan Chrome, Firefox, atau browser lainnya.');
}
</script>
</body>

</html>