<?= $this->extend('layout/main_layout') ?>

<?= $this->section('content') ?>
<!-- Breadcrumb -->
<nav aria-label="breadcrumb" class="bg-light py-3">
    <div class="container">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="<?= site_url() ?>">Beranda</a></li>
            <li class="breadcrumb-item"><a href="<?= site_url('koperasi') ?>">Koperasi</a></li>
            <li class="breadcrumb-item active" aria-current="page">Unit Usaha</li>
        </ol>
    </div>
</nav>

<!-- Header -->
<section class="py-5 bg-danger text-white">
    <div class="container py-4">
        <h1 class="display-5 fw-bold mb-3">Unit Usaha Koperasi</h1>
        <p class="lead">Produk dan layanan unggulan untuk kebutuhan sehari-hari dengan harga terjangkau</p>
    </div>
</section>

<!-- Filter -->
<section class="py-4 bg-light">
    <div class="container">
        <div class="row g-3">
            <div class="col-md-8">
                <form method="get" action="<?= site_url('koperasi/unit-usaha') ?>" class="row g-2">
                    <div class="col-md-6">
                        <select name="kategori" class="form-select" onchange="this.form.submit()">
                            <option value="">Semua Kategori</option>
                            <?php foreach($kategories as $kat): ?>
                            <option value="<?= $kat ?>" <?= ($currentKategori == $kat) ? 'selected' : '' ?>>
                                <?= ucwords(str_replace('-', ' ', $kat)) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <div class="input-group">
                            <input type="text" 
                                   name="search" 
                                   class="form-control" 
                                   placeholder="Cari produk..."
                                   value="<?= esc($searchTerm ?? '') ?>">
                            <button class="btn btn-danger" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-md-4">
                <div class="d-flex justify-content-end">
                    <div class="btn-group" role="group">
                        <button type="button" class="btn btn-outline-danger active" onclick="changeView('grid')">
                            <i class="fas fa-th-large"></i>
                        </button>
                        <button type="button" class="btn btn-outline-danger" onclick="changeView('list')">
                            <i class="fas fa-list"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Kategori -->
<section class="py-3">
    <div class="container">
        <div class="d-flex flex-wrap gap-2 mb-4">
            <a href="<?= site_url('koperasi/unit-usaha') ?>" 
               class="btn btn-sm <?= empty($currentKategori) ? 'btn-danger' : 'btn-outline-danger' ?>">
                Semua
            </a>
            <?php foreach($kategories as $kat): ?>
            <a href="<?= site_url('koperasi/unit-usaha?kategori=' . $kat) ?>" 
               class="btn btn-sm <?= ($currentKategori == $kat) ? 'btn-danger' : 'btn-outline-danger' ?>">
                <?= ucwords(str_replace('-', ' ', $kat)) ?>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Unit Usaha Grid View -->
<section id="gridView" class="py-5">
    <div class="container">
        <?php if(!empty($units)): ?>
        <div class="row g-4">
            <?php foreach($units as $unit): ?>
            <div class="col-xl-3 col-lg-4 col-md-6">
                <div class="card h-100 border-0 shadow-sm hover-lift">
                    <div class="position-relative">
                        <img src="<?= base_url('uploads/koperasi/unit/' . ($unit['gambar'] ?? '')) ?>" 
                             class="card-img-top" 
                             alt="<?= esc($unit['nama_unit']) ?>"
                             style="height: 200px; object-fit: cover;"
                             onerror="this.src='https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80'">
                        <div class="position-absolute top-0 start-0 m-2">
                            <span class="badge bg-danger"><?= esc($unit['kategori'] ?? 'Umum') ?></span>
                        </div>
                        <?php if($unit['status'] == 'habis'): ?>
                        <div class="position-absolute top-0 end-0 m-2">
                            <span class="badge bg-warning">Habis</span>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title fw-bold"><?= esc($unit['nama_unit']) ?></h5>
                        <p class="card-text text-muted small">
                            <?= character_limiter(strip_tags($unit['deskripsi'] ?? ''), 80) ?>
                        </p>
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h5 class="text-danger mb-0">Rp <?= number_format($unit['harga'], 0, ',', '.') ?></h5>
                                <small class="text-muted">per <?= esc($unit['satuan']) ?></small>
                            </div>
                            <span class="badge bg-info">Stok: <?= number_format($unit['stok']) ?></span>
                        </div>
                    </div>
                    <div class="card-footer bg-transparent border-0 pt-0">
                        <div class="d-grid gap-2">
                            <a href="<?= site_url('koperasi/detail/' . $unit['id']) ?>" 
                               class="btn btn-danger">
                                <i class="fas fa-eye me-2"></i>Detail Produk
                            </a>
                            <?php if($unit['status'] == 'tersedia' && $unit['stok'] > 0): ?>
                            <button class="btn btn-outline-danger" onclick="addToCart(<?= $unit['id'] ?>)">
                                <i class="fas fa-cart-plus me-2"></i>Tambah Keranjang
                            </button>
                            <?php else: ?>
                            <button class="btn btn-outline-secondary" disabled>
                                <i class="fas fa-times me-2"></i>Tidak Tersedia
                            </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Pagination -->
        <div class="mt-5">
            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center">
                    <li class="page-item disabled">
                        <a class="page-link" href="#" tabindex="-1">Previous</a>
                    </li>
                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                    <li class="page-item">
                        <a class="page-link" href="#">Next</a>
                    </li>
                </ul>
            </nav>
        </div>
        <?php else: ?>
        <div class="text-center py-5">
            <i class="fas fa-box-open fa-3x text-muted mb-3"></i>
            <h4 class="text-muted">Tidak ada unit usaha</h4>
            <p class="text-muted mb-4">Silakan pilih kategori lain atau gunakan kata kunci pencarian berbeda</p>
            <a href="<?= site_url('koperasi/unit-usaha') ?>" class="btn btn-danger">
                <i class="fas fa-sync me-2"></i>Reset Pencarian
            </a>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- Unit Usaha List View (Hidden by default) -->
<section id="listView" class="py-5 d-none">
    <div class="container">
        <?php if(!empty($units)): ?>
        <div class="list-group">
            <?php foreach($units as $unit): ?>
            <div class="list-group-item list-group-item-action border-0 shadow-sm mb-3">
                <div class="row g-3 align-items-center">
                    <div class="col-md-2">
                        <img src="<?= base_url('uploads/koperasi/unit/' . ($unit['gambar'] ?? '')) ?>" 
                             class="img-fluid rounded" 
                             alt="<?= esc($unit['nama_unit']) ?>"
                             style="height: 120px; object-fit: cover;"
                             onerror="this.src='https://via.placeholder.com/150x120?text=Produk'">
                    </div>
                    <div class="col-md-6">
                        <h5 class="fw-bold mb-1"><?= esc($unit['nama_unit']) ?></h5>
                        <p class="text-muted small mb-2"><?= character_limiter(strip_tags($unit['deskripsi'] ?? ''), 150) ?></p>
                        <div class="d-flex gap-2">
                            <span class="badge bg-danger"><?= esc($unit['kategori'] ?? 'Umum') ?></span>
                            <?php if($unit['status'] == 'habis'): ?>
                            <span class="badge bg-warning">Habis</span>
                            <?php endif; ?>
                            <span class="badge bg-info">Stok: <?= number_format($unit['stok']) ?></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="text-end">
                            <h4 class="text-danger mb-2">Rp <?= number_format($unit['harga'], 0, ',', '.') ?></h4>
                            <small class="text-muted d-block mb-3">per <?= esc($unit['satuan']) ?></small>
                            <div class="d-flex gap-2">
                                <a href="<?= site_url('koperasi/detail/' . $unit['id']) ?>" 
                                   class="btn btn-sm btn-danger flex-fill">
                                    <i class="fas fa-eye me-1"></i>Detail
                                </a>
                                <?php if($unit['status'] == 'tersedia' && $unit['stok'] > 0): ?>
                                <button class="btn btn-sm btn-outline-danger flex-fill" 
                                        onclick="addToCart(<?= $unit['id'] ?>)">
                                    <i class="fas fa-cart-plus me-1"></i>Beli
                                </button>
                                <?php else: ?>
                                <button class="btn btn-sm btn-outline-secondary flex-fill" disabled>
                                    <i class="fas fa-times me-1"></i>Habis
                                </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- Info Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-4">
                <div class="text-center">
                    <div class="rounded-circle bg-danger d-inline-flex align-items-center justify-content-center mb-3" 
                         style="width: 70px; height: 70px;">
                        <i class="fas fa-shipping-fast fa-2x text-white"></i>
                    </div>
                    <h5 class="fw-bold">Pengiriman Cepat</h5>
                    <p class="text-muted small">Gratis ongkir untuk anggota dalam wilayah desa</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="text-center">
                    <div class="rounded-circle bg-danger d-inline-flex align-items-center justify-content-center mb-3" 
                         style="width: 70px; height: 70px;">
                        <i class="fas fa-percentage fa-2x text-white"></i>
                    </div>
                    <h5 class="fw-bold">Harga Anggota</h5>
                    <p class="text-muted small">Diskon khusus untuk anggota koperasi</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="text-center">
                    <div class="rounded-circle bg-danger d-inline-flex align-items-center justify-content-center mb-3" 
                         style="width: 70px; height: 70px;">
                        <i class="fas fa-handshake fa-2x text-white"></i>
                    </div>
                    <h5 class="fw-bold">Kualitas Terjamin</h5>
                    <p class="text-muted small">Produk berkualitas dengan standar terbaik</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Cart Modal -->
<div class="modal fade" id="cartModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-shopping-cart me-2"></i>Keranjang Belanja</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="cartItems"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                <a href="#" class="btn btn-danger">Checkout</a>
            </div>
        </div>
    </div>
</div>

<script>
// View toggle
function changeView(view) {
    if (view === 'grid') {
        document.getElementById('gridView').classList.remove('d-none');
        document.getElementById('listView').classList.add('d-none');
        document.querySelectorAll('.btn-group .btn').forEach(btn => btn.classList.remove('active'));
        document.querySelector('.btn-group .btn:first-child').classList.add('active');
    } else {
        document.getElementById('gridView').classList.add('d-none');
        document.getElementById('listView').classList.remove('d-none');
        document.querySelectorAll('.btn-group .btn').forEach(btn => btn.classList.remove('active'));
        document.querySelector('.btn-group .btn:last-child').classList.add('active');
    }
}

// Add to cart function
function addToCart(productId) {
    // Show loading
    const btn = event.target;
    const originalText = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Menambah...';
    btn.disabled = true;
    
    // Simulate API call
    setTimeout(() => {
        // Show success message
        const toast = document.createElement('div');
        toast.className = 'position-fixed bottom-0 end-0 p-3';
        toast.style.zIndex = '11';
        toast.innerHTML = `
            <div class="toast show" role="alert">
                <div class="toast-header bg-success text-white">
                    <strong class="me-auto"><i class="fas fa-check-circle me-2"></i>Berhasil!</strong>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
                </div>
                <div class="toast-body">
                    Produk berhasil ditambahkan ke keranjang
                </div>
            </div>
        `;
        document.body.appendChild(toast);
        
        // Remove toast after 3 seconds
        setTimeout(() => {
            toast.remove();
        }, 3000);
        
        // Reset button
        btn.innerHTML = originalText;
        btn.disabled = false;
    }, 500);
}

// Initialize cart
let cart = JSON.parse(localStorage.getItem('koperasiCart')) || [];

// Update cart display
function updateCartDisplay() {
    const cartItems = document.getElementById('cartItems');
    if (cartItems) {
        if (cart.length === 0) {
            cartItems.innerHTML = `
                <div class="text-center py-4">
                    <i class="fas fa-shopping-cart fa-3x text-muted mb-3"></i>
                    <p class="text-muted">Keranjang belanja kosong</p>
                </div>
            `;
        } else {
            // Show cart items
            cartItems.innerHTML = cart.map(item => `
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div>
                        <h6 class="mb-0">${item.name}</h6>
                        <small class="text-muted">${item.qty} x Rp ${item.price.toLocaleString('id-ID')}</small>
                    </div>
                    <div>
                        <span class="fw-bold">Rp ${(item.qty * item.price).toLocaleString('id-ID')}</span>
                    </div>
                </div>
            `).join('');
        }
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    updateCartDisplay();
});
</script>

<style>
.hover-lift {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.hover-lift:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.1) !important;
}
.list-group-item {
    transition: all 0.3s ease;
}
.list-group-item:hover {
    transform: translateX(5px);
}
</style>
<?= $this->endSection() ?>