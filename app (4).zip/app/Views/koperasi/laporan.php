<?= $this->extend('layout/main_layout') ?>

<?= $this->section('content') ?>
<div class="container py-5">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= site_url('/') ?>">Beranda</a></li>
            <li class="breadcrumb-item"><a href="<?= site_url('koperasi') ?>">Koperasi</a></li>
            <li class="breadcrumb-item active" aria-current="page">Laporan</li>
        </ol>
    </nav>

    <h1 class="mb-4">Laporan Koperasi</h1>
    
    <!-- Filter -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form method="get" action="<?= site_url('koperasi/laporan') ?>">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Tahun</label>
                        <select name="tahun" class="form-select">
                            <option value="">Semua Tahun</option>
                            <?php foreach($tahun_list as $tahun_item): ?>
                            <option value="<?= $tahun_item ?>" <?= ($currentTahun == $tahun_item) ? 'selected' : '' ?>>
                                <?= $tahun_item ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Jenis Laporan</label>
                        <select name="jenis" class="form-select">
                            <option value="">Semua Jenis</option>
                            <option value="RAT" <?= ($currentJenis == 'RAT') ? 'selected' : '' ?>>RAT</option>
                            <option value="keuangan" <?= ($currentJenis == 'keuangan') ? 'selected' : '' ?>>Keuangan</option>
                            <option value="tahunan" <?= ($currentJenis == 'tahunan') ? 'selected' : '' ?>>Tahunan</option>
                            <option value="bulanan" <?= ($currentJenis == 'bulanan') ? 'selected' : '' ?>>Bulanan</option>
                            <option value="khusus" <?= ($currentJenis == 'khusus') ? 'selected' : '' ?>>Khusus</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3 d-flex align-items-end">
                        <button type="submit" class="btn btn-danger w-100">
                            <i class="fas fa-filter me-2"></i>Filter
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Laporan List -->
    <?php if(!empty($laporan)): ?>
    <div class="row g-4">
        <?php foreach($laporan as $item): ?>
        <div class="col-md-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <h5 class="card-title"><?= esc($item['judul']) ?></h5>
                            <span class="badge bg-danger"><?= esc($item['jenis']) ?></span>
                            <?php if($item['bulan']): ?>
                            <span class="badge bg-info ms-2">Bulan <?= $item['bulan'] ?></span>
                            <?php endif; ?>
                        </div>
                        <span class="badge bg-secondary"><?= esc($item['tahun']) ?></span>
                    </div>
                    
                    <p class="card-text text-muted"><?= character_limiter(strip_tags($item['deskripsi']), 150) ?></p>
                    
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <small class="text-muted">
                            <i class="far fa-calendar me-1"></i>
                            <?= date('d M Y', strtotime($item['created_at'])) ?>
                        </small>
                        
                        <a href="<?= site_url('koperasi/download/' . $item['id']) ?>" class="btn btn-sm btn-outline-danger">
                            <i class="fas fa-download me-1"></i>Download
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="text-center py-5">
        <i class="fas fa-file-alt fa-4x text-muted mb-3"></i>
        <h4 class="text-muted">Tidak ada laporan ditemukan</h4>
        <p class="text-muted">Coba pilih tahun atau jenis laporan yang berbeda.</p>
    </div>
    <?php endif; ?>
    
    <!-- Jenis Laporan -->
    <div class="mt-5">
        <h5 class="mb-3">Jenis Laporan Koperasi:</h5>
        <div class="row">
            <div class="col-md-4 mb-3">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-users fa-3x text-danger mb-3"></i>
                        <h5>RAT</h5>
                        <p class="text-muted small">Laporan Rapat Anggota Tahunan</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-chart-line fa-3x text-danger mb-3"></i>
                        <h5>Keuangan</h5>
                        <p class="text-muted small">Laporan keuangan bulanan/tahunan</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-project-diagram fa-3x text-danger mb-3"></i>
                        <h5>Kegiatan</h5>
                        <p class="text-muted small">Laporan kegiatan dan perkembangan</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>