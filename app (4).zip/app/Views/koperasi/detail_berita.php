<?= $this->extend('layout/main_layout') ?>

<?= $this->section('content') ?>
<div class="container py-5">
    <div class="row">
        <!-- Main Content -->
        <div class="col-lg-8">
            <nav aria-label="breadcrumb" class="mb-4">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= site_url('koperasi') ?>">Koperasi</a></li>
                    <li class="breadcrumb-item"><a href="<?= site_url('koperasi/berita') ?>">Berita</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Detail Berita</li>
                </ol>
            </nav>

            <!-- Tombol Kembali -->
            <div class="mb-3">
                <a href="<?= site_url('koperasi/berita') ?>" class="btn btn-outline-danger">
                    <i class="fas fa-arrow-left me-2"></i>Kembali ke Berita
                </a>
            </div>

            <article class="blog-post">
                <h1 class="fw-bold mb-3"><?= esc($berita['judul']) ?></h1>
                
                <div class="d-flex align-items-center mb-4">
                    <div class="me-3">
                        <i class="far fa-calendar me-1"></i>
                        <span><?= date('d F Y', strtotime($berita['created_at'])) ?></span>
                    </div>
                    <div>
                        <i class="far fa-clock me-1"></i>
                        <span><?= date('H:i', strtotime($berita['created_at'])) ?> WIB</span>
                    </div>
                    <?php if(isset($berita['views']) && $berita['views'] > 0): ?>
                    <div class="ms-3">
                        <i class="far fa-eye me-1"></i>
                        <span><?= number_format($berita['views']) ?> views</span>
                    </div>
                    <?php endif; ?>
                </div>

                <?php if(!empty($berita['gambar'])): ?>
                <div class="mb-4">
                    <img src="<?= base_url('uploads/koperasi/berita/' . $berita['gambar']) ?>" 
                         class="img-fluid rounded shadow" 
                         alt="<?= esc($berita['judul']) ?>"
                         onerror="this.src='https://images.unsplash.com/photo-1559136555-9303baea8ebd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'">
                </div>
                <?php endif; ?>

                <div class="blog-content mb-5">
                    <?= $berita['konten'] ?>
                </div>

                <div class="card border-0 bg-light mb-4">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-3">Bagikan Berita Ini</h5>
                        <div class="d-flex gap-2 flex-wrap">
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?= current_url() ?>" 
                               target="_blank" 
                               class="btn btn-primary btn-sm">
                                <i class="fab fa-facebook-f me-1"></i> Facebook
                            </a>
                            <a href="https://twitter.com/intent/tweet?url=<?= current_url() ?>&text=<?= urlencode($berita['judul']) ?>" 
                               target="_blank" 
                               class="btn btn-info btn-sm">
                                <i class="fab fa-twitter me-1"></i> Twitter
                            </a>
                            <a href="https://wa.me/?text=<?= urlencode($berita['judul'] . ' - ' . current_url()) ?>" 
                               target="_blank" 
                               class="btn btn-success btn-sm">
                                <i class="fab fa-whatsapp me-1"></i> WhatsApp
                            </a>
                            <button onclick="copyLink()" class="btn btn-secondary btn-sm">
                                <i class="fas fa-link me-1"></i> Salin Link
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Navigasi Berita -->
                <div class="d-flex justify-content-between mb-4">
                    <a href="<?= site_url('koperasi/berita') ?>" class="btn btn-outline-danger">
                        <i class="fas fa-arrow-left me-2"></i>Semua Berita
                    </a>
                    <a href="<?= site_url('koperasi') ?>" class="btn btn-danger">
                        <i class="fas fa-home me-2"></i>Kembali ke Beranda
                    </a>
                </div>
            </article>
        </div>

        <!-- Sidebar -->
        <div class="col-lg-4">
            <!-- Berita Terkait -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-danger text-white">
                    <h5 class="mb-0"><i class="fas fa-newspaper me-2"></i>Berita Terkait</h5>
                </div>
                <div class="card-body">
                    <?php if(!empty($berita_terkait)): ?>
                    <div class="list-group list-group-flush">
                        <?php foreach($berita_terkait as $item): ?>
                        <a href="<?= site_url('koperasi/berita/' . $item['slug']) ?>" 
                           class="list-group-item list-group-item-action border-0 px-0">
                            <div class="d-flex w-100">
                                <?php if(!empty($item['gambar'])): ?>
                                <img src="<?= base_url('uploads/koperasi/berita/' . $item['gambar']) ?>" 
                                     class="rounded me-3" 
                                     style="width: 80px; height: 60px; object-fit: cover;"
                                     alt="<?= esc($item['judul']) ?>"
                                     onerror="this.src='https://via.placeholder.com/80x60?text=Gambar'">
                                <?php endif; ?>
                                <div class="flex-grow-1">
                                    <h6 class="mb-1"><?= character_limiter(esc($item['judul']), 50) ?></h6>
                                    <small class="text-muted">
                                        <i class="far fa-calendar me-1"></i>
                                        <?= date('d M Y', strtotime($item['created_at'])) ?>
                                    </small>
                                </div>
                            </div>
                        </a>
                        <?php endforeach; ?>
                    </div>
                    <?php else: ?>
                    <p class="text-muted text-center mb-0">Tidak ada berita terkait</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Info Koperasi -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i>Info Koperasi</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <h6 class="fw-bold"><?= esc($profile['nama_koperasi'] ?? 'Koperasi Merah Putih') ?></h6>
                        <p class="text-muted small mb-0">
                            <?= character_limiter(strip_tags($profile['sejarah'] ?? 'Koperasi Merah Putih Desa Kaliboja'), 100) ?>
                        </p>
                    </div>
                    <div class="d-grid gap-2">
                        <a href="<?= site_url('koperasi/profil') ?>" class="btn btn-outline-danger">
                            <i class="fas fa-building me-1"></i>Profil Lengkap
                        </a>
                        <a href="<?= site_url('koperasi/unit-usaha') ?>" class="btn btn-outline-info">
                            <i class="fas fa-boxes me-1"></i>Unit Usaha
                        </a>
                        <a href="<?= site_url('koperasi/keanggotaan') ?>" class="btn btn-outline-success">
                            <i class="fas fa-user-plus me-1"></i>Daftar Anggota
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function copyLink() {
    const url = window.location.href;
    navigator.clipboard.writeText(url).then(function() {
        alert('Link berhasil disalin!');
    }, function() {
        // Fallback untuk browser lama
        const textArea = document.createElement("textarea");
        textArea.value = url;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        alert('Link berhasil disalin!');
    });
}
</script>

<style>
.blog-content {
    line-height: 1.8;
    font-size: 1.1rem;
}
.blog-content img {
    max-width: 100%;
    height: auto;
    border-radius: 8px;
    margin: 1rem 0;
}
.blog-content h2, 
.blog-content h3, 
.blog-content h4 {
    margin-top: 2rem;
    margin-bottom: 1rem;
    color: #343a40;
}
.blog-content p {
    margin-bottom: 1.5rem;
}
.blog-content ul, 
.blog-content ol {
    margin-bottom: 1.5rem;
    padding-left: 1.5rem;
}
.blog-content blockquote {
    border-left: 4px solid #dc3545;
    padding-left: 1rem;
    margin: 1.5rem 0;
    font-style: italic;
    color: #6c757d;
}
.list-group-item:hover {
    background-color: #f8f9fa;
    transform: translateX(5px);
    transition: all 0.3s ease;
}
</style>
<?= $this->endSection() ?>