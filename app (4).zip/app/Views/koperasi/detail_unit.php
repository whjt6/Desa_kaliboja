<?= $this->extend('layout/main_layout') ?>

<?= $this->section('content') ?>
<!-- Breadcrumb -->
<nav aria-label="breadcrumb" class="bg-light py-3">
    <div class="container">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="<?= site_url() ?>">Beranda</a></li>
            <li class="breadcrumb-item"><a href="<?= site_url('koperasi') ?>">Koperasi</a></li>
            <li class="breadcrumb-item"><a href="<?= site_url('koperasi/unit-usaha') ?>">Unit Usaha</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= esc($unit['nama_unit']) ?></li>
        </ol>
    </div>
</nav>

<div class="container py-5">
    <!-- Tombol Kembali -->
    <div class="mb-4">
        <a href="<?= site_url('koperasi/unit-usaha') ?>" class="btn btn-outline-danger">
            <i class="fas fa-arrow-left me-2"></i>Kembali ke Unit Usaha
        </a>
    </div>

    <div class="row">
        <!-- Gambar & Info Utama -->
        <div class="col-lg-6 mb-4">
            <div class="card border-0 shadow-sm">
                <img src="<?= base_url('uploads/koperasi/unit/' . ($unit['gambar'] ?? '')) ?>" 
                     class="card-img-top" 
                     alt="<?= esc($unit['nama_unit']) ?>"
                     style="height: 400px; object-fit: cover;"
                     onerror="this.src='https://images.unsplash.com/photo-1586864387634-6b7fb11a29ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'">
            </div>
        </div>

        <!-- Detail Produk -->
        <div class="col-lg-6">
            <div class="mb-3">
                <span class="badge bg-info"><?= ucwords(str_replace('-', ' ', $unit['kategori'])) ?></span>
                <span class="badge ms-2 bg-<?= $unit['status'] == 'tersedia' ? 'success' : ($unit['status'] == 'habis' ? 'warning' : 'info') ?>">
                    <?= ucfirst($unit['status']) ?>
                </span>
            </div>

            <h1 class="display-5 fw-bold mb-3"><?= esc($unit['nama_unit']) ?></h1>
            
            <div class="mb-4">
                <small class="text-muted">Kode Unit: <?= esc($unit['kode_unit']) ?></small>
            </div>

            <div class="bg-light rounded p-4 mb-4">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <p class="text-muted mb-1">Harga</p>
                        <h2 class="text-danger fw-bold mb-0">
                            Rp <?= number_format($unit['harga'], 0, ',', '.') ?>
                            <small class="text-muted fs-6">/<?= esc($unit['satuan']) ?></small>
                        </h2>
                    </div>
                    <div class="text-end">
                        <p class="text-muted mb-1">Stok Tersedia</p>
                        <h4 class="mb-0"><?= number_format($unit['stok']) ?> <?= esc($unit['satuan']) ?></h4>
                    </div>
                </div>
            </div>

            <div class="mb-4">
                <h5 class="fw-bold mb-3">Deskripsi Produk</h5>
                <p class="text-muted"><?= nl2br(esc($unit['deskripsi'])) ?></p>
            </div>

            <!-- Kontak Action -->
            <div class="d-grid gap-3">
                <a href="https://wa.me/<?= esc($profile['whatsapp'] ?? '628123456789') ?>?text=<?= urlencode('Halo, saya tertarik dengan ' . $unit['nama_unit']) ?>" 
                   target="_blank" 
                   class="btn btn-success btn-lg">
                    <i class="fab fa-whatsapp me-2"></i>Pesan via WhatsApp
                </a>
                <a href="tel:<?= esc($profile['telepon'] ?? '0285123456') ?>" 
                   class="btn btn-outline-danger btn-lg">
                    <i class="fas fa-phone me-2"></i>Hubungi Telepon
                </a>
            </div>
        </div>
    </div>

    <!-- Detail Tambahan -->
    <div class="row mt-5">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <h4 class="fw-bold mb-4">Informasi Lengkap</h4>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <div class="d-flex">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-tag fa-2x text-danger"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h6 class="fw-bold">Kategori</h6>
                                    <p class="text-muted mb-0"><?= ucwords(str_replace('-', ' ', $unit['kategori'])) ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="d-flex">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-cube fa-2x text-danger"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h6 class="fw-bold">Satuan</h6>
                                    <p class="text-muted mb-0"><?= esc($unit['satuan']) ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="d-flex">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-box fa-2x text-danger"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h6 class="fw-bold">Stok</h6>
                                    <p class="text-muted mb-0"><?= number_format($unit['stok']) ?> <?= esc($unit['satuan']) ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="d-flex">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-check-circle fa-2x text-success"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h6 class="fw-bold">Status</h6>
                                    <p class="text-muted mb-0"><?= ucfirst($unit['status']) ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Unit Usaha Terkait -->
    <?php if(!empty($relatedUnits)): ?>
    <div class="mt-5">
        <h3 class="fw-bold mb-4">Produk Terkait</h3>
        <div class="row g-4">
            <?php foreach($relatedUnits as $related): ?>
            <div class="col-lg-3 col-md-6">
                <div class="card h-100 border-0 shadow-sm hover-lift">
                    <div class="position-relative">
                        <img src="<?= base_url('uploads/koperasi/unit/' . ($related['gambar'] ?? '')) ?>" 
                             class="card-img-top" 
                             alt="<?= esc($related['nama_unit']) ?>"
                             style="height: 180px; object-fit: cover;"
                             onerror="this.src='https://images.unsplash.com/photo-1586864387634-6b7fb11a29ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80'">
                        <div class="position-absolute top-0 end-0 m-2">
                            <span class="badge bg-<?= $related['status'] == 'tersedia' ? 'success' : 'warning' ?>">
                                <?= ucfirst($related['status']) ?>
                            </span>
                        </div>
                    </div>
                    <div class="card-body">
                        <h6 class="card-title fw-bold"><?= esc($related['nama_unit']) ?></h6>
                        <p class="text-danger fw-bold mb-3">
                            Rp <?= number_format($related['harga'], 0, ',', '.') ?>
                            <small class="text-muted">/<?= esc($related['satuan']) ?></small>
                        </p>
                        <a href="<?= site_url('koperasi/detail/' . $related['id']) ?>" class="btn btn-sm btn-outline-danger w-100">
                            Lihat Detail
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<style>
.hover-lift {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.hover-lift:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.1) !important;
}
</style>
<?= $this->endSection() ?>