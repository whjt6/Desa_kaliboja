<?= $this->extend('layout/main_layout') ?>

<?= $this->section('content') ?>
<div class="container py-5">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= site_url('/') ?>">Beranda</a></li>
            <li class="breadcrumb-item"><a href="<?= site_url('koperasi') ?>">Koperasi</a></li>
            <li class="breadcrumb-item active" aria-current="page">Keanggotaan</li>
        </ol>
    </nav>

    <h1 class="mb-4">Keanggotaan Koperasi</h1>
    
    <!-- Persyaratan -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <h3 class="card-title text-danger mb-3"><i class="fas fa-clipboard-check me-2"></i>Persyaratan Keanggotaan</h3>
            <div class="row">
                <div class="col-md-6">
                    <?= nl2br(esc($persyaratan ?? '1. Warga Desa Kaliboja
2. Berusia minimal 17 tahun
3. Membayar simpanan pokok
4. Bersedia mematuhi AD/ART koperasi')) ?>
                </div>
                <div class="col-md-6">
                    <div class="p-3 bg-light rounded">
                        <h5 class="text-danger">Simpanan Wajib:</h5>
                        <ul class="mb-0">
                            <li>Simpanan Pokok: <strong>Rp <?= number_format($simpanan['pokok'] ?? 50000, 0, ',', '.') ?></strong> (sekali saja)</li>
                            <li>Simpanan Wajib: <strong>Rp <?= number_format($simpanan['wajib'] ?? 10000, 0, ',', '.') ?></strong> (per bulan)</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Manfaat -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <h3 class="card-title text-danger mb-3"><i class="fas fa-gift me-2"></i>Manfaat sebagai Anggota</h3>
            <div class="row">
                <div class="col-md-6">
                    <div class="d-flex mb-3">
                        <div class="flex-shrink-0">
                            <i class="fas fa-money-bill-wave text-success fa-2x"></i>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h5>SHU (Sisa Hasil Usaha)</h5>
                            <p class="text-muted">Mendapatkan pembagian keuntungan dari hasil usaha koperasi setiap tahun.</p>
                        </div>
                    </div>
                    
                    <div class="d-flex mb-3">
                        <div class="flex-shrink-0">
                            <i class="fas fa-hand-holding-usd text-success fa-2x"></i>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h5>Pinjaman Murah</h5>
                            <p class="text-muted">Akses pinjaman dengan bunga ringan untuk kebutuhan produktif.</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="d-flex mb-3">
                        <div class="flex-shrink-0">
                            <i class="fas fa-percentage text-success fa-2x"></i>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h5>Diskon Khusus</h5>
                            <p class="text-muted">Diskon khusus untuk pembelian produk dan jasa dari unit usaha koperasi.</p>
                        </div>
                    </div>
                    
                    <div class="d-flex">
                        <div class="flex-shrink-0">
                            <i class="fas fa-vote-yea text-success fa-2x"></i>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h5>Hak Suara</h5>
                            <p class="text-muted">Hak suara dalam Rapat Anggota Tahunan (RAT) untuk menentukan kebijakan koperasi.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Prosedur Pendaftaran -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <h3 class="card-title text-danger mb-3"><i class="fas fa-file-signature me-2"></i>Prosedur Pendaftaran</h3>
            <div class="row text-center">
                <div class="col-md-3">
                    <div class="p-3">
                        <div class="rounded-circle bg-danger text-white d-flex align-items-center justify-content-center mx-auto mb-3" style="width: 60px; height: 60px;">
                            <i class="fas fa-edit fa-2x"></i>
                        </div>
                        <h5>1. Isi Formulir</h5>
                        <p class="text-muted small">Isi formulir pendaftaran online atau datang langsung ke kantor koperasi.</p>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="p-3">
                        <div class="rounded-circle bg-danger text-white d-flex align-items-center justify-content-center mx-auto mb-3" style="width: 60px; height: 60px;">
                            <i class="fas fa-file-upload fa-2x"></i>
                        </div>
                        <h5>2. Upload Dokumen</h5>
                        <p class="text-muted small">Upload fotokopi KTP dan pas foto 3x4 (untuk pendaftaran online).</p>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="p-3">
                        <div class="rounded-circle bg-danger text-white d-flex align-items-center justify-content-center mx-auto mb-3" style="width: 60px; height: 60px;">
                            <i class="fas fa-money-check-alt fa-2x"></i>
                        </div>
                        <h5>3. Bayar Simpanan</h5>
                        <p class="text-muted small">Bayar simpanan pokok dan simpanan wajib pertama.</p>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="p-3">
                        <div class="rounded-circle bg-danger text-white d-flex align-items-center justify-content-center mx-auto mb-3" style="width: 60px; height: 60px;">
                            <i class="fas fa-id-card fa-2x"></i>
                        </div>
                        <h5>4. Terima Kartu</h5>
                        <p class="text-muted small">Terima kartu anggota dan mulai menikmati manfaat keanggotaan.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- CTA -->
    <div class="text-center py-5">
        <h2 class="mb-4">Siap Bergabung dengan Kami?</h2>
        <p class="lead mb-4">Daftar sekarang dan mulai nikmati manfaat sebagai anggota koperasi.</p>
        <div class="d-flex justify-content-center gap-3">
            <a href="<?= site_url('koperasi/form-pendaftaran') ?>" class="btn btn-danger btn-lg px-4">
                <i class="fas fa-user-plus me-2"></i>Daftar Sekarang
            </a>
            <a href="https://wa.me/<?= esc($profile['whatsapp'] ?? '628123456789') ?>" target="_blank" class="btn btn-success btn-lg px-4">
                <i class="fab fa-whatsapp me-2"></i>Tanya via WhatsApp
            </a>
        </div>
    </div>
</div>
<?= $this->endSection() ?>