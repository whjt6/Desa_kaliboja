<?= $this->extend('layout/main_layout') ?>

<?= $this->section('content') ?>
<!-- Breadcrumb -->
<nav aria-label="breadcrumb" class="bg-light py-3">
    <div class="container">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="<?= site_url() ?>">Beranda</a></li>
            <li class="breadcrumb-item"><a href="<?= site_url('koperasi') ?>">Koperasi</a></li>
            <li class="breadcrumb-item active" aria-current="page">Profil</li>
        </ol>
    </div>
</nav>

<!-- Hero Profil -->
<section class="py-5 bg-danger text-white">
    <div class="container py-5">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h1 class="display-4 fw-bold mb-3"><?= esc($profile['nama_koperasi'] ?? 'Koperasi Merah Putih') ?></h1>
                <p class="lead"><?= esc($profile['singkatan'] ?? 'KMP') ?> - Berdiri sejak tahun 2000</p>
            </div>
            <div class="col-lg-4 text-center">
                <div class="bg-white rounded-circle p-4 shadow" style="width: 200px; height: 200px; margin: 0 auto;">
                    <i class="fas fa-handshake fa-5x text-danger"></i>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Sejarah -->
<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="fw-bold mb-4 section-title">Sejarah Koperasi</h2>
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-4">
                        <?= $profile['sejarah'] ?? 'Sejarah koperasi akan diisi di sini.' ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Visi Misi -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-6">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body p-4">
                        <div class="text-center mb-4">
                            <div class="rounded-circle bg-danger d-inline-flex align-items-center justify-content-center" 
                                 style="width: 60px; height: 60px;">
                                <i class="fas fa-eye fa-2x text-white"></i>
                            </div>
                        </div>
                        <h3 class="fw-bold text-center mb-4">Visi</h3>
                        <div class="text-center">
                            <p class="lead"><?= esc($visi_misi['visi'] ?? 'Menjadi koperasi terbaik yang mensejahterakan anggota') ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body p-4">
                        <div class="text-center mb-4">
                            <div class="rounded-circle bg-danger d-inline-flex align-items-center justify-content-center" 
                                 style="width: 60px; height: 60px;">
                                <i class="fas fa-bullseye fa-2x text-white"></i>
                            </div>
                        </div>
                        <h3 class="fw-bold text-center mb-4">Misi</h3>
                        <div class="text-center">
                            <?php 
                            $misi = $visi_misi['misi'] ?? "1. Meningkatkan kesejahteraan anggota\n2. Mengembangkan usaha produktif\n3. Memberikan pelayanan terbaik";
                            $misiPoints = explode("\n", $misi);
                            ?>
                            <ul class="list-unstyled">
                                <?php foreach($misiPoints as $point): ?>
                                <li class="mb-2"><i class="fas fa-check text-danger me-2"></i><?= trim($point) ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Struktur Organisasi -->
<section class="py-5">
    <div class="container">
        <h2 class="fw-bold mb-4 section-title">Struktur Organisasi</h2>
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <?php if(!empty($struktur)): ?>
                <?= $struktur ?>
                <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-users fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">Struktur organisasi akan diisi di sini</h5>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<!-- Kontak -->
<section class="py-5 bg-danger text-white">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <h2 class="fw-bold mb-4">Kontak Kami</h2>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <i class="fas fa-map-marker-alt me-2"></i>
                        <strong>Alamat:</strong><br>
                        <?= esc($profile['alamat'] ?? 'Desa Kaliboja, Paninggaran, Pekalongan') ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <i class="fas fa-phone me-2"></i>
                        <strong>Telepon:</strong><br>
                        <?= esc($profile['telepon'] ?? '0812-3456-7890') ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <i class="fab fa-whatsapp me-2"></i>
                        <strong>WhatsApp:</strong><br>
                        <?= esc($profile['whatsapp'] ?? '0812-3456-7890') ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <i class="fas fa-envelope me-2"></i>
                        <strong>Email:</strong><br>
                        <?= esc($profile['email'] ?? 'koperasi@kaliboja.id') ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="bg-white text-dark rounded p-4 shadow">
                    <h4 class="mb-3">Jam Operasional</h4>
                    <?php 
                    $jamOperasional = $profile['jam_operasional'] ?? "Senin - Jumat: 08:00 - 16:00\nSabtu: 08:00 - 14:00";
                    $jamLines = explode("\n", $jamOperasional);
                    ?>
                    <ul class="list-unstyled">
                        <?php foreach($jamLines as $jam): ?>
                        <li class="mb-2"><i class="fas fa-clock text-danger me-2"></i><?= trim($jam) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
.section-title {
    position: relative;
    padding-bottom: 15px;
}
.section-title::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 50px;
    height: 3px;
    background: #dc3545;
}
</style>
<?= $this->endSection() ?>