<?= $this->extend('layout/main_layout') ?>

<?= $this->section('content') ?>
<div class="container py-3">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= site_url('/') ?>">Beranda</a></li>
            <li class="breadcrumb-item"><a href="<?= site_url('koperasi') ?>">Koperasi</a></li>
            <li class="breadcrumb-item"><a href="<?= site_url('koperasi/keanggotaan') ?>">Keanggotaan</a></li>
            <li class="breadcrumb-item active" aria-current="page">Formulir Pendaftaran</li>
        </ol>
    </nav>

    <h1 class="mb-4">Formulir Pendaftaran Anggota Koperasi</h1>
    
    <!-- Alert -->
    <?php if(session()->getFlashdata('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="fas fa-check-circle me-2"></i><?= session()->getFlashdata('success') ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    
    <?php if(session()->getFlashdata('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fas fa-exclamation-circle me-2"></i><?= session()->getFlashdata('error') ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <!-- Form -->
    <div class="card border-0 shadow-sm">
        <div class="card-body p-4 p-md-5">
            <form method="post" action="<?= site_url('koperasi/submit-pendaftaran') ?>" enctype="multipart/form-data">
                <?= csrf_field() ?>
                
                <h4 class="text-danger mb-4">Data Pribadi</h4>
                
                <div class="row">
                    <!-- Nama -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                        <input type="text" 
                               name="nama" 
                               class="form-control <?= ($validation && $validation->hasError('nama')) ? 'is-invalid' : '' ?>" 
                               value="<?= old('nama') ?>" 
                               required>
                        <?php if($validation && $validation->hasError('nama')): ?>
                        <div class="invalid-feedback"><?= $validation->getError('nama') ?></div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- NIK -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">NIK <span class="text-danger">*</span></label>
                        <input type="text" 
                               name="nik" 
                               class="form-control <?= ($validation && $validation->hasError('nik')) ? 'is-invalid' : '' ?>" 
                               value="<?= old('nik') ?>" 
                               maxlength="16" 
                               required>
                        <?php if($validation && $validation->hasError('nik')): ?>
                        <div class="invalid-feedback"><?= $validation->getError('nik') ?></div>
                        <?php endif; ?>
                        <small class="text-muted">16 digit NIK sesuai KTP</small>
                    </div>
                </div>
                
                <div class="row">
                    <!-- Tempat Lahir -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Tempat Lahir <span class="text-danger">*</span></label>
                        <input type="text" 
                               name="tempat_lahir" 
                               class="form-control <?= ($validation && $validation->hasError('tempat_lahir')) ? 'is-invalid' : '' ?>" 
                               value="<?= old('tempat_lahir') ?>" 
                               required>
                        <?php if($validation && $validation->hasError('tempat_lahir')): ?>
                        <div class="invalid-feedback"><?= $validation->getError('tempat_lahir') ?></div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Tanggal Lahir -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Tanggal Lahir <span class="text-danger">*</span></label>
                        <input type="date" 
                               name="tanggal_lahir" 
                               class="form-control <?= ($validation && $validation->hasError('tanggal_lahir')) ? 'is-invalid' : '' ?>" 
                               value="<?= old('tanggal_lahir') ?>" 
                               required>
                        <?php if($validation && $validation->hasError('tanggal_lahir')): ?>
                        <div class="invalid-feedback"><?= $validation->getError('tanggal_lahir') ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="row">
                    <!-- Jenis Kelamin -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Jenis Kelamin <span class="text-danger">*</span></label>
                        <select name="jenis_kelamin" 
                                class="form-select <?= ($validation && $validation->hasError('jenis_kelamin')) ? 'is-invalid' : '' ?>" 
                                required>
                            <option value="">Pilih Jenis Kelamin</option>
                            <option value="L" <?= old('jenis_kelamin') == 'L' ? 'selected' : '' ?>>Laki-laki</option>
                            <option value="P" <?= old('jenis_kelamin') == 'P' ? 'selected' : '' ?>>Perempuan</option>
                        </select>
                        <?php if($validation && $validation->hasError('jenis_kelamin')): ?>
                        <div class="invalid-feedback"><?= $validation->getError('jenis_kelamin') ?></div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Pekerjaan -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Pekerjaan <span class="text-danger">*</span></label>
                        <input type="text" 
                               name="pekerjaan" 
                               class="form-control <?= ($validation && $validation->hasError('pekerjaan')) ? 'is-invalid' : '' ?>" 
                               value="<?= old('pekerjaan') ?>" 
                               required>
                        <?php if($validation && $validation->hasError('pekerjaan')): ?>
                        <div class="invalid-feedback"><?= $validation->getError('pekerjaan') ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="row">
                    <!-- Alamat -->
                    <div class="col-12 mb-3">
                        <label class="form-label">Alamat Lengkap <span class="text-danger">*</span></label>
                        <textarea name="alamat" 
                                  class="form-control <?= ($validation && $validation->hasError('alamat')) ? 'is-invalid' : '' ?>" 
                                  rows="3" 
                                  required><?= old('alamat') ?></textarea>
                        <?php if($validation && $validation->hasError('alamat')): ?>
                        <div class="invalid-feedback"><?= $validation->getError('alamat') ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="row">
                    <!-- No HP -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">No. HP/WhatsApp <span class="text-danger">*</span></label>
                        <input type="tel" 
                               name="no_hp" 
                               class="form-control <?= ($validation && $validation->hasError('no_hp')) ? 'is-invalid' : '' ?>" 
                               value="<?= old('no_hp') ?>" 
                               required>
                        <?php if($validation && $validation->hasError('no_hp')): ?>
                        <div class="invalid-feedback"><?= $validation->getError('no_hp') ?></div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Email -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" 
                               name="email" 
                               class="form-control <?= ($validation && $validation->hasError('email')) ? 'is-invalid' : '' ?>" 
                               value="<?= old('email') ?>">
                        <?php if($validation && $validation->hasError('email')): ?>
                        <div class="invalid-feedback"><?= $validation->getError('email') ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <h4 class="text-danger mt-5 mb-4">Simpanan</h4>
                
                <div class="row">
                    <!-- Simpanan Pokok -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Simpanan Pokok <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text">Rp</span>
                            <input type="number" 
                                   name="simpanan_pokok" 
                                   class="form-control <?= ($validation && $validation->hasError('simpanan_pokok')) ? 'is-invalid' : '' ?>" 
                                   value="<?= old('simpanan_pokok', 50000) ?>" 
                                   min="50000" 
                                   step="10000" 
                                   required>
                        </div>
                        <?php if($validation && $validation->hasError('simpanan_pokok')): ?>
                        <div class="invalid-feedback"><?= $validation->getError('simpanan_pokok') ?></div>
                        <?php endif; ?>
                        <small class="text-muted">Minimal Rp 50.000 (sekali saja)</small>
                    </div>
                    
                    <!-- Simpanan Wajib -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Simpanan Wajib <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text">Rp</span>
                            <input type="number" 
                                   name="simpanan_wajib" 
                                   class="form-control <?= ($validation && $validation->hasError('simpanan_wajib')) ? 'is-invalid' : '' ?>" 
                                   value="<?= old('simpanan_wajib', 10000) ?>" 
                                   min="10000" 
                                   step="5000" 
                                   required>
                        </div>
                        <?php if($validation && $validation->hasError('simpanan_wajib')): ?>
                        <div class="invalid-feedback"><?= $validation->getError('simpanan_wajib') ?></div>
                        <?php endif; ?>
                        <small class="text-muted">Minimal Rp 10.000 (per bulan)</small>
                    </div>
                </div>
                
                <h4 class="text-danger mt-5 mb-4">Upload Dokumen</h4>
                
                <div class="row">
                    <!-- Foto KTP -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Foto KTP <span class="text-danger">*</span></label>
                        <input type="file" 
                               name="foto_ktp" 
                               class="form-control <?= ($validation && $validation->hasError('foto_ktp')) ? 'is-invalid' : '' ?>" 
                               accept="image/*" 
                               required>
                        <?php if($validation && $validation->hasError('foto_ktp')): ?>
                        <div class="invalid-feedback"><?= $validation->getError('foto_ktp') ?></div>
                        <?php endif; ?>
                        <small class="text-muted">Format: JPG/PNG, maksimal 2MB</small>
                    </div>
                    
                    <!-- Foto Diri -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Foto Diri (3x4) <span class="text-danger">*</span></label>
                        <input type="file" 
                               name="foto_diri" 
                               class="form-control <?= ($validation && $validation->hasError('foto_diri')) ? 'is-invalid' : '' ?>" 
                               accept="image/*" 
                               required>
                        <?php if($validation && $validation->hasError('foto_diri')): ?>
                        <div class="invalid-feedback"><?= $validation->getError('foto_diri') ?></div>
                        <?php endif; ?>
                        <small class="text-muted">Format: JPG/PNG, maksimal 2MB</small>
                    </div>
                </div>
                
                <!-- Persetujuan -->
                <div class="form-check mt-4">
                    <input class="form-check-input <?= ($validation && $validation->hasError('persetujuan')) ? 'is-invalid' : '' ?>" 
                           type="checkbox" 
                           name="persetujuan" 
                           id="persetujuan" 
                           value="1" 
                           required>
                    <label class="form-check-label" for="persetujuan">
                        Saya menyetujui <a href="#" data-bs-toggle="modal" data-bs-target="#syaratModal">syarat dan ketentuan</a> keanggotaan koperasi.
                    </label>
                    <?php if($validation && $validation->hasError('persetujuan')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('persetujuan') ?></div>
                    <?php endif; ?>
                </div>
                
                <!-- Tombol -->
                <div class="mt-5">
                    <button type="submit" class="btn btn-danger btn-lg px-5">
                        <i class="fas fa-paper-plane me-2"></i>Kirim Pendaftaran
                    </button>
                    <a href="<?= site_url('koperasi/keanggotaan') ?>" class="btn btn-outline-secondary ms-2">
                        Kembali
                    </a>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Info -->
    <div class="alert alert-info mt-4">
        <h5><i class="fas fa-info-circle me-2"></i>Informasi Penting</h5>
        <ul class="mb-0">
            <li>Data yang Anda kirim akan diverifikasi oleh admin koperasi dalam 1x24 jam.</li>
            <li>Setelah verifikasi berhasil, Anda akan dihubungi via WhatsApp untuk pembayaran simpanan.</li>
            <li>Setelah pembayaran dikonfirmasi, kartu anggota akan segera diproses.</li>
            <li>Untuk pertanyaan, hubungi: <?= esc($profile['whatsapp'] ?? '628123456789') ?></li>
        </ul>
    </div>
</div>

<!-- Modal Syarat -->
<div class="modal fade" id="syaratModal" tabindex="-1" aria-labelledby="syaratModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="syaratModalLabel">Syarat dan Ketentuan Keanggotaan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <h6>1. Persyaratan Umum</h6>
                <ul>
                    <li>Warga Desa Kaliboja</li>
                    <li>Berusia minimal 17 tahun</li>
                    <li>Memiliki KTP yang masih berlaku</li>
                    <li>Bersedia mematuhi AD/ART Koperasi Merah Putih</li>
                </ul>
                
                <h6>2. Kewajiban Anggota</h6>
                <ul>
                    <li>Membayar simpanan pokok dan simpanan wajib tepat waktu</li>
                    <li>Mengikuti Rapat Anggota Tahunan (RAT)</li>
                    <li>Menjaga nama baik koperasi</li>
                    <li>Membayar iuran bulanan tepat waktu</li>
                </ul>
                
                <h6>3. Hak Anggota</h6>
                <ul>
                    <li>Mendapatkan SHU (Sisa Hasil Usaha)</li>
                    <li>Mengajukan pinjaman dengan syarat yang berlaku</li>
                    <li>Mendapatkan diskon khusus untuk produk koperasi</li>
                    <li>Hak suara dalam pengambilan keputusan</li>
                </ul>
                
                <h6>4. Ketentuan Lainnya</h6>
                <ul>
                    <li>Data yang diberikan harus benar dan valid</li>
                    <li>Koperasi berhak menolak pendaftaran jika tidak memenuhi syarat</li>
                    <li>Keanggotaan dapat dibekukan jika melanggar AD/ART</li>
                    <li>Keputusan pengurus koperasi bersifat mutlak</li>
                </ul>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>