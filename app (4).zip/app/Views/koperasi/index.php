<?= $this->extend('layout/main_layout') ?>

<?= $this->section('content') ?>
<!-- Hero Section -->
<section class="hero-section bg-danger text-white py-5">
    <div class="container py-5">
        <div class="row align-items-center">
            <div class="col-lg-6 mb-4 mb-lg-0">
                <h1 class="display-4 fw-bold mb-3"><?= esc($profile['nama_koperasi'] ?? 'Koperasi Merah Putih') ?></h1>
                <p class="lead mb-4"><?= esc($profile['singkatan'] ?? 'KMP') ?> - Bersama Membangun Ekonomi Kerakyatan</p>
                <div class="d-flex gap-3">
                    <a href="<?= site_url('koperasi/keanggotaan') ?>" class="btn btn-light btn-lg">
                        <i class="fas fa-user-plus me-2"></i>Daftar Anggota
                    </a>
                    <a href="<?= site_url('koperasi/profil') ?>" class="btn btn-outline-light btn-lg">
                        <i class="fas fa-info-circle me-2"></i>Tentang Kami
                    </a>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="bg-white rounded shadow-lg p-4">
                    <img src="https://images.unsplash.com/photo-1559136555-9303baea8ebd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                         class="img-fluid rounded" 
                         alt="Koperasi">
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Statistik Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row text-center">
            <div class="col-md-3 mb-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="text-danger mb-3">
                            <i class="fas fa-users fa-3x"></i>
                        </div>
                        <h3 class="fw-bold text-danger"><?= number_format($statistik['total_anggota'] ?? 0) ?></h3>
                        <p class="text-muted mb-0">Total Anggota</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="text-success mb-3">
                            <i class="fas fa-user-check fa-3x"></i>
                        </div>
                        <h3 class="fw-bold text-success"><?= number_format($statistik['anggota_aktif'] ?? 0) ?></h3>
                        <p class="text-muted mb-0">Anggota Aktif</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="text-info mb-3">
                            <i class="fas fa-boxes fa-3x"></i>
                        </div>
                        <h3 class="fw-bold text-info"><?= number_format($statistik['total_unit'] ?? 0) ?></h3>
                        <p class="text-muted mb-0">Unit Usaha</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="text-warning mb-3">
                            <i class="fas fa-money-bill-wave fa-3x"></i>
                        </div>
                        <h5 class="fw-bold text-warning">Rp <?= number_format(($statistik['total_simpanan'] ?? 0), 0, ',', '.') ?></h5>
                        <p class="text-muted mb-0">Total Simpanan</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Unit Usaha Populer -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Unit Usaha Populer</h2>
            <p class="text-muted">Produk dan layanan unggulan dari koperasi kami</p>
        </div>

        <?php if(!empty($unit_populer)): ?>
        <div class="row g-4">
            <?php foreach($unit_populer as $unit): ?>
            <div class="col-lg-4 col-md-6">
                <div class="card h-100 border-0 shadow-sm hover-lift">
                    <div class="position-relative">
                        <img src="<?= base_url('uploads/koperasi/unit/' . ($unit['gambar'] ?? '')) ?>" 
                             class="card-img-top" 
                             alt="<?= esc($unit['nama_unit']) ?>"
                             style="height: 250px; object-fit: cover;"
                             onerror="this.src='https://images.unsplash.com/photo-1586864387634-6b7fb11a29ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80'">
                        <div class="position-absolute top-0 end-0 m-3">
                            <?php if($unit['status'] == 'tersedia'): ?>
                            <span class="badge bg-success">Tersedia</span>
                            <?php elseif($unit['status'] == 'habis'): ?>
                            <span class="badge bg-warning">Habis</span>
                            <?php else: ?>
                            <span class="badge bg-info">Preorder</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title fw-bold"><?= esc($unit['nama_unit']) ?></h5>
                        <p class="card-text text-muted">
                            <?= character_limiter(strip_tags($unit['deskripsi'] ?? ''), 100) ?>
                        </p>
                        <div class="d-flex justify-content-between align-items-center">
                            <h4 class="text-danger mb-0">
                                Rp <?= number_format($unit['harga'], 0, ',', '.') ?>
                                <small class="text-muted">/<?= esc($unit['satuan']) ?></small>
                            </h4>
                            <a href="<?= site_url('koperasi/detail/' . $unit['id']) ?>" class="btn btn-danger">
                                Lihat Detail
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <div class="text-center mt-5">
            <a href="<?= site_url('koperasi/unit-usaha') ?>" class="btn btn-outline-danger btn-lg">
                <i class="fas fa-boxes me-2"></i>Lihat Semua Unit Usaha
            </a>
        </div>
        <?php else: ?>
        <div class="text-center py-5">
            <i class="fas fa-box-open fa-3x text-muted mb-3"></i>
            <p class="text-muted">Belum ada unit usaha tersedia</p>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- Berita Terbaru -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Berita & Kegiatan Terbaru</h2>
            <p class="text-muted">Informasi terkini seputar aktivitas koperasi</p>
        </div>

        <?php if(!empty($berita_terbaru)): ?>
        <div class="row g-4">
            <?php foreach($berita_terbaru as $berita): ?>
            <div class="col-lg-4 col-md-6">
                <div class="card h-100 border-0 shadow-sm hover-lift">
                    <img src="<?= base_url('uploads/koperasi/berita/' . ($berita['gambar'] ?? '')) ?>" 
                         class="card-img-top" 
                         alt="<?= esc($berita['judul']) ?>"
                         style="height: 200px; object-fit: cover;"
                         onerror="this.src='https://images.unsplash.com/photo-1504711434969-e33886168f5c?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80'">
                    <div class="card-body">
                        <p class="text-muted small mb-2">
                            <i class="far fa-calendar me-1"></i>
                            <?= date('d F Y', strtotime($berita['created_at'])) ?>
                        </p>
                        <h5 class="card-title fw-bold"><?= esc($berita['judul']) ?></h5>
                        <p class="card-text text-muted">
                            <?= character_limiter(strip_tags($berita['konten'] ?? ''), 100) ?>
                        </p>
                        <a href="<?= site_url('koperasi/berita/' . $berita['slug']) ?>" class="btn btn-outline-danger">
                            Baca Selengkapnya <i class="fas fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <div class="text-center mt-5">
            <a href="<?= site_url('koperasi/berita') ?>" class="btn btn-outline-danger btn-lg">
                <i class="fas fa-newspaper me-2"></i>Lihat Semua Berita
            </a>
        </div>
        <?php else: ?>
        <div class="text-center py-5">
            <i class="fas fa-newspaper fa-3x text-muted mb-3"></i>
            <p class="text-muted">Belum ada berita tersedia</p>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- CTA Section -->
<section class="py-5 bg-danger text-white">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8 mb-4 mb-lg-0">
                <h2 class="fw-bold mb-3">Bergabunglah dengan Koperasi Merah Putih</h2>
                <p class="lead mb-0">Wujudkan kesejahteraan bersama melalui koperasi yang amanah dan profesional</p>
            </div>
            <div class="col-lg-4 text-lg-end">
                <a href="<?= site_url('koperasi/form-pendaftaran') ?>" class="btn btn-light btn-lg px-5">
                    <i class="fas fa-user-plus me-2"></i>Daftar Sekarang
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Laporan Terbaru -->
<?php if(!empty($laporan_terbaru)): ?>
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Laporan Keuangan</h2>
            <p class="text-muted">Transparansi dan akuntabilitas pengelolaan koperasi</p>
        </div>

        <div class="row g-4">
            <?php foreach($laporan_terbaru as $laporan): ?>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <div>
                                <span class="badge bg-info mb-2"><?= esc($laporan['jenis']) ?></span>
                                <h5 class="fw-bold mb-0"><?= esc($laporan['judul']) ?></h5>
                            </div>
                            <i class="fas fa-file-pdf fa-2x text-danger"></i>
                        </div>
                        <p class="text-muted small mb-3">
                            <?= character_limiter($laporan['deskripsi'], 80) ?>
                        </p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="text-muted small">
                                <i class="far fa-calendar me-1"></i>
                                <?= esc($laporan['tahun']) ?>
                            </span>
                            <a href="<?= site_url('koperasi/download/' . $laporan['id']) ?>" 
                               class="btn btn-sm btn-outline-danger">
                                <i class="fas fa-download me-1"></i>Download
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="text-center mt-4">
            <a href="<?= site_url('koperasi/laporan') ?>" class="btn btn-outline-danger">
                <i class="fas fa-file-alt me-2"></i>Lihat Semua Laporan
            </a>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- Kontak Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 mb-4 mb-lg-0">
                <h2 class="fw-bold mb-4">Hubungi Kami</h2>
                <div class="d-flex mb-3">
                    <div class="flex-shrink-0">
                        <i class="fas fa-map-marker-alt fa-2x text-danger"></i>
                    </div>
                    <div class="flex-grow-1 ms-3">
                        <h5>Alamat</h5>
                        <p class="text-muted mb-0"><?= nl2br(esc($profile['alamat'] ?? 'Desa Kaliboja, Paninggaran, Pekalongan')) ?></p>
                    </div>
                </div>
                <div class="d-flex mb-3">
                    <div class="flex-shrink-0">
                        <i class="fas fa-phone fa-2x text-danger"></i>
                    </div>
                    <div class="flex-grow-1 ms-3">
                        <h5>Telepon</h5>
                        <p class="text-muted mb-0"><?= esc($profile['telepon'] ?? '0285-123456') ?></p>
                    </div>
                </div>
                <div class="d-flex">
                    <div class="flex-shrink-0">
                        <i class="fab fa-whatsapp fa-2x text-success"></i>
                    </div>
                    <div class="flex-grow-1 ms-3">
                        <h5>WhatsApp</h5>
                        <p class="text-muted mb-0"><?= esc($profile['whatsapp'] ?? '628123456789') ?></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="d-grid gap-3">
                    <a href="https://wa.me/<?= esc($profile['whatsapp'] ?? '628123456789') ?>" 
                       target="_blank" 
                       class="btn btn-success btn-lg">
                        <i class="fab fa-whatsapp me-2"></i>Chat via WhatsApp
                    </a>
                    <a href="<?= site_url('koperasi/kontak') ?>" 
                       class="btn btn-outline-danger btn-lg">
                        <i class="fas fa-envelope me-2"></i>Lihat Detail Kontak
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
.hover-lift {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.hover-lift:hover {
    transform: translateY(-10px);
    box-shadow: 0 15px 30px rgba(0,0,0,0.15) !important;
}
</style>
<?= $this->endSection() ?>