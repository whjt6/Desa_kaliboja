<?= $this->extend('layout/main_layout') ?>

<?= $this->section('content') ?>
<!-- Breadcrumb -->
<nav aria-label="breadcrumb" class="bg-light py-3">
    <div class="container">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="<?= site_url() ?>">Beranda</a></li>
            <li class="breadcrumb-item"><a href="<?= site_url('koperasi') ?>">Koperasi</a></li>
            <li class="breadcrumb-item active" aria-current="page">Berita & Kegiatan</li>
        </ol>
    </div>
</nav>

<!-- Header -->
<section class="py-5 bg-danger text-white">
    <div class="container py-4">
        <h1 class="display-5 fw-bold mb-3">Berita & Kegiatan Koperasi</h1>
        <p class="lead">Informasi terbaru seputar kegiatan dan perkembangan Koperasi Merah Putih</p>
    </div>
</section>

<!-- Search & Filter -->
<section class="py-4 bg-light">
    <div class="container">
        <form method="get" action="<?= site_url('koperasi/berita') ?>" class="row g-3">
            <div class="col-md-10">
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                    <input type="text" 
                           name="search" 
                           class="form-control" 
                           placeholder="Cari berita..."
                           value="<?= esc($searchTerm ?? '') ?>">
                    <button class="btn btn-danger" type="submit">Cari</button>
                </div>
            </div>
            <div class="col-md-2">
                <a href="<?= site_url('koperasi/berita') ?>" class="btn btn-outline-secondary w-100">
                    <i class="fas fa-sync me-1"></i>Reset
                </a>
            </div>
        </form>
    </div>
</section>

<!-- Berita List -->
<section class="py-5">
    <div class="container">
        <!-- Tombol Kembali -->
        <div class="mb-4">
            <a href="<?= site_url('koperasi') ?>" class="btn btn-outline-danger">
                <i class="fas fa-arrow-left me-2"></i>Kembali ke Beranda Koperasi
            </a>
        </div>

        <?php if(!empty($berita)): ?>
        <div class="row g-4">
            <?php foreach($berita as $item): ?>
            <div class="col-lg-4 col-md-6">
                <div class="card h-100 shadow-sm border-0 hover-lift">
                    <div class="position-relative">
                        <img src="<?= base_url('uploads/koperasi/berita/' . ($item['gambar'] ?? '')) ?>" 
                             class="card-img-top" 
                             alt="<?= esc($item['judul']) ?>"
                             style="height: 250px; object-fit: cover;"
                             onerror="this.src='https://images.unsplash.com/photo-1559136555-9303baea8ebd?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80'">
                        <div class="position-absolute top-0 end-0 m-3">
                            <span class="badge bg-danger">Berita</span>
                        </div>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title fw-bold"><?= esc($item['judul']) ?></h5>
                        <p class="card-text text-muted">
                            <?= character_limiter(strip_tags($item['konten'] ?? ''), 120) ?>
                        </p>
                    </div>
                    <div class="card-footer bg-transparent border-0">
                        <div class="d-flex justify-content-between align-items-center">
                            <small class="text-muted">
                                <i class="far fa-calendar me-1"></i>
                                <?= date('d M Y', strtotime($item['created_at'])) ?>
                            </small>
                            <a href="<?= site_url('koperasi/berita/' . $item['slug']) ?>" class="btn btn-sm btn-danger">
                                Baca Selengkapnya <i class="fas fa-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Pagination Placeholder -->
        <div class="mt-5">
            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center">
                    <li class="page-item disabled">
                        <span class="page-link">Previous</span>
                    </li>
                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                    <li class="page-item">
                        <a class="page-link" href="#">Next</a>
                    </li>
                </ul>
            </nav>
        </div>
        <?php else: ?>
        <div class="text-center py-5">
            <i class="fas fa-newspaper fa-3x text-muted mb-3"></i>
            <h4 class="text-muted">Tidak ada berita ditemukan</h4>
            <p class="text-muted mb-4">Silakan coba kata kunci pencarian yang berbeda</p>
            <a href="<?= site_url('koperasi/berita') ?>" class="btn btn-danger">
                <i class="fas fa-sync me-2"></i>Lihat Semua Berita
            </a>
        </div>
        <?php endif; ?>
    </div>
</section>

<style>
.hover-lift {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.hover-lift:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.1) !important;
}
</style>
<?= $this->endSection() ?>