<?= $this->extend('layout/main_layout') ?>

<?= $this->section('content') ?>
<div class="container py-5">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= site_url('/') ?>">Beranda</a></li>
            <li class="breadcrumb-item"><a href="<?= site_url('koperasi') ?>">Koperasi</a></li>
            <li class="breadcrumb-item active" aria-current="page">Kontak</li>
        </ol>
    </nav>

    <h1 class="mb-4">Kontak Koperasi Merah Putih</h1>
    
    <div class="row">
        <!-- Info Kontak -->
        <div class="col-lg-8 mb-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="d-flex">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-map-marker-alt text-danger fa-2x"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h5>Alamat</h5>
                                    <p class="mb-0"><?= nl2br(esc($kontak['alamat'] ?? 'Desa Kaliboja, Kec. Paninggaran, Kab. Pekalongan, Jawa Tengah')) ?></p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-4">
                            <div class="d-flex">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-phone text-danger fa-2x"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h5>Telepon</h5>
                                    <p class="mb-0"><?= esc($kontak['telepon'] ?? '0285-123456') ?></p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-4">
                            <div class="d-flex">
                                <div class="flex-shrink-0">
                                    <i class="fab fa-whatsapp text-success fa-2x"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h5>WhatsApp</h5>
                                    <p class="mb-0"><?= esc($kontak['whatsapp'] ?? '628123456789') ?></p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-4">
                            <div class="d-flex">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-envelope text-danger fa-2x"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h5>Email</h5>
                                    <p class="mb-0"><?= esc($kontak['email'] ?? 'koperasi@kaliboja.desa.id') ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Jam Operasional -->
                    <div class="mt-4 pt-4 border-top">
                        <h5><i class="fas fa-clock text-danger me-2"></i>Jam Operasional</h5>
                        <p class="mb-0"><?= nl2br(esc($jam_operasional ?? "Senin - Jumat: 08:00 - 16:00\nSabtu: 08:00 - 12:00\nMinggu & Hari Libur: Tutup")) ?></p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="col-lg-4 mb-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <h5 class="card-title text-danger mb-4">Aksi Cepat</h5>
                    
                    <div class="d-grid gap-3">
                        <a href="https://wa.me/<?= esc($kontak['whatsapp'] ?? '628123456789') ?>" 
                           target="_blank" 
                           class="btn btn-success btn-lg">
                            <i class="fab fa-whatsapp me-2"></i>Chat via WhatsApp
                        </a>
                        
                        <a href="tel:<?= esc($kontak['telepon'] ?? '0285123456') ?>" 
                           class="btn btn-danger btn-lg">
                            <i class="fas fa-phone me-2"></i>Telepon Sekarang
                        </a>
                        
                        <a href="mailto:<?= esc($kontak['email'] ?? 'koperasi@kaliboja.desa.id') ?>" 
                           class="btn btn-outline-danger btn-lg">
                            <i class="fas fa-envelope me-2"></i>Kirim Email
                        </a>
                        
                        <a href="https://maps.google.com/?q=<?= urlencode($kontak['alamat'] ?? 'Desa Kaliboja, Paninggaran, Pekalongan') ?>" 
                           target="_blank" 
                           class="btn btn-outline-secondary btn-lg">
                            <i class="fas fa-map-marked-alt me-2"></i>Lihat di Peta
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Map -->
    <div class="card border-0 shadow-sm mt-4">
        <div class="card-body p-0">
            <iframe 
                src="https://maps.google.com/maps?q=<?= urlencode($kontak['alamat'] ?? 'Desa Kaliboja, Paninggaran, Pekalongan') ?>&t=&z=15&ie=UTF8&iwloc=&output=embed" 
                width="100%" 
                height="400" 
                style="border:0;" 
                allowfullscreen="" 
                loading="lazy">
            </iframe>
        </div>
    </div>
    
    <!-- Info -->
    <div class="alert alert-info mt-4">
        <h5><i class="fas fa-info-circle me-2"></i>Informasi Pelayanan</h5>
        <ul class="mb-0">
            <li>Untuk informasi keanggotaan, silakan datang langsung ke kantor koperasi.</li>
            <li>Pembayaran simpanan dapat dilakukan via transfer atau tunai di kantor.</li>
            <li>Pengajuan pinjaman harus melalui proses verifikasi di kantor.</li>
            <li>Untuk pengaduan atau keluhan, hubungi WhatsApp di atas.</li>
        </ul>
    </div>
</div>
<?= $this->endSection() ?>