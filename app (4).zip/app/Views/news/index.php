<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="mb-2"></div>
<?php
// Muat class Time dan Text helper
use CodeIgniter\I18n\Time;
helper('text'); // Memuat helper untuk fungsi word_limiter()
?>

<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            
        </div>
    </div>
</div>

<section class="content">
    <div class="container-fluid">
        <?php if(session()->getFlashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle mr-2"></i><?= session()->getFlashdata('success') ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>
        
        <?php if(session()->getFlashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle mr-2"></i><?= session()->getFlashdata('error') ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>
        
        <div class="row">
            <div class="col-12">
                <div class="card card-primary card-outline">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <a href="<?= base_url('/dashboard/news/create') ?>" class="btn btn-primary btn-sm">
                            <i class="fas fa-plus-circle mr-1"></i> Tambah Berita
                        </a>
                    </div>
                    <div class="card-body">
                        <?php if (empty($news)): ?>
                        <div class="text-center py-5">
                            <i class="fas fa-newspaper fa-4x text-light mb-3" style="background: linear-gradient(135deg, #4e73df 0%, #224abe 100%); padding: 20px; border-radius: 50%;"></i>
                            <h4 class="text-muted mt-3">Belum ada berita</h4>
                            <p class="text-muted">Silakan tambahkan berita pertama Anda</p>
                            <a href="<?= base_url('/dashboard/news/create') ?>" class="btn btn-primary mt-2">
                                <i class="fas fa-plus-circle mr-1"></i> Tambah Berita
                            </a>
                        </div>
                        <?php else: ?>
                        <div class="row">
                            <?php foreach($news as $item): ?>
                            <div class="col-xl-4 col-lg-6 col-md-6 mb-4">
                                <div class="card news-card h-100 shadow-sm border-0">
                                    <div class="news-image-container position-relative">
                                        <?php if (!empty($item['images'])): ?>
                                            <img src="/uploads/news/<?= esc($item['images'][0]['image_filename']); ?>" class="card-img-top" alt="<?= esc($item['title']); ?>">
                                        <?php else: ?>
                                            <div class="no-image d-flex flex-column align-items-center justify-content-center">
                                                <i class="fas fa-image fa-3x text-light"></i>
                                                <p class="text-light mt-2 mb-0 small">Tidak ada gambar</p>
                                            </div>
                                        <?php endif; ?>
                                        <div class="news-actions">
                                            <a href="<?= base_url('dashboard/news/edit/' . $item['id']) ?>" class="btn btn-sm btn-light rounded-circle shadow-sm" title="Edit">
                                                <i class="fas fa-edit text-primary"></i>
                                            </a>
                                            <form action="<?= base_url('dashboard/news/delete/' . $item['id']) ?>" method="post" class="d-inline" onsubmit="return confirm('Apakah Anda yakin ingin menghapus berita ini?')">
                                                <?= csrf_field() ?>
                                                <button type="submit" class="btn btn-sm btn-light rounded-circle shadow-sm" title="Hapus">
                                                    <i class="fas fa-trash text-danger"></i>
                                                </button>
                                            </form>
                                        </div>
                                        <div class="news-badge">
                                            <i class="fas fa-newspaper mr-1"></i> Berita Desa
                                        </div>
                                    </div>
                                    <div class="card-body d-flex flex-column">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <div class="text-muted small">
                                                <i class="far fa-clock mr-1"></i>
                                                <?php if (!empty($item['updated_at'])): ?>
                                                    <?= Time::parse($item['updated_at'])->toLocalizedString('d MMM yyyy') ?>
                                                <?php endif; ?>
                                            </div>
                                            <span class="badge badge-light text-muted small">
                                                <i class="fas fa-eye mr-1"></i> 0
                                            </span>
                                        </div>
                                        <h5 class="card-title mb-2">
                                            <a href="<?= base_url('dashboard/news/show/' . $item['id']) ?>" class="text-dark text-decoration-none stretched-link">
                                                <?= esc($item['title']); ?>
                                            </a>
                                        </h5>
                                        <p class="card-text news-content flex-grow-1">
                                            <?= esc(word_limiter(strip_tags($item['content']), 18, '...')); ?>
                                        </p>
                                        <div class="mt-auto pt-2">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <a href="<?= base_url('dashboard/news/show/' . $item['id']) ?>" class="btn btn-sm btn-outline-primary rounded-pill">
                                                    <i class="fas fa-eye mr-1"></i> Baca Selengkapnya
                                                </a>
                                                <div class="news-actions">
                                            <a href="<?= base_url('dashboard/news/edit/' . $item['id']) ?>" class="btn btn-sm btn-light rounded-circle shadow-sm" title="Edit">
                                                <i class="fas fa-edit text-primary"></i>
                                            </a>
                                            <form action="<?= base_url('dashboard/news/delete/' . $item['id']) ?>" method="post" class="d-inline" onsubmit="return confirm('Apakah Anda yakin ingin menghapus berita ini?')">
                                                <?= csrf_field() ?>
                                                <button type="submit" class="btn btn-sm btn-light rounded-circle shadow-sm" title="Hapus">
                                                    <i class="fas fa-trash text-danger"></i>
                                                </button>
                                            </form>
                                        </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php if (!empty($news)): ?>
                    <div class="card-footer">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="dataTables_info">
                                Menampilkan <b><?= count($news) ?></b> berita
                            </div>
                            <div class="dataTables_paginate">
                                <ul class="pagination pagination-sm m-0">
                                    <li class="page-item disabled"><a class="page-link" href="#">«</a></li>
                                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                    <li class="page-item"><a class="page-link" href="#">»</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
.news-card {
    transition: all 0.3s ease;
    border-radius: 12px;
    overflow: hidden;
}

.news-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 12px 20px rgba(78, 115, 223, 0.15) !important;
}

.news-image-container {
    position: relative;
    height: 220px;
    overflow: hidden;
}

.news-image-container img {
    height: 100%;
    width: 100%;
    object-fit: cover;
    transition: transform 0.5s ease;
}

.news-card:hover .news-image-container img {
    transform: scale(1.08);
}

.no-image {
    height: 100%;
    background: linear-gradient(135deg, #6c757d 0%, #495057 100%);
}

.news-actions {
    position: absolute;
    top: 15px;
    right: 15px;
    opacity: 0;
    transition: opacity 0.3s ease;
    z-index: 3;
}

.news-card:hover .news-actions {
    opacity: 1;
}

.news-actions .btn, .news-actions form {
    margin-left: 8px;
    display: inline-flex;
}

.news-actions .btn {
    border-radius: 50%;
    width: 36px;
    height: 36px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(4px);
    border: none;
    transition: all 0.2s ease;
}

.news-actions .btn:hover {
    transform: scale(1.1);
    background: #fff;
}

.news-badge {
    position: absolute;
    top: 15px;
    left: 15px;
    background: linear-gradient(45deg, #4e73df, #224abe);
    color: white;
    padding: 6px 14px;
    border-radius: 30px;
    font-size: 12px;
    font-weight: 600;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
    z-index: 3;
}

.news-content {
    color: #6c757d;
    font-size: 0.95rem;
    line-height: 1.6;
    margin-bottom: 1rem;
}

.card-title a {
    transition: color 0.2s ease;
    font-weight: 600;
    line-height: 1.4;
}

.card-title a:hover {
    color: #4e73df !important;
}

.card-footer .btn, .card-body .btn {
    border-radius: 6px;
    font-weight: 500;
    padding: 0.375rem 0.75rem;
    transition: all 0.2s ease;
}

.btn-outline-primary:hover {
    background: linear-gradient(45deg, #4e73df, #224abe);
    border-color: #4e73df;
    transform: translateY(-2px);
}

.btn-rounded {
    border-radius: 50px !important;
}

/* Efek overlay pada gambar */
.news-image-container::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 40%;
    background: linear-gradient(to top, rgba(0,0,0,0.6) 0%, transparent 100%);
    z-index: 1;
}

/* Pagination styling */
.pagination .page-link {
    border-radius: 8px;
    margin: 0 3px;
    border: none;
    color: #6c757d;
}

.pagination .page-item.active .page-link {
    background: linear-gradient(45deg, #4e73df, #224abe);
    border-color: #4e73df;
}

@media (max-width: 1200px) {
    .col-xl-4 {
        flex: 0 0 50%;
        max-width: 50%;
    }
}

@media (max-width: 768px) {
    .news-actions {
        opacity: 1;
    }
    
    .news-actions .btn {
        width: 34px;
        height: 34px;
    }
    
    .col-xl-4, .col-lg-6, .col-md-6 {
        flex: 0 0 100%;
        max-width: 100%;
    }
    
    .news-image-container {
        height: 200px;
    }
    
    .card-header {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .card-header .btn {
        margin-top: 10px;
    }
    
    .pagination {
        margin-top: 15px;
    }
}
</style>

<?= $this->endSection() ?>