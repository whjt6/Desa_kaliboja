<!DOCTYPE html>
<html lang="id">

<head>
    <!-- Polyfill untuk browser lama -->
    <script src="https://cdn.jsdelivr.net/npm/es6-promise@4/dist/es6-promise.auto.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/whatwg-fetch@3.6.2/dist/fetch.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/3.21.1/minified.min.js"></script>

    <!-- Memaksa IE menggunakan mode rendering terbaru -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Desa Kaliboja | Website Resmi</title>
    <meta name="description"
        content="Website resmi Desa Kaliboja - Portal digital untuk transparansi informasi, promosi potensi, dan pelayanan digital kepada masyarakat.">
    <meta name="keywords" content="Desa Kaliboja, website desa, potensi desa, produk unggulan, wisata desa">
    <meta name="author" content="Desa Kaliboja">
    <meta name="robots" content="index, follow">

    <!-- Open Graph Meta Tags -->
    <meta property="og:title" content="Desa Kaliboja | Website Resmi">
    <meta property="og:description"
        content="Website resmi Desa Kaliboja - Portal digital untuk transparansi informasi, promosi potensi, dan pelayanan digital kepada masyarakat.">
    <meta property="og:image" content="img/logo.png">
    <meta property="og:url" content="/">
    <meta property="og:type" content="website">

    <link rel="icon" href="/img/logo.png" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600&display=swap"
        rel="stylesheet">

    <style>
    :root {
        --primary: #4A6C6F;
        --primary-dark: #3a5659;
        --secondary: #F4EAD5;
        --accent: #D6A25B;
        --accent-light: #e6b877;
        --dark: #1f2937;
        --light: #F9F7F3;
        --success: #28a745;
        --text-dark: #333;
        --text-light: #6c757d;
        --shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        --shadow-hover: 0 10px 25px rgba(0, 0, 0, 0.15);
    }

    body {
        background: var(--light);
        color: var(--text-dark);
        font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Ubuntu, 'Helvetica Neue', Arial, sans-serif;
        line-height: 1.6;
        scroll-behavior: smooth;
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6,
    .navbar-brand {
        font-family: 'Poppins', sans-serif;
        font-weight: 700;
    }

    .navbar {
        background: white !important;
        box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
        padding: 0.8rem 0;
        transition: all 0.3s ease;
    }

    .navbar.scrolled {
        padding: 0.5rem 0;
        background: rgba(255, 255, 255, 0.95) !important;
        backdrop-filter: blur(10px);
    }

    .navbar-brand img {
        height: 40px;
        transition: all 0.3s ease;
    }

    .navbar.scrolled .navbar-brand img {
        height: 36px;
    }

    .nav-link {
        font-weight: 500;
        position: relative;
        padding: 0.5rem 0.8rem !important;
        margin: 0 0.2rem;
        transition: all 0.3s ease;
        color: var(--text-dark) !important;
    }

    .nav-link::before {
        content: '';
        position: absolute;
        bottom: 0;
        left: 50%;
        width: 0;
        height: 2px;
        background: var(--accent);
        transition: all 0.3s ease;
        transform: translateX(-50%);
    }

    .nav-link:hover::before,
    .nav-link.active::before {
        width: 70%;
    }

    .btn-primary {
        background: var(--primary);
        border-color: var(--primary);
        padding: 0.6rem 1.5rem;
        font-weight: 500;
        transition: all 0.3s ease;
    }

    .btn-primary:hover {
        background: var(--primary-dark);
        border-color: var(--primary-dark);
        transform: translateY(-2px) scale(1.05);
        box-shadow: var(--shadow-hover);
    }

    .btn-outline-primary {
        color: var(--primary);
        border-color: var(--primary);
        font-weight: 500;
        transition: all 0.3s ease;
    }

    .btn-outline-primary:hover {
        background: var(--primary);
        border-color: var(--primary);
        transform: translateY(-2px) scale(1.05);
    }

    .btn-success {
        background: var(--success);
        border-color: var(--success);
        transition: all 0.3s ease;
    }

    .btn-success:hover {
        transform: translateY(-2px) scale(1.05);
        box-shadow: var(--shadow-hover);
    }

    .section-title {
        font-weight: 700;
        color: var(--primary);
        text-align: center;
        margin-bottom: 2.4rem;
        position: relative;
    }

    .section-title::after {
        content: '';
        display: block;
        width: 84px;
        height: 4px;
        background: var(--accent);
        margin: 0.8rem auto 0;
        border-radius: 2px;
    }

    /* PERBAIKAN UTAMA: HERO CAROUSEL RESPONSIF */
    .hero {
        position: relative;
        overflow: hidden;
        height: 100vh;
        max-height: 800px;
    }

    .hero .carousel-item {
    height: 100vh;
    max-height: 800px;
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    position: relative;
    transition: all 0.5s ease;
    /* Optimasi untuk kualitas gambar */
    image-rendering: -webkit-optimize-contrast;
    image-rendering: crisp-edges;
    -ms-interpolation-mode: bicubic;
}

/* Pastikan gambar load dengan baik */
.hero .carousel-item img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center;
}

    .hero .carousel-item::after {
    content: '';
    position: absolute;
    inset: 0;
    background: radial-gradient(
        ellipse at center,
        transparent 30%,
        rgba(0, 0, 0, 0.15) 100%
    );
}

    .hero .carousel-caption {
        z-index: 2;
        top: 50%;
        transform: translateY(-50%);
        bottom: initial;
        padding: 20px;
        text-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
    }

    .hero h1 {
    font-size: 2.5rem;
    margin-bottom: 1rem;
    animation: fadeInDown 1s ease, bounceIn 1.5s ease-in-out infinite alternate;
    color: white;
    text-shadow: 
        0 2px 4px rgba(0, 0, 0, 0.8),
        0 4px 8px rgba(0, 0, 0, 0.4); /* Double shadow untuk depth */
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}

.hero p {
    font-size: 1.25rem;
    margin-bottom: 2rem;
    animation: fadeInUp 1s ease, float 2s ease-in-out infinite;
    color: white;
    text-shadow: 
        0 1px 3px rgba(0, 0, 0, 0.8),
        0 2px 6px rgba(0, 0, 0, 0.4);
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}
    /* Media queries untuk carousel */
    @media (min-width: 576px) {
        .hero h1 {
            font-size: 3rem;
        }

        .hero p {
            font-size: 1.5rem;
        }
    }

    @media (min-width: 768px) {
        .hero h1 {
            font-size: 3.5rem;
        }
    }

    @media (min-width: 992px) {
        .hero h1 {
            font-size: 4rem;
        }
    }

    @media (max-width: 768px) {
        .hero,
        .hero .carousel-item {
            height: 80vh;
        }

        .hero .btn-lg {
            padding: 0.5rem 1rem;
            font-size: 1rem;
        }
    }

    @media (max-width: 576px) {
        .hero,
        .hero .carousel-item {
            height: 70vh;
        }

        .hero .carousel-caption {
            padding: 10px;
        }

        .hero h1 {
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }

        .hero p {
            font-size: 1rem;
            margin-bottom: 1rem;
        }

        .hero .btn-lg {
            padding: 0.4rem 0.8rem;
            font-size: 0.9rem;
        }
    }

    .carousel-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
    }

    .stat-card {
        background: #fff;
        border-radius: 1rem;
        padding: 2rem;
        text-align: center;
        box-shadow: var(--shadow);
        transition: all 0.3s ease;
        height: 100%;
        border: 1px solid rgba(0, 0, 0, 0.05);
    }

    .stat-card:hover {
        transform: translateY(-8px) rotate(2deg);
        box-shadow: var(--shadow-hover);
    }

    .stat-card i {
        font-size: 2.6rem;
        color: var(--primary);
        margin-bottom: 0.6rem;
        transition: transform 0.3s ease;
    }

    .stat-card:hover i {
        transform: scale(1.2) rotate(10deg);
    }

    .counter {
        font-size: 2.2rem;
        font-weight: 800;
        color: var(--accent);
    }

    .no-data {
        font-size: 1.2rem;
        color: var(--text-light);
        font-style: italic;
    }

    .card-elev {
        border: none;
        border-radius: 1rem;
        overflow: hidden;
        box-shadow: var(--shadow);
        transition: all 0.3s ease;
        height: 100%;
    }

    .card-elev:hover {
        transform: translateY(-8px) scale(1.02);
        box-shadow: var(--shadow-hover);
    }

    .product-thumb {
        height: 200px;
        object-fit: cover;
        width: 100%;
        transition: all 0.5s ease;
    }

    .card-elev:hover .product-thumb {
        transform: scale(1.1) rotate(3deg);
    }

    .official-avatar {
        width: 150px;
        height: 150px;
        object-fit: cover;
        border-radius: 50%;
        border: 4px solid var(--accent);
        background: #fff;
        box-shadow: var(--shadow);
        transition: all 0.3s ease;
    }

    .official-item:hover .official-avatar {
        transform: scale(1.05) rotate(5deg);
        border-color: var(--accent-light);
    }

    footer {
        background: linear-gradient(to right, #0a1920, #111);
        color: #bbb;
        position: relative;
        overflow: hidden;
    }

    footer::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 4px;
        background: linear-gradient(to right, var(--accent), var(--primary));
    }

    footer a {
        color: #bbb;
        text-decoration: none;
        transition: all 0.3s ease;
    }

    footer a:hover {
        color: #fff;
        padding-left: 5px;
        transform: scale(1.1);
    }

    /* Floating */
    .wa-float {
        position: fixed;
        right: 20px;
        bottom: 20px;
        z-index: 1030;
        animation: pulse 2s infinite, float 3s ease-in-out infinite;
    }

    .to-top {
        position: fixed;
        right: 20px;
        bottom: 80px;
        z-index: 1030;
        display: none;
        animation: fadeIn 0.5s ease, bounce 1.5s infinite;
    }

    /* Announcement bar */
    .announcement-bar {
        background: linear-gradient(90deg, var(--primary-dark), var(--primary));
        color: white;
        padding: 10px 0;
        position: relative;
        overflow: hidden;
        animation: slideInLeft 1s ease;
    }

    .announcement-bar::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: url("data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 0h20L0 20z' fill='%23ffffff' fill-opacity='0.05'/%3E%3C/svg%3E");
        opacity: 0.1;
    }

    /* New sections */
    .feature-icon {
        font-size: 2.5rem;
        color: var(--accent);
        margin-bottom: 1rem;
        transition: transform 0.3s ease;
    }

    .feature-icon:hover {
        transform: rotate(360deg) scale(1.2);
    }

    .testimonial-card {
        background: white;
        border-radius: 1rem;
        padding: 2rem;
        box-shadow: var(--shadow);
        position: relative;
        margin-top: 2rem;
        transition: all 0.3s ease;
    }

    .testimonial-card:hover {
        transform: translateY(-5px) rotate(-2deg);
    }

    .testimonial-card::before {
        content: '\201C';
        font-size: 5rem;
        color: var(--accent-light);
        position: absolute;
        top: -1rem;
        left: 1rem;
        line-height: 1;
        opacity: 0.2;
        font-family: Georgia, serif;
        animation: fadeIn 1s ease;
    }

    .testimonial-avatar {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        object-fit: cover;
        border: 3px solid var(--accent);
        transition: transform 0.3s ease;
    }

    .testimonial-card:hover .testimonial-avatar {
        transform: scale(1.1) rotate(10deg);
    }

    /* Gallery Section Styles - Disamakan dengan halaman gallery */
    .gallery-section {
        background: var(--light);
    }

    .gallery-filter {
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        gap: 10px;
        margin-bottom: 2rem;
        padding: 0 15px;
    }

    .gallery-filter-btn {
        padding: 10px 20px;
        border: 2px solid var(--primary);
        background: white;
        color: var(--primary);
        border-radius: 25px;
        cursor: pointer;
        transition: all 0.3s ease;
        font-weight: 500;
        position: relative;
        overflow: hidden;
    }

    .gallery-filter-btn::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(74, 108, 111, 0.1), transparent);
        transition: left 0.5s;
    }

    .gallery-filter-btn:hover::before {
        left: 100%;
    }

    .gallery-filter-btn.active,
    .gallery-filter-btn:hover {
        background: var(--primary);
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(74, 108, 111, 0.3);
    }

    .gallery-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 20px;
        padding: 0 15px;
    }

    .gallery-item {
        position: relative;
        border-radius: 12px;
        overflow: hidden;
        cursor: pointer;
        transition: all 0.4s ease;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        background: white;
        animation: fadeInUp 0.6s ease forwards;
        opacity: 0;
    }

    .gallery-item.visible {
        opacity: 1;
        transform: translateY(0);
    }

    .gallery-item:hover {
        transform: translateY(-10px) scale(1.02);
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
    }

    .gallery-image-container {
        position: relative;
        overflow: hidden;
        height: 250px;
    }

    .gallery-image {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: all 0.5s ease;
    }

    .gallery-item:hover .gallery-image {
        transform: scale(1.1);
    }

    .gallery-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(to bottom, transparent 40%, rgba(0, 0, 0, 0.7));
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
        padding: 20px;
        opacity: 0;
        transition: all 0.3s ease;
    }

    .gallery-item:hover .gallery-overlay {
        opacity: 1;
    }

    .gallery-overlay-content {
        transform: translateY(20px);
        transition: transform 0.3s ease;
    }

    .gallery-item:hover .gallery-overlay-content {
        transform: translateY(0);
    }

    .gallery-title {
        color: white;
        font-weight: 600;
        margin-bottom: 5px;
        font-size: 1.1rem;
        line-height: 1.3;
    }

    .gallery-category {
        display: inline-block;
        background: var(--accent);
        color: white;
        padding: 5px 12px;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 500;
    }

    .gallery-actions {
        position: absolute;
        top: 15px;
        right: 15px;
        display: flex;
        gap: 10px;
        opacity: 0;
        transform: translateY(-10px);
        transition: all 0.3s ease;
    }

    .gallery-item:hover .gallery-actions {
        opacity: 1;
        transform: translateY(0);
    }

    .gallery-action-btn {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.9);
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--primary);
        text-decoration: none;
        transition: all 0.3s ease;
        backdrop-filter: blur(5px);
        border: none;
        cursor: pointer;
    }

    .gallery-action-btn:hover {
        background: var(--primary);
        color: white;
        transform: scale(1.1);
    }

    .gallery-empty {
        text-align: center;
        padding: 60px 20px;
        background: white;
        border-radius: 12px;
        box-shadow: var(--shadow);
        grid-column: 1 / -1;
    }

    .gallery-empty-icon {
        font-size: 4rem;
        color: var(--accent-light);
        margin-bottom: 20px;
        opacity: 0.7;
    }

    .gallery-loading {
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 40px;
        grid-column: 1 / -1;
    }

    .loading-dots {
        display: flex;
        gap: 8px;
    }

    .loading-dot {
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background: var(--primary);
        animation: bounce 1.4s infinite ease-in-out;
    }

    .loading-dot:nth-child(1) {
        animation-delay: -0.32s;
    }

    .loading-dot:nth-child(2) {
        animation-delay: -0.16s;
    }

    @keyframes bounce {
        0%, 80%, 100% {
            transform: scale(0);
        }
        40% {
            transform: scale(1);
        }
    }

    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    /* Modal Styles - Sama dengan halaman gallery */
    .modal-content {
        border-radius: var(--border-radius);
        border: none;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        overflow: hidden;
    }

    .modal-header {
        border-bottom: 1px solid rgba(0,0,0,0.1);
        background: var(--primary);
        color: white;
        padding: 1rem 1.5rem;
    }

    .modal-title {
        font-size: 1.1rem;
        font-weight: 600;
        margin: 0;
    }

    .btn-close-white {
        filter: invert(1) grayscale(100%) brightness(200%);
    }

    .modal-body {
        padding: 0;
        position: relative;
        max-height: 70vh;
        overflow-y: auto;
    }

    .modal-image-container {
        position: relative;
        background: #000;
        min-height: 300px;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
    }

    .modal-image {
        max-width: 100%;
        max-height: 50vh;
        width: auto;
        height: auto;
        object-fit: contain;
        display: block;
        margin: 0 auto;
    }

    .modal-footer {
        border-top: 1px solid rgba(0,0,0,0.1);
        background: #f8f9fa;
        padding: 1rem 1.5rem;
    }

    .image-info {
        padding: 1.5rem;
        background: white;
    }

    .image-title {
        font-weight: 600;
        color: var(--primary);
        margin-bottom: 0.75rem;
        font-size: 1.2rem;
        line-height: 1.4;
    }

    .image-description {
        color: var(--text-light);
        margin-bottom: 1rem;
        line-height: 1.6;
        font-size: 0.95rem;
    }

    .image-meta {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 0.9rem;
        color: var(--text-light);
        padding-top: 0.75rem;
        border-top: 1px solid rgba(0,0,0,0.1);
    }

    .image-date, .image-category {
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .image-category {
        background: var(--accent);
        color: white;
        padding: 0.25rem 0.75rem;
        border-radius: 20px;
        font-size: 0.8rem;
    }

    /* Navigation arrows */
    .modal-nav {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        background: rgba(0,0,0,0.7);
        color: white;
        border: none;
        width: 50px;
        height: 50px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.2rem;
        transition: all 0.3s ease;
        z-index: 10;
        opacity: 0.7;
    }

    .modal-nav:hover {
        background: rgba(0,0,0,0.9);
        transform: translateY(-50%) scale(1.1);
        opacity: 1;
    }

    .modal-nav.prev {
        left: 15px;
    }

    .modal-nav.next {
        right: 15px;
    }

    /* Modal image counter */
    .image-counter {
        background: rgba(0,0,0,0.7);
        color: white;
        padding: 5px 15px;
        border-radius: 20px;
        font-size: 0.85rem;
        position: absolute;
        top: 15px;
        right: 15px;
        z-index: 10;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .gallery-grid {
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 15px;
        }
        
        .gallery-image-container {
            height: 200px;
        }
        
        .gallery-filter {
            gap: 8px;
        }
        
        .gallery-filter-btn {
            padding: 8px 16px;
            font-size: 0.9rem;
        }
        
        .modal-nav {
            width: 40px;
            height: 40px;
            font-size: 1rem;
        }
        
        .modal-image {
            max-height: 40vh;
        }
        
        .gallery-title {
            font-size: 1rem;
        }
        
        .gallery-category {
            font-size: 0.8rem;
            padding: 4px 10px;
        }
    }

    @media (max-width: 576px) {
        .gallery-grid {
            grid-template-columns: 1fr;
            gap: 15px;
        }
        
        .gallery-image-container {
            height: 220px;
        }
        
        .gallery-overlay {
            padding: 15px;
        }
        
        .lightbox-nav {
            width: 40px;
            height: 40px;
        }
        
        .lightbox-prev {
            left: 10px;
        }
        
        .lightbox-next {
            right: 10px;
        }
        
        .modal-body {
            max-height: 60vh;
        }
        
        .modal-image-container {
            min-height: 250px;
            padding: 15px;
        }
        
        .modal-image {
            max-height: 35vh;
        }
        
        .modal-nav {
            width: 35px;
            height: 35px;
            font-size: 0.9rem;
        }
        
        .image-info {
            padding: 1rem;
        }
        
        .image-title {
            font-size: 1.1rem;
        }
        
        .image-description {
            font-size: 0.9rem;
        }
    }

    /* Dark mode */
    .dark .gallery-item {
        background: #1e293b;
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.35);
    }

    .dark .gallery-title {
        color: #e5e7eb;
    }

    .dark .gallery-category {
        background: var(--accent-light);
    }

    .dark .gallery-empty {
        background: #1e293b;
    }

    .dark .gallery-filter-btn {
        background: #1e293b;
        color: #e5e7eb;
        border-color: var(--primary);
    }

    .dark .gallery-filter-btn.active,
    .dark .gallery-filter-btn:hover {
        background: var(--primary);
        color: white;
    }

    .dark .image-info {
        background: #1e293b;
        color: #e5e7eb;
    }

    .dark .image-title {
        color: var(--accent-light);
    }

    .dark .image-description {
        color: #94a3b8;
    }

    .dark .modal-header {
        background: var(--primary-dark);
        border-bottom: 1px solid #374151;
    }

    .dark .modal-footer {
        background: #111827;
        border-top: 1px solid #374151;
    }

    .dark .modal-content {
        background: #1e293b;
        color: #e5e7eb;
    }

    /* Flip Card */
    .flip-card {
        perspective: 1000px;
        height: 300px;
    }

    .flip-card-inner {
        position: relative;
        width: 100%;
        height: 100%;
        text-align: center;
        transition: transform 0.8s;
        transform-style: preserve-3d;
    }

    .flip-card:hover .flip-card-inner {
        transform: rotateY(180deg);
    }

    .flip-card-front,
    .flip-card-back {
        position: absolute;
        width: 100%;
        height: 100%;
        backface-visibility: hidden;
        border-radius: 1rem;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        padding: 2rem;
    }

    .flip-card-front {
        background-color: var(--primary);
        color: white;
    }

    .flip-card-back {
        background-color: var(--accent);
        color: white;
        transform: rotateY(180deg);
    }

    /* New animations */
    @keyframes fadeInLeft {
        from {
            opacity: 0;
            transform: translateX(-50px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }

    @keyframes fadeInRight {
        from {
            opacity: 0;
            transform: translateX(50px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }

    @keyframes zoomInUp {
        from {
            opacity: 0;
            transform: scale3d(0.1, 0.1, 0.1) translate3d(0, 1000px, 0);
            animation-timing-function: cubic-bezier(0.55, 0.055, 0.675, 0.19);
        }
        60% {
            opacity: 1;
            transform: scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0);
            animation-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1);
        }
    }

    @keyframes tada {
        from {
            transform: scale3d(1, 1, 1);
        }
        10%, 20% {
            transform: scale3d(0.9, 0.9, 0.9) rotate3d(0, 0, 1, -3deg);
        }
        30%, 50%, 70%, 90% {
            transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg);
        }
        40%, 60%, 80% {
            transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg);
        }
        to {
            transform: scale3d(1, 1, 1);
        }
    }

    @keyframes heartBeat {
        0% {
            transform: scale(1);
        }
        14% {
            transform: scale(1.3);
        }
        28% {
            transform: scale(1);
        }
        42% {
            transform: scale(1.3);
        }
        70% {
            transform: scale(1);
        }
    }

    /* Additional animation classes */
    .animate-fadeInLeft {
        animation: fadeInLeft 1s ease-out;
    }

    .animate-fadeInRight {
        animation: fadeInRight 1s ease-out;
    }

    .animate-zoomInUp {
        animation: zoomInUp 1s ease-out;
    }

    .animate-tada {
        animation: tada 1s;
    }

    .animate-heartBeat {
        animation: heartBeat 1s infinite;
    }

    /* Hover effects */
    .hover-lift {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .hover-lift:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
    }

    .hover-shine {
        position: relative;
        overflow: hidden;
    }

    .hover-shine::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
        transition: 0.5s;
    }

    .hover-shine:hover::before {
        left: 100%;
    }

    /* Responsive adjustments */
    @media (max-width: 1200px) {
        .hero h1 {
            font-size: 3rem;
        }
    }

    @media (max-width: 992px) {
        .hero h1 {
            font-size: 2.5rem;
        }

        .hero p {
            font-size: 1.1rem;
        }

        .navbar .nav-link {
            padding: 0.8rem 0.5rem !important;
            margin: 0.1rem 0;
        }

        .navbar .btn {
            margin-top: 0.5rem;
            margin-bottom: 0.5rem;
        }

        .section-title {
            font-size: 1.8rem;
        }

        .stat-card {
            padding: 1.5rem;
        }

        .counter {
            font-size: 1.8rem;
        }

        .testimonial-card {
            padding: 1.5rem;
        }
    }

    @media (max-width: 768px) {
        .hero .carousel-item {
            min-height: 500px;
            height: 70vh;
        }

        .hero h1 {
            font-size: 2rem;
            margin-bottom: 1rem;
        }

        .hero p {
            font-size: 1rem;
            margin-bottom: 1.5rem;
        }

        .hero .btn {
            padding: 0.5rem 1.2rem;
            font-size: 0.9rem;
        }

        .section-title {
            font-size: 1.6rem;
            margin-bottom: 1.5rem;
        }

        .section-title::after {
            width: 60px;
            height: 3px;
        }

        .stat-card {
            margin-bottom: 1rem;
            padding: 1.2rem;
        }

        .stat-card i {
            font-size: 2rem;
        }

        .counter {
            font-size: 1.6rem;
        }

        .card-elev {
            margin-bottom: 1.5rem;
        }

        .official-avatar {
            width: 120px;
            height: 120px;
        }

        .testimonial-card {
            padding: 1.2rem;
            margin-top: 1.5rem;
        }

        .testimonial-card::before {
            font-size: 4rem;
        }

        .gallery-item img {
            height: 180px;
        }

        footer .col-md-4 {
            margin-bottom: 2rem;
        }

        .navbar .ms-lg-3,
        .navbar .ms-2 {
            margin-left: 0.5rem !important;
        }

        .position-absolute.end-0 {
            position: relative !important;
            top: unset !important;
            transform: none !important;
            margin-top: 1rem;
            text-align: center;
        }

        .box-desa {
            padding: 10px;
            margin-bottom: 15px;
        }
    }

    @media (max-width: 576px) {
        .hero .carousel-item {
            min-height: 400px;
            height: 60vh;
        }

        .hero h1 {
            font-size: 1.8rem;
        }

        .hero p {
            font-size: 0.9rem;
        }

        .section-title {
            font-size: 1.5rem;
        }

        .stat-card {
            padding: 1rem;
        }

        .stat-card i {
            font-size: 1.8rem;
        }

        .counter {
            font-size: 1.5rem;
        }

        .btn,
        .btn-sm {
            padding: 0.4rem 1rem;
            font-size: 0.85rem;
        }

        .col-md-4,
        .col-md-3,
        .col-6 {
            width: 100%;
            flex: 0 0 100%;
            max-width: 100%;
        }

        .container,
        .container-fluid {
            padding-left: 15px;
            padding-right: 15px;
        }

        .container-fluid .col-md-8,
        .container-fluid .col-md-4 {
            height: 300px;
        }

        .container-fluid .col-md-4 {
            padding: 1.5rem;
        }

        .wa-float,
        .to-top {
            right: 15px;
            bottom: 15px;
            width: 45px;
            height: 45px;
        }

        .to-top {
            bottom: 70px;
        }

        .wa-float i,
        .to-top i {
            font-size: 1.2rem;
        }
    }

    @media (max-width: 400px) {
        .navbar-brand {
            font-size: 1rem;
        }

        .navbar-brand img {
            height: 30px;
        }

        .hero h1 {
            font-size: 1.5rem;
        }

        .hero .btn {
            font-size: 0.8rem;
        }
    }

    .navbar-collapse {
        background-color: white;
        padding: 1rem;
        border-radius: 0.5rem;
        box-shadow: var(--shadow);
        margin-top: 0.5rem;
    }

    img {
        max-width: 100%;
        height: auto;
    }

    .btn,
    .nav-link,
    .form-control {
        touch-action: manipulation;
    }

    html,
    body {
        overflow-x: hidden;
    }

    /* Tambahkan di bagian CSS */
    .position-absolute.end-0 {
        right: 0 !important;
    }

    .top-50 {
        top: 50% !important;
    }

    .translate-middle-y {
        transform: translateY(-50%) !important;
    }

    .d-none.d-md-inline-block {
        display: none;
    }

    @media (min-width: 768px) {
        .d-none.d-md-inline-block {
            display: inline-block !important;
        }
    }

    /* Styling untuk tombol Lihat Semua */
    .btn-outline-primary {
        border: 2px solid var(--primary);
        color: var(--primary);
        font-weight: 500;
        transition: all 0.3s ease;
    }

    .btn-outline-primary:hover {
        background: var(--primary);
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }

    .stat-card {
        background: #fff;
        border-radius: 1rem;
        padding: 2rem;
        text-align: center;
        box-shadow: var(--shadow);
        transition: all 0.3s ease;
        height: 100%;
    }

    .stat-card:hover {
        transform: translateY(-8px);
        box-shadow: var(--shadow-hover);
    }

    .stat-card i {
        font-size: 2.6rem;
        color: var(--primary);
        margin-bottom: 0.6rem;
    }

    .counter {
        font-size: 2.2rem;
        font-weight: 800;
        color: var(--accent);
    }

    /* Service Card - UNTUK POSYANDU & POSBINDU */
    .service-card {
        background: white;
        border-radius: 1rem;
        padding: 2.5rem 2rem;
        box-shadow: var(--shadow);
        transition: all 0.3s ease;
        height: 100%;
        border: 2px solid transparent;
        position: relative;
        overflow: hidden;
    }

    .service-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
        transition: 0.5s;
    }

    .service-card:hover::before {
        left: 100%;
    }

    .service-card:hover {
        transform: translateY(-10px);
        box-shadow: var(--shadow-hover);
    }

    .service-card.service-primary { border-color: var(--primary); }
    .service-card.service-primary:hover { background: linear-gradient(135deg, rgba(74,108,111,0.05), rgba(74,108,111,0.1)); }
    
    .service-card.service-success { border-color: var(--success); }
    .service-card.service-success:hover { background: linear-gradient(135deg, rgba(40,167,69,0.05), rgba(40,167,69,0.1)); }

    .service-icon {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 1.5rem;
        font-size: 2rem;
        transition: all 0.3s ease;
    }

    .service-card:hover .service-icon {
        transform: scale(1.1) rotate(5deg);
    }

    .service-primary .service-icon {
        background: linear-gradient(135deg, var(--primary), var(--primary-dark));
        color: white;
    }

    .service-success .service-icon {
        background: linear-gradient(135deg, #28a745, #1e7e34);
        color: white;
    }

    .service-stats {
        display: flex;
        justify-content: space-around;
        margin-top: 1.5rem;
        padding-top: 1.5rem;
        border-top: 1px solid #eee;
    }

    .service-stat-value {
        font-weight: 700;
        color: var(--primary);
        font-size: 1.5rem;
    }

    .service-stat-label {
        font-size: 0.85rem;
        color: var(--text-light);
    }

    /* JDIH Section Styles */
    .jdih-section {
        background: linear-gradient(135deg, #ffc107 0%, #ff9800 100%);
        position: relative;
        overflow: hidden;
    }

    .jdih-section::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.05'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
        opacity: 0.1;
    }

    .jdih-card {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border-radius: 1rem;
        padding: 2rem;
        box-shadow: var(--shadow);
        transition: all 0.3s ease;
    }

    .jdih-card:hover {
        transform: translateY(-5px);
        box-shadow: var(--shadow-hover);
    }

    /* RKP Section Styles */
    .rkp-section {
        background: linear-gradient(135deg, #17a2b8 0%, #138496 100%);
        position: relative;
        overflow: hidden;
    }

    .rkp-section::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M20 20.5V18H0v-2h20v-2H0v-2h20v-2H0V8h20v-2H0V4h20v-2H0V0h22v20h2V0h2v20h2V0h2v20h2V0h2v20h2v2H20v-1.5zM0 20h2v20H0V20zm4 0h2v20H4V20zm4 0h2v20H8V20zm4 0h2v20h-2V20zm4 0h2v20h-2V20zm4 4h20v2H20v-2zm0 4h20v2H20v-2zm0 4h20v2H20v-2zm0 4h20v2H20v-2z' fill='%23ffffff' fill-opacity='0.05' fill-rule='evenodd'/%3E%3C/svg%3E");
    }

    .rkp-card {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border-radius: 1rem;
        padding: 2rem;
        box-shadow: var(--shadow);
        transition: all 0.3s ease;
    }

    .rkp-card:hover {
        transform: translateY(-5px);
        box-shadow: var(--shadow-hover);
    }

    /* Profil Premium Card */
    .profil-premium-section {
        background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary) 100%);
        position: relative;
        overflow: hidden;
    }

    .profil-premium-section::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: url("data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 0h20L0 20z' fill='%23ffffff' fill-opacity='0.05'/%3E%3C/svg%3E");
    }

    .card-glass {
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        position: relative;
    }

    .btn-profil {
        background: white;
        color: var(--primary);
        border: none;
        border-radius: 50px;
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
    }

    .btn-profil:hover {
        transform: scale(1.05);
        box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        background: var(--accent);
        color: white;
    }

    /* Gallery filter styles */
    .gallery-filter {
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        margin-bottom: 2rem;
        gap: 0.5rem;
    }

    .gallery-filter-btn {
        background: white;
        border: 2px solid var(--primary);
        color: var(--primary);
        padding: 0.5rem 1.5rem;
        border-radius: 2rem;
        font-weight: 500;
        transition: all 0.3s ease;
        cursor: pointer;
    }

    .gallery-filter-btn.active,
    .gallery-filter-btn:hover {
        background: var(--primary);
        color: white;
        transform: translateY(-2px);
    }

    /* Gallery item styles */
    .gallery-item {
        border-radius: 0.5rem;
        overflow: hidden;
        position: relative;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .gallery-item img {
        transition: all 0.5s ease;
        width: 100%;
        height: 200px;
        object-fit: cover;
    }

    .gallery-item:hover img {
        transform: scale(1.1);
    }

    .gallery-overlay {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        background: linear-gradient(to top, rgba(0, 0, 0, 0.7), transparent);
        padding: 1rem;
        color: white;
        transform: translateY(100%);
        transition: all 0.3s ease;
    }

    .gallery-item:hover .gallery-overlay {
        transform: translateY(0);
    }

    .carousel-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
    }

    /* Perbaikan untuk testimoni */
    .testimonial-item {
        background: white;
        border-radius: 1rem;
        padding: 1.5rem;
        margin-bottom: 1.5rem;
        box-shadow: var(--shadow);
        transition: all 0.3s ease;
    }

    .testimonial-item:hover {
        transform: translateY(-5px);
        box-shadow: var(--shadow-hover);
    }

    .testimonial-meta {
        display: flex;
        align-items: center;
        margin-bottom: 1rem;
    }

    .testimonial-author {
        font-weight: 600;
        color: var(--primary);
    }

    .testimonial-date {
        font-size: 0.85rem;
        color: var(--text-light);
    }

    /* Notifikasi */
    .alert {
        position: fixed;
        top: 100px;
        right: 20px;
        z-index: 1060;
        min-width: 300px;
    }

    /* Perbaikan aksesibilitas */
    @media (prefers-reduced-motion: reduce) {
        * {
            animation-duration: 0.01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: 0.01ms !important;
        }
    }

    /* Focus styles untuk aksesibilitas */
    .btn:focus,
    .form-control:focus,
    .nav-link:focus {
        outline: 2px solid var(--accent);
        outline-offset: 2px;
    }

    .contact-container {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
    }

    .contact-card {
        background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
        border-radius: 16px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
        overflow: hidden;
        transition: transform 0.3s ease;
        width: 100%;
    }

    .contact-card:hover {
        transform: translateY(-5px);
    }

    .contact-header {
        border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        padding-bottom: 1rem;
    }

    .contact-info p {
        margin-bottom: 1.2rem;
        line-height: 1.6;
        display: flex;
        align-items: flex-start;
    }

    .contact-icon {
        width: 24px;
        text-align: center;
        margin-right: 12px;
        flex-shrink: 0;
        padding-top: 3px;
    }

    .btn-hover-lift {
        transition: all 0.3s ease;
        border-radius: 8px;
        font-weight: 500;
        padding: 12px 24px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }

    .btn-hover-lift:hover {
        transform: translateY(-3px);
        box-shadow: 0 7px 20px rgba(0, 0, 0, 0.2);
    }

    /* Responsive adjustments */
    @media (max-width: 576px) {
        .contact-card {
            padding: 25px 20px !important;
            margin: 10px 0;
        }

        .contact-info p {
            font-size: 15px;
        }

        .btn-hover-lift {
            width: 100%;
        }
    }

    @media (min-width: 577px) and (max-width: 768px) {
        .contact-card {
            padding: 30px 25px !important;
        }
    }

    @media (max-width: 992px) {
        .contact-container {
            padding: 40px 20px;
        }

        .gallery-filter {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 2rem;
        }

        .gallery-filter-btn {
            padding: 8px 16px;
            border: 2px solid var(--primary);
            background: white;
            color: var(--primary);
            border-radius: 25px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .gallery-filter-btn.active,
        .gallery-filter-btn:hover {
            background: var(--primary);
            color: white;
            transform: translateY(-2px);
        }

        .gallery-item {
            transition: all 0.3s ease;
        }

        .gallery-item:hover {
            transform: translateY(-5px);
        }
    }

    /* Live Indicator */
    .live-indicator {
        position: absolute;
        top: 10px;
        right: 10px;
        width: 10px;
        height: 10px;
        background-color: #28a745;
        border-radius: 50%;
        animation: pulse 1.5s infinite;
    }

    @keyframes pulse {
        0% { transform: scale(0.8); opacity: 0.7; }
        50% { transform: scale(1.2); opacity: 1; }
        100% { transform: scale(0.8); opacity: 0.7; }
    }

    /* Refresh button */
    .btn-outline-primary:hover {
        background-color: var(--primary);
        color: white;
    }

    /* Koperasi Section Styles */
.koperasi-section {
    background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
    position: relative;
    overflow: hidden;
}

.koperasi-section::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.05'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
}

.koperasi-card {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 1rem;
    padding: 2rem;
    box-shadow: var(--shadow);
    transition: all 0.3s ease;
    height: 100%;
}

.koperasi-card:hover {
    transform: translateY(-5px);
    box-shadow: var(--shadow-hover);
}

/* Unit Card Hover Effect */
.koperasi-card .border:hover {
    border-color: #dc3545 !important;
    background: rgba(220, 53, 69, 0.05);
}
</style>
</head>

<body>
    <!-- Announcement Bar -->
    <div class="announcement-bar text-center">
        <div class="container">
            <p class="mb-0"><i class="fas fa-bullhorn me-2"></i> Selamat datang di website resmi Desa Kaliboja! <a
                    href="#berita" class="text-white fw-bold ms-2">Lihat berita terbaru &rarr;</a></p>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="/">
                <img src="/img/logo.png" class="me-2" alt="Logo">Desa Kaliboja
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu"
                aria-controls="navMenu" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navMenu">
                <ul class="navbar-nav ms-auto align-items-lg-center">
                    <li class="nav-item"><a href="#berita" class="nav-link">Berita</a></li>
                    <li class="nav-item"><a href="#wisata" class="nav-link">Wisata</a></li>
                    <li class="nav-item"><a href="#produk" class="nav-link">Produk</a></li>
                    <li class="nav-item"><a href="#kesehatan" class="nav-link">Kesehatan</a></li>
                    <li class="nav-item"><a href="#jdih" class="nav-link">JDIH</a></li>
                    <li class="nav-item"><a href="#rkp" class="nav-link">RKP</a></li>
                    <li class="nav-item"><a href="#koperasi" class="nav-link">Koperasi</a></li>
                    <li class="nav-item"><a href="#profil" class="nav-link">Profil</a></li>
                    <li class="nav-item"><a href="#galeri" class="nav-link">Galeri</a></li>
                    <li class="nav-item my-2 my-lg-0"><a href="/login" class="btn btn-primary btn-sm">Login</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- HERO Carousel - PERBAIKAN UTAMA -->
<section class="hero" data-aos="zoom-in" data-aos-duration="1500" aria-label="Slider utama">
    <div id="heroCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="900">
        <div class="carousel-inner">
            <div class="carousel-item active" style="background-image:url('img/profil.jpg')">
                <!-- Overlay lebih terang -->
                <div class="carousel-overlay-very-light"></div>
                <div class="carousel-caption text-center">
                    <h1 class="fw-bold text-white">Desa Kaliboja</h1>
                    <p class="lead text-white">Transparan, partisipatif, dan berdaya saing.</p>
                    <a href="#profil" class="btn btn-light btn-lg mt-3 text-primary">Pelajari Lebih Lanjut</a>
                </div>
            </div>
            <div class="carousel-item" style="background-image:url('img/view.jpg')">
                <!-- Overlay lebih terang -->
                <div class="carousel-overlay-very-light"></div>
                <div class="carousel-caption text-center">
                    <h1 class="fw-bold text-white">Potensi Alam & UMKM</h1>
                    <p class="lead text-white">Wisata dan produk unggulan.</p>
                    <a href="#potensi" class="btn btn-light btn-lg mt-3 text-primary">Lihat Potensi</a>
                </div>
            </div>
            <div class="carousel-item" style="background-image:url('img/Pangkat.jpg')">
                <!-- Overlay lebih terang -->
                <div class="carousel-overlay-very-light"></div>
                <div class="carousel-caption text-center">
                    <h1 class="fw-bold text-white">Layanan Digital</h1>
                    <p class="lead text-white">Informasi publik, agenda, dan berita terkini.</p>
                    <a href="#berita" class="btn btn-light btn-lg mt-3 text-primary">Lihat Berita</a>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev"
            aria-label="Slide sebelumnya">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next"
            aria-label="Slide berikutnya">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
</section>

<!-- Berita -->
    <section id="berita" class="py-5 bg-light">
        <div class="container">
            <div class="row align-items-center mb-4">
                <div class="col-12 position-relative text-center">
                    <h2 class="section-title m-0" data-aos="slide-right">Berita Terbaru</h2>
                </div>
            </div>

            <div class="row g-4 justify-content-center">
                <?php 
            // Ambil data berita dari controller
            $newsModel = new \App\Models\NewsModel();
            $newsImageModel = new \App\Models\NewsImageModel();
            
            // Ambil 3 berita terbaru
            $latestNews = $newsModel->orderBy('created_at', 'DESC')->findAll(3);
            
            if(!empty($latestNews)): 
                foreach($latestNews as $n): 
                    // Ambil gambar untuk berita ini
                    $images = $newsImageModel->where('news_id', $n['id'])->findAll();
                    $imagePath = '';
                    $imageExists = false;
                    
                    if(!empty($images)) {
                        $imagePath = 'uploads/news/' . esc($images[0]['image_filename']);
                        $imageExists = file_exists(ROOTPATH . 'public/' . $imagePath);
                    }
            ?>
                <div class="col-md-4" data-aos="zoom-in-up" data-aos-delay="100">
                    <article class="card card-elev h-100 hover-lift">
                        <div class="position-relative overflow-hidden">
                            <img class="w-100" style="height:200px;object-fit:cover" loading="lazy"
                                src="<?= $imageExists ? base_url($imagePath) : 'https://images.unsplash.com/photo-1588681664899-f142ff2dc9b1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80' ?>"
                                alt="<?= esc($n['title']) ?>"
                                onerror="this.src='https://images.unsplash.com/photo-1588681664899-f142ff2dc9b1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80'">
                            <div class="position-absolute top-0 end-0 m-2">
                                <span class="badge bg-primary">Berita</span>
                            </div>
                        </div>
                        <div class="card-body text-start">
                            <h5 class="fw-bold mb-2"><?= esc($n['title']) ?></h5>
                            <p class="text-muted mb-3">
                                <?= esc(substr(strip_tags($n['content']), 0, 100)) ?>...
                            </p>
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-secondary">
                                    <i class="fa-regular fa-clock me-1"></i>
                                    <?= date('d M Y', strtotime($n['created_at'])) ?>
                                </small>
                                <a href="<?= base_url('berita/' . $n['id']) ?>"
                                    class="btn btn-sm btn-outline-primary">Baca Selengkapnya</a>
                            </div>
                        </div>
                    </article>
                </div>
                <?php endforeach; else: ?>
                <div class="col-12">
                    <div class="text-center py-5" data-aos="fade-in">
                        <i class="fa-regular fa-newspaper fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">Belum ada berita</h5>
                        <?php if(session()->get('isLoggedIn')): ?>
                        <a href="/dashboard/news/create" class="btn btn-primary mt-2">Tambah Berita Pertama</a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Tombol Lihat Semua untuk mobile -->
            <div class="text-center mt-4 d-md-none">
                <a href="<?= base_url('berita') ?>" class="btn btn-outline-primary">Lihat Semua Berita</a>
            </div>
            <!-- Tombol Lihat Selengkapnya jika ada lebih banyak data -->
            <?php 
        $allNews = $newsModel->findAll();
        if(count($allNews) > 3): 
        ?>
            <div class="text-center mt-4 d-none d-md-block">
                <a href="<?= base_url('berita') ?>" class="btn btn-outline-primary animate-heartBeat">
                    Lihat Selengkapnya <i class="fas fa-arrow-right ms-2"></i>
                </a>
            </div>
            <?php endif; ?>
        </div>
    </section>
    
    <!-- Wisata -->
    <section id="wisata" class="py-5 parallax"
        style="background-image: url('https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1350&q=80');">
        <div class="container">
            <div class="row align-items-center mb-4">
                <div class="col-12 position-relative text-center">
                    <h2 class="section-title m-0 text-white" data-aos="rotateIn">Wisata Desa</h2>
                    <a href="<?= base_url('wisata'); ?>"
                        class="btn btn-outline-light btn-sm position-absolute end-0 top-50 translate-middle-y d-none d-md-inline-block">
                        Lihat Semua
                    </a>
                </div>
            </div>

            <div class="row g-4 justify-content-center">
                <?php if (!empty($wisata) && count($wisata) > 0): ?>
                <?php 
                // Batasi wisata yang ditampilkan (maksimal 3)
                $limitedWisata = array_slice($wisata, 0, 3);
                foreach ($limitedWisata as $w): 
                    // Cek apakah gambar wisata ada
                    $wisataImagePath = 'uploads/wisata/' . esc($w['gambar']);
                    $wisataImageExists = !empty($w['gambar']) && file_exists(ROOTPATH . 'public/' . $wisataImagePath);
                ?>
                <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="card h-100 shadow-sm border-0">
                        <img src="<?= $wisataImageExists ? base_url($wisataImagePath) : 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&w=400&q=80'; ?>"
                            alt="<?= esc($w['nama']); ?>" class="card-img-top" style="height: 200px; object-fit: cover;"
                            onerror="this.src='https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&w=400&q=80'">
                        <div class="card-body">
                            <h5 class="card-title"><?= esc($w['nama']); ?></h5>
                            <p class="card-text">
                                <i class="fas fa-map-marker-alt text-primary me-2"></i>
                                <?= esc($w['lokasi']); ?>
                            </p>
                            <p class="card-text small">
                                <?= character_limiter(strip_tags($w['deskripsi']), 80); ?>
                            </p>
                        </div>
                        <div class="card-footer bg-transparent border-0">
                            <a href="<?= base_url('wisata/' . $w['id']); ?>" class="btn btn-primary btn-sm w-100">
                                Lihat Detail
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php else: ?>
                <div class="col-12">
                    <div class="text-center py-5" data-aos="fade-in">
                        <i class="fa-solid fa-mountain-sun fa-3x text-white mb-3"></i>
                        <h5 class="text-white">Belum ada data wisata</h5>
                        <?php if(session()->get('isLoggedIn')): ?>
                        <a href="<?= base_url('dashboard/wisata/create'); ?>" class="btn btn-light mt-2">Tambah
                            Wisata</a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Tombol Lihat Semua untuk mobile -->
            <div class="text-center mt-4 d-md-none">
                <a href="<?= base_url('wisata'); ?>" class="btn btn-outline-light">Lihat Semua Wisata</a>
            </div>

            <!-- Tombol Lihat Selengkapnya jika ada lebih banyak data -->
            <?php if(!empty($wisata) && count($wisata) > 3): ?>
            <div class="text-center mt-4 d-none d-md-block">
                <a href="<?= base_url('wisata'); ?>" class="btn btn-outline-light animate-heartBeat">
                    Lihat Selengkapnya <i class="fas fa-arrow-right ms-2"></i>
                </a>
            </div>
            <?php endif; ?>
        </div>
    </section>
    
    <!-- Produk -->
<section id="produk" class="py-5">
    <div class="container">
        <div class="row align-items-center mb-4">
            <div class="col-12 position-relative text-center">
                <h2 class="section-title m-0" data-aos="fade-in">Produk Unggulan Desa</h2>
                <a href="<?= site_url('products') ?>"
                    class="btn btn-outline-primary btn-sm position-absolute end-0 top-50 translate-middle-y d-none d-md-inline-block">
                    Lihat Semua
                </a>
            </div>
        </div>

        <?php 
        // Ambil data produk dari model
        $productModel = new \App\Models\ProductModel();
        
        // Ambil produk yang ditandai sebagai unggulan (is_featured = 1)
        $featuredProducts = $productModel->where('is_featured', 1)->orderBy('created_at', 'DESC')->findAll(6);
        
        // Jika tidak ada produk unggulan, ambil semua produk terbaru
        if (empty($featuredProducts)) {
            $featuredProducts = $productModel->orderBy('created_at', 'DESC')->findAll(6);
        }
        ?>

        <?php if (!empty($featuredProducts)): ?>
        <div class="row g-4 justify-content-center">
            <?php foreach ($featuredProducts as $p): 
                // Pastikan semua key yang diperlukan ada
                $productImage = $p['image'] ?? '';
                $productName = $p['name'] ?? 'Produk Tanpa Nama';
                
                $imagePath = 'uploads/products/' . esc($productImage);
                $imageExists = !empty($productImage) && file_exists(ROOTPATH . 'public/' . $imagePath);
                
                // Fallback ke gambar default jika tidak ada
                if (!$imageExists) {
                    $imagePath = 'assets/images/default-product.jpg';
                    $imageExists = file_exists(ROOTPATH . 'public/' . $imagePath);
                }
            ?>
            <div class="col-md-4 col-lg-3" data-aos="zoom-in-up" data-aos-delay="100">
                <div class="card product-card h-100 hover-lift">
                    <div class="product-image-container position-relative">
                        <?php if($imageExists): ?>
                        <img src="<?= base_url($imagePath) ?>" class="card-img-top product-thumb"
                            alt="<?= esc($productName) ?>">
                        <?php else: ?>
                        <div
                            class="card-img-top product-thumb bg-light d-flex align-items-center justify-content-center">
                            <span>Gambar Tidak Tersedia</span>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title"><?= esc($productName) ?></h5>
                        <p class="card-text text-muted small">
                            <?= character_limiter(strip_tags($p['description'] ?? 'Deskripsi tidak tersedia'), 80) ?>
                        </p>
                        
                        <!-- TOMBOL DETAIL DITAMBAHKAN DI SINI -->
                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <small class="text-muted">
                                <?php if(!empty($p['category'])): ?>
                                <i class="fas fa-tag me-1"></i><?= esc($p['category']) ?>
                                <?php endif; ?>
                            </small>
                            <a href="/products/<?= esc($p['id']); ?>" 
                               class="btn btn-primary btn-sm">
                                Detail <i class="fas fa-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Tombol Lihat Semua untuk mobile -->
        <div class="text-center mt-4 d-md-none">
            <a href="<?= site_url('products') ?>" class="btn btn-outline-primary">Lihat Semua Produk</a>
        </div>

        <!-- Tombol Lihat Selengkapnya jika ada lebih banyak data -->
        <?php 
        $allProducts = $productModel->findAll();
        if(count($allProducts) > 6): 
        ?>
        <div class="text-center mt-4 d-none d-md-block">
            <a href="<?= site_url('products') ?>" class="btn btn-outline-primary animate-heartBeat">
                Lihat Selengkapnya <i class="fas fa-arrow-right ms-2"></i>
            </a>
        </div>
        <?php endif; ?>

        <?php else: ?>
        <div class="col-12 text-center py-5">
            <i class="fas fa-box-open fa-3x text-muted mb-3"></i>
            <h5 class="text-muted">Belum ada produk</h5>
            <?php if(session()->get('isLoggedIn')): ?>
            <a href="/dashboard/products/create" class="btn btn-primary mt-2">Tambah Produk Pertama</a>
            <?php endif; ?>
        </div>
        
        <?php endif; ?>
    </div>
</section>
    
<!-- Layanan Kesehatan Section -->
<section id="kesehatan" class="py-5 bg-light">
    <div class="container">
        <h2 class="section-title" data-aos="fade-in">Layanan Kesehatan Desa</h2>
        
        <div class="row g-4">
            <!-- Posyandu -->
            <div class="col-lg-6" data-aos="fade-right">
                <div class="service-card service-primary">
                    <div class="service-icon">
                        <i class="fas fa-baby-carriage"></i>
                    </div>
                    <h4 class="text-center mb-3">Posyandu</h4>
                    <p class="text-center mb-4">Pelayanan kesehatan ibu dan anak terpadu dengan fokus pada peningkatan gizi dan imunisasi</p>
                    
                    <div class="service-stats">
                        <div class="text-center">
                            <div class="service-stat-value"><?= number_format($kesehatan_stats['posyandu']['total_balita'] ?? 0) ?></div>
                            <div class="service-stat-label">Total Balita</div>
                        </div>
                        <div class="text-center">
                            <div class="service-stat-value"><?= number_format($kesehatan_stats['posyandu']['total_ibu_hamil'] ?? 0) ?></div>
                            <div class="service-stat-label">Ibu Hamil</div>
                        </div>
                        <div class="text-center">
                            <div class="service-stat-value"><?= number_format($kesehatan_stats['posyandu']['total_kelahiran'] ?? 0) ?></div>
                            <div class="service-stat-label">Kelahiran</div>
                        </div>
                    </div>
                    
                    <div class="text-center mt-4">
                        <a href="<?= site_url('posyandu') ?>" class="btn btn-outline-primary">Lihat Detail Posyandu</a>
                    </div>
                </div>
            </div>
            
            <!-- Posbindu Lansia -->
            <div class="col-lg-6" data-aos="fade-left">
                <div class="service-card service-success">
                    <div class="service-icon">
                        <i class="fas fa-user-md"></i>
                    </div>
                    <h4 class="text-center mb-3">Posbindu Lansia</h4>
                    <p class="text-center mb-4">Pemeriksaan kesehatan berkala untuk lansia dengan deteksi dini penyakit degeneratif</p>
                    
                    <div class="service-stats">
                        <div class="text-center">
                            <div class="service-stat-value"><?= number_format($kesehatan_stats['posbindu']['total_lansia'] ?? 0) ?></div>
                            <div class="service-stat-label">Total Lansia</div>
                        </div>
                        <div class="text-center">
                            <div class="service-stat-value"><?= number_format($kesehatan_stats['posbindu']['total_hipertensi'] ?? 0) ?></div>
                            <div class="service-stat-label">Hipertensi</div>
                        </div>
                        <div class="text-center">
                            <div class="service-stat-value"><?= number_format($kesehatan_stats['posbindu']['total_diabetes'] ?? 0) ?></div>
                            <div class="service-stat-label">Diabetes</div>
                        </div>
                    </div>
                    
                    <div class="text-center mt-4">
                        <a href="<?= site_url('posbindu') ?>" class="btn btn-outline-success">Lihat Detail Posbindu</a>
                    </div>
                </div>
            </div>
        </div>
        
        
        
        <div class="text-center mt-4">
            <a href="<?= site_url('kesehatan') ?>" class="btn btn-primary animate-heartBeat">
                <i class="fas fa-stethoscope me-2"></i>Lihat Selengkapnya Layanan Kesehatan
            </a>
        </div>
    </div>
</section>

    <!-- JDIH - SECTION TERPISAH -->
    <section id="jdih" class="py-5 jdih-section">
        <div class="container position-relative">
            <h2 class="section-title text-white" data-aos="fade-in">Jaringan Dokumentasi dan Informasi Hukum</h2>
            
            <div class="row align-items-center">
                <div class="col-lg-6 mb-4 mb-lg-0" data-aos="fade-right">
                    <div class="jdih-card">
                        <div class="text-center mb-4">
                            <div class="d-inline-block p-3 rounded-circle" style="background: linear-gradient(135deg, #ffc107, #ff9800);">
                                <i class="fas fa-gavel fa-3x text-white"></i>
                            </div>
                        </div>
                        <h4 class="mb-3 text-center">JDIH Desa Kaliboja</h4>
                        <p class="text-muted mb-4 text-center">
                            Akses dokumen peraturan perundang-undangan dan produk hukum desa secara digital dan transparan
                        </p>
                        
                        <div class="row text-center mb-4">
                            <div class="col-6">
                                <h3 class="text-warning mb-0"><?= count($fitur_data['jdih']['peraturan_terbaru']) ?></h3>
                                <small class="text-muted">Peraturan Terbaru</small>
                            </div>
                            <div class="col-6">
                                <h3 class="text-warning mb-0">100%</h3>
                                <small class="text-muted">Transparansi</small>
                            </div>
                        </div>

                        <div class="text-center">
                            <a href="<?= site_url('jdih') ?>" class="btn btn-warning btn-lg w-100">
                                <i class="fas fa-book-open me-2"></i>Lihat Dokumen JDIH
                            </a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6" data-aos="fade-left">
                    <div class="jdih-card">
                        <h5 class="mb-3"><i class="fas fa-file-alt me-2 text-warning"></i>Peraturan Terbaru</h5>
                        <?php if(!empty($fitur_data['jdih']['peraturan_terbaru'])): ?>
                            <ul class="list-group list-group-flush">
                                <?php foreach(array_slice($fitur_data['jdih']['peraturan_terbaru'], 0, 5) as $peraturan): ?>
                                <li class="list-group-item d-flex justify-content-between align-items-start">
                                    <div class="ms-2 me-auto">
                                        <div class="fw-bold"><?= esc($peraturan['jenis_peraturan']) ?> No. <?= esc($peraturan['nomor']) ?></div>
                                        <small class="text-muted"><?= esc($peraturan['tentang']) ?></small>
                                    </div>
                                    <span class="badge bg-warning rounded-pill"><?= esc($peraturan['tahun']) ?></span>
                                </li>
                                <?php endforeach; ?>
                            </ul>
                            
                        <?php else: ?>
                            <p class="text-center text-muted">Belum ada peraturan</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- RKP DESA - SECTION TERPISAH -->
    <section id="rkp" class="py-5 rkp-section">
        <div class="container position-relative">
            <h2 class="section-title text-white" data-aos="fade-in">Rencana Kerja Pemerintah Desa</h2>
            
            <div class="row align-items-center">
                <div class="col-lg-6 order-lg-2 mb-4 mb-lg-0" data-aos="fade-left">
                    <div class="rkp-card">
                        <div class="text-center mb-4">
                            <div class="d-inline-block p-3 rounded-circle" style="background: linear-gradient(135deg, #17a2b8, #138496);">
                                <i class="fas fa-chart-line fa-3x text-white"></i>
                            </div>
                        </div>
                        <h4 class="mb-3 text-center">RKP Desa Kaliboja</h4>
                        <p class="text-muted mb-4 text-center">
                            Rencana pembangunan dan kegiatan desa yang terstruktur dan terukur untuk kemajuan bersama
                        </p>
                        
                        <div class="row text-center mb-4">
                            <div class="col-6">
                                <h3 class="text-info mb-0"><?= count($fitur_data['rkp']['kegiatan_terbaru']) ?></h3>
                                <small class="text-muted">Kegiatan Aktif</small>
                            </div>
                            <div class="col-6">
                                <h3 class="text-info mb-0"><?= date('Y') ?></h3>
                                <small class="text-muted">Tahun Berjalan</small>
                            </div>
                        </div>

                        <div class="text-center">
                            <a href="<?= site_url('rkp') ?>" class="btn btn-info btn-lg w-100">
                                <i class="fas fa-project-diagram me-2"></i>Lihat Rencana Lengkap
                            </a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 order-lg-1" data-aos="fade-right">
                    <div class="rkp-card">
                        <h5 class="mb-3"><i class="fas fa-tasks me-2 text-info"></i>Kegiatan Terbaru</h5>
                        <?php if(!empty($fitur_data['rkp']['kegiatan_terbaru'])): ?>
                            <ul class="list-group list-group-flush">
                                <?php foreach(array_slice($fitur_data['rkp']['kegiatan_terbaru'], 0, 5) as $kegiatan): ?>
                                <li class="list-group-item">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div class="ms-2 me-auto">
                                            <div class="fw-bold"><?= esc($kegiatan['nama_kegiatan']) ?></div>
                                            <small class="text-muted">
                                                <i class="fas fa-map-marker-alt me-1"></i><?= esc($kegiatan['lokasi']) ?>
                                            </small>
                                        </div>
                                        <span class="badge bg-info"><?= esc($kegiatan['progress']) ?>%</span>
                                    </div>
                                    <div class="progress mt-2" style="height: 5px;">
                                        <div class="progress-bar bg-info" style="width: <?= esc($kegiatan['progress']) ?>%"></div>
                                    </div>
                                </li>
                                <?php endforeach; ?>
                            </ul>
                           
                        <?php else: ?>
                            <p class="text-center text-muted">Belum ada kegiatan</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Koperasi Merah Putih -->
<section id="koperasi" class="py-5 koperasi-section">
    <div class="container position-relative">
        <h2 class="section-title text-white" data-aos="fade-in">Koperasi Merah Putih</h2>
        
        <div class="row align-items-center">
            <div class="col-lg-6 mb-4 mb-lg-0" data-aos="fade-right">
                <div class="koperasi-card">
                    <div class="text-center mb-4">
                        <div class="d-inline-block p-3 rounded-circle" style="background: linear-gradient(135deg, #dc3545, #c82333);">
                            <i class="fas fa-handshake fa-3x text-white"></i>
                        </div>
                    </div>
                    <h4 class="mb-3 text-center"><?= esc($koperasi['profile']['nama_koperasi'] ?? 'Koperasi Merah Putih') ?></h4>
                    <p class="text-muted mb-4 text-center">
                        Gotong royong untuk kesejahteraan bersama warga Desa Kaliboja
                    </p>
                    
                    <div class="row text-center mb-4">
                        <div class="col-6">
                            <h3 class="text-danger mb-0"><?= number_format($koperasi['statistik']['total_anggota'] ?? 0) ?></h3>
                            <small class="text-muted">Total Anggota</small>
                        </div>
                        <div class="col-6">
                            <h3 class="text-danger mb-0"><?= number_format($koperasi['statistik']['total_unit'] ?? 0) ?></h3>
                            <small class="text-muted">Unit Usaha</small>
                        </div>
                    </div>

                    <div class="text-center">
                        <a href="<?= site_url('koperasi') ?>" class="btn btn-danger btn-lg w-100">
                            <i class="fas fa-store me-2"></i>Kunjungi Koperasi
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-lg-6" data-aos="fade-left">
                <div class="koperasi-card">
                    <h5 class="mb-3"><i class="fas fa-box me-2 text-danger"></i>Unit Usaha Populer</h5>
                    <?php if(!empty($koperasi['units'])): ?>
                        <div class="row">
                            <?php foreach(array_slice($koperasi['units'], 0, 4) as $unit): ?>
                            <div class="col-6 mb-3">
                                <div class="border rounded p-2 text-center hover-lift">
                                    <div class="mb-2">
                                        <?php if($unit['gambar']): ?>
                                        <img src="<?= base_url('uploads/koperasi/unit/' . $unit['gambar']) ?>" 
                                             alt="<?= esc($unit['nama_unit']) ?>" 
                                             class="img-fluid rounded" 
                                             style="height: 80px; object-fit: cover;"
                                             onerror="this.src='https://via.placeholder.com/100x80/dc3545/ffffff?text=Unit'">
                                        <?php else: ?>
                                        <div class="bg-danger text-white rounded d-flex align-items-center justify-content-center" 
                                             style="height: 80px;">
                                            <i class="fas fa-box fa-2x"></i>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <h6 class="mb-1 small"><?= esc($unit['nama_unit']) ?></h6>
                                    <p class="mb-0 text-danger fw-bold">
                                        Rp <?= number_format($unit['harga'], 0, ',', '.') ?>
                                    </p>
                                    <a href="<?= site_url('koperasi/detail/' . $unit['id']) ?>" class="btn btn-sm btn-outline-danger mt-1 w-100">
                                        Detail
                                    </a>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <?php if(count($koperasi['units']) > 4): ?>
                        <div class="text-center mt-3">
                            <a href="<?= site_url('koperasi/unit-usaha') ?>" class="btn btn-sm btn-outline-danger">
                                Lihat Semua Unit <i class="fas fa-arrow-right ms-1"></i>
                            </a>
                        </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <p class="text-center text-muted">Belum ada unit usaha</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
    
    <!-- PROFIL DESA - PREMIUM DESIGN SIMPLIFIED -->
<section id="profil" class="py-5 position-relative overflow-hidden">
    <!-- Background Elements -->
    <div class="position-absolute top-0 start-0 w-100 h-100">
        <!-- Gradient Background -->
        <div class="position-absolute top-0 start-0 w-100 h-100" 
             style="background: linear-gradient(135deg, rgba(74, 108, 111, 0.95) 0%, rgba(58, 86, 89, 0.95) 100%), 
                    url('https://images.unsplash.com/photo-1506744038136-46273834b3fb?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80');
                    background-size: cover; background-position: center;">
        </div>
        
        <!-- Floating Elements -->
        <div class="floating-element" style="top: 20%; left: 10%; animation-delay: 0s;">
            <i class="fas fa-leaf text-white opacity-10 fa-2x"></i>
        </div>
        <div class="floating-element" style="top: 60%; right: 15%; animation-delay: 1s;">
            <i class="fas fa-mountain text-white opacity-10 fa-2x"></i>
        </div>
    </div>

    <div class="container position-relative z-2">
        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-8 col-sm-10">
                <div class="profil-container" data-aos="zoom-in" data-aos-duration="1000">
                    <!-- Main Card -->
                    <div class="card-glass p-4 p-md-5 rounded-4 border-0 overflow-hidden">
                        <!-- Animated Border -->
                        <div class="animated-border"></div>
                        
                        <!-- Content -->
                        <div class="text-center">
                            <!-- Icon -->
                            <div class="mb-4">
                                <div class="d-inline-block position-relative">
                                    <div class="icon-main bg-white text-desa d-flex align-items-center justify-content-center rounded-circle mx-auto" 
                                         style="width: 80px; height: 80px;">
                                        <i class="fas fa-landmark fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Title -->
                            <h3 class="text-white mb-4 fw-bold fs-2 fs-md-1">Profil Desa</h3>
                            
                            <!-- Main Button -->
                            <div class="d-grid">
                                <a href="/profil" class="btn-profil btn-lg px-4 py-3 fw-bold position-relative overflow-hidden">
                                    <span class="btn-text">Lihat Profil Lengkap</span>
                                    <span class="btn-icon"><i class="fas fa-arrow-right"></i></span>
                                    <span class="btn-shine"></span>
                                </a>
                            </div>
                            
                            <!-- Location -->
                            <div class="mt-4 pt-3 border-top border-white border-opacity-10">
                                <p class="text-light opacity-75 mb-0 small">
                                    <i class="fas fa-map-pin me-1"></i> Kaliboja, Paninggaran, Pekalongan
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

    
    <!-- Galeri Section -->
<section id="galeri" class="py-5 bg-light gallery-section">
    <div class="container">
        <div class="row align-items-center mb-4">
            <div class="col-12 position-relative text-center">
                <h2 class="section-title m-0" data-aos="fade-in">Galeri Desa</h2>
                <a href="<?= site_url('gallery') ?>"
                    class="btn btn-outline-primary btn-sm position-absolute end-0 top-50 translate-middle-y d-none d-md-inline-block">
                    Lihat Semua
                </a>
            </div>
        </div>

        <!-- Grid Galeri -->
        <div class="gallery-grid" id="galleryContainer">
            <?php if (!empty($galleries)): ?>
            <?php 
            // Batasi galeri yang ditampilkan (maksimal 12)
            $limitedGalleries = array_slice($galleries, 0, 12);
            foreach ($limitedGalleries as $index => $gallery): 
                $imagePath = 'uploads/gallery/' . esc($gallery['image']);
                $imageExists = !empty($gallery['image']) && file_exists(ROOTPATH . 'public/' . $imagePath);
                $category = !empty($gallery['category']) ? esc($gallery['category']) : 'umum';
                $uploadDate = isset($gallery['created_at']) ? date('d M Y', strtotime($gallery['created_at'])) : 'Tanggal tidak tersedia';
            ?>
            <div class="gallery-item" 
                 data-bs-toggle="modal" 
                 data-bs-target="#imageLightbox"
                 data-image="<?= $imageExists ? base_url($imagePath) : 'https://via.placeholder.com/800x600?text=Gambar+Tidak+Tersedia' ?>"
                 data-title="<?= esc($gallery['title']) ?>"
                 data-description="<?= esc($gallery['description'] ?? '') ?>"
                 data-category="<?= esc($gallery['category'] ?? 'Umum') ?>"
                 data-date="<?= $uploadDate ?>"
                 data-index="<?= $index ?>">
                <div class="gallery-image-container">
                    <img src="<?= $imageExists ? base_url($imagePath) : 'https://via.placeholder.com/300x200?text=Gambar+Tidak+Tersedia' ?>"
                        alt="<?= esc($gallery['title']) ?>" 
                        class="gallery-image" 
                        loading="lazy"
                        onerror="this.src='https://via.placeholder.com/300x200?text=Gambar+Tidak+Tersedia'">

                    <div class="gallery-overlay">
                        <h5 class="gallery-title"><?= esc($gallery['title']) ?></h5>
                        <?php if(!empty($gallery['category'])): ?>
                        <span class="gallery-category"><?= esc($gallery['category']) ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php else: ?>
            <div class="col-12">
                <div class="gallery-empty" data-aos="fade-in">
                    <i class="fas fa-images gallery-empty-icon"></i>
                    <h5 class="text-muted">Belum ada galeri</h5>
                    <?php if(session()->get('isLoggedIn')): ?>
                    <a href="<?= site_url('dashboard/gallery/create') ?>" class="btn btn-primary mt-2">Tambah Galeri</a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Tombol Lihat Semua untuk mobile -->
        <div class="text-center mt-4 d-md-none">
            <a href="<?= site_url('gallery') ?>" class="btn btn-outline-primary">Lihat Semua Galeri</a>
        </div>

        <!-- Tombol Lihat Selengkapnya -->
        <?php if(!empty($galleries) && count($galleries) > 12): ?>
        <div class="text-center mt-4 d-none d-md-block">
            <a href="<?= site_url('gallery') ?>" class="btn btn-outline-primary animate-heartBeat">
                Lihat Selengkapnya <i class="fas fa-arrow-right ms-2"></i>
            </a>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- Modal Lightbox - Disamakan dengan halaman galeri -->
<div class="modal fade" id="imageLightbox" tabindex="-1" aria-labelledby="imageLightboxLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="imageLightboxTitle">Judul Gambar</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="image-counter" id="modalImageCounter">1 / <?= min(12, count($galleries ?? [])) ?></div>
                <div class="modal-image-container">
                    <button class="modal-nav prev" onclick="navigateGalleryImage(-1)" aria-label="Gambar sebelumnya">
                        <i class="fas fa-chevron-left"></i>
                    </button>
                    
                    <img id="modalLightboxImage" src="" alt="" class="modal-image">
                    
                    <button class="modal-nav next" onclick="navigateGalleryImage(1)" aria-label="Gambar berikutnya">
                        <i class="fas fa-chevron-right"></i>
                    </button>
                </div>
                
                <div class="image-info">
                    <h6 id="modalLightboxImageTitle" class="image-title"></h6>
                    <p id="modalLightboxImageDescription" class="image-description"></p>
                    <div class="image-meta">
                        <span id="modalLightboxImageDate" class="image-date"></span>
                        <span id="modalLightboxImageCategory" class="image-category"></span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <div class="d-flex justify-content-between w-100">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i> Tutup
                    </button>
                    <div>
                        <button type="button" class="btn btn-outline-primary me-2" onclick="rotateGalleryImage(-90)" title="Putar kiri">
                            <i class="fas fa-undo"></i>
                        </button>
                        <button type="button" class="btn btn-outline-primary me-2" onclick="rotateGalleryImage(90)" title="Putar kanan">
                            <i class="fas fa-redo"></i>
                        </button>
                        <button type="button" class="btn btn-primary" onclick="downloadGalleryImage()">
                            <i class="fas fa-download me-1"></i> Unduh
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    <!-- Testimoni -->
    <section id="testimoni" class="py-5">
        <div class="container">
            <h2 class="section-title" data-aos="fade-down">Apa Kata Mereka?</h2>

            <!-- Form Testimoni -->
            <div class="row mb-5" data-aos="fade-up">
                <div class="col-md-8 mx-auto">
                    <div class="testimonial-form">
                        <h4 class="mb-4 text-center">Berikan Kesan dan Pesan Anda</h4>
                        <form id="testimoniForm">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="nama" placeholder="Nama Lengkap"
                                            required>
                                        <label for="nama">Nama Lengkap</label>
                                        <div class="invalid-feedback">Harap masukkan nama lengkap</div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="form-floating">
                                        <input type="email" class="form-control" id="email" placeholder="Alamat Email">
                                        <label for="email">Alamat Email</label>
                                        <div class="invalid-feedback">Format email tidak valid</div>
                                    </div>
                                </div>
                            </div>
                            <div class="mb-3">
                                <div class="form-floating">
                                    <textarea class="form-control" placeholder="Tulis kesan dan pesan Anda di sini"
                                        id="pesan" style="height: 120px" required maxlength="500"></textarea>
                                    <label for="pesan">Kesan dan Pesan</label>
                                    <div class="invalid-feedback">Harap masukkan kesan dan pesan</div>
                                    <div class="form-text"><span id="charCount">0</span>/500 karakter</div>
                                </div>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary px-4">
                                    <i class="fas fa-paper-plane me-2"></i>Kirim Testimoni
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Daftar Testimoni -->
            <div class="row testimonial-list">
                <div class="col-md-8 mx-auto">
                    <h4 class="mb-4 text-center" data-aos="fade-down">Testimoni Masyarakat</h4>
                    <div id="testimoniContainer">
                        <!-- Testimoni akan dimuat secara dinamis di sini -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    
       <!-- Statistik Pengunjung REAL -->
<section id="statistik" class="py-5 bg-light">
    <div class="container">
        <h2 class="section-title" data-aos="fade-in">📊 Statistik Kunjungan REAL</h2>
        
        <div class="row g-4">
            <!-- Hari Ini -->
            <div class="col-md-4 col-lg-2" data-aos="fade-up">
                <div class="stat-card text-center">
                    <div class="live-indicator"></div>
                    <i class="fas fa-calendar-day text-primary mb-3 fa-2x"></i>
                    <div class="counter" data-target="<?= $visitor_stats['today']['visits'] ?? 1 ?>">0</div>
                    <p class="mb-0 fw-bold">Hari Ini</p>
                    <small class="text-muted">Anda pengunjung ke-<?= $visitor_stats['today']['visits'] ?? 1 ?></small>
                </div>
            </div>
            
            <!-- Kemarin -->
            <div class="col-md-4 col-lg-2" data-aos="fade-up" data-aos-delay="100">
                <div class="stat-card text-center">
                    <i class="fas fa-history text-primary mb-3 fa-2x"></i>
                    <div class="counter" data-target="<?= $visitor_stats['yesterday']['visits'] ?? 0 ?>">0</div>
                    <p class="mb-0 fw-bold">Kemarin</p>
                    <small class="text-muted"><?= date('d M', strtotime('-1 day')) ?></small>
                </div>
            </div>
            
            <!-- 7 Hari -->
            <div class="col-md-4 col-lg-2" data-aos="fade-up" data-aos-delay="200">
                <div class="stat-card text-center">
                    <i class="fas fa-calendar-week text-primary mb-3 fa-2x"></i>
                    <div class="counter" data-target="<?= $visitor_stats['thisWeek']['total_visits'] ?? 0 ?>">0</div>
                    <p class="mb-0 fw-bold">7 Hari</p>
                    <small class="text-muted">Terakhir</small>
                </div>
            </div>
            
            <!-- 30 Hari -->
            <div class="col-md-4 col-lg-2" data-aos="fade-up" data-aos-delay="300">
                <div class="stat-card text-center">
                    <i class="fas fa-calendar-alt text-primary mb-3 fa-2x"></i>
                    <div class="counter" data-target="<?= $visitor_stats['thisMonth']['total_visits'] ?? 0 ?>">0</div>
                    <p class="mb-0 fw-bold">30 Hari</p>
                    <small class="text-muted">Terakhir</small>
                </div>
            </div>
            
            <!-- Total -->
            <div class="col-md-4 col-lg-2" data-aos="fade-up" data-aos-delay="400">
                <div class="stat-card text-center">
                    <i class="fas fa-chart-line text-primary mb-3 fa-2x"></i>
                    <?php 
                    $avg = $visitor_stats['thisMonth']['total_visits'] > 0 ? 
                           round($visitor_stats['thisMonth']['total_visits'] / 30) : 0;
                    ?>
                    <div class="counter" data-target="<?= $avg ?>">0</div>
                    <p class="mb-0 fw-bold">Rata-rata</p>
                    <small class="text-muted">Per hari</small>
                </div>
            </div>
            
            <!-- Total Kunjungan -->
            <div class="col-md-4 col-lg-2" data-aos="fade-up" data-aos-delay="500">
                <div class="stat-card text-center">
                    <i class="fas fa-users text-primary mb-3 fa-2x"></i>
                    <div class="counter" data-target="<?= $visitor_stats['total']['total'] ?? 1 ?>">0</div>
                    <p class="mb-0 fw-bold">Total</p>
                    <small class="text-muted">Semua waktu</small>
                </div>
            </div>
        </div>
        
        
        <!-- Log Aktifitas -->
        <div class="row mt-4" data-aos="fade-up">
            <div class="col-12">
                <div class="stat-card">
                   <h6 class="mb-1">Sistem berjalan normal!</h6>
                                <p class="mb-0">
                                    Anda adalah pengunjung ke-<strong><?= $visitor_stats['today']['visits'] ?? 1 ?></strong> 
                                    hari ini (<?= date('d M Y') ?>).
                                </p> 
                   
                </div>
            </div>
        </div>
    </div>
</section>
    <!-- Peta -->
    <section class="container-fluid p-0" data-aos="fade-up">
        <div class="row g-0">
            <div class="col-md-8 order-2 order-md-1" data-aos="swing" data-aos-delay="100">
                <iframe src="https://maps.google.com/maps?q=desa%20kaliboja&t=&z=13&ie=UTF8&iwloc=&output=embed"
                    width="100%" height="450" style="border:0" loading="lazy" allowfullscreen></iframe>
            </div>
            <div class="col-md-4 bg-primary text-white p-3 order-1 order-md-1" data-aos="rubberBand"
                data-aos-delay="200">
                <div class="contact-header">
                    <h3 class="mb-2" data-aos="fade-right">Kunjungi Desa Kami</h3>

                    <div class="contact-info mt-2">
                        <p data-aos="fade-right" data-aos-delay="100">
                            <i class="fa-solid fa-location-dot contact-icon"></i>
                            <span>Desa Kaliboja, Kec. Paninggaran, Kabupaten Pekalongan, Jawa Tengah</span>
                        </p>
                        <p data-aos="fade-right" data-aos-delay="300">
                            <i class="fa-solid fa-envelope contact-icon"></i>
                            <span>kalibojadesa@gmail.com</span>
                        </p>
                        <p data-aos="fade-right" data-aos-delay="400">
                            <i class="fa-solid fa-clock contact-icon"></i>
                            <span>Senin - Jumat: 08:00 - 16:00</span>
                        </p>

                        <a href="https://goo.gl/maps/example" target="_blank" class="btn btn-light mt-2 btn-hover-lift"
                            data-aos="bounceIn" data-aos-delay="500">
                            <i class="fa-solid fa-directions me-2"></i> Dapatkan Petunjuk Arah
                        </a>

                    </div>
                </div>
            </div>
        </div>
    </section>



    <!-- Footer -->
    <footer class="mt-0">
        <div class="container py-5">
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <h5 class="text-white mb-4">Desa Kaliboja</h5>
                    <p class="mb-4">Portal resmi desa untuk transparansi informasi, promosi potensi, dan
                        pelayanan digital kepada masyarakat.</p>
                    <div class="d-flex">
                        <a href="https://www.facebook.com/share/17fpGKh173/" target="_blank"
                            class="text-white me-3 hover-lift">
                            <div class="social-icon">
                                <i class="fa-brands fa-facebook-f"></i>
                            </div>
                        </a>
                        <a href="https://www.instagram.com/desa_kaliboja?igsh=MTB2enB2N3I4dGp2OA==" target="_blank"
                            class="text-white me-3 hover-lift">
                            <div class="social-icon">
                                <i class="fa-brands fa-instagram"></i>
                            </div>
                        </a>
                        <a href="https://x.com/desa_kaliboja?t=taTDsUWdhSoPbIiqADFfyQ&s=09&fbclid=PAdGRjcAMvYX1leHRuA2FlbQIxMQABp9AdVHP8awNqQGOky0UFUiiEt9za1hiL0Wldzmpg5X_LPj7CyczURUw5Jk2f_aem_r-xoS5uVycPxEOxfhEjr2A"
                            target="_blank" class="text-white me-3 hover-lift">
                            <div class="social-icon">
                                <i class="fa-brands fa-x-twitter"></i>
                            </div>
                        </a>
                        <a href="https://www.tiktok.com/@desa_kaliboja?fbclid=PAdGRjcAMvYeNleHRuA2FlbQIxMQABp-jUXBxjp43fgoeGN6x01EfX3g1Nj10GpaTEukdsoluv5Zt4yNimvhdrphwe_aem_5lvWmF8h8HUWv1miYT-y0A"
                            target="_blank" class="text-white hover-lift">
                            <div class="social-icon">
                                <i class="fa-brands fa-tiktok"></i>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <h5 class="text-white mb-4">Kontak</h5>
                    <ul class="list-unstyled small">
                        <li class="mb-2"><i class="fa-solid fa-location-dot me-2"></i>Desa Kaliboja,
                            Kec. Paninggaran,
                            Kabupaten Pekalongan, Jawa Tengah</li>
                        <li class="mb-2"><i class="fa-solid fa-envelope me-2"></i>kalibojadesa@gmail.com
                        </li>
                        <li><i class="fa-solid fa-clock me-2"></i>Senin - Jumat: 08:00 - 16:00</li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-12">
                    <h5 class="text-white mb-4">Tautan Cepat</h5>
                    <div class="row">
                        <div class="col-6">
                            <ul class="list-unstyled small">
                                <li class="mb-2"><a href="#berita"
                                        class="hover-lift text-white text-decoration-none">Berita</a></li>
                                <li class="mb-2"><a href="#wisata"
                                        class="hover-lift text-white text-decoration-none">Wisata</a></li>
                                <li class="mb-2"><a href="#produk"
                                        class="hover-lift text-white text-decoration-none">Produk</a></li>
                                <li class="mb-2"><a href="#layanan"
                                        class="hover-lift text-white text-decoration-none">Layanan</a></li>
                                <li class="mb-2"><a href="#jdih"
                                        class="hover-lift text-white text-decoration-none">JDIH</a></li>
                            </ul>
                        </div>
                        <div class="col-6">
                            <ul class="list-unstyled small">
                                <li class="mb-2"><a href="#rkp"
                                        class="hover-lift text-white text-decoration-none">RKP</a></li>
                                <li class="mb-2"><a href="#koperasi"
                                        class="hover-lift text-white text-decoration-none">Koperasi</a></li>
                                <li class="mb-2"><a href="#profil"
                                        class="hover-lift text-white text-decoration-none">Profil</a></li>
                                <li class="mb-2"><a href="#galeri"
                                        class="hover-lift text-white text-decoration-none">Galeri</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <hr class="border-secondary my-4">
            <div class="text-center small">
                <div class="mb-2">&copy; 2025 Pemerintah Desa Kaliboja. All Rights Reserved.
                </div>
                <div>Dikembangkan oleh <a href="#" class="text-white hover-lift text-decoration-none">Tim IT KKN 4
                        Kelompok 7
                        Desa Kaliboja</a></div>
            </div>
        </div>
    </footer>

    <!-- Floating WA & To Top -->
    <a class="wa-float btn btn-success rounded-circle shadow" href="https://wa.me/" target="_blank"
        title="Hubungi via WhatsApp">
        <i class="fa-brands fa-whatsapp fa-lg"></i>
    </a>

    <button id="toTop" class="to-top btn btn-primary rounded-circle shadow" title="Kembali ke atas">
        <i class="fa-solid fa-arrow-up"></i>
    </button>

    <!-- Loading Spinner -->
    <div class="loading-spinner"
        style="position:fixed;top:0;left:0;width:100%;height:100%;background:white;z-index:9999;display:flex;align-items:center;justify-content:center;transition:opacity 0.5s ease">
        <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
document.addEventListener('DOMContentLoaded', function() {
    // Inisialisasi AOS
    if (typeof AOS !== 'undefined') {
        AOS.init({
            once: true,
            duration: 1000,
            offset: 100
        });
    }

    // Loading spinner
    window.addEventListener('load', function() {
        setTimeout(function() {
            const spinner = document.querySelector('.loading-spinner');
            if (spinner) {
                spinner.style.opacity = '0';
                setTimeout(() => spinner.style.display = 'none', 500);
            }
        }, 1000);
    });

    // Scroll to top
    const toTop = document.getElementById('toTop');
    if (toTop) {
        window.addEventListener('scroll', function() {
            toTop.style.display = window.scrollY > 400 ? 'block' : 'none';
        });
        
        toTop.addEventListener('click', function(e) {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // Navbar scroll effect
    window.addEventListener('scroll', function() {
        const navbar = document.querySelector('.navbar');
        if (navbar) {
            navbar.classList.toggle('scrolled', window.scrollY > 100);
        }
    });

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                e.preventDefault();
                const navbarHeight = document.querySelector('.navbar')?.offsetHeight || 70;
                const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - navbarHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Counter animation
    function animateCounters() {
        document.querySelectorAll('.counter').forEach(counter => {
            const target = +counter.dataset.target || 0;
            if (target > 0) {
                let current = 0;
                const step = Math.max(1, Math.floor(target / 50));
                const timer = setInterval(() => {
                    current += step;
                    if (current >= target) {
                        current = target;
                        clearInterval(timer);
                    }
                    counter.textContent = current.toLocaleString('id-ID');
                }, 30);
            }
        });
    }
    setTimeout(animateCounters, 1000);

    // =============================================
    // GALERI FUNCTIONALITY - VERSION FIXED
    // =============================================
    
    // Global variables
    let currentGalleryIndex = 0;
    let galleriesData = [];
    
    // Initialize gallery from PHP data
    try {
        // Parse gallery data from PHP - FIX FOR INVALID JSON
        const galleriesJson = <?= isset($limitedGalleries) ? json_encode($limitedGalleries) : '[]' ?>;
        galleriesData = Array.isArray(galleriesJson) ? galleriesJson : [];
        
        console.log('Gallery data loaded:', galleriesData.length, 'items');
    } catch (e) {
        console.error('Error loading gallery data:', e);
        galleriesData = [];
    }
    
    // Initialize gallery
    function initializeGallery() {
        console.log('Initializing gallery with', galleriesData.length, 'items');
        
        // Add click handlers to gallery items
        document.querySelectorAll('.gallery-item').forEach((item, index) => {
            // Add animation
            setTimeout(() => {
                item.classList.add('visible');
            }, index * 100);
            
            // Add click handler
            item.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                const dataIndex = this.dataset.index ? parseInt(this.dataset.index) : index;
                openLightbox(dataIndex);
            });
        });
        
        // Initialize lightbox modal
        const lightboxModal = document.getElementById('imageLightbox');
        if (lightboxModal) {
            const modal = new bootstrap.Modal(lightboxModal);
            
            // Keyboard navigation
            document.addEventListener('keydown', function(e) {
                if (lightboxModal.classList.contains('show')) {
                    switch(e.key) {
                        case 'ArrowLeft':
                            e.preventDefault();
                            navigateGallery(-1);
                            break;
                        case 'ArrowRight':
                            e.preventDefault();
                            navigateGallery(1);
                            break;
                        case 'Escape':
                            modal.hide();
                            break;
                    }
                }
            });
            
            // Touch events for mobile
            const modalImage = document.getElementById('modalLightboxImage');
            if (modalImage) {
                let touchStartX = 0;
                
                modalImage.addEventListener('touchstart', function(e) {
                    touchStartX = e.touches[0].clientX;
                });
                
                modalImage.addEventListener('touchend', function(e) {
                    const touchEndX = e.changedTouches[0].clientX;
                    const diff = touchStartX - touchEndX;
                    
                    if (Math.abs(diff) > 50) {
                        if (diff > 0) {
                            // Swipe left -> next
                            navigateGallery(1);
                        } else {
                            // Swipe right -> previous
                            navigateGallery(-1);
                        }
                    }
                });
            }
            
            // Modal hidden event
            lightboxModal.addEventListener('hidden.bs.modal', function() {
                resetImageRotation();
            });
        }
    }
    
    // Open lightbox
    function openLightbox(index) {
        if (galleriesData.length === 0) {
            console.warn('No gallery data available');
            return;
        }
        
        currentGalleryIndex = Math.max(0, Math.min(index, galleriesData.length - 1));
        
        // Show modal
        const lightboxModal = document.getElementById('imageLightbox');
        if (lightboxModal) {
            const modal = bootstrap.Modal.getOrCreateInstance(lightboxModal);
            updateLightboxContent();
            modal.show();
        }
    }
    
    // Update lightbox content
    function updateLightboxContent() {
        if (galleriesData.length === 0 || currentGalleryIndex >= galleriesData.length) {
            console.error('Invalid gallery data or index');
            return;
        }
        
        const item = galleriesData[currentGalleryIndex];
        if (!item) return;
        
        console.log('Updating lightbox with item:', item);
        
        // Update text content
        document.getElementById('imageLightboxTitle').textContent = item.title || 'Tanpa Judul';
        document.getElementById('modalLightboxImageTitle').textContent = item.title || 'Tanpa Judul';
        document.getElementById('modalLightboxImageDescription').textContent = 
            item.description || 'Tidak ada deskripsi';
        
        // Date
        const dateStr = item.created_at || item.date || new Date().toISOString();
        const displayDate = new Date(dateStr).toLocaleDateString('id-ID', {
            day: 'numeric',
            month: 'long',
            year: 'numeric'
        });
        document.getElementById('modalLightboxImageDate').innerHTML = 
            `<i class="far fa-calendar me-1"></i>${displayDate}`;
        
        // Category
        const category = item.category || 'Umum';
        document.getElementById('modalLightboxImageCategory').innerHTML = 
            `<i class="fas fa-tag me-1"></i>${category}`;
        
        // Image
        const modalImage = document.getElementById('modalLightboxImage');
        const baseUrl = '<?= base_url() ?>' || window.location.origin + '/';
        
        if (item.image && item.image.trim() !== '') {
            const imagePath = 'uploads/gallery/' + item.image;
            modalImage.src = baseUrl + imagePath;
            modalImage.alt = item.title || 'Galeri';
            
            // Handle image error
            modalImage.onerror = function() {
                console.error('Failed to load image:', imagePath);
                this.src = 'https://via.placeholder.com/800x600/4A6C6F/FFFFFF?text=Gambar+Tidak+Tersedia';
                this.alt = 'Gambar tidak tersedia';
            };
        } else {
            modalImage.src = 'https://via.placeholder.com/800x600/4A6C6F/FFFFFF?text=Gambar+Tidak+Tersedia';
            modalImage.alt = 'Gambar tidak tersedia';
        }
        
        // Reset rotation
        modalImage.style.transform = 'rotate(0deg)';
        
        // Update counter
        const counterElement = document.getElementById('modalImageCounter');
        if (counterElement) {
            counterElement.textContent = `${currentGalleryIndex + 1} / ${galleriesData.length}`;
        }
    }
    
    // Navigate gallery
    function navigateGallery(direction) {
        if (galleriesData.length === 0) return;
        
        currentGalleryIndex += direction;
        
        // Loop around
        if (currentGalleryIndex < 0) {
            currentGalleryIndex = galleriesData.length - 1;
        } else if (currentGalleryIndex >= galleriesData.length) {
            currentGalleryIndex = 0;
        }
        
        updateLightboxContent();
    }
    
    // Rotate image
    window.rotateGalleryImage = function(degrees) {
        const modalImage = document.getElementById('modalLightboxImage');
        if (!modalImage) return;
        
        const currentRotation = parseInt(modalImage.style.transform.replace('rotate(', '').replace('deg)', '')) || 0;
        const newRotation = currentRotation + degrees;
        modalImage.style.transform = `rotate(${newRotation}deg)`;
    }
    
    // Reset image rotation
    function resetImageRotation() {
        const modalImage = document.getElementById('modalLightboxImage');
        if (modalImage) {
            modalImage.style.transform = 'rotate(0deg)';
        }
    }
    
    // Download image
    window.downloadGalleryImage = function() {
        const modalImage = document.getElementById('modalLightboxImage');
        if (!modalImage) return;
        
        const link = document.createElement('a');
        link.href = modalImage.src;
        link.download = `galeri-desa-kaliboja-${currentGalleryIndex + 1}.jpg`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
    
    // Expose navigate function for buttons
    window.navigateGalleryImage = navigateGallery;
    
    // Initialize gallery after a short delay
    setTimeout(initializeGallery, 500);
    
    // =============================================
    // TESTIMONI FUNCTIONALITY
    // =============================================
    
    // Character count for testimoni form
    const testimoniForm = document.getElementById('testimoniForm');
    if (testimoniForm) {
        const textarea = testimoniForm.querySelector('#pesan');
        const charCount = testimoniForm.querySelector('#charCount');
        
        if (textarea && charCount) {
            textarea.addEventListener('input', function() {
                charCount.textContent = this.value.length;
            });
        }
        
        testimoniForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            // Simple validation
            const nama = document.getElementById('nama').value.trim();
            const pesan = document.getElementById('pesan').value.trim();
            
            if (!nama || !pesan) {
                alert('Harap isi nama dan pesan');
                return;
            }
            
            // Show loading
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Mengirim...';
            submitBtn.disabled = true;
            
            try {
                // Simulate API call
                await new Promise(resolve => setTimeout(resolve, 1000));
                
                // Success
                alert('Testimoni berhasil dikirim! Terima kasih atas masukan Anda.');
                this.reset();
                if (charCount) charCount.textContent = '0';
                
                // Add to DOM
                const testimoniEl = document.createElement('div');
                testimoniEl.className = 'testimonial-item';
                testimoniEl.innerHTML = `
                    <div class="testimonial-meta">
                        <strong class="testimonial-author">${nama}</strong>
                        <span class="testimonial-date">${new Date().toLocaleDateString('id-ID')}</span>
                    </div>
                    <p>${pesan}</p>
                `;
                
                const container = document.getElementById('testimoniContainer');
                if (container) {
                    container.prepend(testimoniEl);
                }
                
            } catch (error) {
                console.error('Error:', error);
                alert('Terjadi kesalahan saat mengirim testimoni');
            } finally {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }
        });
    }
    
    // Load initial testimonials
    async function loadTestimonials() {
        try {
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 500));
            
            const container = document.getElementById('testimoniContainer');
            if (container) {
                container.innerHTML = `
                    <div class="testimonial-item">
                        <div class="testimonial-meta">
                            <strong class="testimonial-author">Budi Santoso</strong>
                            <span class="testimonial-date">15 Desember 2024</span>
                        </div>
                        <p>Website desa sangat informatif dan membantu saya mendapatkan informasi terbaru tentang kegiatan desa.</p>
                    </div>
                    <div class="testimonial-item">
                        <div class="testimonial-meta">
                            <strong class="testimonial-author">Siti Aminah</strong>
                            <span class="testimonial-date">10 Desember 2024</span>
                        </div>
                        <p>Pelayanan melalui website sangat memudahkan, terutama untuk melihat jadwal posyandu dan kegiatan desa.</p>
                    </div>
                `;
            }
        } catch (error) {
            console.error('Error loading testimonials:', error);
        }
    }
    
    if (document.getElementById('testimoniContainer')) {
        loadTestimonials();
    }
    
    // =============================================
    // OTHER FUNCTIONALITY
    // =============================================
    
    // Handle image errors
    document.querySelectorAll('img').forEach(img => {
        img.addEventListener('error', function() {
            if (!this.src.includes('placeholder')) {
                this.src = 'https://via.placeholder.com/400x300/4A6C6F/FFFFFF?text=Gambar+Tidak+Tersedia';
                this.alt = 'Gambar tidak tersedia';
            }
        });
    });
    
    // Mobile menu close on click
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function() {
            const navbarCollapse = document.getElementById('navMenu');
            const navbarToggler = document.querySelector('.navbar-toggler');
            
            if (navbarCollapse && navbarCollapse.classList.contains('show') && navbarToggler) {
                navbarToggler.click();
            }
        });
    });
    
    // Hero carousel
    const heroCarousel = document.getElementById('heroCarousel');
    if (heroCarousel) {
        heroCarousel.addEventListener('slide.bs.carousel', function(e) {
            const caption = e.relatedTarget.querySelector('.carousel-caption');
            if (caption) {
                const h1 = caption.querySelector('h1');
                const p = caption.querySelector('p');
                
                if (h1) h1.style.animation = 'none';
                if (p) p.style.animation = 'none';
                
                setTimeout(() => {
                    if (h1) h1.style.animation = 'fadeInDown 1s ease';
                    if (p) p.style.animation = 'fadeInUp 1s ease';
                }, 50);
            }
        });
    }
});
</script>
</body>

</html>