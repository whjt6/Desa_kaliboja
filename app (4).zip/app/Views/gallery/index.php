<!doctype html>
<html lang="id">

<head>
    <!-- Polyfill untuk browser lama -->
    <script src="https://cdn.jsdelivr.net/npm/es6-promise@4/dist/es6-promise.auto.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/whatwg-fetch@3.6.2/dist/fetch.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/3.21.1/minified.min.js"></script>

    <!-- Memaksa IE menggunakan mode rendering terbaru -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Galeri Desa Kaliboja | Website Resmi</title>
    <meta name="description"
        content="Galeri foto dan dokumentasi kegiatan Desa Kaliboja - Lihat berbagai aktivitas, potensi, dan keindahan desa kami.">
    <link rel="icon" href="/img/logo.png" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600&display=swap"
        rel="stylesheet">
    <style>
    /* Variabel CSS */
    :root {
        --primary: #4A6C6F;
        --primary-dark: #3a5659;
        --secondary: #F4EAD5;
        --accent: #D6A25B;
        --accent-light: #e6b877;
        --dark: #1f2937;
        --light: #F9F7F3;
        --success: #28a745;
        --text-dark: #333;
        --text-light: #6c757d;
        --shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        --shadow-hover: 0 10px 25px rgba(0, 0, 0, 0.15);
        --border-radius: 0.75rem;
    }

    /* Dasar Typography */
    body {
        background: var(--light);
        color: var(--text-dark);
        font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Ubuntu, 'Helvetica Neue', Arial, sans-serif;
        line-height: 1.6;
        font-size: 1rem;
        scroll-behavior: smooth;
    }

    h1, h2, h3, h4, h5, h6,
    .navbar-brand {
        font-family: 'Poppins', sans-serif;
        font-weight: 700;
        line-height: 1.3;
    }

    h1 { font-size: 2.5rem; }
    h2 { font-size: 2rem; }
    h3 { font-size: 1.75rem; }
    h4 { font-size: 1.5rem; }
    h5 { font-size: 1.25rem; }
    h6 { font-size: 1.1rem; }

    p, li, td, th {
        font-size: 1rem;
        line-height: 1.6;
    }

    .lead {
        font-size: 1.2rem;
        font-weight: 400;
    }

    /* Navbar */
    .navbar {
        box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
        padding: 0.8rem 0;
        transition: all 0.3s ease;
    }

    .navbar.scrolled {
        padding: 0.5rem 0;
        background: rgba(255, 255, 255, 0.95) !important;
        backdrop-filter: blur(10px);
    }

    .navbar-brand img {
        height: 40px;
        transition: all 0.3s ease;
    }

    .navbar.scrolled .navbar-brand img {
        height: 36px;
    }

    .nav-link {
        font-weight: 500;
        position: relative;
        padding: 0.5rem 0.8rem !important;
        margin: 0 0.2rem;
        transition: all 0.3s ease;
        font-size: 0.95rem;
    }

    .nav-link::before {
        content: '';
        position: absolute;
        bottom: 0;
        left: 50%;
        width: 0;
        height: 2px;
        background: var(--accent);
        transition: all 0.3s ease;
        transform: translateX(-50%);
    }

    .nav-link:hover::before,
    .nav-link.active::before {
        width: 70%;
    }

    /* Tombol */
    .btn-primary {
        background: var(--primary);
        border-color: var(--primary);
        padding: 0.6rem 1.5rem;
        font-weight: 500;
        transition: all 0.3s ease;
        font-size: 0.95rem;
    }

    .btn-primary:hover {
        background: var(--primary-dark);
        border-color: var(--primary-dark);
        transform: translateY(-2px);
        box-shadow: var(--shadow-hover);
    }

    .btn-outline-primary {
        color: var(--primary);
        border-color: var(--primary);
        font-weight: 500;
        transition: all 0.3s ease;
        font-size: 0.95rem;
    }

    .btn-outline-primary:hover {
        background: var(--primary);
        border-color: var(--primary);
        transform: translateY(-2px);
    }

    /* Section Title */
    .section-title {
        font-weight: 700;
        color: var(--primary);
        text-align: center;
        margin-bottom: 2.4rem;
        position: relative;
    }

    .section-title::after {
        content: '';
        display: block;
        width: 84px;
        height: 4px;
        background: var(--accent);
        margin: 0.8rem auto 0;
        border-radius: 2px;
    }

    /* Hero Section */
    .hero-section {
        background: linear-gradient(135deg, var(--primary-dark), var(--primary));
        color: white;
        position: relative;
        overflow: hidden;
        padding: 6rem 0 4rem;
    }

    .hero-section::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: url("data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 0h20L0 20z' fill='%23ffffff' fill-opacity='0.05'/%3E%3C/svg%3E");
        opacity: 0.1;
    }

    /* Gallery Styles */
    .gallery-item {
        position: relative;
        overflow: hidden;
        border-radius: var(--border-radius);
        margin-bottom: 1.5rem;
        transition: all 0.3s ease;
        background: white;
        box-shadow: var(--shadow);
        cursor: pointer;
    }

    .gallery-item:hover {
        transform: translateY(-5px);
        box-shadow: var(--shadow-hover);
    }

    .gallery-img {
        width: 100%;
        height: 250px;
        object-fit: cover;
        transition: transform 0.3s ease;
    }

    .gallery-item:hover .gallery-img {
        transform: scale(1.05);
    }

    .gallery-content {
        padding: 1.5rem;
    }

    .gallery-title {
        font-weight: 600;
        color: var(--primary);
        margin-bottom: 0.5rem;
        font-size: 1.1rem;
    }

    .gallery-description {
        color: var(--text-light);
        font-size: 0.9rem;
        line-height: 1.5;
        margin-bottom: 0.5rem;
    }

    .gallery-date {
        color: var(--text-light);
        font-size: 0.8rem;
        display: flex;
        align-items: center;
        gap: 0.3rem;
    }

    .no-gallery {
        text-align: center;
        padding: 4rem 2rem;
        color: var(--text-light);
    }

    .no-gallery i {
        font-size: 4rem;
        margin-bottom: 1rem;
        display: block;
        color: var(--accent-light);
    }

    /* Modal Styles - IMPROVED */
    .modal-content {
        border-radius: var(--border-radius);
        border: none;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        overflow: hidden;
    }

    .modal-header {
        border-bottom: 1px solid rgba(0,0,0,0.1);
        background: var(--primary);
        color: white;
        padding: 1rem 1.5rem;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .modal-title {
        font-size: 1.1rem;
        font-weight: 600;
        margin: 0;
    }

    .btn-close-white {
        filter: invert(1) grayscale(100%) brightness(200%);
    }

    .modal-body {
        padding: 0;
        position: relative;
        max-height: 70vh;
        overflow-y: auto;
    }

    .modal-image-container {
        position: relative;
        background: #000;
        min-height: 300px;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
    }

    .modal-image {
        max-width: 100%;
        max-height: 50vh;
        width: auto;
        height: auto;
        object-fit: contain;
        display: block;
        margin: 0 auto;
    }

    .modal-footer {
        border-top: 1px solid rgba(0,0,0,0.1);
        background: #f8f9fa;
        padding: 1rem 1.5rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .image-info {
        padding: 1.5rem;
        background: white;
    }

    .image-title {
        font-weight: 600;
        color: var(--primary);
        margin-bottom: 0.75rem;
        font-size: 1.2rem;
        line-height: 1.4;
    }

    .image-description {
        color: var(--text-light);
        margin-bottom: 1rem;
        line-height: 1.6;
        font-size: 0.95rem;
    }

    .image-meta {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 0.9rem;
        color: var(--text-light);
        padding-top: 0.75rem;
        border-top: 1px solid rgba(0,0,0,0.1);
    }

    /* Navigation arrows - IMPROVED */
    .modal-nav {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        background: rgba(0,0,0,0.7);
        color: white;
        border: none;
        width: 50px;
        height: 50px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.2rem;
        transition: all 0.3s ease;
        z-index: 10;
        opacity: 0.7;
    }

    .modal-nav:hover {
        background: rgba(0,0,0,0.9);
        transform: translateY(-50%) scale(1.1);
        opacity: 1;
    }

    .modal-nav.prev {
        left: 15px;
    }

    .modal-nav.next {
        right: 15px;
    }

    /* Modal image counter */
    .image-counter {
        background: rgba(0,0,0,0.7);
        color: white;
        padding: 5px 15px;
        border-radius: 20px;
        font-size: 0.85rem;
        position: absolute;
        top: 15px;
        right: 15px;
        z-index: 10;
    }

    /* Footer */
    footer {
        background: linear-gradient(to right, #0a1920, #111);
        color: #bbb;
        position: relative;
        overflow: hidden;
    }

    footer::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 4px;
        background: linear-gradient(to right, var(--accent), var(--primary));
    }

    footer a {
        color: #bbb;
        text-decoration: none;
        transition: all 0.3s ease;
    }

    footer a:hover {
        color: #fff;
        padding-left: 5px;
    }

    /* Floating buttons */
    .wa-float {
        position: fixed;
        right: 20px;
        bottom: 20px;
        z-index: 1030;
        animation: pulse 2s infinite, float 3s ease-in-out infinite;
    }

    .to-top {
        position: fixed;
        right: 20px;
        bottom: 80px;
        z-index: 1030;
        display: none;
        animation: fadeIn 0.5s ease;
    }

    /* Animations */
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }

    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        to { transform: scale(1); }
    }

    @keyframes float {
        0% { transform: translateY(0px); }
        50% { transform: translateY(-10px); }
        to { transform: translateY(0px); }
    }

    /* Breadcrumb */
    .breadcrumb {
        background-color: transparent;
        padding: 0.75rem 0;
        margin-bottom: 0;
    }

    .breadcrumb-item a {
        color: var(--primary);
        text-decoration: none;
    }

    /* Dark mode */
    .dark body {
        background: #0b1220;
        color: #e5e7eb;
    }

    .dark .navbar {
        background: #0f172a !important;
    }

    .dark .gallery-item {
        background: #1e293b;
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.35);
    }

    .dark footer {
        background: #020617;
    }

    .dark .gallery-title {
        color: var(--accent-light);
    }

    .dark .modal-content {
        background: #1e293b;
        color: #e5e7eb;
    }

    .dark .modal-header {
        background: var(--primary-dark);
        border-bottom: 1px solid #374151;
    }

    .dark .modal-footer {
        background: #111827;
        border-top: 1px solid #374151;
    }

    .dark .image-info {
        background: #1e293b;
    }

    .dark .image-title {
        color: var(--accent-light);
    }

    /* Perbaikan responsivitas untuk modal */
    @media (max-width: 1200px) {
        h1 { font-size: 2.3rem; }
        .display-4 { font-size: 2.5rem; }
        
        .modal-image {
            max-height: 55vh;
        }
    }

    @media (max-width: 992px) {
        h1 { font-size: 2.1rem; }
        h2 { font-size: 1.8rem; }
        .display-4 { font-size: 2.2rem; }
        .lead { font-size: 1.15rem; }
        
        .section-title {
            font-size: 1.8rem;
            margin-bottom: 2rem;
        }
        
        .gallery-img {
            height: 200px;
        }
        
        .modal-image {
            max-height: 50vh;
        }
        
        .modal-nav {
            width: 45px;
            height: 45px;
            font-size: 1.1rem;
        }
    }

    @media (max-width: 768px) {
        body {
            font-size: 0.95rem;
        }
        
        h1 { font-size: 1.9rem; }
        h2 { font-size: 1.65rem; }
        h3 { font-size: 1.5rem; }
        
        .display-4 { font-size: 2rem; }
        .lead { font-size: 1.1rem; }
        
        .section-title {
            font-size: 1.7rem;
            margin-bottom: 1.8rem;
        }
        
        .hero-section {
            padding: 5rem 0 3rem !important;
        }
        
        .gallery-img {
            height: 180px;
        }
        
        .gallery-content {
            padding: 1rem;
        }
        
        .modal-dialog {
            margin: 0.5rem;
            max-width: calc(100% - 1rem);
        }
        
        .modal-header {
            padding: 0.75rem 1rem;
        }
        
        .modal-body {
            max-height: 60vh;
        }
        
        .modal-image-container {
            min-height: 250px;
            padding: 15px;
        }
        
        .modal-image {
            max-height: 40vh;
        }
        
        .modal-nav {
            width: 40px;
            height: 40px;
            font-size: 1rem;
        }
        
        .modal-nav.prev {
            left: 10px;
        }
        
        .modal-nav.next {
            right: 10px;
        }
        
        .image-info {
            padding: 1rem;
        }
        
        .image-title {
            font-size: 1.1rem;
        }
        
        .modal-footer {
            padding: 0.75rem 1rem;
        }
        
        .image-counter {
            font-size: 0.75rem;
            padding: 4px 12px;
            top: 10px;
            right: 10px;
        }
    }

    @media (max-width: 576px) {
        body {
            font-size: 0.9rem;
        }
        
        h1 { font-size: 1.7rem; }
        h2 { font-size: 1.5rem; }
        h3 { font-size: 1.35rem; }
        h4 { font-size: 1.2rem; }
        
        .display-4 { font-size: 1.8rem; }
        .lead { font-size: 1rem; }
        
        .section-title {
            font-size: 1.6rem;
            margin-bottom: 1.5rem;
        }

        .section-title::after {
            width: 60px;
            height: 3px;
        }

        .btn, .btn-sm {
            padding: 0.5rem 1rem;
            font-size: 0.85rem;
        }
        
        .hero-section {
            padding: 4.5rem 0 2.5rem !important;
        }
        
        .breadcrumb {
            font-size: 0.9rem;
        }
        
        .gallery-img {
            height: 150px;
        }
        
        .gallery-content {
            padding: 0.8rem;
        }
        
        .gallery-title {
            font-size: 1rem;
        }
        
        .gallery-description {
            font-size: 0.85rem;
        }
        
        .modal-body {
            max-height: 50vh;
        }
        
        .modal-image-container {
            min-height: 200px;
            padding: 10px;
        }
        
        .modal-image {
            max-height: 35vh;
        }
        
        .modal-nav {
            width: 35px;
            height: 35px;
            font-size: 0.9rem;
        }
        
        .image-info {
            padding: 0.75rem;
        }
        
        .image-title {
            font-size: 1rem;
            margin-bottom: 0.5rem;
        }
        
        .image-description {
            font-size: 0.85rem;
            margin-bottom: 0.75rem;
        }
        
        .image-meta {
            font-size: 0.8rem;
            padding-top: 0.5rem;
        }
        
        .modal-footer .btn {
            padding: 0.4rem 0.8rem;
            font-size: 0.85rem;
        }
    }
    
    /* Untuk layar sangat kecil (portrait) */
    @media (max-width: 400px) {
        .modal-image {
            max-height: 30vh;
        }
        
        .modal-image-container {
            min-height: 180px;
        }
        
        .modal-nav {
            width: 32px;
            height: 32px;
            font-size: 0.8rem;
        }
    }

    /* Untuk landscape mode di mobile */
    @media (max-height: 600px) and (orientation: landscape) {
        .modal-body {
            max-height: 50vh;
        }
        
        .modal-image {
            max-height: 35vh;
        }
        
        .modal-image-container {
            min-height: 180px;
            padding: 10px;
        }
    }
    </style>
</head>

<body>
   <body>
     <!-- Announcement Bar -->
    <div class="announcement-bar text-center">
        <div class="container">
            <p class="mb-0"><i class="fas fa-bullhorn me-2"></i> Selamat datang di Galeri Desa Kaliboja! <a
                    href="/berita" class="text-white fw-bold ms-2">Lihat berita terbaru &rarr;</a></p>
        </div>
    </div>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="/">
                <img src="/img/logo.png" class="me-2" alt="Logo">Desa Kaliboja
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu"
                aria-controls="navMenu" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navMenu">
                <ul class="navbar-nav ms-auto align-items-lg-center">
                    
                </ul>
            </div>
        </div>
    </nav>
    <!-- Header Galeri -->
    <section class="hero-section">
        <div class="container py-5">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h1 class="display-4 fw-bold mb-3" data-aos="fade-down">Galeri Desa Kaliboja</h1>
                    <p class="lead" data-aos="fade-up" data-aos-delay="200">Klik foto untuk melihat dalam ukuran penuh</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="bg-light py-3">
        <div class="container">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item active">Galeri</li>
            </ol>
        </div>
    </nav>

    <!-- Galeri Foto -->
    <section id="galeri-foto" class="py-5">
        <div class="container">
            <h2 class="section-title text-center mb-5">Koleksi Foto Desa</h2>

            <div class="row" id="gallery-container">
                <?php if (!empty($galleries)): ?>
                    <?php foreach ($galleries as $index => $gallery): ?>
                        <?php 
                        $imagePath = 'uploads/gallery/' . esc($gallery['image']);
                        $imageExists = !empty($gallery['image']) && file_exists(ROOTPATH . 'public/' . $imagePath);
                        $uploadDate = isset($gallery['created_at']) ? date('d M Y', strtotime($gallery['created_at'])) : 'Tanggal tidak tersedia';
                        ?>
                        
                        <div class="col-lg-4 col-md-6 mb-4">
                            <div class="gallery-item" 
                                 data-bs-toggle="modal" 
                                 data-bs-target="#imageModal"
                                 data-image="<?= $imageExists ? base_url($imagePath) : 'https://via.placeholder.com/800x600?text=Gambar+Tidak+Tersedia' ?>"
                                 data-title="<?= esc($gallery['title']) ?>"
                                 data-description="<?= esc($gallery['description'] ?? '') ?>"
                                 data-date="<?= $uploadDate ?>"
                                 data-index="<?= $index ?>">
                                <img src="<?= $imageExists ? base_url($imagePath) : 'https://via.placeholder.com/400x250?text=Gambar+Tidak+Tersedia' ?>" 
                                     alt="<?= esc($gallery['title']) ?>" 
                                     class="gallery-img"
                                     onerror="this.src='https://via.placeholder.com/400x250?text=Gambar+Error'"
                                     loading="lazy">
                                <div class="gallery-content">
                                    <h5 class="gallery-title"><?= esc($gallery['title']) ?></h5>
                                    <?php if (!empty($gallery['description'])): ?>
                                        <p class="gallery-description"><?= esc(substr($gallery['description'], 0, 100)) ?><?= strlen($gallery['description']) > 100 ? '...' : '' ?></p>
                                    <?php endif; ?>
                                    <div class="gallery-date">
                                        <i class="fas fa-calendar-alt"></i>
                                        <?= $uploadDate ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="col-12">
                        <div class="no-gallery" data-aos="fade-up">
                            <i class="fas fa-images"></i>
                            <h4>Belum Ada Foto di Galeri</h4>
                            <p>Silakan tambahkan foto melalui dashboard admin</p>
                            <?php if(session()->get('isLoggedIn')): ?>
                                <a href="<?= site_url('dashboard/gallery/create') ?>" class="btn btn-primary mt-3">
                                    <i class="fas fa-plus"></i> Tambah Foto
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Pagination atau Load More jika diperlukan -->
            <?php if (!empty($galleries) && count($galleries) > 12): ?>
                <div class="text-center mt-5">
                    <button id="loadMore" class="btn btn-outline-primary">
                        <i class="fas fa-plus"></i> Muat Lebih Banyak
                    </button>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Modal untuk menampilkan gambar besar - IMPROVED -->
    <div class="modal fade" id="imageModal" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="imageModalTitle">Judul Gambar</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="image-counter" id="modalImageCounter">1 / <?= count($galleries ?? []) ?></div>
                    <div class="modal-image-container">
                        <button class="modal-nav prev" onclick="navigateImage(-1)" aria-label="Gambar sebelumnya">
                            <i class="fas fa-chevron-left"></i>
                        </button>
                        
                        <img id="modalImage" src="" alt="" class="modal-image">
                        
                        <button class="modal-nav next" onclick="navigateImage(1)" aria-label="Gambar berikutnya">
                            <i class="fas fa-chevron-right"></i>
                        </button>
                    </div>
                    
                    <div class="image-info">
                        <h6 id="modalImageTitle" class="image-title"></h6>
                        <p id="modalImageDescription" class="image-description"></p>
                        <div class="image-meta">
                            <span id="modalImageDate" class="image-date"></span>
                            <span id="imageSize" class="image-size"></span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="d-flex justify-content-between w-100">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="fas fa-times me-1"></i> Tutup
                        </button>
                        <div>
                            <button type="button" class="btn btn-outline-primary me-2" onclick="rotateImage(-90)" title="Putar kiri">
                                <i class="fas fa-undo"></i>
                            </button>
                            <button type="button" class="btn btn-outline-primary me-2" onclick="rotateImage(90)" title="Putar kanan">
                                <i class="fas fa-redo"></i>
                            </button>
                            <button type="button" class="btn btn-primary" onclick="downloadImage()">
                                <i class="fas fa-download me-1"></i> Unduh
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

   <!-- Footer -->
    <footer class="mt-0">
        <div class="container py-5">
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <h5 class="text-white mb-4">Desa Kaliboja</h5>
                    <p class="mb-4">Portal resmi desa untuk transparansi informasi, promosi potensi, dan
                        pelayanan digital kepada masyarakat.</p>
                    <div class="d-flex">
                        <a href="https://www.facebook.com/share/17fpGKh173/" target="_blank"
                            class="text-white me-3 hover-lift">
                            <div class="social-icon">
                                <i class="fa-brands fa-facebook-f"></i>
                            </div>
                        </a>
                        <a href="https://www.instagram.com/desa_kaliboja?igsh=MTB2enB2N3I4dGp2OA==" target="_blank"
                            class="text-white me-3 hover-lift">
                            <div class="social-icon">
                                <i class="fa-brands fa-instagram"></i>
                            </div>
                        </a>
                        <a href="https://x.com/desa_kaliboja?t=taTDsUWdhSoPbIiqADFfyQ&s=09&fbclid=PAdGRjcAMvYX1leHRuA2FlbQIxMQABp9AdVHP8awNqQGOky0UFUiiEt9za1hiL0Wldzmpg5X_LPj7CyczURUw5Jk2f_aem_r-xoS5uVycPxEOxfhEjr2A"
                            target="_blank" class="text-white me-3 hover-lift">
                            <div class="social-icon">
                                <i class="fa-brands fa-x-twitter"></i>
                            </div>
                        </a>
                        <a href="https://www.tiktok.com/@desa_kaliboja?fbclid=PAdGRjcAMvYeNleHRuA2FlbQIxMQABp-jUXBxjp43fgoeGN6x01EfX3g1Nj10GpaTEukdsoluv5Zt4yNimvhdrphwe_aem_5lvWmF8h8HUWv1miYT-y0A"
                            target="_blank" class="text-white hover-lift">
                            <div class="social-icon">
                                <i class="fa-brands fa-tiktok"></i>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <h5 class="text-white mb-4">Kontak</h5>
                    <ul class="list-unstyled small">
                        <li class="mb-2"><i class="fa-solid fa-location-dot me-2"></i>Desa Kaliboja,
                            Kec. Paninggaran,
                            Kabupaten Pekalongan, Jawa Tengah</li>
                        <li class="mb-2"><i class="fa-solid fa-envelope me-2"></i>kalibojadesa@gmail.com
                        </li>
                        <li><i class="fa-solid fa-clock me-2"></i>Senin - Jumat: 08:00 - 16:00</li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-12">
                    <h5 class="text-white mb-4">Tautan Cepat</h5>
                    <div class="row">
                        <div class="col-6">
                            <ul class="list-unstyled small">
                                <li class="mb-2"><a href="#berita"
                                        class="hover-lift text-white text-decoration-none">Berita</a></li>
                                <li class="mb-2"><a href="#wisata"
                                        class="hover-lift text-white text-decoration-none">Wisata</a></li>
                                <li class="mb-2"><a href="#produk"
                                        class="hover-lift text-white text-decoration-none">Produk</a></li>
                                <li class="mb-2"><a href="#layanan"
                                        class="hover-lift text-white text-decoration-none">Layanan</a></li>
                                <li class="mb-2"><a href="#jdih"
                                        class="hover-lift text-white text-decoration-none">JDIH</a></li>
                            </ul>
                        </div>
                        <div class="col-6">
                            <ul class="list-unstyled small">
                                <li class="mb-2"><a href="#rkp"
                                        class="hover-lift text-white text-decoration-none">RKP</a></li>
                                <li class="mb-2"><a href="#koperasi"
                                        class="hover-lift text-white text-decoration-none">Koperasi</a></li>
                                <li class="mb-2"><a href="#profil"
                                        class="hover-lift text-white text-decoration-none">Profil</a></li>
                                <li class="mb-2"><a href="#galeri"
                                        class="hover-lift text-white text-decoration-none">Galeri</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <hr class="border-secondary my-4">
            <div class="text-center small">
                <div class="mb-2">&copy; 2025 Pemerintah Desa Kaliboja. All Rights Reserved.
                </div>
                <div>Dikembangkan oleh <a href="#" class="text-white hover-lift text-decoration-none">Tim IT KKN 4
                        Kelompok 7
                        Desa Kaliboja</a></div>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
    // Data gallery dari PHP
    const galleries = <?= json_encode($galleries ?? []) ?>;
    let currentImageIndex = 0;
    let currentRotation = 0;

    // Inisialisasi AOS dengan konfigurasi yang benar
    document.addEventListener('DOMContentLoaded', function() {
        // Inisialisasi AOS
        AOS.init({
            once: true,
            duration: 1000,
            offset: 100,
            easing: 'ease-out-back'
        });

        // Loading spinner
        window.addEventListener('load', function() {
            const spinner = document.querySelector('.loading-spinner');
            if (spinner) {
                spinner.style.opacity = '0';
                setTimeout(function() {
                    spinner.style.display = 'none';
                }, 500);
            }
        });

        // Scroll effects & to top
        const toTop = document.getElementById('toTop');
        const navbar = document.querySelector('.navbar');

        if (toTop && navbar) {
            window.addEventListener('scroll', () => {
                toTop.style.display = window.scrollY > 400 ? 'block' : 'none';
                if (window.scrollY > 100) {
                    navbar.classList.add('scrolled');
                } else {
                    navbar.classList.remove('scrolled');
                }
            });

            toTop.addEventListener('click', (e) => {
                e.preventDefault();
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            });
        }

        // Dark mode toggle
        const darkToggle = document.getElementById('darkToggle');
        if (darkToggle) {
            darkToggle.addEventListener('click', () => {
                document.body.classList.toggle('dark');
                const icon = darkToggle.querySelector('i');
                if (document.body.classList.contains('dark')) {
                    icon.classList.remove('fa-moon');
                    icon.classList.add('fa-sun');
                } else {
                    icon.classList.remove('fa-sun');
                    icon.classList.add('fa-moon');
                }
            });
        }

        // Modal functionality dengan perbaikan
        const imageModal = document.getElementById('imageModal');
        if (imageModal) {
            imageModal.addEventListener('show.bs.modal', function (event) {
                const button = event.relatedTarget;
                const imageSrc = button.getAttribute('data-image');
                const imageTitle = button.getAttribute('data-title');
                const imageDescription = button.getAttribute('data-description');
                const imageDate = button.getAttribute('data-date');
                const imageIndex = parseInt(button.getAttribute('data-index'));
                
                currentImageIndex = imageIndex;
                currentRotation = 0; // Reset rotation
                
                const modalTitle = document.getElementById('imageModalTitle');
                const modalImage = document.getElementById('modalImage');
                const modalImageTitle = document.getElementById('modalImageTitle');
                const modalImageDescription = document.getElementById('modalImageDescription');
                const modalImageDate = document.getElementById('modalImageDate');
                const modalImageCounter = document.getElementById('modalImageCounter');
                
                // Reset transform
                modalImage.style.transform = 'rotate(0deg)';
                
                modalTitle.textContent = imageTitle;
                modalImage.src = imageSrc;
                modalImage.alt = imageTitle;
                modalImageTitle.textContent = imageTitle;
                modalImageDescription.textContent = imageDescription || 'Tidak ada deskripsi';
                modalImageDate.innerHTML = `<i class="fas fa-calendar-alt me-1"></i> ${imageDate}`;
                modalImageCounter.textContent = `${imageIndex + 1} / ${galleries.length}`;
                
                // Preload adjacent images for smoother navigation
                preloadAdjacentImages(imageIndex);
                
                // Load image size
                loadImageSize(imageSrc);
            });
            
            // Reset rotation when modal closes
            imageModal.addEventListener('hidden.bs.modal', function () {
                const modalImage = document.getElementById('modalImage');
                modalImage.style.transform = 'rotate(0deg)';
                currentRotation = 0;
            });
        }

        // Gallery item click handlers
        document.querySelectorAll('.gallery-item').forEach(item => {
            item.addEventListener('click', function() {
                // Animation effect on click
                this.style.transform = 'scale(0.98)';
                setTimeout(() => {
                    this.style.transform = '';
                }, 150);
            });
        });

        // Load more functionality
        const loadMoreBtn = document.getElementById('loadMore');
        if (loadMoreBtn) {
            let visibleItems = 12;
            const galleryItems = document.querySelectorAll('.gallery-item');
            
            // Initially hide items beyond the first 12
            galleryItems.forEach((item, index) => {
                if (index >= visibleItems) {
                    item.parentElement.style.display = 'none';
                }
            });
            
            loadMoreBtn.addEventListener('click', function() {
                visibleItems += 6;
                let itemsShown = 0;
                
                galleryItems.forEach((item, index) => {
                    if (index < visibleItems) {
                        item.parentElement.style.display = 'block';
                        itemsShown++;
                        
                        // Add animation for newly shown items
                        if (index >= visibleItems - 6) {
                            setTimeout(() => {
                                item.style.opacity = '0';
                                item.style.transform = 'translateY(20px)';
                                item.style.display = 'block';
                                
                                setTimeout(() => {
                                    item.style.transition = 'all 0.5s ease';
                                    item.style.opacity = '1';
                                    item.style.transform = 'translateY(0)';
                                }, 50);
                            }, (index - (visibleItems - 6)) * 100);
                        }
                    }
                });
                
                // Hide button if all items are visible
                if (visibleItems >= galleryItems.length) {
                    loadMoreBtn.style.display = 'none';
                }
            });
        }
    });

    // Function to navigate between images in modal
    function navigateImage(direction) {
        if (galleries.length <= 1) return;
        
        currentImageIndex += direction;
        
        // Loop around if at ends
        if (currentImageIndex < 0) {
            currentImageIndex = galleries.length - 1;
        } else if (currentImageIndex >= galleries.length) {
            currentImageIndex = 0;
        }
        
        const gallery = galleries[currentImageIndex];
        const imagePath = 'uploads/gallery/' + gallery.image;
        
        // Reset rotation when changing image
        currentRotation = 0;
        const modalImage = document.getElementById('modalImage');
        modalImage.style.transform = 'rotate(0deg)';
        
        // Check if image exists
        let imageSrc;
        if (gallery.image) {
            imageSrc = '<?= base_url() ?>' + imagePath;
        } else {
            imageSrc = 'https://via.placeholder.com/800x600?text=Gambar+Tidak+Tersedia';
        }
        
        const uploadDate = gallery.created_at ? new Date(gallery.created_at).toLocaleDateString('id-ID', { 
            day: 'numeric', 
            month: 'long', 
            year: 'numeric' 
        }) : 'Tanggal tidak tersedia';
        
        // Update modal content
        document.getElementById('imageModalTitle').textContent = gallery.title;
        modalImage.src = imageSrc;
        modalImage.alt = gallery.title;
        document.getElementById('modalImageTitle').textContent = gallery.title;
        document.getElementById('modalImageDescription').textContent = gallery.description || 'Tidak ada deskripsi';
        document.getElementById('modalImageDate').innerHTML = `<i class="fas fa-calendar-alt me-1"></i> ${uploadDate}`;
        document.getElementById('modalImageCounter').textContent = `${currentImageIndex + 1} / ${galleries.length}`;
        
        // Preload adjacent images
        preloadAdjacentImages(currentImageIndex);
        
        // Load image size
        loadImageSize(imageSrc);
        
        // Add fade transition
        modalImage.style.opacity = '0';
        setTimeout(() => {
            modalImage.style.opacity = '1';
        }, 300);
    }

    // Function to preload adjacent images for smoother navigation
    function preloadAdjacentImages(currentIndex) {
        if (galleries.length <= 1) return;
        
        const indicesToPreload = [
            (currentIndex - 1 + galleries.length) % galleries.length,
            (currentIndex + 1) % galleries.length
        ];
        
        indicesToPreload.forEach(index => {
            const gallery = galleries[index];
            if (gallery && gallery.image) {
                const imagePath = 'uploads/gallery/' + gallery.image;
                const img = new Image();
                img.src = '<?= base_url() ?>' + imagePath;
            }
        });
    }

    // Function to load image size info
    function loadImageSize(imageSrc) {
        const img = new Image();
        img.onload = function() {
            const sizeInKB = Math.round((this.naturalWidth * this.naturalHeight * 3) / 1024);
            const imageSizeElement = document.getElementById('imageSize');
            if (imageSizeElement) {
                imageSizeElement.innerHTML = `<i class="fas fa-expand me-1"></i> ${this.naturalWidth} × ${this.naturalHeight} (${sizeInKB} KB)`;
            }
        };
        img.src = imageSrc;
    }

    // Function to rotate image
    function rotateImage(degrees) {
        const modalImage = document.getElementById('modalImage');
        currentRotation += degrees;
        modalImage.style.transform = `rotate(${currentRotation}deg)`;
        modalImage.style.transition = 'transform 0.3s ease';
    }

    // Function to download current image
    function downloadImage() {
        const imageSrc = document.getElementById('modalImage').src;
        const imageTitle = document.getElementById('modalImageTitle').textContent;
        
        // Check if image is from placeholder (external)
        if (imageSrc.includes('via.placeholder.com') || imageSrc.includes('placeholder')) {
            alert('Gambar placeholder tidak dapat diunduh. Silakan pilih gambar asli dari galeri.');
            return;
        }
        
        // Create a temporary anchor element for download
        const link = document.createElement('a');
        link.href = imageSrc;
        link.download = `desa-kaliboja-${imageTitle.toLowerCase().replace(/\s+/g, '-')}.jpg`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    // Keyboard navigation for modal
    document.addEventListener('keydown', function(event) {
        const modal = document.getElementById('imageModal');
        if (modal && modal.classList.contains('show')) {
            switch(event.key) {
                case 'ArrowLeft':
                    navigateImage(-1);
                    break;
                case 'ArrowRight':
                    navigateImage(1);
                    break;
                case 'Escape':
                    bootstrap.Modal.getInstance(modal).hide();
                    break;
                case 'r':
                case 'R':
                    if (event.ctrlKey) {
                        rotateImage(90);
                    }
                    break;
            }
        }
    });

    // Touch swipe support for mobile
    let touchStartX = 0;
    let touchEndX = 0;

    const modalImageContainer = document.querySelector('.modal-image-container');
    if (modalImageContainer) {
        modalImageContainer.addEventListener('touchstart', function(event) {
            touchStartX = event.changedTouches[0].screenX;
        });

        modalImageContainer.addEventListener('touchend', function(event) {
            touchEndX = event.changedTouches[0].screenX;
            handleSwipe();
        });
    }

    function handleSwipe() {
        const modal = document.getElementById('imageModal');
        if (modal && modal.classList.contains('show')) {
            const swipeThreshold = 50;
            
            if (touchEndX < touchStartX - swipeThreshold) {
                // Swipe left - next image
                navigateImage(1);
            } else if (touchEndX > touchStartX + swipeThreshold) {
                // Swipe right - previous image
                navigateImage(-1);
            }
        }
    }

    // Error handling for images
    document.addEventListener('error', function(e) {
        if (e.target.tagName === 'IMG') {
            if (e.target.classList.contains('gallery-img')) {
                e.target.src = 'https://via.placeholder.com/400x250?text=Gambar+Tidak+Tersedia';
            } else if (e.target.id === 'modalImage') {
                e.target.src = 'https://via.placeholder.com/800x600?text=Gambar+Tidak+Tersedia';
                document.getElementById('imageSize').innerHTML = '';
            }
        }
    }, true);

    // Performance optimization: Lazy loading for images
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    if (img.dataset.src) {
                        img.src = img.dataset.src;
                        img.classList.remove('lazy');
                    }
                    imageObserver.unobserve(img);
                }
            });
        });

        document.querySelectorAll('img[data-src]').forEach(img => {
            imageObserver.observe(img);
        });
    }
    
    // Zoom functionality (optional)
    let scale = 1;
    function zoomImage(factor) {
        const modalImage = document.getElementById('modalImage');
        scale *= factor;
        modalImage.style.transform = `scale(${scale})`;
    }
    </script>
</body>
</html>