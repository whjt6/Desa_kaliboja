<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title) ?> - Desa Kaliboja</title>
    
    <!-- Include CSS dari halaman utama -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #4A6C6F;
            --primary-dark: #3a5659;
            --accent: #D6A25B;
        }
        
        body {
            background: #f9f9f9;
            font-family: 'Inter', sans-serif;
        }
        
        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            margin-bottom: 25px;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.15);
        }
        
        .stat-number {
            font-size: 2.5rem;
            font-weight: 800;
            color: var(--primary);
            line-height: 1;
        }
        
        .stat-label {
            font-size: 0.9rem;
            color: #666;
            margin-top: 10px;
        }
        
        .stat-change {
            font-size: 0.85rem;
            padding: 3px 10px;
            border-radius: 20px;
            margin-left: 10px;
        }
        
        .change-up {
            background: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }
        
        .change-down {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
        }
        
        .chart-container {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            margin-bottom: 25px;
        }
        
        .table-container {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }
    </style>
</head>
<body>
    <!-- Navbar Sama dengan Halaman Utama -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold" href="/">
                <img src="/img/logo.png" class="me-2" alt="Logo" style="height: 40px;">Desa Kaliboja
            </a>
            <div class="d-flex">
                <a href="/" class="btn btn-outline-primary btn-sm me-2">
                    <i class="fas fa-home me-1"></i> Beranda
                </a>
                <?php if(session()->get('isLoggedIn')): ?>
                <a href="/dashboard/statistik" class="btn btn-primary btn-sm">
                    <i class="fas fa-chart-bar me-1"></i> Admin
                </a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Header -->
    <div class="container mt-5 mb-4">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h1 class="fw-bold mb-2">Statistik Pengunjung</h1>
                <p class="text-muted mb-0">Data kunjungan website Desa Kaliboja</p>
            </div>
            <div class="col-md-4 text-end">
                <div class="btn-group">
                    <button class="btn btn-outline-primary btn-sm" onclick="changePeriod('today')">
                        <i class="fas fa-calendar-day me-1"></i> Hari Ini
                    </button>
                    <button class="btn btn-outline-primary btn-sm" onclick="changePeriod('week')">
                        <i class="fas fa-calendar-week me-1"></i> Minggu Ini
                    </button>
                    <button class="btn btn-outline-primary btn-sm" onclick="changePeriod('month')">
                        <i class="fas fa-calendar-alt me-1"></i> Bulan Ini
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistik Utama -->
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <div class="stat-number">
                        <?= isset($today['visits']) ? number_format($today['visits']) : '0' ?>
                    </div>
                    <div class="stat-label">Hari Ini</div>
                    <?php if($yesterday): ?>
                    <div class="mt-3">
                        <small class="text-muted">
                            <i class="fas fa-history me-1"></i> 
                            <?= number_format($yesterday['visits']) ?> kemarin
                            <?php if($yesterday['visits'] > 0): 
                                $change = (($today['visits'] ?? 0) - $yesterday['visits']) / $yesterday['visits'] * 100;
                            ?>
                            <span class="stat-change <?= $change >= 0 ? 'change-up' : 'change-down' ?>">
                                <i class="fas fa-arrow-<?= $change >= 0 ? 'up' : 'down' ?> me-1"></i>
                                <?= number_format(abs($change), 1) ?>%
                            </span>
                            <?php endif; ?>
                        </small>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <div class="stat-number">
                        <?= isset($thisWeek['total_visits']) ? number_format($thisWeek['total_visits']) : '0' ?>
                    </div>
                    <div class="stat-label">Minggu Ini</div>
                    <?php if($lastWeek): ?>
                    <div class="mt-3">
                        <small class="text-muted">
                            <i class="fas fa-history me-1"></i> 
                            <?= number_format($lastWeek['total_visits']) ?> minggu lalu
                            <?php if($lastWeek['total_visits'] > 0): 
                                $change = (($thisWeek['total_visits'] ?? 0) - $lastWeek['total_visits']) / $lastWeek['total_visits'] * 100;
                            ?>
                            <span class="stat-change <?= $change >= 0 ? 'change-up' : 'change-down' ?>">
                                <i class="fas fa-arrow-<?= $change >= 0 ? 'up' : 'down' ?> me-1"></i>
                                <?= number_format(abs($change), 1) ?>%
                            </span>
                            <?php endif; ?>
                        </small>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <div class="stat-number">
                        <?= isset($thisMonth['total_visits']) ? number_format($thisMonth['total_visits']) : '0' ?>
                    </div>
                    <div class="stat-label">Bulan Ini</div>
                    <?php if($lastMonth): ?>
                    <div class="mt-3">
                        <small class="text-muted">
                            <i class="fas fa-history me-1"></i> 
                            <?= number_format($lastMonth['total_visits']) ?> bulan lalu
                            <?php if($lastMonth['total_visits'] > 0): 
                                $change = (($thisMonth['total_visits'] ?? 0) - $lastMonth['total_visits']) / $lastMonth['total_visits'] * 100;
                            ?>
                            <span class="stat-change <?= $change >= 0 ? 'change-up' : 'change-down' ?>">
                                <i class="fas fa-arrow-<?= $change >= 0 ? 'up' : 'down' ?> me-1"></i>
                                <?= number_format(abs($change), 1) ?>%
                            </span>
                            <?php endif; ?>
                        </small>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <div class="stat-number">
                        <?= isset($total['total']) ? number_format($total['total']) : '0' ?>
                    </div>
                    <div class="stat-label">Total Kunjungan</div>
                    <div class="mt-3">
                        <small class="text-muted">
                            <i class="fas fa-globe me-1"></i> Semua waktu
                        </small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Grafik 7 Hari Terakhir -->
        <div class="chart-container">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="mb-0 fw-bold">Kunjungan 7 Hari Terakhir</h5>
                <div class="btn-group btn-group-sm">
                    <button class="btn btn-outline-primary active" onclick="showChart('visits')">
                        Kunjungan
                    </button>
                    <button class="btn btn-outline-primary" onclick="showChart('unique')">
                        Pengunjung Unik
                    </button>
                </div>
            </div>
            <canvas id="chart7Days" height="120"></canvas>
        </div>

        <!-- Data Detail -->
        <div class="row">
            <div class="col-md-8">
                <div class="chart-container">
                    <h5 class="mb-4 fw-bold">Statistik Per Jam (Hari Ini)</h5>
                    <canvas id="hourlyChart" height="200"></canvas>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="table-container">
                    <h5 class="mb-4 fw-bold">Halaman Populer</h5>
                    <?php if(!empty($popularPages)): ?>
                    <div class="list-group list-group-flush">
                        <?php foreach($popularPages as $index => $page): ?>
                        <div class="list-group-item d-flex justify-content-between align-items-center px-0 py-2 border-0">
                            <div class="d-flex align-items-center">
                                <span class="badge bg-primary me-2"><?= $index + 1 ?></span>
                                <div>
                                    <small class="d-block text-truncate" style="max-width: 180px;" title="<?= esc($page['page_title'] ?? $page['page_url']) ?>">
                                        <?= esc($page['page_title'] ?? basename($page['page_url'])) ?>
                                    </small>
                                    <small class="text-muted"><?= esc($page['page_url']) ?></small>
                                </div>
                            </div>
                            <span class="badge bg-light text-dark"><?= number_format($page['total_visits']) ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php else: ?>
                    <p class="text-muted text-center">Belum ada data</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Tabel Data Historis -->
        <div class="table-container mt-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="mb-0 fw-bold">Data Historis</h5>
                <div class="d-flex">
                    <input type="date" class="form-control form-control-sm me-2" id="startDate" value="<?= date('Y-m-d', strtotime('-7 days')) ?>">
                    <input type="date" class="form-control form-control-sm me-2" id="endDate" value="<?= date('Y-m-d') ?>">
                    <button class="btn btn-primary btn-sm" onclick="filterData()">
                        <i class="fas fa-filter me-1"></i> Filter
                    </button>
                </div>
            </div>
            
            <div class="table-responsive">
                <table class="table table-hover" id="historyTable">
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Kunjungan</th>
                            <th>Pengunjung Unik</th>
                            <th>Pageviews</th>
                            <th>Rata-rata/Waktu</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($chart30Days)): ?>
                        <?php foreach($chart30Days as $day): ?>
                        <tr>
                            <td><?= date('d M Y', strtotime($day['date'])) ?></td>
                            <td><?= number_format($day['visits']) ?></td>
                            <td><?= number_format($day['unique_visitors'] ?? 0) ?></td>
                            <td><?= number_format($day['pageviews'] ?? 0) ?></td>
                            <td><?= $day['visits'] > 0 ? round(1440 / $day['visits'], 1) . ' menit' : '-' ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center">Belum ada data</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Footer Sama dengan Halaman Utama -->
    <footer class="mt-5 bg-dark text-white py-4">
        <div class="container">
            <div class="text-center small">
                <div class="mb-2">&copy; 2025 Pemerintah Desa Kaliboja. All Rights Reserved.</div>
                <div>Dikembangkan oleh <a href="#" class="text-white">Tim IT KKN 4 Kelompok 7 Desa Kaliboja</a></div>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
    <script>
    // Data untuk chart 7 hari
    const chart7DaysData = {
        dates: <?= json_encode(array_column($chart7Days, 'date')) ?>,
        visits: <?= json_encode(array_column($chart7Days, 'visits')) ?>,
        unique: <?= json_encode(array_column($chart7Days, 'unique_visitors')) ?>
    };

    // Data untuk chart per jam
    const hourlyData = <?= json_encode($hourly) ?>;
    
    // Inisialisasi chart 7 hari
    let chart7DaysCtx = document.getElementById('chart7Days').getContext('2d');
    let chart7Days = new Chart(chart7DaysCtx, {
        type: 'line',
        data: {
            labels: chart7DaysData.dates.map(date => {
                const d = new Date(date);
                return d.toLocaleDateString('id-ID', { weekday: 'short', day: 'numeric' });
            }),
            datasets: [{
                label: 'Kunjungan',
                data: chart7DaysData.visits,
                borderColor: '#4A6C6F',
                backgroundColor: 'rgba(74, 108, 111, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            }
        }
    });

    // Inisialisasi chart per jam
    if (hourlyData.length > 0) {
        let hourlyCtx = document.getElementById('hourlyChart').getContext('2d');
        let hourlyLabels = [];
        let hourlyVisits = [];
        
        // Generate data per jam (0-23)
        for (let i = 0; i < 24; i++) {
            hourlyLabels.push(i.toString().padStart(2, '0') + ':00');
            
            // Cari data untuk jam ini
            let hourData = hourlyData.find(h => parseInt(h.hour) === i);
            hourlyVisits.push(hourData ? hourData.visits : 0);
        }
        
        new Chart(hourlyCtx, {
            type: 'bar',
            data: {
                labels: hourlyLabels,
                datasets: [{
                    label: 'Kunjungan',
                    data: hourlyVisits,
                    backgroundColor: 'rgba(74, 108, 111, 0.8)',
                    borderColor: '#4A6C6F',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                }
            }
        });
    }

    // Fungsi untuk mengganti jenis chart
    function showChart(type) {
        if (type === 'unique') {
            chart7Days.data.datasets[0].data = chart7DaysData.unique;
            chart7Days.data.datasets[0].label = 'Pengunjung Unik';
        } else {
            chart7Days.data.datasets[0].data = chart7DaysData.visits;
            chart7Days.data.datasets[0].label = 'Kunjungan';
        }
        chart7Days.update();
    }

    // Fungsi untuk mengganti periode
    function changePeriod(period) {
        // Implementasi AJAX untuk mengganti periode
        alert('Fitur periode akan diimplementasi pada versi berikutnya');
    }

    // Fungsi untuk filter data
    function filterData() {
        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;
        
        // Redirect ke halaman dengan filter
        window.location.href = `/statistik?start_date=${startDate}&end_date=${endDate}`;
    }
    </script>
</body>
</html>