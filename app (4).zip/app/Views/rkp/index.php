<?= $this->extend('layout/main_layout'); ?>

<?= $this->section('content'); ?>
<!-- Hero Section RKP -->
<div class="container py-5">
    <!-- Filter Tahun -->
    <div class="row mb-5">
        <div class="col-lg-6 mx-auto">
            <div class="card shadow border-0" data-aos="zoom-in">
                <div class="card-body p-4">
                    <h4 class="card-title text-center mb-4">
                        <i class="fas fa-calendar-alt text-primary me-2"></i>Pilih Tahun RKP
                    </h4>
                    <form action="<?= site_url('rkp'); ?>" method="get" class="row g-3">
                        <div class="col-md-8">
                            <select class="form-select form-select-lg" name="tahun" onchange="this.form.submit()">
                                <option value="">Pilih Tahun</option>
                                <?php foreach ($tahunList as $tl): ?>
                                <option value="<?= $tl['tahun']; ?>" <?= ($tahun == $tl['tahun']) ? 'selected' : ''; ?>>
                                    RKP Tahun <?= $tl['tahun']; ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary btn-lg w-100">
                                <i class="fas fa-filter me-2"></i>Filter
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistik -->
    <div class="row mb-5" id="statistik">
        <div class="col-12">
            <h2 class="section-title mb-4" data-aos="fade-up">
                <i class="fas fa-chart-pie me-2"></i>Statistik RKP Tahun <?= $tahun; ?>
            </h2>
            
            <div class="row g-4">
                <?php 
                // Hitung statistik
                $totalKegiatan = count($rkps);
                $totalAnggaran = array_sum(array_column($rkps, 'jumlah_biaya'));
                $kegiatanSelesai = count(array_filter($rkps, function($r) { return $r['status'] == 'selesai'; }));
                $progressRata = $totalKegiatan > 0 ? array_sum(array_column($rkps, 'progress')) / $totalKegiatan : 0;
                ?>
                
                <div class="col-md-3 col-6" data-aos="fade-up">
                    <div class="card border-0 shadow-sm text-center h-100">
                        <div class="card-body p-3">
                            <i class="fas fa-tasks fa-2x text-primary mb-3"></i>
                            <h3 class="fw-bold"><?= number_format($totalKegiatan); ?></h3>
                            <p class="text-muted mb-0">Total Kegiatan</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 col-6" data-aos="fade-up" data-aos-delay="100">
                    <div class="card border-0 shadow-sm text-center h-100">
                        <div class="card-body p-3">
                            <i class="fas fa-money-bill-wave fa-2x text-success mb-3"></i>
                            <h3 class="fw-bold">Rp <?= number_format($totalAnggaran, 0, ',', '.'); ?></h3>
                            <p class="text-muted mb-0">Total Anggaran</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 col-6" data-aos="fade-up" data-aos-delay="200">
                    <div class="card border-0 shadow-sm text-center h-100">
                        <div class="card-body p-3">
                            <i class="fas fa-check-circle fa-2x text-info mb-3"></i>
                            <h3 class="fw-bold"><?= number_format($kegiatanSelesai); ?></h3>
                            <p class="text-muted mb-0">Kegiatan Selesai</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 col-6" data-aos="fade-up" data-aos-delay="300">
                    <div class="card border-0 shadow-sm text-center h-100">
                        <div class="card-body p-3">
                            <i class="fas fa-chart-line fa-2x text-warning mb-3"></i>
                            <h3 class="fw-bold"><?= number_format($progressRata, 1); ?>%</h3>
                            <p class="text-muted mb-0">Progress Rata-rata</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Daftar Kegiatan -->
    <div class="row" id="kegiatan">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="section-title m-0" data-aos="fade-up">
                    <i class="fas fa-list-check me-2"></i>Daftar Kegiatan
                </h2>
                <div class="dropdown" data-aos="fade-up">
                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="fas fa-filter me-2"></i>Filter Status
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="?tahun=<?= $tahun; ?>">Semua</a></li>
                        <li><a class="dropdown-item" href="?tahun=<?= $tahun; ?>&status=selesai">Selesai</a></li>
                        <li><a class="dropdown-item" href="?tahun=<?= $tahun; ?>&status=berjalan">Berjalan</a></li>
                        <li><a class="dropdown-item" href="?tahun=<?= $tahun; ?>&status=rencana">Rencana</a></li>
                    </ul>
                </div>
            </div>

            <?php if (!empty($rkps)): ?>
                <div class="table-responsive" data-aos="fade-up">
                    <table class="table table-hover table-striped">
                        <thead class="table-primary">
                            <tr>
                                <th width="50">No</th>
                                <th>Nama Kegiatan</th>
                                <th>Lokasi</th>
                                <th>Anggaran</th>
                                <th>Status</th>
                                <th>Progress</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; ?>
                            <?php foreach ($rkps as $r): ?>
                            <tr>
                                <td class="text-center"><?= $no++; ?></td>
                                <td>
                                    <strong class="text-primary"><?= esc($r['nama_kegiatan']); ?></strong><br>
                                    <small class="text-muted"><?= esc($r['sasaran']); ?></small>
                                </td>
                                <td><?= esc($r['lokasi']); ?></td>
                                <td>
                                    <strong class="text-success">Rp <?= number_format($r['jumlah_biaya'], 0, ',', '.'); ?></strong><br>
                                    <small class="text-muted"><?= esc($r['sumber_dana']); ?></small>
                                </td>
                                <td>
                                    <?php 
                                    $status_badge = [
                                        'rencana' => 'secondary',
                                        'berjalan' => 'warning',
                                        'selesai' => 'success',
                                        'tertunda' => 'danger'
                                    ];
                                    $status_text = [
                                        'rencana' => 'Rencana',
                                        'berjalan' => 'Berjalan',
                                        'selesai' => 'Selesai',
                                        'tertunda' => 'Tertunda'
                                    ];
                                    ?>
                                    <span class="badge bg-<?= $status_badge[$r['status']] ?? 'secondary'; ?>">
                                        <?= $status_text[$r['status']] ?? $r['status']; ?>
                                    </span>
                                </td>
                                <td width="150">
                                    <div class="d-flex align-items-center">
                                        <div class="progress flex-grow-1" style="height: 8px;">
                                            <div class="progress-bar bg-success" role="progressbar" 
                                                 style="width: <?= $r['progress']; ?>%" 
                                                 aria-valuenow="<?= $r['progress']; ?>" 
                                                 aria-valuemin="0" 
                                                 aria-valuemax="100"></div>
                                        </div>
                                        <small class="ms-2 text-muted"><?= $r['progress']; ?>%</small>
                                    </div>
                                </td>
                                <td>
                                    <a href="<?= site_url('rkp/detail/' . $r['id']); ?>" 
                                       class="btn btn-sm btn-primary">
                                        <i class="fas fa-eye me-1"></i>Detail
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot class="table-light">
                            <tr>
                                <td colspan="3" class="text-end fw-bold">Total Anggaran Tahun <?= $tahun; ?>:</td>
                                <td colspan="4" class="fw-bold text-danger">
                                    Rp <?= number_format($totalAnggaran, 0, ',', '.'); ?>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-5" data-aos="fade-up">
                    <i class="fas fa-clipboard-list fa-4x text-muted mb-4"></i>
                    <h4 class="text-muted">Belum ada rencana kegiatan untuk tahun <?= $tahun; ?></h4>
                    <p class="text-muted mb-4">Rencana kerja pemerintah desa akan segera diunggah</p>
                    <a href="<?= site_url('rkp'); ?>" class="btn btn-primary">
                        <i class="fas fa-redo me-2"></i>Refresh
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Informasi Tambahan -->
<section class="bg-light py-5">
    <div class="container">
        <h3 class="section-title mb-5 text-center" data-aos="fade-up">
            <i class="fas fa-info-circle me-2"></i>Tentang RKP Desa
        </h3>
        
        <div class="row">
            <div class="col-md-4 mb-4" data-aos="fade-up">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body p-4">
                        <div class="d-flex align-items-start mb-3">
                            <i class="fas fa-bullseye fa-2x text-primary me-3"></i>
                            <div>
                                <h5 class="card-title mb-1">Tujuan RKP</h5>
                                <p class="card-text small text-muted">
                                    RKP merupakan pedoman pelaksanaan pembangunan desa dalam satu tahun anggaran.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="100">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body p-4">
                        <div class="d-flex align-items-start mb-3">
                            <i class="fas fa-users fa-2x text-success me-3"></i>
                            <div>
                                <h5 class="card-title mb-1">Partisipatif</h5>
                                <p class="card-text small text-muted">
                                    Disusun dengan melibatkan partisipasi masyarakat melalui musyawarah desa.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="200">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body p-4">
                        <div class="d-flex align-items-start mb-3">
                            <i class="fas fa-chart-line fa-2x text-warning me-3"></i>
                            <div>
                                <h5 class="card-title mb-1">Transparan</h5>
                                <p class="card-text small text-muted">
                                    Informasi anggaran dan progress kegiatan tersedia untuk publik secara transparan.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?= $this->endSection(); ?>