<?= $this->extend('layout/main_layout'); ?>

<?= $this->section('content'); ?>
<!-- Hero Section Detail Kegiatan -->


<div class="container py-5">
    <div class="row">
        <!-- Detail Kegiatan -->
        <div class="col-lg-8 mb-5" id="detail">
            <div class="card border-0 shadow-sm mb-4" data-aos="fade-up">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h4 class="mb-0"><i class="fas fa-tasks me-2"></i>Informasi Kegiatan</h4>
                    <span class="badge bg-light text-dark">Tahun <?= $rkp['tahun']; ?></span>
                </div>
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <th width="40%" class="text-dark">Nama Kegiatan</th>
                                    <td class="text-dark"><strong><?= esc($rkp['nama_kegiatan']); ?></strong></td>
                                </tr>
                                <tr>
                                    <th class="text-dark">Lokasi</th>
                                    <td class="text-dark"><?= esc($rkp['lokasi']); ?></td>
                                </tr>
                                <tr>
                                    <th class="text-dark">Volume</th>
                                    <td class="text-dark"><?= esc($rkp['volume']); ?></td>
                                </tr>
                                <tr>
                                    <th class="text-dark">Sasaran</th>
                                    <td class="text-dark"><?= esc($rkp['sasaran']); ?></td>
                                </tr>
                                <tr>
                                    <th class="text-dark">Waktu Pelaksanaan</th>
                                    <td class="text-dark"><?= esc($rkp['waktu_pelaksanaan']); ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <th width="40%" class="text-dark">Pelaksana</th>
                                    <td class="text-dark"><?= esc($rkp['pelaksana']); ?></td>
                                </tr>
                                <tr>
                                    <th class="text-dark">Status</th>
                                    <td>
                                        <?php 
                                        $status_badge = [
                                            'rencana' => 'secondary',
                                            'berjalan' => 'warning',
                                            'selesai' => 'success',
                                            'tertunda' => 'danger'
                                        ];
                                        $status_text = [
                                            'rencana' => 'Rencana',
                                            'berjalan' => 'Berjalan',
                                            'selesai' => 'Selesai',
                                            'tertunda' => 'Tertunda'
                                        ];
                                        ?>
                                        <span class="badge bg-<?= $status_badge[$rkp['status']] ?? 'secondary'; ?>">
                                            <?= $status_text[$rkp['status']] ?? $rkp['status']; ?>
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <th class="text-dark">Progress</th>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="progress flex-grow-1" style="height: 10px;">
                                                <div class="progress-bar bg-success" role="progressbar" 
                                                     style="width: <?= $rkp['progress']; ?>%" 
                                                     aria-valuenow="<?= $rkp['progress']; ?>" 
                                                     aria-valuemin="0" 
                                                     aria-valuemax="100"></div>
                                            </div>
                                            <span class="ms-2 fw-bold"><?= $rkp['progress']; ?>%</span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th class="text-dark">Update Terakhir</th>
                                    <td class="text-dark"><?= date('d F Y', strtotime($rkp['updated_at'])); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <h5 class="text-primary mb-3">Deskripsi Kegiatan</h5>
                    <div class="alert alert-light">
                        <p class="mb-0 text-dark"><?= nl2br(esc($rkp['keterangan'])); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Anggaran dan Informasi -->
        <div class="col-lg-4 mb-5" id="anggaran">
            <div class="sticky-top" style="top: 100px;">
                <div class="card border-0 shadow-sm mb-4" data-aos="fade-up">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0"><i class="fas fa-money-bill-wave me-2"></i>Informasi Anggaran</h5>
                    </div>
                    <div class="card-body">
                        <div class="text-center mb-4">
                            <i class="fas fa-coins fa-4x text-warning mb-3"></i>
                            <h3 class="text-success fw-bold">Rp <?= number_format($rkp['jumlah_biaya'], 0, ',', '.'); ?></h3>
                            <p class="text-muted">Total Anggaran Kegiatan</p>
                        </div>
                        
                        <table class="table table-borderless">
                            <tr>
                                <th class="text-dark">Sumber Dana</th>
                                <td class="text-dark"><?= esc($rkp['sumber_dana']); ?></td>
                            </tr>
                            <tr>
                                <th class="text-dark">Tahun Anggaran</th>
                                <td class="text-dark"><?= $rkp['tahun']; ?></td>
                            </tr>
                            <tr>
                                <th class="text-dark">Status Anggaran</th>
                                <td>
                                    <span class="badge bg-<?= $rkp['status'] == 'selesai' ? 'success' : ($rkp['status'] == 'berjalan' ? 'warning' : 'secondary'); ?>">
                                        <?= $rkp['status'] == 'selesai' ? 'Terealisasi' : ($rkp['status'] == 'berjalan' ? 'Sedang Berjalan' : 'Rencana'); ?>
                                    </span>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>

                <div class="card border-0 shadow-sm" data-aos="fade-up" data-aos-delay="100">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0"><i class="fas fa-chart-line me-2"></i>Statistik</h5>
                    </div>
                    <div class="card-body">
                        <div class="text-center">
                            <div class="mb-3">
                                <div class="display-6 fw-bold text-primary"><?= $rkp['progress']; ?>%</div>
                                <small class="text-muted">Progress Realisasi</small>
                            </div>
                            <div class="mb-3">
                                <div class="h4 fw-bold text-success"><?= $rkp['volume']; ?></div>
                                <small class="text-muted">Volume Pekerjaan</small>
                            </div>
                            <div class="mb-3">
                                <div class="h4 fw-bold text-warning"><?= $rkp['sasaran']; ?></div>
                                <small class="text-muted">Jumlah Sasaran</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>