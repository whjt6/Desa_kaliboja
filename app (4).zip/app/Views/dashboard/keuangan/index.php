<?= $this->extend('layout/dashboard_layout'); ?>
<?= $this->section('content'); ?>

<div class="card shadow mb-4">
    <div class="card-header py-3 bg-primary text-white">
        <h6 class="m-0 font-weight-bold"><?= esc($title) ?></h6>
    </div>
    <div class="card-body">
        <a href="<?= base_url('dashboard/keuangan/create'); ?>" class="btn btn-primary btn-sm mb-3">
            <i class="fas fa-plus-circle"></i> Tambah Data
        </a>

        <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-bordered table-striped mt-3 align-middle">
                <thead class="table-dark text-center">
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Keterangan</th>
                        <th>Pemasukan</th>
                        <th>Pengeluaran</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; foreach($keuangan as $row): ?>
                    <tr>
                        <td class="text-center"><?= $no++; ?></td>
                        <td><?= esc($row['tanggal']); ?></td>
                        <td><?= esc($row['keterangan']); ?></td>
                        <td class="text-end">Rp <?= number_format($row['pemasukan'], 0, ',', '.'); ?></td>
                        <td class="text-end">Rp <?= number_format($row['pengeluaran'], 0, ',', '.'); ?></td>
                        <td class="text-center">
                            <div class="btn-group" role="group">
                                <a href="<?= base_url('dashboard/keuangan/edit/'.$row['id']); ?>"
                                    class="btn btn-warning btn-sm">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="<?= base_url('dashboard/keuangan/delete/'.$row['id']); ?>"
                                    onclick="return confirm('Hapus data ini?')" class="btn btn-danger btn-sm">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Statistik -->
        <div class="card mt-4">
            <div class="card-header bg-info text-white">
                <h6 class="m-0 font-weight-bold">Statistik Keuangan</h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <div class="card border-left-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Total Pemasukan</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">Rp
                                            <?= number_format($stats['pemasukan_total'], 0, ',', '.'); ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-money-bill-wave fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card border-left-danger shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                            Total Pengeluaran</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">Rp
                                            <?= number_format($stats['pengeluaran_total'], 0, ',', '.'); ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-money-bill fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Saldo</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">Rp
                                            <?= number_format($stats['saldo'], 0, ',', '.'); ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-wallet fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>