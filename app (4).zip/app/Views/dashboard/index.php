<?= $this->extend('layout/dashboard_layout') ?>
<?= $this->section('content') ?>
<div class="mb-4"></div>
<div class="container-fluid px-3">
    <!-- Welcome Banner -->
    <div class="welcome-banner mb-3 p-3">
        <div class="d-flex justify-content-between align-items-center flex-wrap">
            <div>
                <h5 class="mb-0">Selamat datang, <strong><?= esc(session()->get('username')) ?>!</strong></h5>
                <small class="opacity-75"><?= date('l, d F Y') ?></small>
            </div>
        </div>
    </div>

    <!-- Summary Cards -->
    <div class="row g-3 mb-3">
        <!-- Total Penduduk -->
        <div class="col-xl-3 col-md-6">
            <div class="card summary-card card-population h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between">
                        <div class="flex-grow-1">
                            <h6 class="card-subtitle mb-1 text-muted">Total Penduduk</h6>
                            <h4 class="card-title mb-1"><?= number_format($total_penduduk, 0, ',', '.') ?></h4>
                            <div class="d-flex mt-2">
                                <small class="me-3">
                                    <span class="gender-marker male me-1"></span>
                                    L: <?= number_format($stats['laki_laki'] ?? 0, 0, ',', '.') ?>
                                </small>
                                <small>
                                    <span class="gender-marker female me-1"></span>
                                    P: <?= number_format($stats['perempuan'] ?? 0, 0, ',', '.') ?>
                                </small>
                            </div>
                        </div>
                        <div class="card-icon-sm">
                            <i class="fas fa-users"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Berita -->
        <div class="col-xl-3 col-md-6">
            <div class="card summary-card card-news h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between">
                        <div class="flex-grow-1">
                            <h6 class="card-subtitle mb-1 text-muted">Total Berita</h6>
                            <h4 class="card-title mb-1"><?= number_format($total_berita, 0, ',', '.') ?></h4>
                            <div class="mt-2">
                                <small>
                                    <i class="fas fa-newspaper me-1"></i>
                                    Informasi terbaru
                                </small>
                            </div>
                        </div>
                        <div class="card-icon-sm">
                            <i class="fas fa-newspaper"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Layanan Surat -->
        <div class="col-xl-3 col-md-6">
            <div class="card summary-card card-services h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between">
                        <div class="flex-grow-1">
                            <h6 class="card-subtitle mb-1 text-muted">Layanan Surat</h6>
                            <h4 class="card-title mb-1"><?= number_format($layanan_surat, 0, ',', '.') ?></h4>
                            <div class="mt-2">
                                <small>
                                    <i class="fas fa-envelope me-1"></i>
                                    Layanan administrasi
                                </small>
                            </div>
                        </div>
                        <div class="card-icon-sm">
                            <i class="fas fa-envelope"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Produk -->
        <div class="col-xl-3 col-md-6">
            <div class="card summary-card card-products h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between">
                        <div class="flex-grow-1">
                            <h6 class="card-subtitle mb-1 text-muted">Total Produk</h6>
                            <h4 class="card-title mb-1"><?= number_format($total_produk, 0, ',', '.') ?></h4>
                            <div class="mt-2">
                                <small>
                                    <i class="fas fa-box me-1"></i>
                                    Produk UMKM
                                </small>
                            </div>
                        </div>
                        <div class="card-icon-sm">
                            <i class="fas fa-box"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Financial Cards -->
    <div class="row g-3 mb-3">
        <!-- Total Pemasukan -->
        <div class="col-xl-4 col-md-4">
            <div class="card summary-card card-income h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-subtitle mb-0 text-muted">Total Pemasukan</h6>
                            <h5 class="card-title mb-0">Rp <?= number_format($keuangan['pemasukan_total'] ?? 0, 0, ',', '.') ?></h5>
                        </div>
                        <div class="card-icon-xs">
                            <i class="fas fa-arrow-down"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Pengeluaran -->
        <div class="col-xl-4 col-md-4">
            <div class="card summary-card card-expense h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-subtitle mb-0 text-muted">Total Pengeluaran</h6>
                            <h5 class="card-title mb-0">Rp <?= number_format($keuangan['pengeluaran_total'] ?? 0, 0, ',', '.') ?></h5>
                        </div>
                        <div class="card-icon-xs">
                            <i class="fas fa-arrow-up"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Saldo -->
        <div class="col-xl-4 col-md-4">
            <div class="card summary-card card-balance h-100">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-subtitle mb-0 text-muted">Saldo</h6>
                            <h5 class="card-title mb-0">Rp <?= number_format($keuangan['saldo'] ?? 0, 0, ',', '.') ?></h5>
                        </div>
                        <div class="card-icon-xs">
                            <i class="fas fa-wallet"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts Section -->
    <div class="row g-3">
        <!-- Population Chart -->
        <div class="col-xl-6 col-lg-6">
            <div class="card chart-card h-100">
                <div class="card-header py-2 px-3">
                    <h6 class="mb-0">
                        <i class="fas fa-chart-pie me-1"></i>Statistik Penduduk
                    </h6>
                </div>
                <div class="card-body p-3">
                    <?php if (($stats['laki_laki'] ?? 0) > 0 || ($stats['perempuan'] ?? 0) > 0) : ?>
                        <div class="chart-container-sm">
                            <canvas id="populationChart"></canvas>
                        </div>
                        <div class="chart-legend-sm mt-2">
                            <div class="legend-item">
                                <span class="legend-color male"></span>
                                <span class="legend-label">Laki-laki: <?= $stats['laki_laki'] ?? 0 ?></span>
                            </div>
                            <div class="legend-item">
                                <span class="legend-color female"></span>
                                <span class="legend-label">Perempuan: <?= $stats['perempuan'] ?? 0 ?></span>
                            </div>
                        </div>
                    <?php else : ?>
                        <div class="text-center py-3 no-data">
                            <i class="fas fa-chart-pie fa-2x"></i>
                            <p class="mt-2 mb-0 text-muted">Tidak ada data penduduk</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Finance Chart -->
        <div class="col-xl-6 col-lg-6">
            <div class="card chart-card h-100">
                <div class="card-header py-2 px-3">
                    <h6 class="mb-0">
                        <i class="fas fa-chart-bar me-1"></i>Statistik Keuangan
                    </h6>
                </div>
                <div class="card-body p-3">
                    <?php if (!empty($keuangan['grafik_data'])) : ?>
                        <div class="chart-container-sm">
                            <canvas id="financeChart"></canvas>
                        </div>
                        <div class="chart-legend-sm mt-2">
                            <div class="legend-item">
                                <span class="legend-color income"></span>
                                <span class="legend-label">Pemasukan</span>
                            </div>
                            <div class="legend-item">
                                <span class="legend-color expense"></span>
                                <span class="legend-label">Pengeluaran</span>
                            </div>
                        </div>
                    <?php else : ?>
                        <div class="text-center py-3 no-data">
                            <i class="fas fa-chart-bar fa-2x"></i>
                            <p class="mt-2 mb-0 text-muted">Tidak ada data keuangan</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="mb-4"></div>
<?= $this->endSection() ?>

<?= $this->section('page-scripts') ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    $(document).ready(function() {
        // Data statistik penduduk
        var populationData = {
            laki_laki: <?= $stats['laki_laki'] ?? 0 ?>,
            perempuan: <?= $stats['perempuan'] ?? 0 ?>
        };

        // Data statistik keuangan
        var financeData = <?= !empty($keuangan['grafik_data']) ? json_encode($keuangan['grafik_data']) : 'null' ?>;

        // Grafik Penduduk
        if (populationData.laki_laki > 0 || populationData.perempuan > 0) {
            var populationCtx = document.getElementById("populationChart");
            var populationChart = new Chart(populationCtx, {
                type: 'doughnut',
                data: {
                    labels: ["Laki-laki", "Perempuan"],
                    datasets: [{
                        data: [populationData.laki_laki, populationData.perempuan],
                        backgroundColor: ['#4e73df', '#e83e8c'],
                        hoverBackgroundColor: ['#2e59d9', '#d91a72'],
                        borderWidth: 1,
                        hoverBorderColor: '#fff'
                    }],
                },
                options: {
                    maintainAspectRatio: false,
                    cutout: '70%',
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                },
            });
        }

        // Grafik Keuangan
        if (financeData) {
            var financeCtx = document.getElementById("financeChart");
            var financeChart = new Chart(financeCtx, {
                type: 'bar',
                data: {
                    labels: financeData.labels,
                    datasets: [{
                        label: "Pemasukan",
                        backgroundColor: "#1cc88a",
                        hoverBackgroundColor: "#17a673",
                        borderColor: "#1cc88a",
                        data: financeData.pemasukan,
                        barPercentage: 0.5,
                    }, {
                        label: "Pengeluaran",
                        backgroundColor: "#e74a3b",
                        hoverBackgroundColor: "#e02d1b",
                        borderColor: "#e74a3b",
                        data: financeData.pengeluaran,
                        barPercentage: 0.5,
                    }],
                },
                options: {
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                    },
                    scales: {
                        x: {
                            grid: {
                                display: false,
                            },
                        },
                        y: {
                            grid: {
                                color: "rgba(234, 236, 244, 0.3)",
                            },
                            ticks: {
                                beginAtZero: true,
                                callback: function(value) {
                                    if (value >= 1000000) {
                                        return 'Rp ' + (value/1000000).toFixed(1) + 'Jt';
                                    } else if (value >= 1000) {
                                        return 'Rp ' + (value/1000).toFixed(0) + 'Rb';
                                    }
                                    return 'Rp ' + value;
                                }
                            }
                        }
                    }
                }
            });
        }
    });
</script>

<style>
    :root {
        --primary: #4e73df;
        --success: #1cc88a;
        --info: #36b9cc;
        --warning: #f6c23e;
        --danger: #e74a3b;
        --secondary: #858796;
        --light: #f8f9fc;
        --dark: #5a5c69;
        --purple: #6f42c1;
        --pink: #e83e8c;
    }
    
    /* Welcome Banner */
    .welcome-banner {
        background: linear-gradient(45deg, #4e73df, #224abe);
        color: white;
        border-radius: 8px;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
    }
    
    /* Summary Cards */
    .summary-card {
        border: none;
        border-radius: 8px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        transition: transform 0.2s ease;
    }
    
    .summary-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    
    .card-population {
        border-left: 3px solid var(--primary);
    }
    
    .card-news {
        border-left: 3px solid var(--info);
    }
    
    .card-services {
        border-left: 3px solid var(--warning);
    }
    
    .card-products {
        border-left: 3px solid var(--purple);
    }
    
    .card-income {
        border-left: 3px solid var(--success);
    }
    
    .card-expense {
        border-left: 3px solid var(--danger);
    }
    
    .card-balance {
        border-left: 3px solid #20c9a6;
    }
    
    .summary-card .card-title {
        color: var(--dark);
        font-weight: 700;
    }
    
    .card-icon-sm {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 40px;
        height: 40px;
        border-radius: 8px;
        font-size: 1.1rem;
    }
    
    .card-icon-xs {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        border-radius: 6px;
        font-size: 0.9rem;
    }
    
    .card-population .card-icon-sm {
        background: rgba(78, 115, 223, 0.15);
        color: var(--primary);
    }
    
    .card-news .card-icon-sm {
        background: rgba(54, 185, 204, 0.15);
        color: var(--info);
    }
    
    .card-services .card-icon-sm {
        background: rgba(246, 194, 62, 0.15);
        color: var(--warning);
    }
    
    .card-products .card-icon-sm {
        background: rgba(111, 66, 193, 0.15);
        color: var(--purple);
    }
    
    .card-income .card-icon-xs {
        background: rgba(28, 200, 138, 0.15);
        color: var(--success);
    }
    
    .card-expense .card-icon-xs {
        background: rgba(231, 74, 59, 0.15);
        color: var(--danger);
    }
    
    .card-balance .card-icon-xs {
        background: rgba(32, 201, 166, 0.15);
        color: #20c9a6;
    }
    
    .gender-marker {
        display: inline-block;
        width: 8px;
        height: 8px;
        border-radius: 50%;
    }
    
    .gender-marker.male {
        background-color: var(--primary);
    }
    
    .gender-marker.female {
        background-color: var(--pink);
    }
    
    /* Chart Cards */
    .chart-card {
        border: none;
        border-radius: 8px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
    }
    
    .chart-card .card-header {
        background: white;
        border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        padding: 0.5rem 1rem;
    }
    
    .chart-container-sm {
        position: relative;
        height: 200px;
    }
    
    .chart-legend-sm {
        display: flex;
        justify-content: center;
        gap: 1rem;
        font-size: 0.8rem;
    }
    
    .legend-item {
        display: flex;
        align-items: center;
    }
    
    .legend-color {
        display: inline-block;
        width: 10px;
        height: 10px;
        border-radius: 2px;
        margin-right: 0.4rem;
    }
    
    .legend-color.male {
        background-color: var(--primary);
    }
    
    .legend-color.female {
        background-color: var(--pink);
    }
    
    .legend-color.income {
        background-color: var(--success);
    }
    
    .legend-color.expense {
        background-color: var(--danger);
    }
    
    .no-data {
        color: #b7b9cc;
    }
    
    /* Responsive adjustments */
    @media (max-width: 768px) {
        .chart-legend-sm {
            flex-direction: column;
            gap: 0.5rem;
            align-items: center;
        }
        
        .summary-card .card-title {
            font-size: 1.35rem;
        }
    }
</style>
<?= $this->endSection(); ?>