<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-6 mx-auto">
            <div class="card shadow-lg">
                <div class="card-header bg-danger text-white">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-exclamation-triangle me-2"></i> Konfirmasi Penghapusan
                    </h5>
                </div>
                <div class="card-body">
                    <p>Apakah Anda yakin ingin menghapus gambar berikut?</p>
                    <div class="text-center mb-4">
                        <?php
                        $imagePath = 'uploads/gallery/' . $gallery['image'];
                        $imageUrl = base_url($imagePath);
                        $placeholderUrl = 'https://via.placeholder.com/300x200?text=Gambar+Tidak+Tersedia';
                        ?>
                        <img src="<?= file_exists(ROOTPATH . 'public/' . $imagePath) ? $imageUrl : $placeholderUrl ?>" 
                             alt="<?= esc($gallery['title']) ?>" 
                             class="img-fluid rounded"
                             style="max-height: 200px;"
                             onerror="this.src='<?= $placeholderUrl ?>'">
                        <h5 class="mt-3"><?= esc($gallery['title']) ?></h5>
                        <?php if ($gallery['description']): ?>
                            <p class="text-muted"><?= esc($gallery['description']) ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="d-flex justify-content-end">
                        <a href="<?= site_url('dashboard/gallery') ?>" class="btn btn-secondary me-2">Batal</a>
                        <form action="<?= site_url('dashboard/gallery/delete/' . $gallery['id']) ?>" method="post">
                            <?= csrf_field() ?>
                            <input type="hidden" name="_method" value="DELETE">
                            <button type="submit" class="btn btn-danger">Hapus</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>