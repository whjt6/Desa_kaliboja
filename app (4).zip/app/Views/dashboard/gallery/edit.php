<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content'); ?>
<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Edit Foto Galeri</h1>
        <a href="<?= site_url('dashboard/gallery') ?>" class="d-none d-sm-inline-block btn btn-sm btn-secondary shadow-sm">
            <i class="fas fa-arrow-left fa-sm text-white-50"></i> Kembali
        </a>
    </div>

    <!-- Content Row -->
    <div class="row">
        <div class="col-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Form Edit Foto</h6>
                </div>
                <div class="card-body">
                    <form action="<?= site_url('dashboard/gallery/update/' . $gallery['id']) ?>" method="post" enctype="multipart/form-data">
                        <?= csrf_field() ?>
                        
                        <div class="form-group">
                            <label for="title">Judul Foto *</label>
                            <input type="text" class="form-control" id="title" name="title" required 
                                   value="<?= old('title', $gallery['title']) ?>">
                        </div>

                        <div class="form-group">
                            <label for="description">Deskripsi</label>
                            <textarea class="form-control" id="description" name="description" rows="3"><?= old('description', $gallery['description']) ?></textarea>
                        </div>

                        <div class="form-group">
                            <label for="image">Foto</label>
                            <div class="mb-3">
                                <img src="/uploads/gallery/<?= $gallery['image'] ?>" 
                                     alt="<?= $gallery['title'] ?>" 
                                     class="img-thumbnail" 
                                     style="max-height: 200px;">
                                <div class="mt-2">
                                    <small class="text-muted">Foto saat ini</small>
                                </div>
                            </div>
                            <input type="file" class="form-control-file" id="image" name="image" accept="image/*">
                            <small class="form-text text-muted">
                                Biarkan kosong jika tidak ingin mengganti foto. Format: JPG, PNG, GIF. Maksimal 2MB
                            </small>
                        </div>

                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Update Foto
                        </button>
                        <a href="<?= site_url('dashboard/gallery') ?>" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Batal
                        </a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>