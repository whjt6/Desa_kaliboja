<?= $this->extend('layout/dashboard_layout') ?>
<?= $this->section('content'); ?>
<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Manajemen Galeri</h1>
        <a href="<?= site_url('dashboard/gallery/create') ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
            <i class="fas fa-plus fa-sm text-white-50"></i> Tambah Foto
        </a>
    </div>

    <!-- Content Row -->
    <div class="row">
        <div class="col-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Daftar Foto Galeri</h6>
                </div>
                <div class="card-body">
                    <!-- Notifikasi -->
                    <?php if(session()->getFlashdata('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?= session()->getFlashdata('success') ?>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <?php if(session()->getFlashdata('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?= session()->getFlashdata('error') ?>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <!-- Tabel Gallery -->
                    <?php if(!empty($galleries)): ?>
                        <div class="row">
                            <?php foreach($galleries as $gallery): ?>
                            <div class="col-xl-3 col-md-4 col-sm-6 mb-4">
                                <div class="card border-left-primary shadow h-100">
                                    <img src="/uploads/gallery/<?= $gallery['image'] ?>" 
                                         class="card-img-top" 
                                         alt="<?= $gallery['title'] ?>"
                                         style="height: 200px; object-fit: cover;">
                                    <div class="card-body">
                                        <h6 class="card-title font-weight-bold text-primary">
                                            <?= esc($gallery['title']) ?>
                                        </h6>
                                        <?php if($gallery['description']): ?>
                                            <p class="card-text small"><?= esc($gallery['description']) ?></p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="card-footer">
                                        <div class="btn-group btn-group-sm w-100">
                                            <!-- TOMBOL EDIT -->
                                            <a href="<?= site_url('dashboard/gallery/edit/' . $gallery['id']) ?>" 
                                               class="btn btn-warning">
                                                <i class="fas fa-edit"></i> Edit
                                            </a>
                                            
                                            <!-- TOMBOL DELETE -->
                                            <a href="<?= site_url('dashboard/gallery/delete/' . $gallery['id']) ?>" 
                                               class="btn btn-danger" 
                                               onclick="return confirm('Yakin ingin menghapus foto ini?')">
                                                <i class="fas fa-trash"></i> Hapus
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-images fa-3x text-gray-300 mb-3"></i>
                            <h5 class="text-gray-500">Belum ada foto di galeri</h5>
                            <p class="text-gray-400">Klik tombol "Tambah Foto" untuk menambahkan foto pertama</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>