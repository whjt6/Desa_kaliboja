<?= $this->extend('layout/dashboard_layout'); ?>

<?= $this->section('content'); ?>
<div class="page-inner">
    <div class="page-header">
        <h4 class="page-title">Tambah Rencana Kegiatan</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="#">
                    <i class="flaticon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="#">RKP Desa</a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="#">Tambah</a>
            </li>
        </ul>
    </div>

    <!-- Notifikasi Error -->
    <?php if (session()->getFlashdata('errors')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <ul class="mb-0">
                <?php foreach (session()->getFlashdata('errors') as $error): ?>
                    <li><?= $error ?></li>
                <?php endforeach; ?>
            </ul>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= session()->getFlashdata('error') ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-title">Form Tambah Rencana Kegiatan</div>
                </div>
                <div class="card-body">
                    <form action="<?= site_url('dashboard/rkp/store') ?>" method="POST">
                        <?= csrf_field() ?>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="tahun">Tahun *</label>
                                    <input type="number" class="form-control <?= session('errors.tahun') ? 'is-invalid' : '' ?>" 
                                        id="tahun" name="tahun" value="<?= old('tahun') ?: date('Y') ?>" 
                                        min="2020" max="2030" required>
                                    <?php if (session('errors.tahun')): ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.tahun') ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="status">Status *</label>
                                    <select class="form-control <?= session('errors.status') ? 'is-invalid' : '' ?>" 
                                        id="status" name="status" required>
                                        <option value="">Pilih Status</option>
                                        <option value="rencana" <?= old('status') == 'rencana' ? 'selected' : '' ?>>Rencana</option>
                                        <option value="proses" <?= old('status') == 'proses' ? 'selected' : '' ?>>Proses</option>
                                        <option value="selesai" <?= old('status') == 'selesai' ? 'selected' : '' ?>>Selesai</option>
                                    </select>
                                    <?php if (session('errors.status')): ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.status') ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="nama_kegiatan">Nama Kegiatan *</label>
                            <input type="text" class="form-control <?= session('errors.nama_kegiatan') ? 'is-invalid' : '' ?>" 
                                id="nama_kegiatan" name="nama_kegiatan" value="<?= old('nama_kegiatan') ?>" required>
                            <?php if (session('errors.nama_kegiatan')): ?>
                                <div class="invalid-feedback">
                                    <?= session('errors.nama_kegiatan') ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="lokasi">Lokasi *</label>
                                    <input type="text" class="form-control <?= session('errors.lokasi') ? 'is-invalid' : '' ?>" 
                                        id="lokasi" name="lokasi" value="<?= old('lokasi') ?>" required>
                                    <?php if (session('errors.lokasi')): ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.lokasi') ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="volume">Volume *</label>
                                    <input type="text" class="form-control <?= session('errors.volume') ? 'is-invalid' : '' ?>" 
                                        id="volume" name="volume" value="<?= old('volume') ?>" required>
                                    <?php if (session('errors.volume')): ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.volume') ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="sasaran">Sasaran *</label>
                            <input type="text" class="form-control <?= session('errors.sasaran') ? 'is-invalid' : '' ?>" 
                                id="sasaran" name="sasaran" value="<?= old('sasaran') ?>" required>
                            <?php if (session('errors.sasaran')): ?>
                                <div class="invalid-feedback">
                                    <?= session('errors.sasaran') ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="waktu_pelaksanaan">Waktu Pelaksanaan *</label>
                                    <input type="text" class="form-control <?= session('errors.waktu_pelaksanaan') ? 'is-invalid' : '' ?>" 
                                        id="waktu_pelaksanaan" name="waktu_pelaksanaan" value="<?= old('waktu_pelaksanaan') ?>" 
                                        placeholder="Contoh: Januari - Maret 2024" required>
                                    <?php if (session('errors.waktu_pelaksanaan')): ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.waktu_pelaksanaan') ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="jumlah_biaya">Jumlah Biaya (Rp) *</label>
                                    <input type="number" class="form-control <?= session('errors.jumlah_biaya') ? 'is-invalid' : '' ?>" 
                                        id="jumlah_biaya" name="jumlah_biaya" value="<?= old('jumlah_biaya') ?>" 
                                        min="0" required>
                                    <?php if (session('errors.jumlah_biaya')): ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.jumlah_biaya') ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="sumber_dana">Sumber Dana *</label>
                                    <select class="form-control <?= session('errors.sumber_dana') ? 'is-invalid' : '' ?>" 
                                        id="sumber_dana" name="sumber_dana" required>
                                        <option value="">Pilih Sumber Dana</option>
                                        <option value="APBDes" <?= old('sumber_dana') == 'APBDes' ? 'selected' : '' ?>>APBDes</option>
                                        <option value="ADD" <?= old('sumber_dana') == 'ADD' ? 'selected' : '' ?>>ADD</option>
                                        <option value="Bantuan Provinsi" <?= old('sumber_dana') == 'Bantuan Provinsi' ? 'selected' : '' ?>>Bantuan Provinsi</option>
                                        <option value="Bantuan Kabupaten" <?= old('sumber_dana') == 'Bantuan Kabupaten' ? 'selected' : '' ?>>Bantuan Kabupaten</option>
                                        <option value="Swadaya" <?= old('sumber_dana') == 'Swadaya' ? 'selected' : '' ?>>Swadaya</option>
                                    </select>
                                    <?php if (session('errors.sumber_dana')): ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.sumber_dana') ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="pelaksana">Pelaksana *</label>
                                    <input type="text" class="form-control <?= session('errors.pelaksana') ? 'is-invalid' : '' ?>" 
                                        id="pelaksana" name="pelaksana" value="<?= old('pelaksana') ?>" required>
                                    <?php if (session('errors.pelaksana')): ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.pelaksana') ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="progress">Progress (%) *</label>
                            <input type="range" class="form-control-range <?= session('errors.progress') ? 'is-invalid' : '' ?>" 
                                id="progress" name="progress" min="0" max="100" value="<?= old('progress') ?: 0 ?>" 
                                oninput="progressValue.value = this.value" required>
                            <output id="progressValue"><?= old('progress') ?: 0 ?></output>%
                            <?php if (session('errors.progress')): ?>
                                <div class="invalid-feedback">
                                    <?= session('errors.progress') ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="keterangan">Keterangan</label>
                            <textarea class="form-control" id="keterangan" name="keterangan" rows="3"><?= old('keterangan') ?></textarea>
                        </div>

                        <div class="form-group text-right">
                            <a href="<?= site_url('dashboard/rkp') ?>" class="btn btn-secondary">Batal</a>
                            <button type="submit" class="btn btn-primary">Simpan Rencana Kegiatan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>