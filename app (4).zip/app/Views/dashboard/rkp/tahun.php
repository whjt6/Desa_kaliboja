<?= $this->extend('layout/main_layout'); ?>

<?= $this->section('content'); ?>
<!-- Hero Section RKP Tahun -->

<div class="container py-5">
    <!-- Ringkasan Tahun -->
    <div class="row mb-5">
        <div class="col-12">
            <div class="card border-0 shadow-sm" data-aos="fade-up">
                <div class="card-body p-4">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h3 class="text-primary mb-2">RKP Tahun <?= $tahun; ?></h3>
                            <p class="text-muted mb-0">
                                Rencana kerja dan kegiatan pembangunan desa pada tahun <?= $tahun; ?>
                            </p>
                        </div>
                        <div class="col-md-4 text-end">
                            <div class="display-6 fw-bold text-primary"><?= count($rkps); ?></div>
                            <p class="text-muted mb-0">Total Kegiatan</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistik -->
    <div class="row mb-5">
        <div class="col-12">
            <h2 class="section-title mb-4" data-aos="fade-up">
                <i class="fas fa-chart-pie me-2"></i>Statistik RKP Tahun <?= $tahun; ?>
            </h2>
            
            <div class="row g-4">
                <?php 
                // Hitung statistik
                $totalKegiatan = count($rkps);
                $totalAnggaran = array_sum(array_column($rkps, 'jumlah_biaya'));
                $kegiatanSelesai = count(array_filter($rkps, function($r) { return $r['status'] == 'selesai'; }));
                $kegiatanBerjalan = count(array_filter($rkps, function($r) { return $r['status'] == 'berjalan'; }));
                $kegiatanRencana = count(array_filter($rkps, function($r) { return $r['status'] == 'rencana'; }));
                $progressRata = $totalKegiatan > 0 ? array_sum(array_column($rkps, 'progress')) / $totalKegiatan : 0;
                ?>
                
                <div class="col-md-3 col-6" data-aos="fade-up">
                    <div class="card border-0 shadow-sm text-center h-100">
                        <div class="card-body p-3">
                            <i class="fas fa-tasks fa-2x text-primary mb-3"></i>
                            <h3 class="fw-bold text-dark"><?= number_format($totalKegiatan); ?></h3>
                            <p class="text-muted mb-0">Total Kegiatan</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 col-6" data-aos="fade-up" data-aos-delay="100">
                    <div class="card border-0 shadow-sm text-center h-100">
                        <div class="card-body p-3">
                            <i class="fas fa-money-bill-wave fa-2x text-success mb-3"></i>
                            <h3 class="fw-bold text-dark">Rp <?= number_format($totalAnggaran / 1000000, 1); ?> Jt</h3>
                            <p class="text-muted mb-0">Total Anggaran</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 col-6" data-aos="fade-up" data-aos-delay="200">
                    <div class="card border-0 shadow-sm text-center h-100">
                        <div class="card-body p-3">
                            <i class="fas fa-check-circle fa-2x text-info mb-3"></i>
                            <h3 class="fw-bold text-dark"><?= number_format($kegiatanSelesai); ?></h3>
                            <p class="text-muted mb-0">Selesai</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 col-6" data-aos="fade-up" data-aos-delay="300">
                    <div class="card border-0 shadow-sm text-center h-100">
                        <div class="card-body p-3">
                            <i class="fas fa-chart-line fa-2x text-warning mb-3"></i>
                            <h3 class="fw-bold text-dark"><?= number_format($progressRata, 1); ?>%</h3>
                            <p class="text-muted mb-0">Progress Rata</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Grafik Status -->
            <div class="row mt-4" data-aos="fade-up">
                <div class="col-12">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0"><i class="fas fa-chart-bar me-2"></i>Status Kegiatan</h5>
                        </div>
                        <div class="card-body">
                            <div class="row text-center">
                                <div class="col-md-4 mb-3">
                                    <div class="p-3 bg-success bg-opacity-10 rounded">
                                        <div class="display-6 fw-bold text-success"><?= $kegiatanSelesai; ?></div>
                                        <div class="text-muted">Selesai</div>
                                        <div class="progress mt-2" style="height: 8px;">
                                            <div class="progress-bar bg-success" style="width: <?= $totalKegiatan > 0 ? ($kegiatanSelesai / $totalKegiatan) * 100 : 0; ?>%"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="p-3 bg-warning bg-opacity-10 rounded">
                                        <div class="display-6 fw-bold text-warning"><?= $kegiatanBerjalan; ?></div>
                                        <div class="text-muted">Berjalan</div>
                                        <div class="progress mt-2" style="height: 8px;">
                                            <div class="progress-bar bg-warning" style="width: <?= $totalKegiatan > 0 ? ($kegiatanBerjalan / $totalKegiatan) * 100 : 0; ?>%"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="p-3 bg-secondary bg-opacity-10 rounded">
                                        <div class="display-6 fw-bold text-secondary"><?= $kegiatanRencana; ?></div>
                                        <div class="text-muted">Rencana</div>
                                        <div class="progress mt-2" style="height: 8px;">
                                            <div class="progress-bar bg-secondary" style="width: <?= $totalKegiatan > 0 ? ($kegiatanRencana / $totalKegiatan) * 100 : 0; ?>%"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Daftar Kegiatan -->
    <div class="row" id="kegiatan">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="section-title m-0" data-aos="fade-up">
                    <i class="fas fa-list-check me-2"></i>Daftar Kegiatan Tahun <?= $tahun; ?>
                </h2>
                <div class="dropdown" data-aos="fade-up">
                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="fas fa-filter me-2"></i>Filter Status
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="?tahun=<?= $tahun; ?>">Semua</a></li>
                        <li><a class="dropdown-item" href="?tahun=<?= $tahun; ?>&status=selesai">Selesai</a></li>
                        <li><a class="dropdown-item" href="?tahun=<?= $tahun; ?>&status=berjalan">Berjalan</a></li>
                        <li><a class="dropdown-item" href="?tahun=<?= $tahun; ?>&status=rencana">Rencana</a></li>
                    </ul>
                </div>
            </div>

            <?php if (!empty($rkps)): ?>
                <div class="table-responsive" data-aos="fade-up">
                    <table class="table table-hover table-striped">
                        <thead class="table-primary">
                            <tr>
                                <th width="50">No</th>
                                <th>Nama Kegiatan</th>
                                <th>Lokasi</th>
                                <th>Sasaran</th>
                                <th>Anggaran</th>
                                <th>Status</th>
                                <th>Progress</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; ?>
                            <?php foreach ($rkps as $r): ?>
                            <tr>
                                <td class="text-center"><?= $no++; ?></td>
                                <td>
                                    <strong class="text-dark"><?= esc($r['nama_kegiatan']); ?></strong><br>
                                    <small class="text-muted"><?= esc($r['pelaksana']); ?></small>
                                </td>
                                <td class="text-dark"><?= esc($r['lokasi']); ?></td>
                                <td class="text-dark"><?= esc($r['sasaran']); ?></td>
                                <td>
                                    <strong class="text-success">Rp <?= number_format($r['jumlah_biaya'], 0, ',', '.'); ?></strong><br>
                                    <small class="text-muted"><?= esc($r['sumber_dana']); ?></small>
                                </td>
                                <td>
                                    <?php 
                                    $status_badge = [
                                        'rencana' => 'secondary',
                                        'berjalan' => 'warning',
                                        'selesai' => 'success',
                                        'tertunda' => 'danger'
                                    ];
                                    $status_text = [
                                        'rencana' => 'Rencana',
                                        'berjalan' => 'Berjalan',
                                        'selesai' => 'Selesai',
                                        'tertunda' => 'Tertunda'
                                    ];
                                    ?>
                                    <span class="badge bg-<?= $status_badge[$r['status']] ?? 'secondary'; ?>">
                                        <?= $status_text[$r['status']] ?? $r['status']; ?>
                                    </span>
                                </td>
                                <td width="150">
                                    <div class="d-flex align-items-center">
                                        <div class="progress flex-grow-1" style="height: 8px;">
                                            <div class="progress-bar bg-success" role="progressbar" 
                                                 style="width: <?= $r['progress']; ?>%" 
                                                 aria-valuenow="<?= $r['progress']; ?>" 
                                                 aria-valuemin="0" 
                                                 aria-valuemax="100"></div>
                                        </div>
                                        <small class="ms-2 text-muted"><?= $r['progress']; ?>%</small>
                                    </div>
                                </td>
                                <td>
                                    <a href="<?= site_url('rkp/detail/' . $r['id']); ?>" 
                                       class="btn btn-sm btn-primary">
                                        <i class="fas fa-eye me-1"></i>Detail
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot class="table-light">
                            <tr>
                                <td colspan="4" class="text-end fw-bold">Total Anggaran Tahun <?= $tahun; ?>:</td>
                                <td colspan="4" class="fw-bold text-danger">
                                    Rp <?= number_format($totalAnggaran, 0, ',', '.'); ?>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-5" data-aos="fade-up">
                    <i class="fas fa-clipboard-list fa-4x text-muted mb-4"></i>
                    <h4 class="text-muted">Belum ada rencana kegiatan untuk tahun <?= $tahun; ?></h4>
                    <p class="text-muted mb-4">Rencana kerja pemerintah desa akan segera diunggah</p>
                    <a href="<?= site_url('rkp'); ?>" class="btn btn-primary">
                        <i class="fas fa-arrow-left me-2"></i>Kembali
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Tahun Lainnya -->
<section class="bg-light py-5">
    <div class="container">
        <h3 class="section-title mb-4 text-center" data-aos="fade-up">
            <i class="fas fa-calendar me-2"></i>RKP Tahun Lainnya
        </h3>
        
        <div class="row">
            <?php 
            // Contoh tahun lain (dalam implementasi nyata, ini akan diambil dari database)
            $tahunLain = [
                
            ];
            
            // Filter out current year
            $tahunLain = array_filter($tahunLain, function($t) use ($tahun) {
                return $t['tahun'] != $tahun;
            });
            
            // Sort by year descending
            usort($tahunLain, function($a, $b) {
                return $b['tahun'] - $a['tahun'];
            });
            ?>
            
            <?php if (!empty($tahunLain)): ?>
                <?php foreach ($tahunLain as $t): ?>
                <div class="col-md-3 mb-4" data-aos="fade-up">
                    <a href="<?= site_url('rkp/tahun/' . $t['tahun']); ?>" class="text-decoration-none">
                        <div class="card border-0 shadow-sm h-100 hover-lift">
                            <div class="card-body text-center p-4">
                                <div class="display-4 fw-bold text-primary mb-2"><?= $t['tahun']; ?></div>
                                <p class="text-muted mb-2">
                                    <i class="fas fa-tasks me-1"></i>
                                    <?= $t['jumlah']; ?> Kegiatan
                                </p>
                                <p class="text-success fw-bold mb-0">
                                    <i class="fas fa-money-bill-wave me-1"></i>
                                    Rp <?= number_format($t['anggaran'] / 1000000, 1); ?> Jt
                                </p>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <div class="text-center mt-4" data-aos="fade-up">
            <a href="<?= site_url('rkp'); ?>" class="btn btn-outline-primary">
                <i class="fas fa-list me-2"></i>Lihat Semua Tahun
            </a>
        </div>
    </div>
</section>
<?= $this->endSection(); ?>