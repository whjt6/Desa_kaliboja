<?= $this->extend('layout/dashboard_layout'); ?>

<?= $this->section('content'); ?>
<div class="page-inner">
    

    <!-- Notifikasi -->
    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= session()->getFlashdata('success') ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= session()->getFlashdata('error') ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h4 class="card-title">Data Rencana Kegiatan</h4>
                        <a href="<?= site_url('dashboard/rkp/create') ?>" class="btn btn-primary btn-sm">
                            <i class="fas fa-plus me-2"></i>Tambah Rencana
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <!-- Filter Tahun -->
                    <div class="row mb-3">
                        <div class="col-md-3">
                            <select class="form-control" id="filterTahun">
                                <option value="">Semua Tahun</option>
                                <?php foreach ($tahunList as $thn): ?>
                                    <option value="<?= $thn['tahun'] ?>"><?= $thn['tahun'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select class="form-control" id="filterStatus">
                                <option value="">Semua Status</option>
                                <option value="rencana">Rencana</option>
                                <option value="proses">Proses</option>
                                <option value="selesai">Selesai</option>
                            </select>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered" id="rkpTable">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Tahun</th>
                                    <th>Nama Kegiatan</th>
                                    <th>Lokasi</th>
                                    <th>Anggaran</th>
                                    <th>Status</th>
                                    <th>Progress</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($rkps)): ?>
                                    <?php foreach ($rkps as $index => $rkp): ?>
                                        <tr>
                                            <td><?= $index + 1 ?></td>
                                            <td><?= $rkp['tahun'] ?></td>
                                            <td>
                                                <strong><?= esc($rkp['nama_kegiatan']) ?></strong><br>
                                                <small class="text-muted"><?= esc($rkp['sasaran']) ?></small>
                                            </td>
                                            <td><?= esc($rkp['lokasi']) ?></td>
                                            <td>Rp <?= number_format($rkp['jumlah_biaya'], 0, ',', '.') ?></td>
                                            <td>
                                                <span class="badge badge-<?= 
                                                    $rkp['status'] == 'selesai' ? 'success' : 
                                                    ($rkp['status'] == 'proses' ? 'warning' : 'secondary') 
                                                ?>">
                                                    <?= ucfirst($rkp['status']) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <div class="progress" style="height: 20px;">
                                                    <div class="progress-bar progress-bar-<?= 
                                                        $rkp['progress'] == 100 ? 'success' : 
                                                        ($rkp['progress'] >= 50 ? 'info' : 'warning') 
                                                    ?>" 
                                                    role="progressbar" 
                                                    style="width: <?= $rkp['progress'] ?>%;" 
                                                    aria-valuenow="<?= $rkp['progress'] ?>" 
                                                    aria-valuemin="0" 
                                                    aria-valuemax="100">
                                                        <?= $rkp['progress'] ?>%
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="btn-group">
                                                    <a href="<?= site_url('dashboard/rkp/edit/' . $rkp['id']) ?>" class="btn btn-sm btn-warning">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <a href="<?= site_url('rkp/detail/' . $rkp['id']) ?>" target="_blank" class="btn btn-sm btn-info">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <form action="<?= site_url('dashboard/rkp/delete/' . $rkp['id']) ?>" method="POST" class="d-inline">
                                                        <?= csrf_field() ?>
                                                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-center text-muted py-4">
                                            <i class="fas fa-chart-line fa-3x mb-3"></i>
                                            <p>Belum ada data Rencana Kegiatan</p>
                                            <a href="<?= site_url('dashboard/rkp/create') ?>" class="btn btn-primary">
                                                Tambah Data Pertama
                                            </a>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Filter data
    const filterTahun = document.getElementById('filterTahun');
    const filterStatus = document.getElementById('filterStatus');
    const table = document.getElementById('rkpTable');
    
    function filterData() {
        const tahunValue = filterTahun.value.toLowerCase();
        const statusValue = filterStatus.value.toLowerCase();
        const rows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');
        
        for (let i = 0; i < rows.length; i++) {
            const tahunCell = rows[i].getElementsByTagName('td')[1];
            const statusCell = rows[i].getElementsByTagName('td')[5];
            
            const tahunText = tahunCell ? tahunCell.textContent.toLowerCase() : '';
            const statusText = statusCell ? statusCell.textContent.toLowerCase() : '';
            
            const tahunMatch = !tahunValue || tahunText.includes(tahunValue);
            const statusMatch = !statusValue || statusText.includes(statusValue);
            
            rows[i].style.display = tahunMatch && statusMatch ? '' : 'none';
        }
    }
    
    filterTahun.addEventListener('change', filterData);
    filterStatus.addEventListener('change', filterData);
});
</script>
<?= $this->endSection(); ?>