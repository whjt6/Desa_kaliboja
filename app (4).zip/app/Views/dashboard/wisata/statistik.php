<?= $this->extend('layout/dashboard_layout'); ?>
<?= $this->section('content'); ?>

<div class="card shadow mb-4">
    <div class="card-header py-3 bg-gradient-primary text-white">
        <h6 class="m-0 font-weight-bold">Statistik Wisata Desa</h6>
    </div>
    <div class="card-body">
        <div class="mb-3">
            <a href="<?= base_url('dashboard/wisata'); ?>" class="btn btn-secondary btn-icon-split btn-sm">
                <span class="icon text-white-50">
                    <i class="fas fa-arrow-left"></i>
                </span>
                <span class="text">Kembali ke Data</span>
            </a>
        </div>

        <?php if (empty($wisata)): ?>
        <div class="alert alert-info">
            <i class="fas fa-info-circle"></i> Belum ada data wisata.
        </div>
        <?php else: 
        
        // Hitung statistik
        $totalWisata = count($wisata);
        $lokasiUnik = array_unique(array_column($wisata, 'lokasi'));
        $jumlahLokasi = count($lokasiUnik);
        
        // Hitung jumlah wisata per lokasi
        $wisataPerLokasi = [];
        foreach ($wisata as $w) {
            $lokasi = $w['lokasi'];
            if (!isset($wisataPerLokasi[$lokasi])) {
                $wisataPerLokasi[$lokasi] = 0;
            }
            $wisataPerLokasi[$lokasi]++;
        }
        
        // Temukan lokasi dengan wisata terbanyak
        arsort($wisataPerLokasi);
        $lokasiTerbanyak = key($wisataPerLokasi);
        $jumlahTerbanyak = current($wisataPerLokasi);
        
        ?>
        
        <!-- Ringkasan Statistik -->
        <div class="row mb-4">
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                    Total Wisata</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?= $totalWisata; ?>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-map-marked-alt fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-success shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                    Lokasi Wisata</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?= $jumlahLokasi; ?>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-location-arrow fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-info shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                    Rata-rata per Lokasi</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?= number_format($totalWisata / max(1, $jumlahLokasi), 1); ?>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-calculator fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-warning shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                    Lokasi Terbanyak</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?= esc($lokasiTerbanyak) . " ($jumlahTerbanyak)" ?>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-trophy fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Grafik Utama -->
        <div class="row mb-4">
            <div class="col-lg-8">
                <div class="card shadow mb-4">
                    <div class="card-header py-3 bg-gradient-primary text-white">
                        <h6 class="m-0 font-weight-bold">Grafik Wisata per Lokasi</h6>
                    </div>
                    <div class="card-body">
                        <div class="chart-bar">
                            <canvas id="wisataChart" height="300"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="card shadow mb-4">
                    <div class="card-header py-3 bg-gradient-success text-white">
                        <h6 class="m-0 font-weight-bold">Distribusi Lokasi Wisata</h6>
                    </div>
                    <div class="card-body">
                        <div class="chart-pie pt-4 pb-2">
                            <canvas id="lokasiPieChart" height="250"></canvas>
                        </div>
                        <div class="mt-4 text-center small" id="pieLegend">
                            <!-- Legend akan diisi oleh JavaScript -->
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Data dalam bentuk tabel ringkas -->
        <div class="card shadow mb-4">
            <div class="card-header py-3 bg-gradient-info text-white">
                <h6 class="m-0 font-weight-bold">Data Detail Wisata</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                        <thead class="thead-light">
                            <tr>
                                <th>Gambar</th>
                                <th>Nama Wisata</th>
                                <th>Lokasi</th>
                                <th>Deskripsi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($wisata as $w): 
                                $gambar = !empty($w['gambar']) ? base_url('uploads/wisata/' . $w['gambar']) : base_url('assets/img/no-image.png');
                            ?>
                            <tr>
                                <td class="text-center">
                                    <img src="<?= $gambar; ?>" alt="<?= esc($w['nama']); ?>" class="img-thumbnail" style="max-width: 80px; max-height: 80px;">
                                </td>
                                <td><?= esc($w['nama']); ?></td>
                                <td><?= esc($w['lokasi']); ?></td>
                                <td><?= character_limiter(strip_tags($w['deskripsi']), 100); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <?php endif; ?>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
<?php if (!empty($wisata)): ?>
// Data dari PHP
const lokasiLabels = <?= json_encode(array_keys($wisataPerLokasi)); ?>;
const jumlahData = <?= json_encode(array_values($wisataPerLokasi)); ?>;
const colors = [
    '#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b', 
    '#858796', '#f8f9fc', '#5a5c69', '#2e59d9', '#17a673',
    '#6f42c1', '#e83e8c', '#fd7e14', '#20c997'
];

// Grafik Batang
document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('wisataChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: lokasiLabels,
            datasets: [{
                label: 'Jumlah Wisata',
                data: jumlahData,
                backgroundColor: colors,
                borderColor: 'rgba(0, 0, 0, 0.1)',
                borderWidth: 1,
                barPercentage: 0.6,
            }]
        },
        options: {
            maintainAspectRatio: false,
            layout: {
                padding: {
                    left: 10,
                    right: 25,
                    top: 25,
                    bottom: 0
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false,
                        drawBorder: false
                    }
                },
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    },
                    title: {
                        display: true,
                        text: 'Jumlah Wisata'
                    },
                    grid: {
                        drawBorder: false
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `Jumlah: ${context.raw} Wisata`;
                        }
                    }
                }
            }
        }
    });

    // Pie Chart untuk distribusi lokasi
    const pieCtx = document.getElementById('lokasiPieChart').getContext('2d');
    const pieChart = new Chart(pieCtx, {
        type: 'doughnut',
        data: {
            labels: lokasiLabels,
            datasets: [{
                data: jumlahData,
                backgroundColor: colors,
                hoverBackgroundColor: colors,
                hoverBorderColor: "rgba(234, 236, 244, 1)",
            }],
        },
        options: {
            maintainAspectRatio: false,
            tooltips: {
                backgroundColor: "rgb(255,255,255)",
                bodyFontColor: "#858796",
                borderColor: '#dddfeb',
                borderWidth: 1,
                xPadding: 15,
                yPadding: 15,
                displayColors: false,
                caretPadding: 10,
                callbacks: {
                    label: function(tooltipItem, data) {
                        const dataset = data.datasets[tooltipItem.datasetIndex];
                        const currentValue = dataset.data[tooltipItem.index];
                        const total = dataset.data.reduce((acc, value) => acc + value, 0);
                        const percentage = Math.round((currentValue / total) * 100);
                        return `${data.labels[tooltipItem.index]}: ${currentValue} Wisata (${percentage}%)`;
                    }
                }
            },
            legend: {
                display: false
            },
            cutout: '60%',
        },
    });
    
    // Buat legend manual untuk pie chart
    let legendHtml = '';
    const totalWisata = <?= $totalWisata; ?>;
    
    lokasiLabels.forEach((label, i) => {
        const percentage = (jumlahData[i] / totalWisata * 100).toFixed(1);
        legendHtml += `
            <span class="mr-2">
                <i class="fas fa-circle" style="color: ${colors[i]}"></i> ${label} (${percentage}%)
            </span>
            <br>
        `;
    });
    document.getElementById('pieLegend').innerHTML = legendHtml;
});
<?php endif; ?>
</script>

<?= $this->endSection(); ?>