<?= $this->extend('layout/dashboard_layout') ?>
<?= $this->section('content') ?>
<div class="mb-4"></div>
<div class="container-fluid">
    <div class="card shadow-sm border-0">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            
            <a href="<?= site_url('dashboard/population') ?>" class="btn btn-light btn-sm">
                <i class="fas fa-arrow-left me-1"></i> Kembali
            </a>
        </div>
        <div class="card-body">
            <?php if (session('errors')): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php foreach (session('errors') as $error): ?>
                            <li><?= esc($error) ?></li>
                        <?php endforeach ?>
                    </ul>
                </div>
            <?php endif ?>

            <?php if (session('success')): ?>
                <div class="alert alert-success">
                    <?= session('success') ?>
                </div>
            <?php endif ?>

            <?php
            // Pastikan $population terdefinisi dan memiliki struktur yang benar
            $population = $population ?? [];
            $is_edit = isset($population['id']);
            ?>

            <form
                action="<?= $is_edit ? site_url('dashboard/population/update/' . $population['id']) : site_url('dashboard/population/store') ?>"
                method="post">
                <?= csrf_field() ?>

                <?php
                function field_value($field, $data) {
                    return old($field) ?? ($data[$field] ?? '');
                }
                ?>

                <div class="row g-3 mb-3">
                    <div class="col-md-2">
                        <label for="NO" class="form-label">No</label>
                        <input type="number" name="NO" id="NO" class="form-control" required
                            value="<?= field_value('NO', $population) ?>">
                    </div>
                    <div class="col-md-2">
                        <label for="RW" class="form-label">RW</label>
                        <input type="text" name="RW" id="RW" class="form-control" required
                            value="<?= field_value('RW', $population) ?>">
                    </div>
                    <div class="col-md-2">
                        <label for="RT" class="form-label">RT</label>
                        <input type="text" name="RT" id="RT" class="form-control" required
                            value="<?= field_value('RT', $population) ?>">
                    </div>
                    <div class="col-md-3">
                        <label for="NO_RUMAH" class="form-label">No Rumah</label>
                        <input type="text" name="NO_RUMAH" id="NO_RUMAH" class="form-control" required
                            value="<?= field_value('NO_RUMAH', $population) ?>">
                    </div>
                    <div class="col-md-3">
                        <label for="NO_KK" class="form-label">No KK</label>
                        <input type="text" name="NO_KK" id="NO_KK" class="form-control" required
                            value="<?= field_value('NO_KK', $population) ?>">
                    </div>
                </div>

                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label for="NIK" class="form-label">NIK</label>
                        <input type="text" name="NIK" id="NIK" class="form-control" maxlength="16" minlength="16"
                            required value="<?= field_value('NIK', $population) ?>">
                    </div>
                    <div class="col-md-6">
                        <label for="NAMA" class="form-label">Nama Lengkap</label>
                        <input type="text" name="NAMA" id="NAMA" class="form-control" required
                            value="<?= field_value('NAMA', $population) ?>">
                    </div>
                </div>

                <div class="row g-3 mb-3">
                    <div class="col-md-3">
                        <label for="JK" class="form-label">Jenis Kelamin</label>
                        <select name="JK" id="JK" class="form-select" required>
                            <option value="" disabled
                                <?= field_value('JK', $population) == '' ? 'selected' : '' ?>>-- Pilih --</option>
                            <option value="L" <?= field_value('JK', $population) == 'L' ? 'selected' : '' ?>>
                                Laki-laki</option>
                            <option value="P" <?= field_value('JK', $population) == 'P' ? 'selected' : '' ?>>
                                Perempuan</option>
                        </select>
                    </div>
                    <div class="col-md-5">
                        <label for="TMPT_LHR" class="form-label">Tempat Lahir</label>
                        <input type="text" name="TMPT_LHR" id="TMPT_LHR" class="form-control" required
                            value="<?= field_value('TMPT_LHR', $population) ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="TGL_LHR" class="form-label">Tanggal Lahir</label>
                        <input type="date" name="TGL_LHR" id="TGL_LHR" class="form-control" required
                            value="<?= field_value('TGL_LHR', $population) ?>">
                    </div>
                </div>

                <div class="row g-3 mb-3">
                    <div class="col-md-4">
                        <label for="AGAMA" class="form-label">Agama</label>
                        <select name="AGAMA" id="AGAMA" class="form-select" required>
                            <option value="" disabled
                                <?= field_value('AGAMA', $population) == '' ? 'selected' : '' ?>>-- Pilih Agama --
                            </option>
                            <?php
                            $agamaList = ['Islam', 'Kristen', 'Katolik', 'Hindu', 'Buddha', 'Konghucu'];
                            foreach ($agamaList as $agama) :
                                $selected = field_value('AGAMA', $population) == $agama ? 'selected' : '';
                                echo "<option value=\"$agama\" $selected>$agama</option>";
                            endforeach;
                            ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="STATUS" class="form-label">Status</label>
                        <input type="text" name="STATUS" id="STATUS" class="form-control" required
                            value="<?= field_value('STATUS', $population) ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="SHDK" class="form-label">SHDK</label>
                        <input type="text" name="SHDK" id="SHDK" class="form-control" required
                            value="<?= field_value('SHDK', $population) ?>">
                    </div>
                </div>

                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label for="PDDK_AKHIR" class="form-label">Pendidikan Akhir</label>
                        <input type="text" name="PDDK_AKHIR" id="PDDK_AKHIR" class="form-control" required
                            value="<?= field_value('PDDK_AKHIR', $population) ?>">
                    </div>
                    <div class="col-md-6">
                        <label for="PEKERJAAN" class="form-label">Pekerjaan</label>
                        <input type="text" name="PEKERJAAN" id="PEKERJAAN" class="form-control" required
                            value="<?= field_value('PEKERJAAN', $population) ?>">
                    </div>
                </div>

                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label for="NAMA_AYAH" class="form-label">Nama Ayah</label>
                        <input type="text" name="NAMA_AYAH" id="NAMA_AYAH" class="form-control" required
                            value="<?= field_value('NAMA_AYAH', $population) ?>">
                    </div>
                    <div class="col-md-6">
                        <label for="NAMA_IBU" class="form-label">Nama Ibu</label>
                        <input type="text" name="NAMA_IBU" id="NAMA_IBU" class="form-control" required
                            value="<?= field_value('NAMA_IBU', $population) ?>">
                    </div>
                </div>

                <div class="mb-3">
                    <label for="ALAMAT" class="form-label">Alamat Lengkap</label>
                    <textarea name="ALAMAT" id="ALAMAT" class="form-control" rows="2"
                        required><?= field_value('ALAMAT', $population) ?></textarea>
                </div>

                <div class="text-end">
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save me-1"></i> <?= $is_edit ? 'Update Data' : 'Simpan Data' ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?= $this->endSection() ?>