<?= $this->extend('layout/dashboard_layout') ?>
<?= $this->section('content') ?>

<section id="statistik" class="py-5">
    <div class="container text-center">
        

        <!-- Flash Message -->
        <?php if (session()->getFlashdata('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?= session()->getFlashdata('success') ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <?php if (session()->getFlashdata('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?= session()->getFlashdata('error') ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Statistik Ringkas -->
        <div class="row mb-4">
            <?php
            $cards = [
                ['label' => 'Total Penduduk', 'value' => $stats['total'] ?? 0],
                ['label' => 'Laki-laki', 'value' => $stats['laki_laki'] ?? 0],
                ['label' => 'Perempuan', 'value' => $stats['perempuan'] ?? 0],
            ];
            foreach ($cards as $card) : ?>
            <div class="col-md-4 mb-3">
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        <h5 class="card-title"><?= esc($card['label']) ?></h5>
                        <p class="card-text display-6 fw-bold"><?= esc($card['value']) ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="row">
            <!-- Daftar Penduduk -->
            <div class="col-lg-8 mb-4">
                <div class="card card-elev shadow-sm" data-aos="fade-up">
                    <div class="card-header py-3 d-flex justify-content-between align-items-center" style="background-color: #4B7BEC;">
                        <h6 class="m-0 text-white">Daftar Penduduk</h6>
                        <a href="<?= site_url('dashboard/population/create') ?>" class="btn btn-sm btn-light">
                            <i class="fas fa-plus fa-sm"></i> Tambah
                        </a>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped mt-3 align-middle" id="dataTable">
                                <thead class="table-light text-center">
                                    <tr>
                                        <th class="text-dark">No</th>
                                        <th class="text-dark">RW</th>
                                        <th class="text-dark">RT</th>
                                        <th class="text-dark">No Rumah</th>
                                        <th class="text-dark">No KK</th>
                                        <th class="text-dark">NIK</th>
                                        <th class="text-dark">Nama</th>
                                        <th class="text-dark">JK</th>
                                        <th class="text-dark">Tempat Lahir</th>
                                        <th class="text-dark">Tanggal Lahir</th>
                                        <th class="text-dark">Agama</th>
                                        <th class="text-dark">Status</th>
                                        <th class="text-dark">SHDK</th>
                                        <th class="text-dark">Pendidikan Akhir</th>
                                        <th class="text-dark">Pekerjaan</th>
                                        <th class="text-dark">Nama Ayah</th>
                                        <th class="text-dark">Nama Ibu</th>
                                        <th class="text-dark">Umur (Tahun)</th>
                                        <th class="text-dark">Umur (Bulan)</th>
                                        <th class="text-dark">Alamat</th>
                                        <th class="text-dark">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (!empty($populations) && is_array($populations)) : ?>
                                    <?php foreach ($populations as $key => $row) : ?>
                                    <tr data-aos="fade-right" data-aos-delay="<?= ($key + 1) * 100 ?>">
                                        <td class="text-dark"><?= esc($row['NO']) ?></td>
                                        <td class="text-dark"><?= esc($row['RW']) ?></td>
                                        <td class="text-dark"><?= esc($row['RT']) ?></td>
                                        <td class="text-dark"><?= esc($row['NO_RUMAH']) ?></td>
                                        <td class="text-dark"><?= esc($row['NO_KK']) ?></td>
                                        <td class="text-dark"><?= esc($row['NIK']) ?></td>
                                        <td class="text-dark fw-semibold"><?= esc($row['NAMA']) ?></td>
                                        <td class="text-dark"><?= esc($row['JK']) == 'L' ? 'Laki-laki' : 'Perempuan' ?></td>
                                        <td class="text-dark"><?= esc($row['TMPT_LHR']) ?></td>
                                        <td class="text-dark"><?= esc($row['TGL_LHR']) ?></td>
                                        <td class="text-dark"><?= esc($row['AGAMA']) ?></td>
                                        <td class="text-dark"><?= esc($row['STATUS']) ?></td>
                                        <td class="text-dark"><?= esc($row['SHDK']) ?></td>
                                        <td class="text-dark"><?= esc($row['PDDK_AKHIR']) ?></td>
                                        <td class="text-dark"><?= esc($row['PEKERJAAN']) ?></td>
                                        <td class="text-dark"><?= esc($row['NAMA_AYAH']) ?></td>
                                        <td class="text-dark"><?= esc($row['NAMA_IBU']) ?></td>
                                        <td class="text-dark"><?= esc($row['T']) ?></td>
                                        <td class="text-dark"><?= esc($row['B']) ?></td>
                                        <td class="text-dark"><?= esc($row['ALAMAT']) ?></td>
                                        <td class="text-center">
                                            <div class="btn-group" role="group">
                                                <a href="<?= site_url('dashboard/population/edit/' . $row['id']) ?>"
                                                    class="btn btn-sm btn-warning">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <form action="<?= site_url('dashboard/population/delete/' . $row['id']) ?>" method="post" onsubmit="return confirm('Yakin ingin menghapus data ini?');">
                                                    <?= csrf_field() ?>
                                                    <input type="hidden" name="_method" value="DELETE">
                                                    <button type="submit" class="btn btn-danger btn-sm">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php else : ?>
                                    <tr>
                                        <td colspan="21" class="text-center text-muted" data-aos="fade-in">
                                            Belum ada data penduduk.
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Grafik Gender -->
            <div class="col-lg-4 mb-4">
                <div class="card card-elev shadow-sm" data-aos="zoom-in">
                    <div class="card-header py-3" style="background-color: #4B7BEC;">
                        <h6 class="m-0 text-white">Grafik Gender</h6>
                    </div>
                    <div class="card-body">
                        <canvas id="genderChart" height="300"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?= $this->endSection() ?>

<!-- Page Scripts -->
<?= $this->section('page-scripts') ?>
<!-- CSS & AOS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css">

<!-- JS Libraries -->
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

<!-- Init Scripts -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // AOS Animation
    AOS.init({
        once: true,
        duration: 800,
        offset: 100,
        easing: 'ease-in-out-back'
    });

    // DataTables
    $('#dataTable').DataTable({
        language: {
            url: "https://cdn.datatables.net/plug-ins/1.11.5/i18n/id.json"
        },
        pageLength: 10,
        responsive: true,
        order: [[0, 'desc']]
    });

    // Gender Chart
    const ctx = document.getElementById('genderChart').getContext('2d');
    const lakiLaki = <?= json_encode($stats['laki_laki'] ?? 0) ?>;
    const perempuan = <?= json_encode($stats['perempuan'] ?? 0) ?>;
    const total = lakiLaki + perempuan;

    if (total > 0) {
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Laki-laki', 'Perempuan'],
                datasets: [{
                    data: [lakiLaki, perempuan],
                    backgroundColor: ['#4B7BEC', '#00C9A7'],
                    borderColor: ['#FFFFFF', '#FFFFFF'],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            font: {
                                family: 'Inter',
                                size: 14
                            },
                            color: '#000000' // Warna teks hitam untuk legenda
                        }
                    },
                    tooltip: {
                        backgroundColor: '#4B7BEC',
                        titleFont: {
                            family: 'Poppins',
                            size: 14,
                            weight: 'bold'
                        },
                        bodyFont: {
                            family: 'Inter',
                            size: 12
                        },
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff'
                    }
                },
                animation: {
                    animateScale: true,
                    animateRotate: true,
                    duration: 1500,
                    easing: 'easeInOutBack'
                }
            }
        });
    } else {
        // Jika tidak ada data, tampilkan pesan
        document.getElementById('genderChart').parentElement.innerHTML =
            '<p class="text-center text-muted">Tidak ada data untuk ditampilkan.</p>';
    }
});
</script>
<?= $this->endSection() ?>