<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Surat Keterangan Tidak Mampu</title>
    <style>
        body { 
            font-family: 'Times New Roman', Times, serif; 
            font-size: 12pt; 
            margin: 20px 40px;
            line-height: 1.4;
        }
        .container { width: 100%; margin: auto; }
        .kop-table { 
            width: 100%; 
            border-bottom: 2px solid black; 
            padding-bottom: 8px; 
            margin-bottom: 15px; 
        }
        .kop-table td { vertical-align: middle; }
        .kop-text { text-align: center; }
        .logo { width: 80px; text-align: center; }
        .kop-text h3, .kop-text h4, .kop-text p { margin: 0; }
        .kop-text h3 { font-size: 1em; }
        .kop-text h4 { font-size: 1.2em; }
        .kop-text p { font-size: 0.9em; }
        .judul-surat { text-align: center; margin: 15px 0; }
        .judul-surat h4 { text-decoration: underline; margin: 0; }
        .isi-surat { text-align: justify; }
        .isi-surat .indent { text-indent: 40px; }
        .data-pemohon { margin: 10px 0 10px 50px; width: auto; }
        .data-pemohon td { padding: 1px 5px; vertical-align: top; }
        .data-pemohon td:first-child { width: 160px; }
        .penutup { margin-top: 15px; }
        .tanda-tangan { 
            margin-top: 40px; 
            width: 260px; 
            float: right; 
            text-align: center; 
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- KOP SURAT -->
        <table class="kop-table">
            <tr>
                <td class="logo">
                    <img src="<?= esc($logo) ?>" alt="Logo Desa" width="70">
                </td>
                <td class="kop-text">
                    <h4>PEMERINTAH KABUPATEN PEKALONGAN</h4>
                    <h4>KECAMATAN PANINGGARAN</h4>
                    <h4>DESA KALIBOJA</h4>
                    <p>Alamat : Desa Kaliboja Kec. Paninggaran Kab. Pekalongan 51164</p>
                </td>
            </tr>
        </table>

        <!-- JUDUL -->
        <div class="judul-surat">
            <h4>SURAT KETERANGAN TIDAK MAMPU</h4>
            <p>Nomor: <?= esc($nomor_surat) ?></p>
        </div>

        <!-- ISI SURAT -->
        <div class="isi-surat">
            <p>Yang bertanda tangan di bawah ini :</p>
            <table class="data-pemohon">
                <tr><td>Nama</td><td>:</td><td><b><?= esc($kepala_desa ?? 'ABDULLAH') ?></b></td></tr>
                <tr><td>Jabatan</td><td>:</td><td>Kepala Desa Kaliboja</td></tr>
                <tr><td>Alamat</td><td>:</td><td>Desa Kaliboja, Kecamatan Paninggaran, Kabupaten Pekalongan</td></tr>
            </table>

            <p>Menerangkan dengan sebenarnya :</p>
            <table class="data-pemohon">
                <tr><td>Nama</td><td>:</td><td><b><?= esc($data_pemohon->nama_pemohon ?? '-') ?></b></td></tr>
                <tr><td>No. KK</td><td>:</td><td><?= esc($data_pemohon->no_kk ?? '-') ?></td></tr>
                <tr><td>NIK</td><td>:</td><td><?= esc($data_pemohon->nik_pemohon ?? '-') ?></td></tr>
                <tr><td>Tempat, Tgl Lahir</td><td>:</td><td><?= esc($data_pemohon->ttl ?? '-') ?></td></tr>
                <tr><td>Alamat</td><td>:</td><td><?= esc($data_pemohon->alamat ?? '-') ?></td></tr>
                <tr><td>Agama</td><td>:</td><td><?= esc($data_pemohon->agama ?? '-') ?></td></tr>
                <tr><td>Pekerjaan</td><td>:</td><td><?= esc($data_pemohon->pekerjaan ?? '-') ?></td></tr>
                <tr><td>Keperluan</td><td>:</td><td><?= esc($data_pemohon->keperluan ?? '-') ?></td></tr>
            </table>

            <p class="indent"><b>Keterangan :</b> Orang tersebut benar-benar warga kami dan benar keluarga tidak mampu.</p>
            <p class="indent"> Sehubungan dengan maksud yang bersangkutan, diminta agar instansi yang berkepentingan dapat memberikan bantuan dan pelayanan serta fasilitas seperlunya.</p>
            <p class="penutup indent"> Demikian Surat Keterangan ini dibuat dengan sebenarnya dan dapat dipergunakan seperlunya dengan maksud yang bersangkutan.</p>
        </div>

        <!-- TANDA TANGAN -->
        <div class="tanda-tangan">
            <p>Kaliboja, <?= esc($tanggal_surat) ?></p>
            <p>Kepala Desa Kaliboja</p>
            <br><br><br>
            <p><b><u><?= esc(strtoupper($kepala_desa)) ?></u></b></p>
        </div>
    </div>
</body>
</html>