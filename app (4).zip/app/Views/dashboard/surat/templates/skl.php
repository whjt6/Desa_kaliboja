<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Surat Keterangan Kelahiran</title>
    <style>
        body { 
            font-family: 'Times New Roman', Times, serif; 
            font-size: 12pt; 
            margin: 20px 40px;
            line-height: 1.4;
        }
        .container { width: 100%; margin: auto; }
        .kop-table { 
            width: 100%; 
            border-bottom: 2px solid black; 
            padding-bottom: 8px; 
            margin-bottom: 15px; 
        }
        .kop-table td { vertical-align: middle; }
        .kop-text { text-align: center; }
        .logo { width: 80px; text-align: center; }
        .kop-text h3, .kop-text h4, .kop-text p { margin: 0; }
        .kop-text h3 { font-size: 1em; }
        .kop-text h4 { font-size: 1.2em; }
        .kop-text p { font-size: 0.9em; }
        .judul-surat { text-align: center; margin: 15px 0; }
        .judul-surat h4 { text-decoration: underline; margin: 0; }
        .isi-surat { text-align: justify; }
        .isi-surat .indent { text-indent: 40px; }
        .data-pemohon { margin: 10px 0 10px 50px; width: auto; }
        .data-pemohon td { padding: 1px 5px; vertical-align: top; }
        .data-pemohon td:first-child { width: 160px; }
        .penutup { margin-top: 15px; }
        .tanda-tangan { 
            margin-top: 40px; 
            width: 260px; 
            float: right; 
            text-align: center; 
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- KOP SURAT -->
        <table class="kop-table">
            <tr>
                <td class="logo">
                    <img src="<?= esc($logo) ?>" alt="Logo Desa" width="70">
                </td>
                <td class="kop-text">
                    <h4>PEMERINTAH KABUPATEN PEKALONGAN</h4>
                    <h4>KECAMATAN PANINGGARAN</h4>
                    <h4>DESA KALIBOJA</h4>
                    <p>Alamat : Desa Kaliboja Kec. Paninggaran Kab. Pekalongan 51164</p>
                </td>
            </tr>
        </table>

        <!-- JUDUL -->
        <div class="judul-surat">
            <h4>SURAT KETERANGAN KELAHIRAN</h4>
            <p>Nomor: <?= esc($nomor_surat) ?></p>
        </div>

        <!-- ISI SURAT -->
        <div class="isi-surat">
            <p class="indent">
                Yang bertanda tangan di bawah ini, Kepala Desa Kaliboja, menerangkan bahwa telah lahir seorang anak:
            </p>
            <table class="data-pemohon">
                <tr><td>Nama Bayi</td><td>:</td><td><b><?= esc(strtoupper($data_pemohon->nama_bayi ?? '-')) ?></b></td></tr>
                <tr><td>Tanggal Lahir</td><td>:</td><td><?= \CodeIgniter\I18n\Time::parse($data_pemohon->tanggal_lahir ?? '')->toLocalizedString('d MMMM yyyy') ?></td></tr>
                <tr><td>Tempat Lahir</td><td>:</td><td><?= esc($data_pemohon->tempat_lahir ?? '-') ?></td></tr>
                <tr><td>Jenis Kelamin</td><td>:</td><td><?= esc($data_pemohon->jenis_kelamin_bayi ?? '-') ?></td></tr>
            </table>
            
            <p>Dari pasangan suami-istri:</p>
            <table class="data-pemohon">
                <tr><td>Nama Ayah</td><td>:</td><td><?= esc($data_pemohon->nama_ayah ?? '-') ?></td></tr>
                <tr><td>NIK Ayah</td><td>:</td><td><?= esc($data_pemohon->nik_ayah ?? '-') ?></td></tr>
                <tr><td>Nama Ibu</td><td>:</td><td><?= esc($data_pemohon->nama_ibu ?? '-') ?></td></tr>
                <tr><td>NIK Ibu</td><td>:</td><td><?= esc($data_pemohon->nik_ibu ?? '-') ?></td></tr>
            </table>

            <p class="penutup indent">
                Demikian Surat Keterangan ini dibuat untuk dapat dipergunakan sebagaimana mestinya.
            </p>
        </div>

        <!-- TANDA TANGAN -->
        <div class="tanda-tangan">
            <p>Kaliboja, <?= esc($tanggal_surat) ?></p>
            <p>Kepala Desa Kaliboja</p>
            <br><br><br>
            <p><b><u><?= esc(strtoupper($kepala_desa)) ?></u></b></p>
        </div>
    </div>
</body>
</html>