<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('page-styles') ?>
<link rel="stylesheet" href="<?= base_url('css/custom.css') ?>">
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="mb-4"></div>
<div class="card shadow-sm">
    <div class="card-body">
        <div class="row">
            <div class="col-md-5">
                <div class="mb-3">
                    <label for="jenis_surat_id" class="form-label">1. Pilih Jenis Surat</label>
                    <select id="jenis_surat_id" class="form-select">
                        <option selected disabled>-- Silakan Pilih --</option>
                        <?php foreach ($jenisSurat as $jenis): ?>
                            <option value="<?= $jenis['id'] ?>"><?= esc($jenis['nama_surat']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="alert alert-info small">
                    <i class="fas fa-info-circle me-1"></i> Pilih jenis surat di atas untuk menampilkan formulir isian yang sesuai.
                </div>
            </div>
            <div class="col-md-7">
                <form id="form-surat" method="POST" action="<?= site_url('dashboard/surat/generate') ?>">
                     <?= csrf_field() ?>
                     <input type="hidden" name="surat_jenis_id" id="surat_jenis_id_hidden">
                     
                     <label class="form-label">2. Isi Data Pemohon</label>
                     <div id="dynamic-form-fields" class="border p-3 rounded bg-light" style="min-height: 200px;">
                        <p class="text-muted text-center" style="margin-top: 70px;">
                            <i class="fas fa-file-alt fa-2x mb-2"></i><br>
                            Pilih jenis surat untuk menampilkan formulir.
                        </p>
                     </div>
                     <button type="submit" class="btn btn-primary mt-3" id="btn-submit-surat" disabled>
                        <i class="fas fa-print me-1"></i> Buat & Cetak Surat
                     </button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Card untuk menampilkan arsip surat -->
<div class="card shadow-sm mt-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="m-0 font-weight-bold text-white">
            Daftar Surat Terbaru 
            <span class="arsip-count"><?= count($arsip) ?></span>
        </h6>
        <a href="<?= site_url('dashboard/surat/arsip') ?>" class="btn btn-sm btn-outline-light">
            Lihat Semua <i class="fas fa-arrow-right ms-1"></i>
        </a>
    </div>
    <div class="card-body">
        <!-- Pencarian -->
        <div class="search-container mb-3">
            <i class="fas fa-search search-icon"></i>
            <input type="text" id="searchInput" class="search-input" placeholder="Cari surat...">
        </div>
        
        <div class="table-responsive">
            <table class="table table-hover" id="arsipTable">
                <thead>
                    <tr>
                        <th>No. Surat</th>
                        <th>Jenis Surat</th>
                        <th>Tanggal</th>
                        <th>Data Pemohon</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($arsip)) : ?>
                        <?php foreach ($arsip as $item) : ?>
                            <tr class="arsip-item">
                                <td><?= esc($item['nomor_surat']) ?></td>
                                <td><?= esc($item['jenis_surat_nama']) ?></td>
                                <td><?= \CodeIgniter\I18n\Time::parse($item['tanggal_surat'])->toLocalizedString('d MMMM yyyy') ?></td>
                                <td>
                                    <?php 
                                        $dataPemohon = json_decode($item['data_pemohon']);
                                        echo esc($dataPemohon->nama_pemohon ?? $dataPemohon->nama ?? $dataPemohon->nik ?? 'Data tidak lengkap');
                                    ?>
                                </td>
                                <td class="text-center">
                                    <a href="<?= site_url('dashboard/surat/arsip/download/' . $item['id']) ?>" class="btn btn-info btn-sm" title="Download PDF">
                                        <i class="fas fa-download"></i>
                                    </a>
                                    <form action="<?= site_url('dashboard/surat/arsip/delete/' . $item['id']) ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus arsip surat ini?');">
                                        <?= csrf_field() ?>
                                        <button type="submit" class="btn btn-danger btn-sm" title="Hapus Arsip">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="no-arsip">
                                <i class="fas fa-inbox"></i>
                                <p>Belum ada data surat yang diarsipkan.</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Pagination Info -->
        <div class="pagination-controls">
            <div class="pagination-info">
                Menampilkan <?= count($arsip) ?> dari <?= count($arsip) ?> surat
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('page-scripts') ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const selectJenisSurat = document.getElementById('jenis_surat_id');
    const dynamicFormFields = document.getElementById('dynamic-form-fields');
    const btnSubmit = document.getElementById('btn-submit-surat');
    const hiddenJenisId = document.getElementById('surat_jenis_id_hidden');
    const searchInput = document.getElementById('searchInput');
    const arsipTable = document.getElementById('arsipTable');
    const arsipItems = arsipTable.querySelectorAll('tbody tr');

    // Fungsi pencarian
    searchInput.addEventListener('input', function() {
        const searchText = this.value.toLowerCase();
        
        arsipItems.forEach(item => {
            const rowText = item.textContent.toLowerCase();
            if (rowText.includes(searchText)) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        });
        
        // Update info pagination
        updatePaginationInfo();
    });
    
    function updatePaginationInfo() {
        const visibleItems = Array.from(arsipItems).filter(item => item.style.display !== 'none');
        document.querySelector('.pagination-info').textContent = 
            `Menampilkan ${visibleItems.length} dari ${arsipItems.length} surat`;
    }

    selectJenisSurat.addEventListener('change', function () {
        const jenisId = this.value;
        if (!jenisId) return;

        dynamicFormFields.innerHTML = '<p class="text-muted text-center" style="margin-top: 70px;"><i class="fas fa-spinner fa-spin"></i><br>Memuat formulir...</p>';
        btnSubmit.disabled = true;
        hiddenJenisId.value = jenisId;

        fetch(`<?= site_url('dashboard/surat/get-form-fields/') ?>${jenisId}`, {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
        .then(response => response.ok ? response.json() : Promise.reject('Gagal mengambil data.'))
        .then(data => {
            if (data.status === 'success') {
                renderForm(data.fields);
                btnSubmit.disabled = false;
            } else {
                dynamicFormFields.innerHTML = `<p class="text-danger text-center" style="margin-top: 70px;"><i class="fas fa-exclamation-circle"></i><br>Gagal memuat formulir.</p>`;
            }
        })
        .catch(error => {
            dynamicFormFields.innerHTML = `<p class="text-danger text-center" style="margin-top: 70px;"><i class="fas fa-exclamation-circle"></i><br>Terjadi kesalahan. Coba lagi.</p>`;
        });
    });

    function renderForm(fields) {
        let html = '';
        if (fields.length === 0) {
            html = '<p class="text-muted text-center"><i class="fas fa-file-alt"></i><br>Tidak ada isian untuk surat ini.</p>';
        } else {
            fields.forEach(field => {
                html += '<div class="mb-3">';
                html += `<label for="${field.name}" class="form-label">${field.label}</label>`;
                
                const required = field.required ? 'required' : '';

                if (field.type === 'textarea') {
                    html += `<textarea name="data[${field.name}]" id="${field.name}" class="form-control" rows="3" ${required}></textarea>`;
                } else if (field.type === 'select' && field.options) {
                    html += `<select name="data[${field.name}]" id="${field.name}" class="form-select" ${required}>`;
                    html += `<option value="">-- Pilih ${field.label} --</option>`;
                    field.options.forEach(option => {
                        html += `<option value="${option}">${option}</option>`;
                    });
                    html += '</select>';
                } else {
                    html += `<input type="${field.type}" name="data[${field.name}]" id="${field.name}" class="form-control" ${required}>`;
                }
                html += '</div>';
            });
        }
        dynamicFormFields.innerHTML = html;
    }
});
</script>
<?= $this->endSection() ?>