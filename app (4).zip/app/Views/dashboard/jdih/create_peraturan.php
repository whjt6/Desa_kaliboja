<?= $this->extend('layout/dashboard_layout'); ?>

<?= $this->section('content'); ?>
<div class="page-inner">
    <div class="page-header">
        <h4 class="page-title">Tambah Peraturan</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="#">
                    <i class="flaticon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="#">JDIH</a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="#">Peraturan</a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="#">Tambah</a>
            </li>
        </ul>
    </div>
    
    <!-- Notifikasi Error -->
    <?php if (session()->getFlashdata('errors')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <ul class="mb-0">
                <?php foreach (session()->getFlashdata('errors') as $error): ?>
                    <li><?= $error ?></li>
                <?php endforeach; ?>
            </ul>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= session()->getFlashdata('error') ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-title">Form Tambah Peraturan</div>
                </div>
                <div class="card-body">
                    <form action="<?= site_url('dashboard/jdih/peraturan/store') ?>" method="POST" enctype="multipart/form-data">
                        <?= csrf_field() ?>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="kategori_id">Kategori *</label>
                                    <select class="form-control <?= session('errors.kategori_id') ? 'is-invalid' : '' ?>" 
                                        id="kategori_id" name="kategori_id" required>
                                        <option value="">Pilih Kategori</option>
                                        <?php foreach ($kategories as $kategori): ?>
                                            <option value="<?= $kategori['id'] ?>" <?= old('kategori_id') == $kategori['id'] ? 'selected' : '' ?>>
                                                <?= esc($kategori['nama_kategori']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <?php if (session('errors.kategori_id')): ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.kategori_id') ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="jenis_peraturan">Jenis Peraturan *</label>
                                    <select class="form-control <?= session('errors.jenis_peraturan') ? 'is-invalid' : '' ?>" 
                                        id="jenis_peraturan" name="jenis_peraturan" required>
                                        <option value="">Pilih Jenis</option>
                                        <option value="Peraturan Desa" <?= old('jenis_peraturan') == 'Peraturan Desa' ? 'selected' : '' ?>>Peraturan Desa</option>
                                        <option value="Peraturan Bupati" <?= old('jenis_peraturan') == 'Peraturan Bupati' ? 'selected' : '' ?>>Peraturan Bupati</option>
                                        <option value="Peraturan Daerah" <?= old('jenis_peraturan') == 'Peraturan Daerah' ? 'selected' : '' ?>>Peraturan Daerah</option>
                                        <option value="Lainnya" <?= old('jenis_peraturan') == 'Lainnya' ? 'selected' : '' ?>>Lainnya</option>
                                    </select>
                                    <?php if (session('errors.jenis_peraturan')): ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.jenis_peraturan') ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="nomor">Nomor Peraturan *</label>
                                    <input type="text" class="form-control <?= session('errors.nomor') ? 'is-invalid' : '' ?>" 
                                        id="nomor" name="nomor" value="<?= old('nomor') ?>" required>
                                    <?php if (session('errors.nomor')): ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.nomor') ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="tahun">Tahun *</label>
                                    <input type="number" class="form-control <?= session('errors.tahun') ? 'is-invalid' : '' ?>" 
                                        id="tahun" name="tahun" value="<?= old('tahun') ?: date('Y') ?>" 
                                        min="2000" max="2030" required>
                                    <?php if (session('errors.tahun')): ?>
                                        <div class="invalid-feedback">
                                            <?= session('errors.tahun') ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="status">Status *</label>
                                    <select class="form-control" id="status" name="status" required>
                                        <option value="berlaku" <?= old('status') == 'berlaku' ? 'selected' : '' ?>>Berlaku</option>
                                        <option value="tidak berlaku" <?= old('status') == 'tidak berlaku' ? 'selected' : '' ?>>Tidak Berlaku</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="tentang">Tentang *</label>
                            <textarea class="form-control <?= session('errors.tentang') ? 'is-invalid' : '' ?>" 
                                id="tentang" name="tentang" rows="3" required><?= old('tentang') ?></textarea>
                            <?php if (session('errors.tentang')): ?>
                                <div class="invalid-feedback">
                                    <?= session('errors.tentang') ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="tanggal_ditetapkan">Tanggal Ditetapkan</label>
                                    <input type="date" class="form-control" id="tanggal_ditetapkan" 
                                        name="tanggal_ditetapkan" value="<?= old('tanggal_ditetapkan') ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="tanggal_diundangkan">Tanggal Diundangkan</label>
                                    <input type="date" class="form-control" id="tanggal_diundangkan" 
                                        name="tanggal_diundangkan" value="<?= old('tanggal_diundangkan') ?>">
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="abstrak">Abstrak</label>
                            <textarea class="form-control" id="abstrak" name="abstrak" rows="5"><?= old('abstrak') ?></textarea>
                        </div>

                        <div class="form-group">
                            <label for="file_dokumen">File Dokumen (PDF) *</label>
                            <input type="file" class="form-control-file <?= session('errors.file_dokumen') ? 'is-invalid' : '' ?>" 
                                id="file_dokumen" name="file_dokumen" accept=".pdf" required>
                            <?php if (session('errors.file_dokumen')): ?>
                                <div class="invalid-feedback">
                                    <?= session('errors.file_dokumen') ?>
                                </div>
                            <?php endif; ?>
                            <small class="form-text text-muted">Format file: PDF, maksimal 10MB</small>
                        </div>

                        <div class="form-group text-right">
                            <a href="<?= site_url('dashboard/jdih/peraturan') ?>" class="btn btn-secondary">Batal</a>
                            <button type="submit" class="btn btn-primary">Simpan Peraturan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Set tanggal default ke hari ini
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('tanggal_ditetapkan').value = today;
    document.getElementById('tanggal_diundangkan').value = today;
});
</script>
<?= $this->endSection(); ?>