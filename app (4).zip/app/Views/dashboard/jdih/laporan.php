<?= $this->extend('layout/dashboard_layout'); ?>
<?= $this->section('content'); ?>
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Laporan JDIH</h1>
    
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Filter Laporan</h6>
        </div>
        <div class="card-body">
            <?= form_open('dashboard/jdih/laporan', ['method' => 'get']) ?>
            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label>Tahun</label>
                        <select name="tahun" class="form-control">
                            <option value="">Semua Tahun</option>
                            <?php for($i = date('Y'); $i >= 2000; $i--): ?>
                            <option value="<?= $i ?>" <?= ($i == $tahun_filter) ? 'selected' : '' ?>>
                                <?= $i ?>
                            </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label>Kategori</label>
                        <select name="kategori_id" class="form-control">
                            <option value="">Semua Kategori</option>
                            <?php foreach ($kategori as $kat): ?>
                            <option value="<?= $kat['id'] ?>" <?= ($kat['id'] == $kategori_filter) ? 'selected' : '' ?>>
                                <?= $kat['nama_kategori'] ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status" class="form-control">
                            <option value="">Semua Status</option>
                            <option value="aktif" <?= ('aktif' == $status_filter) ? 'selected' : '' ?>>Aktif</option>
                            <option value="tidak aktif" <?= ('tidak aktif' == $status_filter) ? 'selected' : '' ?>>Tidak Aktif</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label>&nbsp;</label>
                        <button type="submit" class="btn btn-primary btn-block">
                            <i class="fas fa-filter"></i> Filter
                        </button>
                    </div>
                </div>
            </div>
            <?= form_close() ?>
        </div>
    </div>
    
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">Data Peraturan</h6>
            <a href="#" class="btn btn-success">
                <i class="fas fa-file-excel"></i> Export Excel
            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Judul Peraturan</th>
                            <th>Nomor</th>
                            <th>Tahun</th>
                            <th>Kategori</th>
                            <th>Status</th>
                            <th>Tanggal Upload</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; ?>
                        <?php foreach ($peraturan as $per): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $per['judul'] ?></td>
                            <td><?= $per['nomor'] ?></td>
                            <td><?= $per['tahun'] ?></td>
                            <td><?= $per['nama_kategori'] ?></td>
                            <td>
                                <span class="badge badge-<?= $per['status'] == 'aktif' ? 'success' : 'secondary' ?>">
                                    <?= ucfirst($per['status']) ?>
                                </span>
                            </td>
                            <td><?= date('d/m/Y', strtotime($per['created_at'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>