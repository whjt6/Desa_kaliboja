<?= $this->extend('layout/dashboard_layout'); ?>


<?= $this->section('content'); ?>
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Manajemen Peraturan</h1>
    
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Peraturan</h6>
            <a href="<?= base_url('dashboard/jdih/peraturan/create') ?>" class="btn btn-primary">
                <i class="fas fa-plus"></i> Tambah Peraturan
            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Judul Peraturan</th>
                            <th>Nomor</th>
                            <th>Tahun</th>
                            <th>Kategori</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; ?>
                        <?php foreach ($peraturan as $per): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $per['judul'] ?></td>
                            <td><?= $per['nomor'] ?></td>
                            <td><?= $per['tahun'] ?></td>
                            <td><?= $per['nama_kategori'] ?></td>
                            <td>
                                <span class="badge badge-<?= $per['status'] == 'aktif' ? 'success' : 'secondary' ?>">
                                    <?= ucfirst($per['status']) ?>
                                </span>
                            </td>
                            <td>
                                <a href="<?= base_url('dashboard/jdih/peraturan/detail/' . $per['id']) ?>" 
                                   class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="<?= base_url('dashboard/jdih/peraturan/edit/' . $per['id']) ?>" 
                                   class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <button type="button" class="btn btn-sm btn-danger" 
                                        onclick="hapusPeraturan(<?= $per['id'] ?>)">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
function hapusPeraturan(id) {
    if (confirm('Apakah Anda yakin ingin menghapus peraturan ini?')) {
        window.location.href = '<?= base_url('dashboard/jdih/peraturan/delete/') ?>' + id;
    }
}
</script>

<?= $this->endSection(); ?>