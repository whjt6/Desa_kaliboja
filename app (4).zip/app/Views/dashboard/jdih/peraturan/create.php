<?= $this->extend('layout/dashboard_layout'); ?>
<?= $this->section('content'); ?>
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Tambah Peraturan Baru</h1>
    
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Form Tambah Peraturan</h6>
        </div>
        <div class="card-body">
            <?= form_open_multipart('dashboard/jdih/peraturan/store') ?>
            
            <div class="form-group">
                <label>Judul Peraturan *</label>
                <input type="text" name="judul" class="form-control" required>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Nomor Peraturan *</label>
                        <input type="text" name="nomor" class="form-control" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Tahun *</label>
                        <input type="number" name="tahun" class="form-control" value="<?= date('Y') ?>" required>
                    </div>
                </div>
            </div>
            
            <div class="form-group">
                <label>Kategori *</label>
                <select name="kategori_id" class="form-control" required>
                    <option value="">Pilih Kategori</option>
                    <?php foreach ($kategori as $kat): ?>
                    <option value="<?= $kat['id'] ?>"><?= $kat['nama_kategori'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>Deskripsi</label>
                <textarea name="deskripsi" class="form-control" rows="3"></textarea>
            </div>
            
            <div class="form-group">
                <label>File Dokumen (PDF/DOC) *</label>
                <input type="file" name="file_dokumen" class="form-control-file" required>
                <small class="text-muted">Format: PDF, DOC, DOCX | Maks: 10MB</small>
            </div>
            
            <div class="form-group">
                <label>Status</label>
                <select name="status" class="form-control">
                    <option value="aktif">Aktif</option>
                    <option value="tidak aktif">Tidak Aktif</option>
                </select>
            </div>
            
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save"></i> Simpan Peraturan
            </button>
            <a href="<?= base_url('dashboard/jdih/peraturan') ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Kembali
            </a>
            
            <?= form_close() ?>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>