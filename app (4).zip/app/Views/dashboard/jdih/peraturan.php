<?= $this->extend('layout/dashboard_layout'); ?>

<?= $this->section('content'); ?>
<div class="page-inner">
    <div class="page-header">
        <h4 class="page-title">Manajemen Peraturan</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="#">
                    <i class="flaticon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="#">JDIH</a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="#">Peraturan</a>
            </li>
        </ul>
    </div>

    <!-- Notifikasi -->
    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= session()->getFlashdata('success') ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= session()->getFlashdata('error') ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h4 class="card-title">Data Peraturan</h4>
                        <a href="<?= site_url('dashboard/jdih/peraturan/create') ?>" class="btn btn-primary btn-sm">
                            <i class="fas fa-plus me-2"></i>Tambah Peraturan
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="peraturanTable">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Jenis & Nomor</th>
                                    <th>Tentang</th>
                                    <th>Kategori</th>
                                    <th>Tahun</th>
                                    <th>Status</th>
                                    <th>File</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($peraturans)): ?>
                                    <?php foreach ($peraturans as $index => $peraturan): ?>
                                        <tr>
                                            <td><?= $index + 1 ?></td>
                                            <td>
                                                <strong><?= esc($peraturan['jenis_peraturan']) ?></strong><br>
                                                <small class="text-muted">No. <?= esc($peraturan['nomor']) ?></small>
                                            </td>
                                            <td><?= character_limiter(esc($peraturan['tentang']), 80) ?></td>
                                            <td>
                                                <span class="badge badge-info"><?= esc($peraturan['nama_kategori']) ?></span>
                                            </td>
                                            <td><?= $peraturan['tahun'] ?></td>
                                            <td>
                                                <span class="badge badge-<?= $peraturan['status'] == 'berlaku' ? 'success' : 'danger' ?>">
                                                    <?= ucfirst($peraturan['status']) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($peraturan['file_dokumen']): ?>
                                                    <span class="badge badge-success">Tersedia</span>
                                                <?php else: ?>
                                                    <span class="badge badge-warning">Tidak Ada</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="btn-group">
                                                    <a href="<?= site_url('dashboard/jdih/peraturan/edit/' . $peraturan['id']) ?>" 
                                                        class="btn btn-sm btn-warning">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <a href="<?= site_url('jdih/detail/' . $peraturan['id']) ?>" 
                                                        target="_blank" class="btn btn-sm btn-info">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <?php if ($peraturan['file_dokumen']): ?>
                                                        <a href="<?= site_url('jdih/download/' . $peraturan['id']) ?>" 
                                                            class="btn btn-sm btn-success">
                                                            <i class="fas fa-download"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    <form action="<?= site_url('dashboard/jdih/peraturan/delete/' . $peraturan['id']) ?>" 
                                                        method="POST" class="d-inline">
                                                        <?= csrf_field() ?>
                                                        <button type="submit" class="btn btn-sm btn-danger" 
                                                            onclick="return confirm('Apakah Anda yakin ingin menghapus peraturan ini?')">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-center text-muted py-4">
                                            <i class="fas fa-gavel fa-3x mb-3"></i>
                                            <p>Belum ada data peraturan</p>
                                            <a href="<?= site_url('dashboard/jdih/peraturan/create') ?>" class="btn btn-primary">
                                                Tambah Data Pertama
                                            </a>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Simple search functionality
    const searchInput = document.createElement('input');
    searchInput.type = 'text';
    searchInput.placeholder = 'Cari peraturan...';
    searchInput.className = 'form-control mb-3';
    searchInput.style.maxWidth = '300px';
    
    const cardHeader = document.querySelector('.card-header .d-flex');
    cardHeader.appendChild(searchInput);

    searchInput.addEventListener('keyup', function() {
        const filter = this.value.toLowerCase();
        const rows = document.querySelectorAll('#peraturanTable tbody tr');
        
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(filter) ? '' : 'none';
        });
    });
});
</script>
<?= $this->endSection(); ?>