<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Dashboard Koperasi</h1>
    <div>
        <a href="<?= site_url('koperasi') ?>" target="_blank" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
            <i class="fas fa-external-link-alt fa-sm text-white-50"></i> Lihat Website
        </a>
    </div>
</div>

<!-- Content Row -->
<div class="row">
    <!-- Total Anggota -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-danger shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                            Total Anggota</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= number_format($total_anggota ?? 0) ?></div>
                        <div class="mt-2">
                            <small class="text-success"><i class="fas fa-user-check"></i> Aktif: <?= number_format(($statistik_anggota['aktif'] ?? 0) + ($statistik_anggota['total_aktif'] ?? 0)) ?></small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-users fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Total Simpanan -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Total Simpanan</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">Rp <?= number_format($total_simpanan ?? 0, 0, ',', '.') ?></div>
                        <div class="mt-2">
                            <small class="text-info"><i class="fas fa-landmark"></i> Pokok: Rp <?= number_format($statistik_simpanan['pokok'] ?? 0, 0, ',', '.') ?></small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-money-bill-wave fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Total Unit Usaha -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Unit Usaha</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= number_format($total_unit ?? 0) ?></div>
                        <div class="mt-2">
                            <small class="text-success"><i class="fas fa-check-circle"></i> Tersedia: <?= number_format($total_unit_tersedia ?? 0) ?></small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-boxes fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Pendaftaran Pending -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Pendaftaran Pending</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= number_format($pendaftaran_pending ?? 0) ?></div>
                        <div class="mt-2">
                            <small class="text-danger"><i class="fas fa-clock"></i> Butuh Tindakan</small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-user-clock fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Content Row -->
<div class="row">
    <!-- Grafik Pendaftaran Anggota -->
    <div class="col-xl-8 col-lg-7">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Grafik Pendaftaran Anggota (12 Bulan Terakhir)</h6>
                <div class="dropdown no-arrow">
                    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" 
                       data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" 
                         aria-labelledby="dropdownMenuLink">
                        <div class="dropdown-header">Opsi Grafik:</div>
                        <a class="dropdown-item" href="#" onclick="updateChart('line')">Garis</a>
                        <a class="dropdown-item" href="#" onclick="updateChart('bar')">Batang</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="chart-area">
                    <canvas id="anggotaChart"></canvas>
                </div>
                <div class="mt-3 text-center small">
                    <span class="mr-3">
                        <i class="fas fa-circle text-primary"></i> Pendaftaran
                    </span>
                </div>
            </div>
        </div>
    </div>

    <!-- Pendaftaran Baru -->
    <div class="col-xl-4 col-lg-5">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-primary">Pendaftaran Terbaru</h6>
                <a href="<?= site_url('dashboard/koperasi/pendaftaran') ?>" class="btn btn-sm btn-outline-primary">
                    <i class="fas fa-list"></i>
                </a>
            </div>
            <div class="card-body p-0">
                <?php if(!empty($pendaftaran_baru)): ?>
                <div class="list-group list-group-flush">
                    <?php foreach($pendaftaran_baru as $pendaftar): ?>
                    <a href="<?= site_url('dashboard/koperasi/pendaftaran/detail/' . $pendaftar['id']) ?>" 
                       class="list-group-item list-group-item-action py-3">
                        <div class="d-flex w-100 justify-content-between align-items-start">
                            <div class="flex-grow-1">
                                <h6 class="mb-1"><?= esc($pendaftar['nama']) ?></h6>
                                <small class="text-muted d-block">
                                    <i class="fas fa-id-card me-1"></i><?= esc($pendaftar['kode_pendaftaran']) ?>
                                </small>
                                <small class="text-muted">
                                    <i class="fas fa-calendar me-1"></i><?= date('d/m/Y', strtotime($pendaftar['created_at'])) ?>
                                </small>
                            </div>
                            <?php if($pendaftar['status'] == 'pending'): ?>
                            <span class="badge bg-warning text-white">Pending</span>
                            <?php elseif($pendaftar['status'] == 'approved'): ?>
                            <span class="badge bg-success">Disetujui</span>
                            <?php else: ?>
                            <span class="badge bg-danger">Ditolak</span>
                            <?php endif; ?>
                        </div>
                        <div class="mt-2 small">
                            <span class="text-danger">
                                <i class="fas fa-money-bill-wave"></i> 
                                Rp <?= number_format($pendaftar['simpanan_pokok'] + $pendaftar['simpanan_wajib'], 0, ',', '.') ?>
                            </span>
                        </div>
                    </a>
                    <?php endforeach; ?>
                </div>
                <?php else: ?>
                <div class="text-center py-4">
                    <i class="fas fa-user-clock fa-3x text-muted mb-3"></i>
                    <p class="text-muted mb-0">Belum ada pendaftaran</p>
                    <a href="<?= site_url('koperasi/form-pendaftaran') ?>" target="_blank" class="btn btn-sm btn-outline-primary mt-2">
                        <i class="fas fa-external-link-alt"></i> Form Pendaftaran
                    </a>
                </div>
                <?php endif; ?>
            </div>
            <div class="card-footer bg-transparent">
                <a href="<?= site_url('dashboard/koperasi/pendaftaran') ?>" class="btn btn-sm btn-primary btn-block">
                    <i class="fas fa-list me-1"></i> Lihat Semua Pendaftaran
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Content Row -->
<div class="row">
    <!-- Grafik Simpanan -->
    <div class="col-xl-6 col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Grafik Simpanan (6 Bulan Terakhir)</h6>
            </div>
            <div class="card-body">
                <div class="chart-area">
                    <canvas id="simpananChart"></canvas>
                </div>
                <div class="mt-3 text-center small">
                    <span class="mr-3">
                        <i class="fas fa-circle text-primary"></i> Simpanan Pokok
                    </span>
                    <span class="mr-3">
                        <i class="fas fa-circle text-success"></i> Simpanan Wajib
                    </span>
                    <span class="mr-3">
                        <i class="fas fa-circle text-info"></i> Simpanan Sukarela
                    </span>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistik Anggota -->
    <div class="col-xl-6 col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Distribusi Status Anggota</h6>
            </div>
            <div class="card-body">
                <div class="chart-pie pt-4">
                    <canvas id="statusAnggotaChart"></canvas>
                </div>
                <div class="mt-4 text-center small">
                    <span class="mr-3">
                        <i class="fas fa-circle text-success"></i> Aktif
                    </span>
                    <span class="mr-3">
                        <i class="fas fa-circle text-warning"></i> Nonaktif
                    </span>
                    <span class="mr-3">
                        <i class="fas fa-circle text-danger"></i> Keluar
                    </span>
                </div>
                <div class="row mt-4 text-center">
                    <div class="col-4">
                        <div class="h5 font-weight-bold text-success">
                            <?= number_format($statistik_anggota['aktif'] ?? 0) ?>
                        </div>
                        <small class="text-muted">Aktif</small>
                    </div>
                    <div class="col-4">
                        <div class="h5 font-weight-bold text-warning">
                            <?= number_format($statistik_anggota['nonaktif'] ?? 0) ?>
                        </div>
                        <small class="text-muted">Nonaktif</small>
                    </div>
                    <div class="col-4">
                        <div class="h5 font-weight-bold text-danger">
                            <?= number_format($statistik_anggota['keluar'] ?? 0) ?>
                        </div>
                        <small class="text-muted">Keluar</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="row">
    <div class="col-12">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Aksi Cepat</h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <!-- Tambahkan di bagian Quick Actions -->
<div class="col-xl-2 col-md-3 col-6 mb-3">
    <a href="<?= site_url('dashboard/koperasi/berita') ?>" class="btn btn-primary btn-block h-100 py-3">
        <i class="fas fa-newspaper fa-2x mb-2"></i><br>
        <span>Kelola Berita</span>
    </a>
</div>
                    <div class="col-xl-2 col-md-3 col-6 mb-3">
                        <a href="<?= site_url('dashboard/koperasi/anggota/create') ?>" class="btn btn-danger btn-block h-100 py-3">
                            <i class="fas fa-user-plus fa-2x mb-2"></i><br>
                            <span>Tambah Anggota</span>
                        </a>
                    </div>
                    
                    <div class="col-xl-2 col-md-3 col-6 mb-3">
                        <a href="<?= site_url('dashboard/koperasi/simpanan/create') ?>" class="btn btn-success btn-block h-100 py-3">
                            <i class="fas fa-money-check-alt fa-2x mb-2"></i><br>
                            <span>Catat Simpanan</span>
                        </a>
                    </div>
                    <div class="col-xl-2 col-md-3 col-6 mb-3">
                        <a href="<?= site_url('dashboard/koperasi/statistik') ?>" class="btn btn-warning btn-block h-100 py-3">
                            <i class="fas fa-chart-bar fa-2x mb-2"></i><br>
                            <span>Lihat Statistik</span>
                        </a>
                    </div>
                    <div class="col-xl-2 col-md-3 col-6 mb-3">
                        <a href="<?= site_url('dashboard/koperasi/pendaftaran') ?>" class="btn btn-primary btn-block h-100 py-3">
                            <i class="fas fa-user-check fa-2x mb-2"></i><br>
                            <span>Kelola Pendaftaran</span>
                        </a>
                    </div>
                    <div class="col-xl-2 col-md-3 col-6 mb-3">
                        <a href="<?= site_url('dashboard/koperasi/laporan') ?>" class="btn btn-secondary btn-block h-100 py-3">
                            <i class="fas fa-file-alt fa-2x mb-2"></i><br>
                            <span>Laporan</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Recent Activities -->
<div class="row">
    <div class="col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Unit Usaha Populer</h6>
            </div>
            <div class="card-body">
                <?php if(!empty($unit_populer)): ?>
                <div class="list-group">
                    <?php foreach(array_slice($unit_populer, 0, 5) as $unit): ?>
                    <a href="<?= site_url('dashboard/koperasi/unit-usaha/show/' . $unit['id']) ?>" 
                       class="list-group-item list-group-item-action">
                        <div class="d-flex w-100 justify-content-between">
                            <div>
                                <h6 class="mb-1"><?= esc($unit['nama_unit']) ?></h6>
                                <small class="text-muted"><?= esc($unit['kategori']) ?></small>
                            </div>
                            <div class="text-end">
                                <span class="badge bg-<?= $unit['status'] == 'tersedia' ? 'success' : ($unit['status'] == 'habis' ? 'warning' : 'info') ?>">
                                    <?= $unit['status'] ?>
                                </span>
                                <div class="mt-1">
                                    <strong class="text-danger">Rp <?= number_format($unit['harga'], 0, ',', '.') ?></strong>
                                </div>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; ?>
                </div>
                <a href="<?= site_url('dashboard/koperasi/unit-usaha') ?>" class="btn btn-sm btn-outline-primary btn-block mt-3">
                    <i class="fas fa-boxes me-1"></i> Lihat Semua Unit
                </a>
                <?php else: ?>
                <div class="text-center py-4">
                    <i class="fas fa-box-open fa-3x text-muted mb-3"></i>
                    <p class="text-muted mb-0">Belum ada unit usaha</p>
                    <a href="<?= site_url('dashboard/koperasi/unit-usaha/create') ?>" class="btn btn-sm btn-primary mt-2">
                        <i class="fas fa-plus me-1"></i> Tambah Unit
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Berita Terbaru</h6>
            </div>
            <div class="card-body">
                <?php if(!empty($berita_terbaru)): ?>
                <div class="list-group">
                    <?php foreach(array_slice($berita_terbaru, 0, 5) as $berita): ?>
                    <a href="<?= site_url('dashboard/koperasi/berita/show/' . $berita['id']) ?>" 
                       class="list-group-item list-group-item-action">
                        <div class="d-flex w-100 justify-content-between">
                            <div class="flex-grow-1">
                                <h6 class="mb-1"><?= character_limiter(esc($berita['judul']), 50) ?></h6>
                                <small class="text-muted">
                                    <i class="far fa-calendar me-1"></i>
                                    <?= date('d M Y', strtotime($berita['created_at'])) ?>
                                </small>
                            </div>
                            <span class="badge bg-<?= $berita['status'] == 'published' ? 'success' : 'secondary' ?> ms-2">
                                <?= $berita['status'] == 'published' ? 'Published' : 'Draft' ?>
                            </span>
                        </div>
                    </a>
                    <?php endforeach; ?>
                </div>
                <a href="<?= site_url('dashboard/koperasi/berita') ?>" class="btn btn-sm btn-outline-primary btn-block mt-3">
                    <i class="fas fa-newspaper me-1"></i> Lihat Semua Berita
                </a>
                <?php else: ?>
                <div class="text-center py-4">
                    <i class="fas fa-newspaper fa-3x text-muted mb-3"></i>
                    <p class="text-muted mb-0">Belum ada berita</p>
                    <a href="<?= site_url('dashboard/koperasi/berita/create') ?>" class="btn btn-sm btn-primary mt-2">
                        <i class="fas fa-plus me-1"></i> Tambah Berita
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?= $this->section('page-scripts') ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Grafik Pendaftaran Anggota
var anggotaChart = null;
function initAnggotaChart() {
    var ctx = document.getElementById('anggotaChart').getContext('2d');
    var chartData = <?= json_encode($grafik_anggota ?? []) ?>;
    
    // Jika tidak ada data, buat data dummy
    if (!chartData || chartData.length === 0) {
        chartData = [];
        var today = new Date();
        for (var i = 11; i >= 0; i--) {
            var date = new Date(today.getFullYear(), today.getMonth() - i, 1);
            chartData.push({
                bulan: date.toLocaleDateString('id-ID', { month: 'short', year: 'numeric' }),
                total: Math.floor(Math.random() * 10) + 1
            });
        }
    }
    
    var labels = chartData.map(item => item.bulan);
    var data = chartData.map(item => item.total);
    
    anggotaChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Jumlah Pendaftar',
                data: data,
                backgroundColor: 'rgba(78, 115, 223, 0.1)',
                borderColor: 'rgba(78, 115, 223, 1)',
                borderWidth: 2,
                pointBackgroundColor: 'rgba(78, 115, 223, 1)',
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: 'rgba(78, 115, 223, 1)',
                pointRadius: 4,
                pointHoverRadius: 6,
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0,
                        callback: function(value) {
                            if (Number.isInteger(value)) {
                                return value;
                            }
                        }
                    },
                    grid: {
                        drawBorder: false
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.7)',
                    titleColor: '#fff',
                    bodyColor: '#fff',
                    borderColor: 'rgba(78, 115, 223, 1)',
                    borderWidth: 1
                }
            }
        }
    });
}

// Grafik Simpanan
var simpananChart = null;
function initSimpananChart() {
    var ctx = document.getElementById('simpananChart').getContext('2d');
    var chartData = <?= json_encode($grafik_simpanan ?? []) ?>;
    
    // Jika tidak ada data, buat data dummy
    if (!chartData || chartData.length === 0) {
        chartData = [];
        var today = new Date();
        for (var i = 5; i >= 0; i--) {
            var date = new Date(today.getFullYear(), today.getMonth() - i, 1);
            chartData.push({
                bulan: date.toLocaleDateString('id-ID', { month: 'short' }),
                total: Math.floor(Math.random() * 5000000) + 1000000
            });
        }
    }
    
    var labels = chartData.map(item => item.bulan);
    var data = chartData.map(item => item.total);
    
    simpananChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Total Simpanan',
                data: data,
                backgroundColor: 'rgba(40, 167, 69, 0.7)',
                borderColor: 'rgba(40, 167, 69, 1)',
                borderWidth: 1,
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return 'Rp ' + value.toLocaleString('id-ID');
                        }
                    },
                    grid: {
                        drawBorder: false
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Total: Rp ' + context.parsed.y.toLocaleString('id-ID');
                        }
                    }
                }
            }
        }
    });
}

// Pie Chart Status Anggota
function initStatusAnggotaChart() {
    var ctx = document.getElementById('statusAnggotaChart').getContext('2d');
    
    var dataAktif = <?= $statistik_anggota['aktif'] ?? 0 ?>;
    var dataNonaktif = <?= $statistik_anggota['nonaktif'] ?? 0 ?>;
    var dataKeluar = <?= $statistik_anggota['keluar'] ?? 0 ?>;
    
    // Jika semua data 0, beri nilai default
    if (dataAktif === 0 && dataNonaktif === 0 && dataKeluar === 0) {
        dataAktif = 1;
    }
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Aktif', 'Nonaktif', 'Keluar'],
            datasets: [{
                data: [dataAktif, dataNonaktif, dataKeluar],
                backgroundColor: ['#1cc88a', '#f6c23e', '#e74a3b'],
                hoverBackgroundColor: ['#17a673', '#dda20a', '#be2617'],
                borderWidth: 2,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            var label = context.label || '';
                            var value = context.parsed || 0;
                            var total = context.dataset.data.reduce((a, b) => a + b, 0);
                            var percentage = Math.round((value / total) * 100);
                            return label + ': ' + value + ' (' + percentage + '%)';
                        }
                    }
                }
            }
        }
    });
}

// Fungsi untuk update tipe grafik
function updateChart(type) {
    if (anggotaChart) {
        anggotaChart.destroy();
        anggotaChart.config.type = type;
        initAnggotaChart();
    }
}

// Inisialisasi semua chart saat dokumen siap
document.addEventListener('DOMContentLoaded', function() {
    initAnggotaChart();
    initSimpananChart();
    initStatusAnggotaChart();
    
    // Auto refresh data setiap 5 menit
    setInterval(function() {
        fetch('<?= site_url("dashboard/koperasi/dashboard-data") ?>')
            .then(response => response.json())
            .then(data => {
                // Update statistik cards
                document.querySelector('.card.border-left-danger .h5').textContent = 
                    data.total_anggota.toLocaleString('id-ID');
                document.querySelector('.card.border-left-success .h5').textContent = 
                    'Rp ' + data.total_simpanan.toLocaleString('id-ID');
                document.querySelector('.card.border-left-info .h5').textContent = 
                    data.total_unit.toLocaleString('id-ID');
                document.querySelector('.card.border-left-warning .h5').textContent = 
                    data.pendaftaran_pending.toLocaleString('id-ID');
            })
            .catch(error => console.error('Error fetching dashboard data:', error));
    }, 300000); // 5 menit
});
</script>

<style>
.card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.1) !important;
}
.list-group-item-action:hover {
    background-color: #f8f9fa;
    transform: translateX(5px);
    transition: all 0.2s ease;
}
.btn-block {
    transition: all 0.3s ease;
}
.btn-block:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}
.chart-area {
    position: relative;
    height: 300px;
    width: 100%;
}
.chart-pie {
    position: relative;
    height: 250px;
}
.badge {
    font-size: 0.75em;
    padding: 0.35em 0.65em;
}
</style>
<?= $this->endSection() ?>
<?= $this->endSection() ?>