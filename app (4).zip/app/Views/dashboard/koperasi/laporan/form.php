<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?= $title ?></h1>
    <a href="<?= site_url('dashboard/koperasi/laporan') ?>" class="d-none d-sm-inline-block btn btn-sm btn-secondary shadow-sm">
        <i class="fas fa-arrow-left fa-sm text-white-50"></i> Kembali
    </a>
</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <form method="post" 
              action="<?= isset($laporan) ? site_url('dashboard/koperasi/laporan/update/' . $laporan['id']) : site_url('dashboard/koperasi/laporan/store') ?>" 
              enctype="multipart/form-data">
            <?= csrf_field() ?>
            <?php if(isset($laporan)): ?>
            <input type="hidden" name="_method" value="PUT">
            <?php endif; ?>

            <div class="row">
                <!-- Judul -->
                <div class="col-md-8 mb-3">
                    <label class="form-label">Judul Laporan *</label>
                    <input type="text" 
                           name="judul" 
                           class="form-control <?= $validation->hasError('judul') ? 'is-invalid' : '' ?>" 
                           value="<?= old('judul', $laporan['judul'] ?? '') ?>" 
                           required>
                    <?php if($validation->hasError('judul')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('judul') ?></div>
                    <?php endif; ?>
                </div>

                <!-- Jenis -->
                <div class="col-md-4 mb-3">
                    <label class="form-label">Jenis Laporan *</label>
                    <select name="jenis" 
                            class="form-select <?= $validation->hasError('jenis') ? 'is-invalid' : '' ?>" 
                            required>
                        <option value="">Pilih Jenis</option>
                        <option value="RAT" <?= (old('jenis', $laporan['jenis'] ?? '') == 'RAT') ? 'selected' : '' ?>>RAT</option>
                        <option value="keuangan" <?= (old('jenis', $laporan['jenis'] ?? '') == 'keuangan') ? 'selected' : '' ?>>Keuangan</option>
                        <option value="tahunan" <?= (old('jenis', $laporan['jenis'] ?? '') == 'tahunan') ? 'selected' : '' ?>>Tahunan</option>
                        <option value="bulanan" <?= (old('jenis', $laporan['jenis'] ?? '') == 'bulanan') ? 'selected' : '' ?>>Bulanan</option>
                        <option value="khusus" <?= (old('jenis', $laporan['jenis'] ?? '') == 'khusus') ? 'selected' : '' ?>>Khusus</option>
                    </select>
                    <?php if($validation->hasError('jenis')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('jenis') ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row">
                <!-- Tahun -->
                <div class="col-md-4 mb-3">
                    <label class="form-label">Tahun *</label>
                    <select name="tahun" 
                            class="form-select <?= $validation->hasError('tahun') ? 'is-invalid' : '' ?>" 
                            required>
                        <option value="">Pilih Tahun</option>
                        <?php for($y = date('Y'); $y >= date('Y')-5; $y--): ?>
                        <option value="<?= $y ?>" <?= (old('tahun', $laporan['tahun'] ?? '') == $y) ? 'selected' : '' ?>>
                            <?= $y ?>
                        </option>
                        <?php endfor; ?>
                    </select>
                    <?php if($validation->hasError('tahun')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('tahun') ?></div>
                    <?php endif; ?>
                </div>

                <!-- Bulan -->
                <div class="col-md-4 mb-3">
                    <label class="form-label">Bulan (Opsional)</label>
                    <select name="bulan" 
                            class="form-select <?= $validation->hasError('bulan') ? 'is-invalid' : '' ?>">
                        <option value="">Pilih Bulan</option>
                        <?php 
                        $months = [
                            '1' => 'Januari', '2' => 'Februari', '3' => 'Maret', '4' => 'April',
                            '5' => 'Mei', '6' => 'Juni', '7' => 'Juli', '8' => 'Agustus',
                            '9' => 'September', '10' => 'Oktober', '11' => 'November', '12' => 'Desember'
                        ];
                        foreach($months as $num => $name): 
                        ?>
                        <option value="<?= $num ?>" <?= (old('bulan', $laporan['bulan'] ?? '') == $num) ? 'selected' : '' ?>>
                            <?= $name ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <?php if($validation->hasError('bulan')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('bulan') ?></div>
                    <?php endif; ?>
                </div>

                <!-- File -->
                <div class="col-md-4 mb-3">
                    <label class="form-label">File Laporan <?= isset($laporan) ? 'Baru' : '*' ?></label>
                    <input type="file" 
                           name="file" 
                           class="form-control <?= $validation->hasError('file') ? 'is-invalid' : '' ?>" 
                           accept=".pdf,.doc,.docx,.xls,.xlsx" 
                           <?= !isset($laporan) ? 'required' : '' ?>>
                    <?php if($validation->hasError('file')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('file') ?></div>
                    <?php endif; ?>
                    <small class="text-muted">Format: PDF, DOC, DOCX, XLS, XLSX (maks 5MB)</small>
                </div>
            </div>

            <!-- Deskripsi -->
            <div class="mb-3">
                <label class="form-label">Deskripsi *</label>
                <textarea name="deskripsi" 
                          class="form-control <?= $validation->hasError('deskripsi') ? 'is-invalid' : '' ?>" 
                          rows="4" 
                          required><?= old('deskripsi', $laporan['deskripsi'] ?? '') ?></textarea>
                <?php if($validation->hasError('deskripsi')): ?>
                <div class="invalid-feedback"><?= $validation->getError('deskripsi') ?></div>
                <?php endif; ?>
            </div>

            <!-- Preview File -->
            <?php if(isset($laporan) && !empty($laporan['file_path'])): ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i>
                File saat ini: 
                <a href="<?= site_url('dashboard/koperasi/laporan/download/' . $laporan['id']) ?>" 
                   target="_blank" class="ms-2">
                    <i class="fas fa-download me-1"></i>Download File
                </a>
            </div>
            <?php endif; ?>

            <!-- Tombol -->
            <div class="d-flex justify-content-between mt-4">
                <a href="<?= site_url('dashboard/koperasi/laporan') ?>" class="btn btn-secondary">
                    <i class="fas fa-times me-1"></i>Batal
                </a>
                <button type="submit" class="btn btn-danger">
                    <i class="fas fa-save me-1"></i>Simpan
                </button>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>