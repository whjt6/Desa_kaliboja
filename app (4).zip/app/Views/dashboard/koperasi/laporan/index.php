<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Manajemen Laporan</h1>
    <a href="<?= site_url('dashboard/koperasi/laporan/create') ?>" class="d-none d-sm-inline-block btn btn-sm btn-danger shadow-sm">
        <i class="fas fa-upload fa-sm text-white-50"></i> Upload Laporan
    </a>
</div>

<!-- Table -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Daftar Laporan Koperasi</h6>
    </div>
    <div class="card-body">
        <?php if(!empty($laporan)): ?>
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Judul</th>
                        <th>Jenis</th>
                        <th>Periode</th>
                        <th>File</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($laporan as $lap): ?>
                    <tr>
                        <td>
                            <strong><?= esc($lap['judul']) ?></strong><br>
                            <small class="text-muted"><?= character_limiter(strip_tags($lap['deskripsi'] ?? ''), 50) ?></small>
                        </td>
                        <td>
                            <?php 
                            $jenisLabel = [
                                'RAT' => 'RAT',
                                'keuangan' => 'Keuangan',
                                'tahunan' => 'Tahunan',
                                'bulanan' => 'Bulanan',
                                'khusus' => 'Khusus'
                            ];
                            $label = $jenisLabel[$lap['jenis']] ?? $lap['jenis'];
                            ?>
                            <span class="badge bg-info"><?= $label ?></span>
                        </td>
                        <td>
                            <?= esc($lap['tahun']) ?>
                            <?php if(!empty($lap['bulan'])): ?>
                            - <?= esc($lap['bulan']) ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($lap['file_path']): ?>
                            <i class="fas fa-file-pdf text-danger me-1"></i>
                            <small>PDF/Doc</small>
                            <?php else: ?>
                            <span class="text-muted">Tidak ada file</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <?php if($lap['file_path']): ?>
                                <a href="<?= site_url('dashboard/koperasi/laporan/download/' . $lap['id']) ?>" 
                                   class="btn btn-sm btn-success" title="Download">
                                    <i class="fas fa-download"></i>
                                </a>
                                <?php endif; ?>
                                <a href="<?= site_url('dashboard/koperasi/laporan/edit/' . $lap['id']) ?>" 
                                   class="btn btn-sm btn-warning" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?= site_url('dashboard/koperasi/laporan/delete/' . $lap['id']) ?>" 
                                      method="post" 
                                      class="d-inline"
                                      onsubmit="return confirm('Hapus laporan ini?')">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-sm btn-danger" title="Hapus">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="text-center py-4">
            <i class="fas fa-file-alt fa-3x text-muted mb-3"></i>
            <p class="text-muted">Belum ada laporan</p>
            <a href="<?= site_url('dashboard/koperasi/laporan/create') ?>" class="btn btn-danger">
                <i class="fas fa-upload me-1"></i>Upload Laporan Pertama
            </a>
        </div>
        <?php endif; ?>
    </div>
</div>
<?= $this->endSection() ?>