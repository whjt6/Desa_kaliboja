<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Manajemen Unit Usaha</h1>
    <div>
        <a href="<?= site_url('dashboard/koperasi/unit-usaha/create') ?>" class="d-none d-sm-inline-block btn btn-sm btn-danger shadow-sm">
            <i class="fas fa-plus fa-sm text-white-50"></i> Tambah Unit
        </a>
        <a href="<?= site_url('dashboard/koperasi/unit-usaha/kategori') ?>" class="d-none d-sm-inline-block btn btn-sm btn-info shadow-sm">
            <i class="fas fa-tags fa-sm text-white-50"></i> Kategori
        </a>
    </div>
</div>

<!-- Stats Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Tersedia</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?= number_format(array_reduce($units, function($carry, $item) {
                                return $carry + ($item['status'] == 'tersedia' ? 1 : 0);
                            }, 0)) ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Habis</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?= number_format(array_reduce($units, function($carry, $item) {
                                return $carry + ($item['status'] == 'habis' ? 1 : 0);
                            }, 0)) ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-times-circle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Preorder</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?= number_format(array_reduce($units, function($carry, $item) {
                                return $carry + ($item['status'] == 'preorder' ? 1 : 0);
                            }, 0)) ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-clock fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Unit</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= number_format(count($units)) ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-boxes fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Table -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Daftar Unit Usaha</h6>
    </div>
    <div class="card-body">
        <?php if(!empty($units)): ?>
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Gambar</th>
                        <th>Kode & Nama</th>
                        <th>Kategori</th>
                        <th>Harga & Stok</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($units as $unit): ?>
                    <tr>
                        <td style="width: 100px;">
                            <?php if(!empty($unit['gambar']) && file_exists(ROOTPATH . 'public/uploads/koperasi/unit/' . $unit['gambar'])): ?>
                            <img src="<?= base_url('uploads/koperasi/unit/' . $unit['gambar']) ?>" 
                                 class="img-fluid rounded" 
                                 style="width: 80px; height: 80px; object-fit: cover;"
                                 alt="<?= esc($unit['nama_unit']) ?>">
                            <?php else: ?>
                            <div class="bg-light rounded d-flex align-items-center justify-content-center" 
                                 style="width: 80px; height: 80px;">
                                <i class="fas fa-box text-muted"></i>
                            </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong><?= esc($unit['kode_unit']) ?></strong><br>
                            <strong><?= esc($unit['nama_unit']) ?></strong><br>
                            <small class="text-muted"><?= character_limiter(strip_tags($unit['deskripsi']), 50) ?></small>
                        </td>
                        <td>
                            <span class="badge bg-info"><?= esc($unit['kategori']) ?></span>
                        </td>
                        <td>
                            <strong class="text-danger">Rp <?= number_format($unit['harga'], 0, ',', '.') ?></strong><br>
                            <small>/<?= esc($unit['satuan']) ?></small><br>
                            Stok: <strong><?= number_format($unit['stok']) ?></strong>
                        </td>
                        <td>
                            <?php if($unit['status'] == 'tersedia'): ?>
                            <span class="badge bg-success">Tersedia</span>
                            <?php elseif($unit['status'] == 'habis'): ?>
                            <span class="badge bg-warning">Habis</span>
                            <?php else: ?>
                            <span class="badge bg-info">Preorder</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?= site_url('dashboard/koperasi/unit-usaha/edit/' . $unit['id']) ?>" 
                                   class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="<?= site_url('koperasi/detail/' . $unit['id']) ?>" 
                                   target="_blank" 
                                   class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <form action="<?= site_url('dashboard/koperasi/unit-usaha/delete/' . $unit['id']) ?>" 
                                      method="post" 
                                      class="d-inline"
                                      onsubmit="return confirm('Hapus unit ini?')">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-sm btn-danger">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="text-center py-4">
            <i class="fas fa-box-open fa-3x text-muted mb-3"></i>
            <p class="text-muted">Belum ada unit usaha</p>
            <a href="<?= site_url('dashboard/koperasi/unit-usaha/create') ?>" class="btn btn-danger">
                <i class="fas fa-plus me-1"></i>Tambah Unit Pertama
            </a>
        </div>
        <?php endif; ?>
    </div>
</div>
<?= $this->endSection() ?>