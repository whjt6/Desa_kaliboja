<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Kategori Unit Usaha</h1>
    <a href="<?= site_url('dashboard/koperasi/unit-usaha') ?>" class="d-none d-sm-inline-block btn btn-sm btn-secondary shadow-sm">
        <i class="fas fa-arrow-left fa-sm text-white-50"></i> Kembali
    </a>
</div>

<!-- Add Category -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Tambah Kategori Baru</h6>
    </div>
    <div class="card-body">
        <form method="post" action="<?= site_url('dashboard/koperasi/unit-usaha/kategori/store') ?>">
            <?= csrf_field() ?>
            <div class="row">
                <div class="col-md-8 mb-3">
                    <input type="text" 
                           name="nama_kategori" 
                           class="form-control" 
                           placeholder="Masukkan nama kategori baru..."
                           required>
                </div>
                <div class="col-md-4 mb-3">
                    <button type="submit" class="btn btn-danger w-100">
                        <i class="fas fa-plus me-1"></i>Tambah Kategori
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Categories List -->
<div class="card shadow">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Daftar Kategori</h6>
    </div>
    <div class="card-body">
        <?php if(!empty($kategories)): ?>
        <div class="row">
            <?php foreach($kategories as $index => $kategori): ?>
            <div class="col-md-3 mb-3">
                <div class="card border-left-info shadow-sm h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <h6 class="mb-0"><?= ucwords(str_replace('-', ' ', $kategori)) ?></h6>
                            <form action="<?= site_url('dashboard/koperasi/unit-usaha/kategori/delete/' . $index) ?>" 
                                  method="post" 
                                  class="d-inline"
                                  onsubmit="return confirm('Hapus kategori ini?')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="_method" value="DELETE">
                                <button type="submit" class="btn btn-sm btn-danger">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div class="text-center py-4">
            <i class="fas fa-tags fa-3x text-muted mb-3"></i>
            <p class="text-muted">Belum ada kategori</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Info -->
<div class="alert alert-info mt-4">
    <h6><i class="fas fa-info-circle me-2"></i>Informasi</h6>
    <ul class="mb-0">
        <li>Kategori digunakan untuk mengelompokkan unit usaha</li>
        <li>Hapus kategori hanya jika tidak ada unit usaha yang menggunakan kategori tersebut</li>
        <li>Edit kategori dengan mengubah langsung nama kategori di form tambah</li>
    </ul>
</div>
<?= $this->endSection() ?>