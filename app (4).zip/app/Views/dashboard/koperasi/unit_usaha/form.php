<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?= $title ?></h1>
    <a href="<?= site_url('dashboard/koperasi/unit-usaha') ?>" class="d-none d-sm-inline-block btn btn-sm btn-secondary shadow-sm">
        <i class="fas fa-arrow-left fa-sm text-white-50"></i> Kembali
    </a>
</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <form method="post" 
              action="<?= isset($unit) ? site_url('dashboard/koperasi/unit-usaha/update/' . $unit['id']) : site_url('dashboard/koperasi/unit-usaha/store') ?>" 
              enctype="multipart/form-data">
            <?= csrf_field() ?>
            <?php if(isset($unit)): ?>
            <input type="hidden" name="_method" value="PUT">
            <?php endif; ?>

            <!-- Preview Gambar -->
            <?php if(isset($unit) && !empty($unit['gambar']) && file_exists(ROOTPATH . 'public/uploads/koperasi/unit/' . $unit['gambar'])): ?>
            <div class="row mb-4">
                <div class="col-12">
                    <label class="form-label">Gambar Saat Ini</label>
                    <div class="mb-3">
                        <img src="<?= base_url('uploads/koperasi/unit/' . $unit['gambar']) ?>" 
                             class="img-fluid rounded" 
                             style="max-height: 200px;"
                             alt="Gambar saat ini">
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="row">
                <!-- Nama Unit -->
                <div class="col-md-8 mb-3">
                    <label class="form-label">Nama Unit *</label>
                    <input type="text" 
                           name="nama_unit" 
                           class="form-control <?= $validation->hasError('nama_unit') ? 'is-invalid' : '' ?>" 
                           value="<?= old('nama_unit', $unit['nama_unit'] ?? '') ?>" 
                           required>
                    <?php if($validation->hasError('nama_unit')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('nama_unit') ?></div>
                    <?php endif; ?>
                </div>

                <!-- Kategori -->
                <div class="col-md-4 mb-3">
                    <label class="form-label">Kategori *</label>
                    <select name="kategori" 
                            class="form-select <?= $validation->hasError('kategori') ? 'is-invalid' : '' ?>" 
                            required>
                        <option value="">Pilih Kategori</option>
                        <?php foreach($kategories as $kat): ?>
                        <option value="<?= $kat ?>" <?= (old('kategori', $unit['kategori'] ?? '') == $kat) ? 'selected' : '' ?>>
                            <?= ucwords(str_replace('-', ' ', $kat)) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <?php if($validation->hasError('kategori')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('kategori') ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Deskripsi -->
            <div class="mb-3">
                <label class="form-label">Deskripsi *</label>
                <textarea name="deskripsi" 
                          class="form-control <?= $validation->hasError('deskripsi') ? 'is-invalid' : '' ?>" 
                          rows="4" 
                          required><?= old('deskripsi', $unit['deskripsi'] ?? '') ?></textarea>
                <?php if($validation->hasError('deskripsi')): ?>
                <div class="invalid-feedback"><?= $validation->getError('deskripsi') ?></div>
                <?php endif; ?>
            </div>

            <div class="row">
                <!-- Harga -->
                <div class="col-md-4 mb-3">
                    <label class="form-label">Harga *</label>
                    <div class="input-group">
                        <span class="input-group-text">Rp</span>
                        <input type="number" 
                               name="harga" 
                               class="form-control <?= $validation->hasError('harga') ? 'is-invalid' : '' ?>" 
                               value="<?= old('harga', $unit['harga'] ?? '') ?>" 
                               min="0" 
                               step="1000" 
                               required>
                    </div>
                    <?php if($validation->hasError('harga')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('harga') ?></div>
                    <?php endif; ?>
                </div>

                <!-- Satuan -->
                <div class="col-md-4 mb-3">
                    <label class="form-label">Satuan *</label>
                    <input type="text" 
                           name="satuan" 
                           class="form-control <?= $validation->hasError('satuan') ? 'is-invalid' : '' ?>" 
                           value="<?= old('satuan', $unit['satuan'] ?? '') ?>" 
                           placeholder="kg/liter/pcs/dll" 
                           required>
                    <?php if($validation->hasError('satuan')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('satuan') ?></div>
                    <?php endif; ?>
                </div>

                <!-- Stok -->
                <div class="col-md-4 mb-3">
                    <label class="form-label">Stok *</label>
                    <input type="number" 
                           name="stok" 
                           class="form-control <?= $validation->hasError('stok') ? 'is-invalid' : '' ?>" 
                           value="<?= old('stok', $unit['stok'] ?? 0) ?>" 
                           min="0" 
                           required>
                    <?php if($validation->hasError('stok')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('stok') ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row">
                <!-- Status -->
                <div class="col-md-6 mb-3">
                    <label class="form-label">Status *</label>
                    <select name="status" 
                            class="form-select <?= $validation->hasError('status') ? 'is-invalid' : '' ?>" 
                            required>
                        <option value="">Pilih Status</option>
                        <option value="tersedia" <?= (old('status', $unit['status'] ?? '') == 'tersedia') ? 'selected' : '' ?>>Tersedia</option>
                        <option value="habis" <?= (old('status', $unit['status'] ?? '') == 'habis') ? 'selected' : '' ?>>Habis</option>
                        <option value="preorder" <?= (old('status', $unit['status'] ?? '') == 'preorder') ? 'selected' : '' ?>>Preorder</option>
                    </select>
                    <?php if($validation->hasError('status')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('status') ?></div>
                    <?php endif; ?>
                </div>

                <!-- Gambar -->
                <div class="col-md-6 mb-3">
                    <label class="form-label"><?= isset($unit) ? 'Gambar Baru' : 'Gambar *' ?></label>
                    <input type="file" 
                           name="gambar" 
                           class="form-control <?= $validation->hasError('gambar') ? 'is-invalid' : '' ?>" 
                           accept="image/*" 
                           <?= !isset($unit) ? 'required' : '' ?>>
                    <?php if($validation->hasError('gambar')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('gambar') ?></div>
                    <?php endif; ?>
                    <small class="text-muted">Format: JPG/PNG, maksimal 2MB</small>
                </div>
            </div>

            <!-- Tombol -->
            <div class="d-flex justify-content-between mt-4">
                <a href="<?= site_url('dashboard/koperasi/unit-usaha') ?>" class="btn btn-secondary">
                    <i class="fas fa-times me-1"></i>Batal
                </a>
                <button type="submit" class="btn btn-danger">
                    <i class="fas fa-save me-1"></i>Simpan
                </button>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>