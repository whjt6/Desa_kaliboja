<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Detail Unit Usaha</h1>
    <div>
        <a href="<?= site_url('dashboard/koperasi/unit-usaha/edit/' . $unit['id']) ?>" 
           class="btn btn-sm btn-warning">
            <i class="fas fa-edit"></i> Edit
        </a>
        <a href="<?= site_url('dashboard/koperasi/unit-usaha') ?>" 
           class="btn btn-sm btn-secondary">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
    </div>
</div>

<div class="row">
    <div class="col-lg-8">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Informasi Unit</h6>
            </div>
            <div class="card-body">
                <table class="table table-borderless">
                    <tr>
                        <td width="200"><strong>Kode Unit</strong></td>
                        <td>: <?= esc($unit['kode_unit']) ?></td>
                    </tr>
                    <tr>
                        <td><strong>Nama Unit</strong></td>
                        <td>: <?= esc($unit['nama_unit']) ?></td>
                    </tr>
                    <tr>
                        <td><strong>Kategori</strong></td>
                        <td>: <span class="badge bg-info"><?= esc($unit['kategori']) ?></span></td>
                    </tr>
                    <tr>
                        <td><strong>Harga</strong></td>
                        <td>: <strong class="text-danger">Rp <?= number_format($unit['harga'], 0, ',', '.') ?></strong> / <?= esc($unit['satuan']) ?></td>
                    </tr>
                    <tr>
                        <td><strong>Stok</strong></td>
                        <td>: <strong><?= number_format($unit['stok']) ?></strong> <?= esc($unit['satuan']) ?></td>
                    </tr>
                    <tr>
                        <td><strong>Status</strong></td>
                        <td>: 
                            <?php if($unit['status'] == 'tersedia'): ?>
                            <span class="badge bg-success">Tersedia</span>
                            <?php elseif($unit['status'] == 'habis'): ?>
                            <span class="badge bg-warning">Habis</span>
                            <?php else: ?>
                            <span class="badge bg-info">Preorder</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Deskripsi</strong></td>
                        <td>: <?= nl2br(esc($unit['deskripsi'])) ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <?php if(!empty($unit['gambar'])): ?>
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Gambar Produk</h6>
            </div>
            <div class="card-body text-center">
                <img src="<?= base_url('uploads/koperasi/unit/' . $unit['gambar']) ?>" 
                     class="img-fluid rounded"
                     alt="<?= esc($unit['nama_unit']) ?>"
                     onerror="this.src='https://via.placeholder.com/300x300?text=Gambar'">
            </div>
        </div>
        <?php endif; ?>

        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Aksi</h6>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="<?= site_url('koperasi/detail/' . $unit['id']) ?>" 
                       target="_blank"
                       class="btn btn-info">
                        <i class="fas fa-external-link-alt me-1"></i>Lihat di Website
                    </a>
                    <a href="<?= site_url('dashboard/koperasi/unit-usaha/edit/' . $unit['id']) ?>" 
                       class="btn btn-warning">
                        <i class="fas fa-edit me-1"></i>Edit Data
                    </a>
                    <form action="<?= site_url('dashboard/koperasi/unit-usaha/delete/' . $unit['id']) ?>" 
                          method="post"
                          onsubmit="return confirm('Hapus unit ini?')">
                        <?= csrf_field() ?>
                        <input type="hidden" name="_method" value="DELETE">
                        <button type="submit" class="btn btn-danger w-100">
                            <i class="fas fa-trash me-1"></i>Hapus Unit
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>