<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Manajemen Simpanan</h1>
    <a href="<?= site_url('dashboard/koperasi/simpanan/create') ?>" class="d-none d-sm-inline-block btn btn-sm btn-danger shadow-sm">
        <i class="fas fa-money-check-alt fa-sm text-white-50"></i> Tambah Transaksi
    </a>
</div>

<!-- Filter -->
<div class="card shadow mb-4">
    <div class="card-body">
        <form method="get" action="<?= site_url('dashboard/koperasi/simpanan') ?>" class="row">
            <div class="col-md-4 mb-2">
                <select name="anggota_id" class="form-select">
                    <option value="">Pilih Anggota</option>
                    <?php foreach($anggota_list as $anggota): ?>
                    <option value="<?= $anggota['id'] ?>" <?= ($currentAnggota == $anggota['id']) ? 'selected' : '' ?>>
                        <?= esc($anggota['kode_anggota']) ?> - <?= esc($anggota['nama']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3 mb-2">
                <select name="jenis" class="form-select">
                    <option value="">Semua Jenis</option>
                    <option value="pokok" <?= ($currentJenis == 'pokok') ? 'selected' : '' ?>>Pokok</option>
                    <option value="wajib" <?= ($currentJenis == 'wajib') ? 'selected' : '' ?>>Wajib</option>
                    <option value="sukarela" <?= ($currentJenis == 'sukarela') ? 'selected' : '' ?>>Sukarela</option>
                </select>
            </div>
            <div class="col-md-3 mb-2">
                <input type="month" name="bulan" class="form-control" value="<?= esc($currentBulan ?? '') ?>">
            </div>
            <div class="col-md-2 mb-2">
                <button type="submit" class="btn btn-primary w-100">Filter</button>
            </div>
        </form>
    </div>
</div>

<!-- Table -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Daftar Transaksi Simpanan</h6>
    </div>
    <div class="card-body">
        <?php if(!empty($simpanan)): ?>
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Kode Transaksi</th>
                        <th>Anggota</th>
                        <th>Jenis</th>
                        <th>Jumlah</th>
                        <th>Tanggal</th>
                        <th>Keterangan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($simpanan as $s): ?>
                    <tr>
                        <td><strong><?= esc($s['kode_transaksi']) ?></strong></td>
                        <td>
                            <strong><?= esc($s['nama_anggota']) ?></strong><br>
                            <small class="text-muted"><?= esc($s['kode_anggota']) ?></small>
                        </td>
                        <td>
                            <?php if($s['jenis'] == 'pokok'): ?>
                            <span class="badge bg-primary">Pokok</span>
                            <?php elseif($s['jenis'] == 'wajib'): ?>
                            <span class="badge bg-success">Wajib</span>
                            <?php else: ?>
                            <span class="badge bg-info">Sukarela</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong class="text-danger">Rp <?= number_format($s['jumlah'], 0, ',', '.') ?></strong>
                        </td>
                        <td><?= date('d/m/Y', strtotime($s['tanggal'])) ?></td>
                        <td><?= character_limiter($s['keterangan'], 30) ?></td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="#" class="btn btn-sm btn-info" title="Detail">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="text-center py-4">
            <i class="fas fa-money-bill-wave fa-3x text-muted mb-3"></i>
            <p class="text-muted">Belum ada transaksi simpanan</p>
            <a href="<?= site_url('dashboard/koperasi/simpanan/create') ?>" class="btn btn-danger">
                <i class="fas fa-plus me-1"></i>Tambah Transaksi Pertama
            </a>
        </div>
        <?php endif; ?>
    </div>
    <div class="card-footer">
        <div class="row">
            <div class="col-md-6">
                <a href="<?= site_url('dashboard/koperasi/simpanan/laporan') ?>" class="btn btn-warning">
                    <i class="fas fa-file-alt me-1"></i>Laporan Tahunan
                </a>
            </div>
            <div class="col-md-6 text-end">
                <a href="<?= site_url('dashboard/koperasi/simpanan/export') ?>" class="btn btn-success">
                    <i class="fas fa-file-excel me-1"></i>Export Excel
                </a>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>