<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Laporan Simpanan</h1>
    <div>
        <a href="<?= site_url('dashboard/koperasi/simpanan/export?tahun=' . ($currentTahun ?? date('Y'))) ?>" 
           class="d-none d-sm-inline-block btn btn-sm btn-success shadow-sm">
            <i class="fas fa-file-excel fa-sm text-white-50"></i> Export Excel
        </a>
        <a href="<?= site_url('dashboard/koperasi/simpanan') ?>" 
           class="d-none d-sm-inline-block btn btn-sm btn-secondary shadow-sm">
            <i class="fas fa-arrow-left fa-sm text-white-50"></i> Kembali
        </a>
    </div>
</div>

<!-- Filter Tahun -->
<div class="card shadow mb-4">
    <div class="card-body">
        <form method="get" action="<?= site_url('dashboard/koperasi/simpanan/laporan') ?>" class="row">
            <div class="col-md-4">
                <select name="tahun" class="form-select" onchange="this.form.submit()">
                    <?php foreach($tahun_list as $tahun): ?>
                    <option value="<?= $tahun ?>" <?= ($currentTahun == $tahun) ? 'selected' : '' ?>>
                        Tahun <?= $tahun ?>
                    </option>
                    <?php endforeach; ?>
                    <?php if(empty($tahun_list)): ?>
                    <option value="<?= date('Y') ?>">Tahun <?= date('Y') ?></option>
                    <?php endif; ?>
                </select>
            </div>
        </form>
    </div>
</div>

<!-- Summary -->
<div class="row mb-4">
    <div class="col-xl-4 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Simpanan Pokok</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            Rp <?= number_format($summary['pokok'] ?? 0, 0, ',', '.') ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-landmark fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-4 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Simpanan Wajib</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            Rp <?= number_format($summary['wajib'] ?? 0, 0, ',', '.') ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-calendar-check fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-4 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Simpanan Sukarela</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            Rp <?= number_format($summary['sukarela'] ?? 0, 0, ',', '.') ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-heart fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Table Laporan -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Laporan Simpanan Tahun <?= $currentTahun ?? date('Y') ?></h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Bulan</th>
                        <th>Simpanan Pokok</th>
                        <th>Simpanan Wajib</th>
                        <th>Simpanan Sukarela</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 
                              'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
                    $totalPokok = $totalWajib = $totalSukarela = 0;
                    
                    for ($i = 0; $i < 12; $i++): 
                        $row = $laporan[$i] ?? ['pokok' => 0, 'wajib' => 0, 'sukarela' => 0];
                        $total = $row['pokok'] + $row['wajib'] + $row['sukarela'];
                        $totalPokok += $row['pokok'];
                        $totalWajib += $row['wajib'];
                        $totalSukarela += $row['sukarela'];
                    ?>
                    <tr>
                        <td><strong><?= $months[$i] ?></strong></td>
                        <td class="text-end">Rp <?= number_format($row['pokok'], 0, ',', '.') ?></td>
                        <td class="text-end">Rp <?= number_format($row['wajib'], 0, ',', '.') ?></td>
                        <td class="text-end">Rp <?= number_format($row['sukarela'], 0, ',', '.') ?></td>
                        <td class="text-end">
                            <strong class="text-primary">Rp <?= number_format($total, 0, ',', '.') ?></strong>
                        </td>
                    </tr>
                    <?php endfor; ?>
                </tbody>
                <tfoot>
                    <tr class="bg-light">
                        <th>Total Tahun <?= $currentTahun ?? date('Y') ?></th>
                        <th class="text-end">Rp <?= number_format($totalPokok, 0, ',', '.') ?></th>
                        <th class="text-end">Rp <?= number_format($totalWajib, 0, ',', '.') ?></th>
                        <th class="text-end">Rp <?= number_format($totalSukarela, 0, ',', '.') ?></th>
                        <th class="text-end">
                            <strong class="text-danger">Rp <?= number_format($totalPokok + $totalWajib + $totalSukarela, 0, ',', '.') ?></strong>
                        </th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>

<!-- Grafik -->
<div class="card shadow">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Grafik Simpanan Tahun <?= $currentTahun ?? date('Y') ?></h6>
    </div>
    <div class="card-body">
        <div class="chart-area">
            <canvas id="simpananChart"></canvas>
        </div>
    </div>
</div>

<?= $this->section('page-scripts') ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Grafik Simpanan
var ctx = document.getElementById('simpananChart').getContext('2d');
var chartData = <?= json_encode($laporan ?? []) ?>;

var labels = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 
              'Jul', 'Agt', 'Sep', 'Okt', 'Nov', 'Des'];

var dataPokok = chartData.map(item => item.pokok || 0);
var dataWajib = chartData.map(item => item.wajib || 0);
var dataSukarela = chartData.map(item => item.sukarela || 0);

var simpananChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: labels,
        datasets: [
            {
                label: 'Simpanan Pokok',
                data: dataPokok,
                backgroundColor: 'rgba(78, 115, 223, 0.8)',
                borderColor: 'rgba(78, 115, 223, 1)',
                borderWidth: 1
            },
            {
                label: 'Simpanan Wajib',
                data: dataWajib,
                backgroundColor: 'rgba(28, 200, 138, 0.8)',
                borderColor: 'rgba(28, 200, 138, 1)',
                borderWidth: 1
            },
            {
                label: 'Simpanan Sukarela',
                data: dataSukarela,
                backgroundColor: 'rgba(54, 185, 204, 0.8)',
                borderColor: 'rgba(54, 185, 204, 1)',
                borderWidth: 1
            }
        ]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return 'Rp ' + value.toLocaleString('id-ID');
                    }
                }
            }
        },
        plugins: {
            legend: {
                display: true,
                position: 'top'
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return context.dataset.label + ': Rp ' + context.parsed.y.toLocaleString('id-ID');
                    }
                }
            }
        }
    }
});
</script>
<?= $this->endSection() ?>
<?= $this->endSection() ?>