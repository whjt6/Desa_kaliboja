<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?= $title ?></h1>
    <a href="<?= site_url('dashboard/koperasi/simpanan') ?>" class="d-none d-sm-inline-block btn btn-sm btn-secondary shadow-sm">
        <i class="fas fa-arrow-left fa-sm text-white-50"></i> Kembali
    </a>
</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <form method="post" action="<?= site_url('dashboard/koperasi/simpanan/store') ?>">
            <?= csrf_field() ?>

            <div class="row">
                <!-- Anggota -->
                <div class="col-md-6 mb-3">
                    <label class="form-label">Anggota *</label>
                    <select name="anggota_id" 
                            class="form-select <?= $validation->hasError('anggota_id') ? 'is-invalid' : '' ?>" 
                            required>
                        <option value="">Pilih Anggota</option>
                        <?php foreach($anggota_list as $anggota): ?>
                        <option value="<?= $anggota['id'] ?>" <?= (old('anggota_id') == $anggota['id']) ? 'selected' : '' ?>>
                            <?= esc($anggota['kode_anggota']) ?> - <?= esc($anggota['nama']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <?php if($validation->hasError('anggota_id')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('anggota_id') ?></div>
                    <?php endif; ?>
                </div>

                <!-- Jenis Simpanan -->
                <div class="col-md-6 mb-3">
                    <label class="form-label">Jenis Simpanan *</label>
                    <select name="jenis" 
                            class="form-select <?= $validation->hasError('jenis') ? 'is-invalid' : '' ?>" 
                            required>
                        <option value="">Pilih Jenis</option>
                        <option value="pokok" <?= (old('jenis') == 'pokok') ? 'selected' : '' ?>>Pokok</option>
                        <option value="wajib" <?= (old('jenis') == 'wajib') ? 'selected' : '' ?>>Wajib</option>
                        <option value="sukarela" <?= (old('jenis') == 'sukarela') ? 'selected' : '' ?>>Sukarela</option>
                    </select>
                    <?php if($validation->hasError('jenis')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('jenis') ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row">
                <!-- Jumlah -->
                <div class="col-md-6 mb-3">
                    <label class="form-label">Jumlah *</label>
                    <div class="input-group">
                        <span class="input-group-text">Rp</span>
                        <input type="number" 
                               name="jumlah" 
                               class="form-control <?= $validation->hasError('jumlah') ? 'is-invalid' : '' ?>" 
                               value="<?= old('jumlah') ?>" 
                               min="0" 
                               step="1000" 
                               required>
                    </div>
                    <?php if($validation->hasError('jumlah')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('jumlah') ?></div>
                    <?php endif; ?>
                </div>

                <!-- Tanggal -->
                <div class="col-md-6 mb-3">
                    <label class="form-label">Tanggal *</label>
                    <input type="date" 
                           name="tanggal" 
                           class="form-control <?= $validation->hasError('tanggal') ? 'is-invalid' : '' ?>" 
                           value="<?= old('tanggal', date('Y-m-d')) ?>" 
                           required>
                    <?php if($validation->hasError('tanggal')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('tanggal') ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Keterangan -->
            <div class="mb-3">
                <label class="form-label">Keterangan *</label>
                <textarea name="keterangan" 
                          class="form-control <?= $validation->hasError('keterangan') ? 'is-invalid' : '' ?>" 
                          rows="3" 
                          required><?= old('keterangan') ?></textarea>
                <?php if($validation->hasError('keterangan')): ?>
                <div class="invalid-feedback"><?= $validation->getError('keterangan') ?></div>
                <?php endif; ?>
            </div>

            <!-- Tombol -->
            <div class="d-flex justify-content-between mt-4">
                <a href="<?= site_url('dashboard/koperasi/simpanan') ?>" class="btn btn-secondary">
                    <i class="fas fa-times me-1"></i>Batal
                </a>
                <button type="submit" class="btn btn-danger">
                    <i class="fas fa-save me-1"></i>Simpan
                </button>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>