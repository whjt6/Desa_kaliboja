<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?= $title ?></h1>
    <div>
        <a href="<?= site_url('dashboard/koperasi/simpanan') ?>" 
           class="d-none d-sm-inline-block btn btn-sm btn-secondary shadow-sm">
            <i class="fas fa-arrow-left fa-sm text-white-50"></i> Kembali
        </a>
        <button onclick="window.print()" 
                class="d-none d-sm-inline-block btn btn-sm btn-info shadow-sm">
            <i class="fas fa-print fa-sm text-white-50"></i> Cetak
        </button>
    </div>
</div>

<!-- Info Anggota -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Informasi Anggota</h6>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-8">
                <table class="table table-borderless">
                    <tr>
                        <td width="150"><strong>Kode Anggota</strong></td>
                        <td>: <?= esc($anggota['kode_anggota']) ?></td>
                    </tr>
                    <tr>
                        <td><strong>Nama</strong></td>
                        <td>: <?= esc($anggota['nama']) ?></td>
                    </tr>
                    <tr>
                        <td><strong>NIK</strong></td>
                        <td>: <?= esc($anggota['nik']) ?></td>
                    </tr>
                    <tr>
                        <td><strong>Alamat</strong></td>
                        <td>: <?= esc($anggota['alamat']) ?></td>
                    </tr>
                    <tr>
                        <td><strong>No. HP</strong></td>
                        <td>: <?= esc($anggota['no_hp']) ?></td>
                    </tr>
                    <tr>
                        <td><strong>Status</strong></td>
                        <td>: 
                            <?php if($anggota['status'] == 'aktif'): ?>
                            <span class="badge bg-success">Aktif</span>
                            <?php elseif($anggota['status'] == 'nonaktif'): ?>
                            <span class="badge bg-warning">Nonaktif</span>
                            <?php else: ?>
                            <span class="badge bg-danger">Keluar</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </div>
            <div class="col-md-4">
                <div class="text-center">
                    <div class="card border-left-primary shadow h-100 py-2 mb-3">
                        <div class="card-body">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Simpanan Pokok</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                Rp <?= number_format($anggota['simpanan_pokok'], 0, ',', '.') ?>
                            </div>
                        </div>
                    </div>
                    <div class="card border-left-success shadow h-100 py-2 mb-3">
                        <div class="card-body">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Simpanan Wajib</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                Rp <?= number_format($anggota['simpanan_wajib'], 0, ',', '.') ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Detail Simpanan -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Rincian Simpanan</h6>
    </div>
    <div class="card-body">
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Pokok</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            Rp <?= number_format($total_pokok, 0, ',', '.') ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-left-success shadow h-100 py-2">
                    <div class="card-body">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Total Wajib</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            Rp <?= number_format($total_wajib, 0, ',', '.') ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-left-info shadow h-100 py-2">
                    <div class="card-body">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Total Sukarela</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            Rp <?= number_format($total_sukarela, 0, ',', '.') ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Transaksi Simpanan -->
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Kode Transaksi</th>
                        <th>Tanggal</th>
                        <th>Jenis</th>
                        <th>Jumlah</th>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($simpanan)): ?>
                    <?php foreach($simpanan as $s): ?>
                    <tr>
                        <td><?= esc($s['kode_transaksi']) ?></td>
                        <td><?= date('d/m/Y', strtotime($s['tanggal'])) ?></td>
                        <td>
                            <?php if($s['jenis'] == 'pokok'): ?>
                            <span class="badge bg-primary">Pokok</span>
                            <?php elseif($s['jenis'] == 'wajib'): ?>
                            <span class="badge bg-success">Wajib</span>
                            <?php else: ?>
                            <span class="badge bg-info">Sukarela</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-end">
                            Rp <?= number_format($s['jumlah'], 0, ',', '.') ?>
                        </td>
                        <td><?= esc($s['keterangan']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-center py-4">
                            <i class="fas fa-money-bill-wave fa-2x text-muted mb-3"></i>
                            <p class="text-muted">Belum ada transaksi simpanan</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr class="bg-light">
                        <th colspan="3" class="text-end">Total:</th>
                        <th class="text-end text-danger">
                            Rp <?= number_format($total_pokok + $total_wajib + $total_sukarela, 0, ',', '.') ?>
                        </th>
                        <th></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
    <div class="card-footer">
        <div class="text-center">
            <a href="<?= site_url('dashboard/koperasi/simpanan/create') ?>" class="btn btn-danger">
                <i class="fas fa-plus me-1"></i>Tambah Transaksi Baru
            </a>
        </div>
    </div>
</div>
<?= $this->endSection() ?>