<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Pengaturan Koperasi</h1>
    <a href="<?= site_url('dashboard/koperasi') ?>" class="d-none d-sm-inline-block btn btn-sm btn-secondary shadow-sm">
        <i class="fas fa-arrow-left fa-sm text-white-50"></i> Kembali
    </a>
</div>

<?php if(session()->getFlashdata('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="fas fa-check-circle me-2"></i><?= session()->getFlashdata('success') ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<form method="post" action="<?= site_url('dashboard/koperasi/settings/update') ?>">
    <?= csrf_field() ?>
    
    <!-- Informasi Umum -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Informasi Umum</h6>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Nama Koperasi *</label>
                    <input type="text" 
                           name="nama_koperasi" 
                           class="form-control" 
                           value="<?= esc($settings['nama_koperasi'] ?? 'Koperasi Merah Putih') ?>" 
                           required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Singkatan *</label>
                    <input type="text" 
                           name="singkatan" 
                           class="form-control" 
                           value="<?= esc($settings['singkatan'] ?? 'KMP') ?>" 
                           required>
                </div>
            </div>
            
            <div class="mb-3">
                <label class="form-label">Sejarah Koperasi</label>
                <textarea name="sejarah" 
                          class="form-control" 
                          rows="5"><?= esc($settings['sejarah'] ?? '') ?></textarea>
            </div>
        </div>
    </div>
    
    <!-- Kontak -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Informasi Kontak</h6>
        </div>
        <div class="card-body">
            <div class="mb-3">
                <label class="form-label">Alamat *</label>
                <textarea name="alamat" 
                          class="form-control" 
                          rows="3" 
                          required><?= esc($settings['alamat'] ?? '') ?></textarea>
            </div>
            
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label class="form-label">Telepon *</label>
                    <input type="text" 
                           name="telepon" 
                           class="form-control" 
                           value="<?= esc($settings['telepon'] ?? '') ?>" 
                           required>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">WhatsApp *</label>
                    <input type="text" 
                           name="whatsapp" 
                           class="form-control" 
                           value="<?= esc($settings['whatsapp'] ?? '') ?>" 
                           placeholder="628123456789"
                           required>
                    <small class="text-muted">Format: 628xxxxxxxxxx (tanpa +)</small>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" 
                           name="email" 
                           class="form-control" 
                           value="<?= esc($settings['email'] ?? '') ?>">
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Website</label>
                    <input type="url" 
                           name="website" 
                           class="form-control" 
                           value="<?= esc($settings['website'] ?? '') ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Jam Operasional</label>
                    <textarea name="jam_operasional" 
                              class="form-control" 
                              rows="2"><?= esc($settings['jam_operasional'] ?? '') ?></textarea>
                    <small class="text-muted">Contoh: Senin - Jumat: 08:00 - 16:00</small>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Visi & Misi -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Visi & Misi</h6>
        </div>
        <div class="card-body">
            <div class="mb-3">
                <label class="form-label">Visi</label>
                <textarea name="visi" 
                          class="form-control" 
                          rows="3"><?= esc($settings['visi'] ?? '') ?></textarea>
            </div>
            
            <div class="mb-3">
                <label class="form-label">Misi</label>
                <textarea name="misi" 
                          class="form-control" 
                          rows="5"><?= esc($settings['misi'] ?? '') ?></textarea>
                <small class="text-muted">Gunakan enter untuk memisahkan setiap poin misi</small>
            </div>
        </div>
    </div>
    
    <!-- Keanggotaan -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Keanggotaan</h6>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Simpanan Pokok *</label>
                    <div class="input-group">
                        <span class="input-group-text">Rp</span>
                        <input type="number" 
                               name="simpanan_pokok" 
                               class="form-control" 
                               value="<?= esc($settings['simpanan_pokok'] ?? '50000') ?>" 
                               min="0" 
                               step="1000" 
                               required>
                    </div>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Simpanan Wajib (per bulan) *</label>
                    <div class="input-group">
                        <span class="input-group-text">Rp</span>
                        <input type="number" 
                               name="simpanan_wajib" 
                               class="form-control" 
                               value="<?= esc($settings['simpanan_wajib'] ?? '10000') ?>" 
                               min="0" 
                               step="1000" 
                               required>
                    </div>
                </div>
            </div>
            
            <div class="mb-3">
                <label class="form-label">Persyaratan Anggota</label>
                <textarea name="persyaratan_anggota" 
                          class="form-control" 
                          rows="5"><?= esc($settings['persyaratan_anggota'] ?? '') ?></textarea>
                <small class="text-muted">Gunakan enter untuk memisahkan setiap poin persyaratan</small>
            </div>
            
            <div class="mb-3">
                <label class="form-label">Manfaat Anggota</label>
                <textarea name="manfaat_anggota" 
                          class="form-control" 
                          rows="5"><?= esc($settings['manfaat_anggota'] ?? '') ?></textarea>
                <small class="text-muted">Gunakan enter untuk memisahkan setiap poin manfaat</small>
            </div>
        </div>
    </div>
    
    <!-- Struktur Organisasi -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Struktur Organisasi</h6>
        </div>
        <div class="card-body">
            <div class="mb-3">
                <label class="form-label">Struktur Organisasi</label>
                <textarea name="struktur_organisasi" 
                          class="form-control" 
                          rows="10" 
                          id="strukturEditor"><?= $settings['struktur_organisasi'] ?? '' ?></textarea>
                <small class="text-muted">Anda bisa menggunakan HTML untuk format yang lebih baik</small>
            </div>
        </div>
    </div>
    
    <!-- Tombol Simpan -->
    <div class="text-center mb-5">
        <button type="submit" class="btn btn-danger btn-lg px-5">
            <i class="fas fa-save me-2"></i>Simpan Pengaturan
        </button>
    </div>
</form>

<?= $this->section('page-scripts') ?>
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('strukturEditor', {
        height: 300
    });
</script>
<?= $this->endSection() ?>
<?= $this->endSection() ?>