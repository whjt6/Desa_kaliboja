<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Statistik Koperasi</h1>
    <button onclick="window.print()" class="d-none d-sm-inline-block btn btn-sm btn-info shadow-sm">
        <i class="fas fa-print fa-sm text-white-50"></i> Cetak
    </button>
</div>

<!-- Stats Cards -->
<div class="row">
    <!-- Statistik Anggota -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-danger shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                            Total Anggota</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?= number_format($statistik_anggota['aktif'] + $statistik_anggota['nonaktif'] + $statistik_anggota['keluar']) ?>
                        </div>
                        <div class="mt-2">
                            <span class="badge bg-success">Aktif: <?= $statistik_anggota['aktif'] ?? 0 ?></span>
                            <span class="badge bg-warning">Nonaktif: <?= $statistik_anggota['nonaktif'] ?? 0 ?></span>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-users fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistik Simpanan -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Total Simpanan</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            Rp <?= number_format(($statistik_simpanan['pokok'] ?? 0) + ($statistik_simpanan['wajib'] ?? 0) + ($statistik_simpanan['sukarela'] ?? 0), 0, ',', '.') ?>
                        </div>
                        <div class="mt-2 small">
                            <div>Pokok: Rp <?= number_format($statistik_simpanan['pokok'] ?? 0, 0, ',', '.') ?></div>
                            <div>Wajib: Rp <?= number_format($statistik_simpanan['wajib'] ?? 0, 0, ',', '.') ?></div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-money-bill-wave fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistik Unit -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Unit Usaha</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?= number_format($statistik_unit ? array_sum(array_values($statistik_unit)) : 0) ?>
                        </div>
                        <div class="mt-2">
                            <?php if(!empty($statistik_unit)): ?>
                                <?php foreach(array_slice($statistik_unit, 0, 2) as $kat => $total): ?>
                                    <span class="badge bg-info"><?= ucfirst($kat) ?>: <?= $total ?></span>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-boxes fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Pendaftaran -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Pendaftaran Baru</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">30</div>
                        <div class="mt-2">
                            <span class="badge bg-warning">Bulan ini: 5</span>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-user-plus fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Grafik -->
<div class="row">
    <!-- Grafik Pendaftaran Anggota -->
    <div class="col-xl-6 col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Grafik Pendaftaran Anggota</h6>
            </div>
            <div class="card-body">
                <div class="chart-area">
                    <canvas id="anggotaChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Grafik Simpanan -->
    <div class="col-xl-6 col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Grafik Simpanan</h6>
            </div>
            <div class="card-body">
                <div class="chart-area">
                    <canvas id="simpananChart"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Detail Statistik -->
<div class="row">
    <!-- Distribusi Status Anggota -->
    <div class="col-xl-4 col-lg-4">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Distribusi Status Anggota</h6>
            </div>
            <div class="card-body">
                <div class="chart-pie pt-4">
                    <canvas id="statusAnggotaChart"></canvas>
                </div>
                <div class="mt-4 text-center small">
                    <span class="mr-2">
                        <i class="fas fa-circle text-success"></i> Aktif
                    </span>
                    <span class="mr-2">
                        <i class="fas fa-circle text-warning"></i> Nonaktif
                    </span>
                    <span class="mr-2">
                        <i class="fas fa-circle text-danger"></i> Keluar
                    </span>
                </div>
            </div>
        </div>
    </div>

    <!-- Distribusi Unit Usaha -->
    <div class="col-xl-4 col-lg-4">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Distribusi Unit Usaha</h6>
            </div>
            <div class="card-body">
                <div class="chart-pie pt-4">
                    <canvas id="unitUsahaChart"></canvas>
                </div>
                <div class="mt-4 text-center small">
                    <?php if(!empty($statistik_unit)): ?>
                        <?php 
                        $colors = ['primary', 'success', 'info', 'warning', 'danger', 'secondary'];
                        $i = 0;
                        foreach($statistik_unit as $kat => $total): 
                            if($i >= 6) break;
                        ?>
                        <span class="mr-2">
                            <i class="fas fa-circle text-<?= $colors[$i] ?>"></i> <?= ucfirst($kat) ?>
                        </span>
                        <?php $i++; endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Top 5 Anggota -->
    <div class="col-xl-4 col-lg-4">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Top 5 Simpanan Terbesar</h6>
            </div>
            <div class="card-body">
                <div class="list-group">
                    <?php for($i = 1; $i <= 5; $i++): ?>
                    <div class="list-group-item list-group-item-action">
                        <div class="d-flex w-100 justify-content-between">
                            <h6 class="mb-1">Anggota <?= $i ?></h6>
                            <small class="text-muted">Rp <?= number_format(rand(500000, 2000000), 0, ',', '.') ?></small>
                        </div>
                        <small class="text-muted">Total simpanan pokok dan wajib</small>
                    </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->section('page-scripts') ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Grafik Pendaftaran Anggota
var ctx1 = document.getElementById('anggotaChart').getContext('2d');
var chartData1 = <?= json_encode($grafik_anggota ?? []) ?>;

var labels1 = chartData1.map(item => item.bulan);
var data1 = chartData1.map(item => item.total);

var anggotaChart = new Chart(ctx1, {
    type: 'line',
    data: {
        labels: labels1,
        datasets: [{
            label: 'Jumlah Pendaftar',
            data: data1,
            backgroundColor: 'rgba(220, 53, 69, 0.05)',
            borderColor: 'rgba(220, 53, 69, 1)',
            borderWidth: 2,
            pointBackgroundColor: 'rgba(220, 53, 69, 1)',
            pointBorderColor: '#fff',
            tension: 0.4
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

// Grafik Simpanan
var ctx2 = document.getElementById('simpananChart').getContext('2d');
var chartData2 = <?= json_encode($grafik_simpanan ?? []) ?>;

var labels2 = chartData2.map(item => item.bulan);
var data2 = chartData2.map(item => item.total);

var simpananChart = new Chart(ctx2, {
    type: 'bar',
    data: {
        labels: labels2,
        datasets: [{
            label: 'Total Simpanan (Rp)',
            data: data2,
            backgroundColor: 'rgba(40, 167, 69, 0.7)',
            borderColor: 'rgba(40, 167, 69, 1)',
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return 'Rp ' + value.toLocaleString('id-ID');
                    }
                }
            }
        }
    }
});

// Pie Chart Status Anggota
var ctx3 = document.getElementById('statusAnggotaChart').getContext('2d');
var statusAnggotaChart = new Chart(ctx3, {
    type: 'pie',
    data: {
        labels: ['Aktif', 'Nonaktif', 'Keluar'],
        datasets: [{
            data: [
                <?= $statistik_anggota['aktif'] ?? 0 ?>,
                <?= $statistik_anggota['nonaktif'] ?? 0 ?>,
                <?= $statistik_anggota['keluar'] ?? 0 ?>
            ],
            backgroundColor: ['#1cc88a', '#f6c23e', '#e74a3b'],
            hoverBackgroundColor: ['#17a673', '#dda20a', '#be2617']
        }]
    },
    options: {
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false
            }
        }
    }
});

// Pie Chart Unit Usaha
var ctx4 = document.getElementById('unitUsahaChart').getContext('2d');
var unitData = <?= json_encode($statistik_unit ?? []) ?>;
var unitLabels = Object.keys(unitData).map(k => ucfirst(k));
var unitValues = Object.values(unitData);

var unitUsahaChart = new Chart(ctx4, {
    type: 'pie',
    data: {
        labels: unitLabels,
        datasets: [{
            data: unitValues,
            backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b', '#858796'],
            hoverBackgroundColor: ['#2e59d9', '#17a673', '#2c9faf', '#dda20a', '#be2617', '#6c757d']
        }]
    },
    options: {
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false
            }
        }
    }
});

function ucfirst(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}
</script>
<?= $this->endSection() ?>
<?= $this->endSection() ?>