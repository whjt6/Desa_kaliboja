<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Detail Pendaftaran</h1>
    <a href="<?= site_url('dashboard/koperasi/pendaftaran') ?>" class="d-none d-sm-inline-block btn btn-sm btn-secondary shadow-sm">
        <i class="fas fa-arrow-left fa-sm text-white-50"></i> Kembali
    </a>
</div>

<div class="row">
    <!-- Data Pribadi -->
    <div class="col-lg-8">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Data Pribadi</h6>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <tr>
                        <td width="200"><strong>Kode Pendaftaran</strong></td>
                        <td><?= esc($pendaftaran['kode_pendaftaran']) ?></td>
                    </tr>
                    <tr>
                        <td><strong>Nama Lengkap</strong></td>
                        <td><?= esc($pendaftaran['nama']) ?></td>
                    </tr>
                    <tr>
                        <td><strong>NIK</strong></td>
                        <td><?= esc($pendaftaran['nik']) ?></td>
                    </tr>
                    <tr>
                        <td><strong>Tempat, Tanggal Lahir</strong></td>
                        <td><?= esc($pendaftaran['tempat_lahir']) ?>, <?= date('d/m/Y', strtotime($pendaftaran['tanggal_lahir'])) ?></td>
                    </tr>
                    <tr>
                        <td><strong>Jenis Kelamin</strong></td>
                        <td><?= ($pendaftaran['jenis_kelamin'] == 'L') ? 'Laki-laki' : 'Perempuan' ?></td>
                    </tr>
                    <tr>
                        <td><strong>Alamat</strong></td>
                        <td><?= esc($pendaftaran['alamat']) ?></td>
                    </tr>
                    <tr>
                        <td><strong>No. HP</strong></td>
                        <td><?= esc($pendaftaran['no_hp']) ?></td>
                    </tr>
                    <tr>
                        <td><strong>Email</strong></td>
                        <td><?= esc($pendaftaran['email']) ?></td>
                    </tr>
                    <tr>
                        <td><strong>Pekerjaan</strong></td>
                        <td><?= esc($pendaftaran['pekerjaan']) ?></td>
                    </tr>
                </table>
            </div>
        </div>

        <!-- Simpanan -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Simpanan</h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="card border-left-primary shadow h-100 py-2 mb-3">
                            <div class="card-body">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                    Simpanan Pokok</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    Rp <?= number_format($pendaftaran['simpanan_pokok'], 0, ',', '.') ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card border-left-success shadow h-100 py-2 mb-3">
                            <div class="card-body">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                    Simpanan Wajib</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    Rp <?= number_format($pendaftaran['simpanan_wajib'], 0, ',', '.') ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Foto & Status -->
    <div class="col-lg-4">
        <!-- Foto -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Foto</h6>
            </div>
            <div class="card-body text-center">
                <div class="mb-4">
                    <h6>Foto KTP</h6>
                    <img src="<?= base_url('uploads/koperasi/ktp/' . $pendaftaran['foto_ktp']) ?>" 
                         class="img-fluid rounded border" 
                         style="max-height: 200px;"
                         alt="Foto KTP"
                         onerror="this.src='<?= base_url('img/default-ktp.png') ?>'">
                </div>
                <div>
                    <h6>Foto Diri</h6>
                    <img src="<?= base_url('uploads/koperasi/foto/' . $pendaftaran['foto_diri']) ?>" 
                         class="img-fluid rounded border" 
                         style="max-height: 200px;"
                         alt="Foto Diri"
                         onerror="this.src='<?= base_url('img/default-profile.png') ?>'">
                </div>
            </div>
        </div>

        <!-- Status & Aksi -->
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Status & Aksi</h6>
            </div>
            <div class="card-body">
                <div class="mb-4">
                    <h6>Status:</h6>
                    <?php if($pendaftaran['status'] == 'pending'): ?>
                    <span class="badge bg-warning fs-6">Pending</span>
                    <?php elseif($pendaftaran['status'] == 'approved'): ?>
                    <span class="badge bg-success fs-6">Disetujui</span>
                    <?php elseif($pendaftaran['status'] == 'rejected'): ?>
                    <span class="badge bg-danger fs-6">Ditolak</span>
                    <?php endif; ?>
                    
                    <?php if($pendaftaran['status'] == 'approved' && $pendaftaran['approved_at']): ?>
                    <p class="mt-2 mb-0">
                        <small>Disetujui pada: <?= date('d/m/Y H:i', strtotime($pendaftaran['approved_at'])) ?></small>
                    </p>
                    <?php elseif($pendaftaran['status'] == 'rejected' && $pendaftaran['rejected_at']): ?>
                    <p class="mt-2 mb-0">
                        <small>Ditolak pada: <?= date('d/m/Y H:i', strtotime($pendaftaran['rejected_at'])) ?></small>
                    </p>
                    <?php endif; ?>
                </div>

                <?php if($pendaftaran['status'] == 'pending'): ?>
                <div class="d-grid gap-2">
                    <form action="<?= site_url('dashboard/koperasi/pendaftaran/approve/' . $pendaftaran['id']) ?>" 
                          method="post">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-success w-100 mb-2" 
                                onclick="return confirm('Setujui pendaftaran ini?')">
                            <i class="fas fa-check me-1"></i>Setujui Pendaftaran
                        </button>
                    </form>
                    
                    <button type="button" class="btn btn-danger w-100" data-bs-toggle="modal" data-bs-target="#rejectModal">
                        <i class="fas fa-times me-1"></i>Tolak Pendaftaran
                    </button>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Reject Modal -->
<div class="modal fade" id="rejectModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Alasan Penolakan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?= site_url('dashboard/koperasi/pendaftaran/reject/' . $pendaftaran['id']) ?>" method="post">
                <div class="modal-body">
                    <?= csrf_field() ?>
                    <div class="mb-3">
                        <label class="form-label">Alasan Penolakan *</label>
                        <textarea name="reason" class="form-control" rows="3" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-danger">Tolak Pendaftaran</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?= $this->endSection() ?>