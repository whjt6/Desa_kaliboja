<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Manajemen Pendaftaran Anggota</h1>
    <div>
        <a href="<?= site_url('dashboard/koperasi') ?>" class="d-none d-sm-inline-block btn btn-sm btn-secondary shadow-sm">
            <i class="fas fa-arrow-left fa-sm text-white-50"></i> Kembali
        </a>
    </div>
</div>

<!-- Filter -->
<div class="card shadow mb-4">
    <div class="card-body">
        <form method="get" action="<?= site_url('dashboard/koperasi/pendaftaran') ?>" class="row">
            <div class="col-md-4">
                <select name="status" class="form-select" onchange="this.form.submit()">
                    <option value="">Semua Status</option>
                    <option value="pending" <?= ($currentStatus == 'pending') ? 'selected' : '' ?>>Pending</option>
                    <option value="approved" <?= ($currentStatus == 'approved') ? 'selected' : '' ?>>Disetujui</option>
                    <option value="rejected" <?= ($currentStatus == 'rejected') ? 'selected' : '' ?>>Ditolak</option>
                </select>
            </div>
        </form>
    </div>
</div>

<!-- Table -->
<div class="card shadow">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Daftar Pendaftaran</h6>
    </div>
    <div class="card-body">
        <?php if(!empty($pendaftaran)): ?>
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Nama</th>
                        <th>NIK</th>
                        <th>Tanggal Daftar</th>
                        <th>Simpanan</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($pendaftaran as $p): ?>
                    <tr>
                        <td><strong><?= esc($p['kode_pendaftaran']) ?></strong></td>
                        <td><?= esc($p['nama']) ?></td>
                        <td><?= esc($p['nik']) ?></td>
                        <td><?= date('d/m/Y', strtotime($p['created_at'])) ?></td>
                        <td>
                            Pokok: Rp <?= number_format($p['simpanan_pokok'], 0, ',', '.') ?><br>
                            Wajib: Rp <?= number_format($p['simpanan_wajib'], 0, ',', '.') ?>
                        </td>
                        <td>
                            <?php if($p['status'] == 'pending'): ?>
                            <span class="badge bg-warning">Pending</span>
                            <?php elseif($p['status'] == 'approved'): ?>
                            <span class="badge bg-success">Disetujui</span>
                            <?php elseif($p['status'] == 'rejected'): ?>
                            <span class="badge bg-danger">Ditolak</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?= site_url('dashboard/koperasi/pendaftaran/detail/' . $p['id']) ?>" 
                                   class="btn btn-sm btn-info" title="Detail">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <?php if($p['status'] == 'pending'): ?>
                                <button type="button" class="btn btn-sm btn-success" 
                                        onclick="approvePendaftaran(<?= $p['id'] ?>)"
                                        title="Setujui">
                                    <i class="fas fa-check"></i>
                                </button>
                                <button type="button" class="btn btn-sm btn-danger" 
                                        onclick="rejectPendaftaran(<?= $p['id'] ?>)"
                                        title="Tolak">
                                    <i class="fas fa-times"></i>
                                </button>
                                <?php endif; ?>
                                <form action="<?= site_url('dashboard/koperasi/pendaftaran/delete/' . $p['id']) ?>" 
                                      method="post" 
                                      class="d-inline"
                                      onsubmit="return confirm('Hapus pendaftaran ini?')">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Hapus">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="text-center py-4">
            <i class="fas fa-user-clock fa-3x text-muted mb-3"></i>
            <p class="text-muted">Belum ada pendaftaran</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modal Reject -->
<div class="modal fade" id="rejectModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Alasan Penolakan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="rejectForm" method="post">
                <div class="modal-body">
                    <?= csrf_field() ?>
                    <input type="hidden" name="_method" value="POST">
                    <div class="mb-3">
                        <label class="form-label">Alasan Penolakan</label>
                        <textarea name="reason" class="form-control" rows="3" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-danger">Tolak Pendaftaran</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
let currentPendaftaranId = null;

function approvePendaftaran(id) {
    if (confirm('Setujui pendaftaran ini?')) {
        window.location.href = '<?= site_url('dashboard/koperasi/pendaftaran/approve/') ?>' + id;
    }
}

function rejectPendaftaran(id) {
    currentPendaftaranId = id;
    const modal = new bootstrap.Modal(document.getElementById('rejectModal'));
    modal.show();
}

document.getElementById('rejectForm').addEventListener('submit', function(e) {
    e.preventDefault();
    if (currentPendaftaranId) {
        this.action = '<?= site_url('dashboard/koperasi/pendaftaran/reject/') ?>' + currentPendaftaranId;
        this.submit();
    }
});
</script>
<?= $this->endSection() ?>