<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?= $title ?></h1>
    <a href="<?= site_url('dashboard/koperasi/anggota') ?>" class="d-none d-sm-inline-block btn btn-sm btn-secondary shadow-sm">
        <i class="fas fa-arrow-left fa-sm text-white-50"></i> Kembali
    </a>
</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <form method="post" action="<?= isset($anggota) ? site_url('dashboard/koperasi/anggota/update/' . $anggota['id']) : site_url('dashboard/koperasi/anggota/store') ?>">
            <?= csrf_field() ?>
            <?php if(isset($anggota)): ?>
            <input type="hidden" name="_method" value="PUT">
            <?php endif; ?>

            <div class="row">
                <!-- Kode Anggota -->
                <!-- Kode Anggota -->
<div class="col-md-6 mb-3">
    <label class="form-label">Kode Anggota *</label>
    <input type="text" 
           name="kode_anggota" 
           class="form-control" 
           value="<?= old('kode_anggota', $anggota['kode_anggota'] ?? 'KA-' . date('Ym') . '-' . str_pad((isset($anggota) ? 1 : 1), 4, '0', STR_PAD_LEFT)) ?>" 
           <?= isset($anggota) ? 'readonly' : '' ?>
           required>
    <small class="text-muted">Kode otomatis dihasilkan sistem</small>
</div>

                <!-- Nama -->
                <div class="col-md-6 mb-3">
                    <label class="form-label">Nama Lengkap *</label>
                    <input type="text" 
                           name="nama" 
                           class="form-control <?= $validation->hasError('nama') ? 'is-invalid' : '' ?>" 
                           value="<?= old('nama', $anggota['nama'] ?? '') ?>" 
                           required>
                    <?php if($validation->hasError('nama')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('nama') ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row">
                <!-- NIK -->
                <div class="col-md-6 mb-3">
                    <label class="form-label">NIK *</label>
                    <input type="text" 
                           name="nik" 
                           class="form-control <?= $validation->hasError('nik') ? 'is-invalid' : '' ?>" 
                           value="<?= old('nik', $anggota['nik'] ?? '') ?>" 
                           maxlength="16" 
                           required>
                    <?php if($validation->hasError('nik')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('nik') ?></div>
                    <?php endif; ?>
                </div>

                <!-- Tempat Lahir -->
                <div class="col-md-6 mb-3">
                    <label class="form-label">Tempat Lahir *</label>
                    <input type="text" 
                           name="tempat_lahir" 
                           class="form-control <?= $validation->hasError('tempat_lahir') ? 'is-invalid' : '' ?>" 
                           value="<?= old('tempat_lahir', $anggota['tempat_lahir'] ?? '') ?>" 
                           required>
                    <?php if($validation->hasError('tempat_lahir')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('tempat_lahir') ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row">
                <!-- Tanggal Lahir -->
                <div class="col-md-6 mb-3">
                    <label class="form-label">Tanggal Lahir *</label>
                    <input type="date" 
                           name="tanggal_lahir" 
                           class="form-control <?= $validation->hasError('tanggal_lahir') ? 'is-invalid' : '' ?>" 
                           value="<?= old('tanggal_lahir', $anggota['tanggal_lahir'] ?? '') ?>" 
                           required>
                    <?php if($validation->hasError('tanggal_lahir')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('tanggal_lahir') ?></div>
                    <?php endif; ?>
                </div>

                <!-- Jenis Kelamin -->
                <div class="col-md-6 mb-3">
                    <label class="form-label">Jenis Kelamin *</label>
                    <select name="jenis_kelamin" 
                            class="form-select <?= $validation->hasError('jenis_kelamin') ? 'is-invalid' : '' ?>" 
                            required>
                        <option value="">Pilih</option>
                        <option value="L" <?= (old('jenis_kelamin', $anggota['jenis_kelamin'] ?? '') == 'L') ? 'selected' : '' ?>>Laki-laki</option>
                        <option value="P" <?= (old('jenis_kelamin', $anggota['jenis_kelamin'] ?? '') == 'P') ? 'selected' : '' ?>>Perempuan</option>
                    </select>
                    <?php if($validation->hasError('jenis_kelamin')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('jenis_kelamin') ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row">
                <!-- Alamat -->
                <div class="col-12 mb-3">
                    <label class="form-label">Alamat Lengkap *</label>
                    <textarea name="alamat" 
                              class="form-control <?= $validation->hasError('alamat') ? 'is-invalid' : '' ?>" 
                              rows="3" 
                              required><?= old('alamat', $anggota['alamat'] ?? '') ?></textarea>
                    <?php if($validation->hasError('alamat')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('alamat') ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row">
                <!-- No HP -->
                <div class="col-md-6 mb-3">
                    <label class="form-label">No. HP *</label>
                    <input type="text" 
                           name="no_hp" 
                           class="form-control <?= $validation->hasError('no_hp') ? 'is-invalid' : '' ?>" 
                           value="<?= old('no_hp', $anggota['no_hp'] ?? '') ?>" 
                           required>
                    <?php if($validation->hasError('no_hp')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('no_hp') ?></div>
                    <?php endif; ?>
                </div>

                <!-- Email -->
                <div class="col-md-6 mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" 
                           name="email" 
                           class="form-control <?= $validation->hasError('email') ? 'is-invalid' : '' ?>" 
                           value="<?= old('email', $anggota['email'] ?? '') ?>">
                    <?php if($validation->hasError('email')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('email') ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row">
                <!-- Pekerjaan -->
                <div class="col-md-6 mb-3">
                    <label class="form-label">Pekerjaan *</label>
                    <input type="text" 
                           name="pekerjaan" 
                           class="form-control <?= $validation->hasError('pekerjaan') ? 'is-invalid' : '' ?>" 
                           value="<?= old('pekerjaan', $anggota['pekerjaan'] ?? '') ?>" 
                           required>
                    <?php if($validation->hasError('pekerjaan')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('pekerjaan') ?></div>
                    <?php endif; ?>
                </div>

                <!-- Tanggal Daftar -->
                <div class="col-md-6 mb-3">
                    <label class="form-label">Tanggal Daftar *</label>
                    <input type="date" 
                           name="tanggal_daftar" 
                           class="form-control <?= $validation->hasError('tanggal_daftar') ? 'is-invalid' : '' ?>" 
                           value="<?= old('tanggal_daftar', $anggota['tanggal_daftar'] ?? date('Y-m-d')) ?>" 
                           required>
                    <?php if($validation->hasError('tanggal_daftar')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('tanggal_daftar') ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row">
                <!-- Simpanan Pokok -->
                <div class="col-md-6 mb-3">
                    <label class="form-label">Simpanan Pokok *</label>
                    <div class="input-group">
                        <span class="input-group-text">Rp</span>
                        <input type="number" 
                               name="simpanan_pokok" 
                               class="form-control <?= $validation->hasError('simpanan_pokok') ? 'is-invalid' : '' ?>" 
                               value="<?= old('simpanan_pokok', $anggota['simpanan_pokok'] ?? 50000) ?>" 
                               min="50000" 
                               step="10000" 
                               required>
                    </div>
                    <?php if($validation->hasError('simpanan_pokok')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('simpanan_pokok') ?></div>
                    <?php endif; ?>
                </div>

                <!-- Simpanan Wajib -->
                <div class="col-md-6 mb-3">
                    <label class="form-label">Simpanan Wajib *</label>
                    <div class="input-group">
                        <span class="input-group-text">Rp</span>
                        <input type="number" 
                               name="simpanan_wajib" 
                               class="form-control <?= $validation->hasError('simpanan_wajib') ? 'is-invalid' : '' ?>" 
                               value="<?= old('simpanan_wajib', $anggota['simpanan_wajib'] ?? 10000) ?>" 
                               min="10000" 
                               step="5000" 
                               required>
                    </div>
                    <?php if($validation->hasError('simpanan_wajib')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('simpanan_wajib') ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Status -->
            <div class="mb-3">
                <label class="form-label">Status *</label>
                <select name="status" 
                        class="form-select <?= $validation->hasError('status') ? 'is-invalid' : '' ?>" 
                        required>
                    <option value="">Pilih Status</option>
                    <option value="aktif" <?= (old('status', $anggota['status'] ?? '') == 'aktif') ? 'selected' : '' ?>>Aktif</option>
                    <option value="nonaktif" <?= (old('status', $anggota['status'] ?? '') == 'nonaktif') ? 'selected' : '' ?>>Nonaktif</option>
                    <option value="keluar" <?= (old('status', $anggota['status'] ?? '') == 'keluar') ? 'selected' : '' ?>>Keluar</option>
                </select>
                <?php if($validation->hasError('status')): ?>
                <div class="invalid-feedback"><?= $validation->getError('status') ?></div>
                <?php endif; ?>
            </div>

            <!-- Tombol -->
            <div class="d-flex justify-content-between mt-4">
                <a href="<?= site_url('dashboard/koperasi/anggota') ?>" class="btn btn-secondary">
                    <i class="fas fa-times me-1"></i>Batal
                </a>
                <button type="submit" class="btn btn-danger">
                    <i class="fas fa-save me-1"></i>Simpan
                </button>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>