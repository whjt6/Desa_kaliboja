<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Manajemen Anggota</h1>
    <a href="<?= site_url('dashboard/koperasi/anggota/create') ?>" class="d-none d-sm-inline-block btn btn-sm btn-danger shadow-sm">
        <i class="fas fa-user-plus fa-sm text-white-50"></i> Tambah Anggota
    </a>
</div>

<!-- Filter -->
<div class="card shadow mb-4">
    <div class="card-body">
        <form method="get" action="<?= site_url('dashboard/koperasi/anggota') ?>" class="row">
            <div class="col-md-6 mb-2">
                <input type="text" 
                       name="search" 
                       class="form-control" 
                       placeholder="Cari nama/NIK/alamat..."
                       value="<?= esc($searchTerm ?? '') ?>">
            </div>
            <div class="col-md-4 mb-2">
                <select name="status" class="form-select">
                    <option value="">Semua Status</option>
                    <option value="aktif" <?= ($currentStatus == 'aktif') ? 'selected' : '' ?>>Aktif</option>
                    <option value="nonaktif" <?= ($currentStatus == 'nonaktif') ? 'selected' : '' ?>>Nonaktif</option>
                    <option value="keluar" <?= ($currentStatus == 'keluar') ? 'selected' : '' ?>>Keluar</option>
                </select>
            </div>
            <div class="col-md-2 mb-2">
                <button type="submit" class="btn btn-primary w-100">Filter</button>
            </div>
        </form>
    </div>
</div>

<!-- Table -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Daftar Anggota</h6>
    </div>
    <div class="card-body">
        <?php if(!empty($anggota)): ?>
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Nama</th>
                        <th>NIK</th>
                        <th>Alamat</th>
                        <th>Tanggal Daftar</th>
                        <th>Simpanan</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($anggota as $row): ?>
                    <tr>
                        <td>
                            <strong><?= esc($row['kode_anggota']) ?></strong>
                        </td>
                        <td>
                            <strong><?= esc($row['nama']) ?></strong><br>
                            <small class="text-muted"><?= esc($row['no_hp']) ?></small>
                        </td>
                        <td><?= esc($row['nik']) ?></td>
                        <td><?= character_limiter($row['alamat'], 30) ?></td>
                        <td><?= date('d/m/Y', strtotime($row['tanggal_daftar'])) ?></td>
                        <td>
                            Pokok: <strong>Rp <?= number_format($row['simpanan_pokok'], 0, ',', '.') ?></strong><br>
                            Wajib: <strong>Rp <?= number_format($row['simpanan_wajib'], 0, ',', '.') ?></strong>
                        </td>
                        <td>
                            <?php if($row['status'] == 'aktif'): ?>
                            <span class="badge bg-success">Aktif</span>
                            <?php elseif($row['status'] == 'nonaktif'): ?>
                            <span class="badge bg-warning">Nonaktif</span>
                            <?php else: ?>
                            <span class="badge bg-danger">Keluar</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?= site_url('dashboard/koperasi/anggota/edit/' . $row['id']) ?>" 
                                   class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="<?= site_url('dashboard/koperasi/simpanan/detail/' . $row['id']) ?>" 
                                   class="btn btn-sm btn-info">
                                    <i class="fas fa-money-check-alt"></i>
                                </a>
                                <form action="<?= site_url('dashboard/koperasi/anggota/delete/' . $row['id']) ?>" 
                                      method="post" 
                                      class="d-inline"
                                      onsubmit="return confirm('Hapus anggota ini?')">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-sm btn-danger">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="text-center py-4">
            <i class="fas fa-users fa-3x text-muted mb-3"></i>
            <p class="text-muted">Belum ada data anggota</p>
            <a href="<?= site_url('dashboard/koperasi/anggota/create') ?>" class="btn btn-danger">
                <i class="fas fa-user-plus me-1"></i>Tambah Anggota Pertama
            </a>
        </div>
        <?php endif; ?>
    </div>
    <div class="card-footer">
        <a href="<?= site_url('dashboard/koperasi/anggota/export') ?>" class="btn btn-success">
            <i class="fas fa-file-excel me-1"></i>Export to Excel
        </a>
    </div>
</div>
<?= $this->endSection() ?>