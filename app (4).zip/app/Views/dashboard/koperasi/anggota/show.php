<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Detail Anggota</h1>
<div>
<a href="<?= site_url('dashboard/koperasi/anggota/edit/' . $anggota['id']) ?>" 
        class="btn btn-sm btn-warning">
<i class="fas fa-edit"></i> Edit
</a>
<a href="<?= site_url('dashboard/koperasi/anggota') ?>" 
        class="btn btn-sm btn-secondary">
<i class="fas fa-arrow-left"></i> Kembali
</a>
</div>
</div>
<div class="row">
    <div class="col-lg-8">
        <!-- Data Pribadi -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Data Pribadi</h6>
            </div>
            <div class="card-body">
                <table class="table table-borderless">
                    <tr>
                        <td width="200"><strong>Kode Anggota</strong></td>
                        <td>: <?= esc($anggota['kode_anggota']) ?></td>
                    </tr>
                    <tr>
                        <td><strong>Nama</strong></td>
                        <td>: <?= esc($anggota['nama']) ?></td>
                    </tr>
                    <tr>
                        <td><strong>NIK</strong></td>
                        <td>: <?= esc($anggota['nik']) ?></td>
                    </tr>
                    <tr>
                        <td><strong>Tempat, Tanggal Lahir</strong></td>
                        <td>: <?= esc($anggota['tempat_lahir']) ?>, <?= date('d/m/Y', strtotime($anggota['tanggal_lahir'])) ?></td>
                    </tr>
                    <tr>
                        <td><strong>Jenis Kelamin</strong></td>
                        <td>: <?= $anggota['jenis_kelamin'] == 'L' ? 'Laki-laki' : 'Perempuan' ?></td>
                    </tr>
                    <tr>
                        <td><strong>Alamat</strong></td>
                        <td>: <?= esc($anggota['alamat']) ?></td>
                    </tr>
                    <tr>
                        <td><strong>No. HP</strong></td>
                        <td>: <?= esc($anggota['no_hp']) ?></td>
                    </tr>
                    <tr>
                        <td><strong>Email</strong></td>
                        <td>: <?= esc($anggota['email'] ?? '-') ?></td>
                    </tr>
                    <tr>
                        <td><strong>Pekerjaan</strong></td>
                        <td>: <?= esc($anggota['pekerjaan']) ?></td>
                    </tr>
                    <tr>
                        <td><strong>Tanggal Daftar</strong></td>
                        <td>: <?= date('d/m/Y', strtotime($anggota['tanggal_daftar'])) ?></td>
                    </tr>
                    <tr>
                        <td><strong>Status</strong></td>
                        <td>: 
                            <?php if($anggota['status'] == 'aktif'): ?>
                            <span class="badge bg-success">Aktif</span>
                            <?php elseif($anggota['status'] == 'nonaktif'): ?>
                            <span class="badge bg-warning">Nonaktif</span>
                            <?php else: ?>
                            <span class="badge bg-danger">Keluar</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
<div class="col-lg-4">
    <!-- Simpanan -->
    <div class="card border-left-primary shadow mb-4">
        <div class="card-body">
            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                Simpanan Pokok</div>
            <div class="h5 mb-0 font-weight-bold text-gray-800">
                Rp <?= number_format($anggota['simpanan_pokok'], 0, ',', '.') ?>
            </div>
        </div>
    </div>

    <div class="card border-left-success shadow mb-4">
        <div class="card-body">
            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                Simpanan Wajib</div>
            <div class="h5 mb-0 font-weight-bold text-gray-800">
                Rp <?= number_format($anggota['simpanan_wajib'], 0, ',', '.') ?>
            </div>
        </div>
    </div>

    <!-- Actions -->
    <div class="card shadow">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Aksi</h6>
        </div>
        <div class="card-body">
            <div class="d-grid gap-2">
                <a href="<?= site_url('dashboard/koperasi/simpanan/detail/' . $anggota['id']) ?>" 
                   class="btn btn-info">
                    <i class="fas fa-money-check-alt me-1"></i>Lihat Simpanan
                </a>
                <a href="<?= site_url('dashboard/koperasi/anggota/edit/' . $anggota['id']) ?>" 
                   class="btn btn-warning">
                    <i class="fas fa-edit me-1"></i>Edit Data
                </a>
                <form action="<?= site_url('dashboard/koperasi/anggota/delete/' . $anggota['id']) ?>" 
                      method="post"
                      onsubmit="return confirm('Hapus anggota ini?')">
                    <?= csrf_field() ?>
                    <input type="hidden" name="_method" value="DELETE">
                    <button type="submit" class="btn btn-danger w-100">
                        <i class="fas fa-trash me-1"></i>Hapus Anggota
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
<?= $this->endSection() ?>