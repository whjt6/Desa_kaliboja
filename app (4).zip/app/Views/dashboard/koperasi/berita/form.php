<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?= $title ?></h1>
    <a href="<?= site_url('dashboard/koperasi/berita') ?>" class="d-none d-sm-inline-block btn btn-sm btn-secondary shadow-sm">
        <i class="fas fa-arrow-left fa-sm text-white-50"></i> Kembali
    </a>
</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <form method="post" 
              action="<?= isset($berita) ? site_url('dashboard/koperasi/berita/update/' . $berita['id']) : site_url('dashboard/koperasi/berita/store') ?>" 
              enctype="multipart/form-data">
            <?= csrf_field() ?>
            <?php if(isset($berita)): ?>
            <input type="hidden" name="_method" value="PUT">
            <?php endif; ?>

            <!-- Preview Gambar -->
            <?php if(isset($berita) && !empty($berita['gambar']) && file_exists(ROOTPATH . 'public/uploads/koperasi/berita/' . $berita['gambar'])): ?>
            <div class="row mb-4">
                <div class="col-12">
                    <label class="form-label">Gambar Saat Ini</label>
                    <div class="mb-3">
                        <img src="<?= base_url('uploads/koperasi/berita/' . $berita['gambar']) ?>" 
                             class="img-fluid rounded" 
                             style="max-height: 200px;"
                             alt="Gambar saat ini">
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Judul -->
            <div class="mb-3">
                <label class="form-label">Judul Berita *</label>
                <input type="text" 
                       name="judul" 
                       class="form-control <?= $validation->hasError('judul') ? 'is-invalid' : '' ?>" 
                       value="<?= old('judul', $berita['judul'] ?? '') ?>" 
                       required>
                <?php if($validation->hasError('judul')): ?>
                <div class="invalid-feedback"><?= $validation->getError('judul') ?></div>
                <?php endif; ?>
            </div>

            <!-- Konten -->
            <div class="mb-3">
                <label class="form-label">Konten *</label>
                <textarea name="konten" 
                          class="form-control <?= $validation->hasError('konten') ? 'is-invalid' : '' ?>" 
                          rows="10" 
                          id="kontenEditor"
                          required><?= old('konten', $berita['konten'] ?? '') ?></textarea>
                <?php if($validation->hasError('konten')): ?>
                <div class="invalid-feedback"><?= $validation->getError('konten') ?></div>
                <?php endif; ?>
            </div>

            <div class="row">
                <!-- Gambar -->
                <div class="col-md-6 mb-3">
                    <label class="form-label"><?= isset($berita) ? 'Gambar Baru' : 'Gambar *' ?></label>
                    <input type="file" 
                           name="gambar" 
                           class="form-control <?= $validation->hasError('gambar') ? 'is-invalid' : '' ?>" 
                           accept="image/*" 
                           <?= !isset($berita) ? 'required' : '' ?>>
                    <?php if($validation->hasError('gambar')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('gambar') ?></div>
                    <?php endif; ?>
                    <small class="text-muted">Format: JPG/PNG, maksimal 2MB</small>
                </div>

                <!-- Status -->
                <div class="col-md-6 mb-3">
                    <label class="form-label">Status *</label>
                    <select name="status" 
                            class="form-select <?= $validation->hasError('status') ? 'is-invalid' : '' ?>" 
                            required>
                        <option value="draft" <?= (old('status', $berita['status'] ?? '') == 'draft') ? 'selected' : '' ?>>Draft</option>
                        <option value="published" <?= (old('status', $berita['status'] ?? '') == 'published') ? 'selected' : '' ?>>Published</option>
                    </select>
                    <?php if($validation->hasError('status')): ?>
                    <div class="invalid-feedback"><?= $validation->getError('status') ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Tombol -->
            <div class="d-flex justify-content-between mt-4">
                <a href="<?= site_url('dashboard/koperasi/berita') ?>" class="btn btn-secondary">
                    <i class="fas fa-times me-1"></i>Batal
                </a>
                <button type="submit" class="btn btn-danger">
                    <i class="fas fa-save me-1"></i>Simpan
                </button>
            </div>
        </form>
    </div>
</div>

<?= $this->section('page-scripts') ?>
<!-- CKEditor (opsional) -->
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('kontenEditor', {
        height: 300
    });
</script>
<?= $this->endSection() ?>
<?= $this->endSection() ?>