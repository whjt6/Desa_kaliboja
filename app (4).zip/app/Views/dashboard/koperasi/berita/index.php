<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Manajemen Berita Koperasi</h1>
    <a href="<?= site_url('dashboard/koperasi/berita/create') ?>" class="d-none d-sm-inline-block btn btn-sm btn-danger shadow-sm">
        <i class="fas fa-plus fa-sm text-white-50"></i> Tambah Berita
    </a>
</div>

<!-- Table -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Daftar Berita Koperasi</h6>
    </div>
    <div class="card-body">
        <?php if(!empty($berita)): ?>
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Gambar</th>
                        <th>Judul</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($berita as $b): ?>
                    <tr>
                        <td style="width: 100px;">
                            <?php if(!empty($b['gambar'])): ?>
                            <img src="<?= base_url('uploads/koperasi/berita/' . $b['gambar']) ?>" 
                                 class="img-fluid rounded" 
                                 style="width: 80px; height: 80px; object-fit: cover;"
                                 alt="<?= esc($b['judul']) ?>"
                                 onerror="this.src='https://via.placeholder.com/80x80?text=Gambar'">
                            <?php else: ?>
                            <div class="bg-light rounded d-flex align-items-center justify-content-center" 
                                 style="width: 80px; height: 80px;">
                                <i class="fas fa-newspaper text-muted"></i>
                            </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong><?= esc($b['judul']) ?></strong><br>
                            <small class="text-muted"><?= character_limiter(strip_tags($b['konten']), 50) ?></small>
                        </td>
                        <td>
                            <?php if($b['status'] == 'published'): ?>
                            <span class="badge bg-success">Published</span>
                            <?php else: ?>
                            <span class="badge bg-warning">Draft</span>
                            <?php endif; ?>
                        </td>
                        <td><?= date('d/m/Y', strtotime($b['created_at'])) ?></td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?= site_url('koperasi/berita/' . $b['slug']) ?>" 
                                   target="_blank" 
                                   class="btn btn-sm btn-info" title="Lihat">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="<?= site_url('dashboard/koperasi/berita/edit/' . $b['id']) ?>" 
                                   class="btn btn-sm btn-warning" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?= site_url('dashboard/koperasi/berita/delete/' . $b['id']) ?>" 
                                      method="post" 
                                      class="d-inline"
                                      onsubmit="return confirm('Hapus berita ini?')">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-sm btn-danger" title="Hapus">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="text-center py-4">
            <i class="fas fa-newspaper fa-3x text-muted mb-3"></i>
            <p class="text-muted">Belum ada berita</p>
            <a href="<?= site_url('dashboard/koperasi/berita/create') ?>" class="btn btn-danger">
                <i class="fas fa-plus me-1"></i>Tambah Berita Pertama
            </a>
        </div>
        <?php endif; ?>
    </div>
</div>
<?= $this->endSection() ?>