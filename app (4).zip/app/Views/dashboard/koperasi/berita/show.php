<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Detail Berita</h1>
    <div>
        <a href="<?= site_url('koperasi/berita/' . $berita['slug']) ?>" 
           target="_blank"
           class="btn btn-sm btn-info">
            <i class="fas fa-external-link-alt"></i> Lihat di Website
        </a>
        <a href="<?= site_url('dashboard/koperasi/berita/edit/' . $berita['id']) ?>" 
           class="btn btn-sm btn-warning">
            <i class="fas fa-edit"></i> Edit
        </a>
        <a href="<?= site_url('dashboard/koperasi/berita') ?>" 
           class="btn btn-sm btn-secondary">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Informasi Berita</h6>
            </div>
            <div class="card-body">
                <?php if(!empty($berita['gambar'])): ?>
                <div class="text-center mb-4">
                    <img src="<?= base_url('uploads/koperasi/berita/' . $berita['gambar']) ?>" 
                         class="img-fluid rounded"
                         style="max-height: 400px;"
                         alt="<?= esc($berita['judul']) ?>">
                </div>
                <?php endif; ?>

                <h2 class="mb-3"><?= esc($berita['judul']) ?></h2>
                
                <div class="d-flex gap-3 mb-4">
                    <span class="badge bg-<?= $berita['status'] == 'published' ? 'success' : 'secondary' ?>">
                        <?= $berita['status'] == 'published' ? 'Published' : 'Draft' ?>
                    </span>
                    <span class="text-muted">
                        <i class="far fa-calendar me-1"></i>
                        <?= date('d F Y, H:i', strtotime($berita['created_at'])) ?> WIB
                    </span>
                    <?php if(isset($berita['views'])): ?>
                    <span class="text-muted">
                        <i class="far fa-eye me-1"></i>
                        <?= number_format($berita['views']) ?> views
                    </span>
                    <?php endif; ?>
                </div>

                <div class="blog-content">
                    <?= $berita['konten'] ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.blog-content {
    line-height: 1.8;
    font-size: 1.05rem;
}
.blog-content img {
    max-width: 100%;
    height: auto;
    border-radius: 8px;
    margin: 1rem 0;
}
</style>
<?= $this->endSection() ?>