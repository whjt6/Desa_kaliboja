<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?= $title ?></h1>
        <div>
            <a href="<?= site_url('dashboard/posbindu/statistik') ?>" class="btn btn-info btn-sm mr-2">
                <i class="fas fa-chart-bar mr-2"></i>Statistik
            </a>
            <a href="<?= site_url('dashboard/posbindu/create') ?>" class="btn btn-primary btn-sm">
                <i class="fas fa-plus-circle mr-2"></i>Tambah Data
            </a>
        </div>
    </div>
    
    <!-- Filter -->
    <div class="card mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Filter Data</h6>
        </div>
        <div class="card-body">
            <form method="get" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Tahun</label>
                    <input type="number" name="tahun" class="form-control" value="<?= $tahun ?>" 
                           min="2020" max="<?= date('Y') ?>" placeholder="Tahun">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Dusun</label>
                    <select name="dusun" class="form-control">
                        <option value="">Semua Dusun</option>
                        <?php foreach($dusunList as $key => $name): ?>
                        <option value="<?= $key ?>" <?= $dusun == $key ? 'selected' : '' ?>><?= $name ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">&nbsp;</label><br>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter mr-2"></i>Filter
                    </button>
                    <a href="<?= site_url('dashboard/posbindu') ?>" class="btn btn-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Quick Stats -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Total Lansia</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= number_format($statistik['total_lansia'] ?? 0) ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-user-md fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-danger shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                Hipertensi</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= number_format($statistik['total_hipertensi'] ?? 0) ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-heartbeat fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Diabetes</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= number_format($statistik['total_diabetes'] ?? 0) ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-tint fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Rujukan</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= number_format($statistik['total_rujukan'] ?? 0) ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-ambulance fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Data Table -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">Data Posbindu Lansia Tahun <?= $tahun ?></h6>
            
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead class="bg-light">
                        <tr>
                            <th width="5%">#</th>
                            <th width="15%">Dusun</th>
                            <th width="15%">Bulan/Tahun</th>
                            <th width="10%">Lansia</th>
                            <th width="10%">Hipertensi</th>
                            <th width="10%">Diabetes</th>
                            <th width="10%">Obesitas</th>
                            <th width="10%">Rujukan</th>
                            <th width="15%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($posbindu)): ?>
                        <tr>
                            <td colspan="9" class="text-center py-4">
                                <i class="fas fa-database fa-2x text-muted mb-3"></i><br>
                                <span class="text-muted">Belum ada data posbindu</span><br>
                                <a href="<?= site_url('dashboard/posbindu/create') ?>" class="btn btn-primary btn-sm mt-2">
                                    <i class="fas fa-plus mr-1"></i> Tambah Data
                                </a>
                            </td>
                        </tr>
                        <?php else: ?>
                        <?php $no = 1; foreach($posbindu as $p): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td>
                                <span class="badge badge-primary"><?= $dusunList[$p['dusun']] ?></span>
                            </td>
                            <td>
                                <?= date('F Y', strtotime($p['bulan'] . '-01')) ?><br>
                                <small class="text-muted"><?= $p['tahun'] ?></small>
                            </td>
                            <td class="text-center">
                                <?= number_format($p['jumlah_lansia_total']) ?><br>
                                <small class="text-muted">L:<?= $p['jumlah_lansia_l'] ?> P:<?= $p['jumlah_lansia_p'] ?></small>
                            </td>
                            <td class="text-center">
                                <?php 
                                $hipertensi = $p['tekanan_darah_tingkat2'] + $p['tekanan_darah_tingkat3'];
                                echo number_format($hipertensi);
                                ?>
                                <div class="progress mb-1" style="height: 5px;">
                                    <?php 
                                    $hipertensiPercent = $p['jumlah_lansia_total'] > 0 ? ($hipertensi / $p['jumlah_lansia_total'] * 100) : 0;
                                    ?>
                                    <div class="progress-bar bg-danger" role="progressbar" 
                                         style="width: <?= min(100, $hipertensiPercent) ?>%">
                                    </div>
                                </div>
                            </td>
                            <td class="text-center">
                                <?= number_format($p['gula_darah_diabetes']) ?>
                                <div class="progress mb-1" style="height: 5px;">
                                    <?php 
                                    $diabetesPercent = $p['jumlah_lansia_total'] > 0 ? ($p['gula_darah_diabetes'] / $p['jumlah_lansia_total'] * 100) : 0;
                                    ?>
                                    <div class="progress-bar bg-warning" role="progressbar" 
                                         style="width: <?= min(100, $diabetesPercent) ?>%">
                                    </div>
                                </div>
                            </td>
                            <td class="text-center">
                                <?= number_format($p['imt_obesitas']) ?>
                                <div class="progress mb-1" style="height: 5px;">
                                    <?php 
                                    $obesitasPercent = $p['jumlah_lansia_total'] > 0 ? ($p['imt_obesitas'] / $p['jumlah_lansia_total'] * 100) : 0;
                                    ?>
                                    <div class="progress-bar bg-info" role="progressbar" 
                                         style="width: <?= min(100, $obesitasPercent) ?>%">
                                    </div>
                                </div>
                            </td>
                            <td class="text-center">
                                <span class="badge <?= $p['jumlah_rujukan'] > 0 ? 'badge-danger' : 'badge-success' ?>">
                                    <?= number_format($p['jumlah_rujukan']) ?>
                                </span>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="<?= site_url('dashboard/posbindu/show/' . $p['id']) ?>" 
   class="btn btn-sm btn-info" title="Detail">
    <i class="fas fa-eye"></i>
</a>
                                    <a href="<?= site_url('dashboard/posbindu/edit/' . $p['id']) ?>" 
                                       class="btn btn-sm btn-warning" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button onclick="confirmDelete(<?= $p['id'] ?>)" 
                                            class="btn btn-sm btn-danger" title="Hapus">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Konfirmasi Hapus</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Apakah Anda yakin ingin menghapus data ini?</p>
                <p class="text-danger"><small>Tindakan ini tidak dapat dibatalkan!</small></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                <form id="deleteForm" method="post" style="display: inline;">
                    <button type="submit" class="btn btn-danger">Hapus</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?= $this->section('page-scripts') ?>
<script>
function confirmDelete(id) {
    $('#deleteForm').attr('action', '<?= site_url('dashboard/posbindu/delete/') ?>' + id);
    $('#deleteModal').modal('show');
}

$(document).ready(function() {
    $('#dataTable').DataTable({
        "pageLength": 25,
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.25/i18n/Indonesian.json"
        }
    });
});
</script>
<?= $this->endSection() ?>
<?= $this->endSection() ?>