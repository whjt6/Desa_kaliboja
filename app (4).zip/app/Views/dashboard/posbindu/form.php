<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?= $title ?></h1>
        <a href="<?= site_url('dashboard/posbindu') ?>" class="btn btn-secondary btn-sm">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <div class="row">
        <div class="col-lg-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Form Data Posbindu Lansia</h6>
                </div>
                <div class="card-body">
                    <?php if(session()->getFlashdata('errors')): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach(session()->getFlashdata('errors') as $error): ?>
                                <li><?= $error ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    
                    <?php if(session()->getFlashdata('error')): ?>
                    <div class="alert alert-danger">
                        <?= session()->getFlashdata('error') ?>
                    </div>
                    <?php endif; ?>
                    
                    <form action="<?= isset($posbindu['id']) ? site_url('dashboard/posbindu/update/' . $posbindu['id']) : site_url('dashboard/posbindu/store') ?>" 
                          method="post">
                        <?= csrf_field() ?>
                        
                        <!-- Informasi Dasar -->
                        <div class="row mb-4">
                            <div class="col-md-12">
                                <h5 class="text-primary mb-3">
                                    <i class="fas fa-info-circle mr-2"></i>Informasi Dasar
                                </h5>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="dusun">Dusun <span class="text-danger">*</span></label>
                                    <select name="dusun" id="dusun" class="form-control" required>
                                        <option value="">Pilih Dusun</option>
                                        <?php foreach($dusunList as $key => $name): ?>
                                        <option value="<?= $key ?>" 
                                            <?= (isset($posbindu['dusun']) && $posbindu['dusun'] == $key) ? 'selected' : '' ?>>
                                            <?= $name ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="bulan">Bulan <span class="text-danger">*</span></label>
                                    <input type="month" name="bulan" id="bulan" class="form-control" 
                                           value="<?= isset($posbindu['bulan']) ? $posbindu['bulan'] : $bulanSekarang ?>" required>
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="tahun">Tahun <span class="text-danger">*</span></label>
                                    <input type="number" name="tahun" id="tahun" class="form-control" 
                                           value="<?= isset($posbindu['tahun']) ? $posbindu['tahun'] : date('Y') ?>" 
                                           min="2020" max="<?= date('Y') + 1 ?>" required>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Data Lansia -->
                        <div class="row mb-4">
                            <div class="col-md-12">
                                <h5 class="text-primary mb-3">
                                    <i class="fas fa-user-md mr-2"></i>Data Lansia
                                </h5>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="jumlah_lansia_l">Lansia Laki-laki</label>
                                    <input type="number" name="jumlah_lansia_l" id="jumlah_lansia_l" class="form-control" 
                                           value="<?= $posbindu['jumlah_lansia_l'] ?? 0 ?>" min="0">
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="jumlah_lansia_p">Lansia Perempuan</label>
                                    <input type="number" name="jumlah_lansia_p" id="jumlah_lansia_p" class="form-control" 
                                           value="<?= $posbindu['jumlah_lansia_p'] ?? 0 ?>" min="0">
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="jumlah_lansia_total">Total Lansia (Otomatis)</label>
                                    <input type="number" name="jumlah_lansia_total" id="jumlah_lansia_total" class="form-control" 
                                           value="<?= $posbindu['jumlah_lansia_total'] ?? 0 ?>" min="0" readonly>
                                    <small class="form-text text-muted">Akan dihitung otomatis</small>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Tekanan Darah -->
                        <div class="row mb-4">
                            <div class="col-md-12">
                                <h5 class="text-primary mb-3">
                                    <i class="fas fa-heartbeat mr-2"></i>Tekanan Darah (Hipertensi)
                                </h5>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="tekanan_darah_normal">Normal</label>
                                    <input type="number" name="tekanan_darah_normal" id="tekanan_darah_normal" class="form-control" 
                                           value="<?= $posbindu['tekanan_darah_normal'] ?? 0 ?>" min="0">
                                    <small class="form-text text-muted">120/80 mmHg</small>
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="tekanan_darah_tingkat1">Prahipertensi</label>
                                    <input type="number" name="tekanan_darah_tingkat1" id="tekanan_darah_tingkat1" class="form-control" 
                                           value="<?= $posbindu['tekanan_darah_tingkat1'] ?? 0 ?>" min="0">
                                    <small class="form-text text-muted">120-139/80-89</small>
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="tekanan_darah_tingkat2">Hipertensi Stage 1</label>
                                    <input type="number" name="tekanan_darah_tingkat2" id="tekanan_darah_tingkat2" class="form-control" 
                                           value="<?= $posbindu['tekanan_darah_tingkat2'] ?? 0 ?>" min="0">
                                    <small class="form-text text-muted">140-159/90-99</small>
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="tekanan_darah_tingkat3">Hipertensi Stage 2</label>
                                    <input type="number" name="tekanan_darah_tingkat3" id="tekanan_darah_tingkat3" class="form-control" 
                                           value="<?= $posbindu['tekanan_darah_tingkat3'] ?? 0 ?>" min="0">
                                    <small class="form-text text-muted">≥160/≥100</small>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Gula Darah -->
                        <div class="row mb-4">
                            <div class="col-md-12">
                                <h5 class="text-primary mb-3">
                                    <i class="fas fa-tint mr-2"></i>Gula Darah (Diabetes)
                                </h5>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="gula_darah_normal">Normal</label>
                                    <input type="number" name="gula_darah_normal" id="gula_darah_normal" class="form-control" 
                                           value="<?= $posbindu['gula_darah_normal'] ?? 0 ?>" min="0">
                                    <small class="form-text text-muted">< 140 mg/dL</small>
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="gula_darah_pradiabetes">Pradiabetes</label>
                                    <input type="number" name="gula_darah_pradiabetes" id="gula_darah_pradiabetes" class="form-control" 
                                           value="<?= $posbindu['gula_darah_pradiabetes'] ?? 0 ?>" min="0">
                                    <small class="form-text text-muted">140-199 mg/dL</small>
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="gula_darah_diabetes">Diabetes</label>
                                    <input type="number" name="gula_darah_diabetes" id="gula_darah_diabetes" class="form-control" 
                                           value="<?= $posbindu['gula_darah_diabetes'] ?? 0 ?>" min="0">
                                    <small class="form-text text-muted">≥ 200 mg/dL</small>
                                </div>
                            </div>
                        </div>
                        
                        <!-- IMT (Indeks Massa Tubuh) -->
                        <div class="row mb-4">
                            <div class="col-md-12">
                                <h5 class="text-primary mb-3">
                                    <i class="fas fa-weight mr-2"></i>Indeks Massa Tubuh (IMT)
                                </h5>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="imt_kurus">Kurus</label>
                                    <input type="number" name="imt_kurus" id="imt_kurus" class="form-control" 
                                           value="<?= $posbindu['imt_kurus'] ?? 0 ?>" min="0">
                                    <small class="form-text text-muted">< 18.5</small>
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="imt_normal">Normal</label>
                                    <input type="number" name="imt_normal" id="imt_normal" class="form-control" 
                                           value="<?= $posbindu['imt_normal'] ?? 0 ?>" min="0">
                                    <small class="form-text text-muted">18.5 - 24.9</small>
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="imt_gemuk">Gemuk</label>
                                    <input type="number" name="imt_gemuk" id="imt_gemuk" class="form-control" 
                                           value="<?= $posbindu['imt_gemuk'] ?? 0 ?>" min="0">
                                    <small class="form-text text-muted">25.0 - 29.9</small>
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="imt_obesitas">Obesitas</label>
                                    <input type="number" name="imt_obesitas" id="imt_obesitas" class="form-control" 
                                           value="<?= $posbindu['imt_obesitas'] ?? 0 ?>" min="0">
                                    <small class="form-text text-muted">≥ 30.0</small>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Data Lainnya -->
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="lingkar_perut_normal">Lingkar Perut Normal</label>
                                    <input type="number" name="lingkar_perut_normal" id="lingkar_perut_normal" class="form-control" 
                                           value="<?= $posbindu['lingkar_perut_normal'] ?? 0 ?>" min="0">
                                    <small class="form-text text-muted">Pria ≤90cm, Wanita ≤80cm</small>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="lingkar_perut_obesitas">Lingkar Perut Obesitas</label>
                                    <input type="number" name="lingkar_perut_obesitas" id="lingkar_perut_obesitas" class="form-control" 
                                           value="<?= $posbindu['lingkar_perut_obesitas'] ?? 0 ?>" min="0">
                                    <small class="form-text text-muted">Pria >90cm, Wanita >80cm</small>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Riwayat Penyakit -->
                        <div class="row mb-4">
                            <div class="col-md-12">
                                <h5 class="text-primary mb-3">
                                    <i class="fas fa-history mr-2"></i>Riwayat Penyakit
                                </h5>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="riwayat_hipertensi">Hipertensi</label>
                                    <input type="number" name="riwayat_hipertensi" id="riwayat_hipertensi" class="form-control" 
                                           value="<?= $posbindu['riwayat_hipertensi'] ?? 0 ?>" min="0">
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="riwayat_diabetes">Diabetes</label>
                                    <input type="number" name="riwayat_diabetes" id="riwayat_diabetes" class="form-control" 
                                           value="<?= $posbindu['riwayat_diabetes'] ?? 0 ?>" min="0">
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="riwayat_jantung">Jantung</label>
                                    <input type="number" name="riwayat_jantung" id="riwayat_jantung" class="form-control" 
                                           value="<?= $posbindu['riwayat_jantung'] ?? 0 ?>" min="0">
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="riwayat_stroke">Stroke</label>
                                    <input type="number" name="riwayat_stroke" id="riwayat_stroke" class="form-control" 
                                           value="<?= $posbindu['riwayat_stroke'] ?? 0 ?>" min="0">
                                </div>
                            </div>
                        </div>
                        
                        <!-- Rujukan dan Keterangan -->
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="jumlah_rujukan">Jumlah Rujukan</label>
                                    <input type="number" name="jumlah_rujukan" id="jumlah_rujukan" class="form-control" 
                                           value="<?= $posbindu['jumlah_rujukan'] ?? 0 ?>" min="0">
                                    <small class="form-text text-muted">Dirujuk ke puskesmas/rumah sakit</small>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="keterangan">Keterangan / Catatan</label>
                                    <textarea name="keterangan" id="keterangan" class="form-control" rows="3"><?= $posbindu['keterangan'] ?? '' ?></textarea>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Tombol Submit -->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group text-right">
                                    <button type="reset" class="btn btn-secondary mr-2">
                                        <i class="fas fa-redo mr-2"></i>Reset
                                    </button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save mr-2"></i>Simpan Data
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->section('page-scripts') ?>
<script>
$(document).ready(function() {
    // Auto-fill tahun dari bulan yang dipilih
    $('#bulan').on('change', function() {
        var bulan = $(this).val();
        if (bulan) {
            var tahun = bulan.split('-')[0];
            $('#tahun').val(tahun);
        }
    });
    
    // Hitung total lansia otomatis
    function calculateTotalLansia() {
        var laki = parseInt($('#jumlah_lansia_l').val()) || 0;
        var perempuan = parseInt($('#jumlah_lansia_p').val()) || 0;
        var total = laki + perempuan;
        $('#jumlah_lansia_total').val(total);
    }
    
    $('#jumlah_lansia_l, #jumlah_lansia_p').on('input', calculateTotalLansia);
    calculateTotalLansia();
    
    // Validasi form
    $('form').submit(function(e) {
        var bulan = $('#bulan').val();
        var tahun = $('#tahun').val();
        var dusun = $('#dusun').val();
        
        if (!dusun || !bulan || !tahun) {
            alert('Harap isi semua field yang wajib diisi!');
            e.preventDefault();
            return false;
        }
    });
});
</script>
<?= $this->endSection() ?>
<?= $this->endSection() ?>