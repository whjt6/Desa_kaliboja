<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?= $title ?></h1>
        <div>
            <form method="get" class="d-inline-block">
                <div class="input-group">
                    <input type="number" name="tahun" class="form-control form-control-sm" 
                           value="<?= $tahun ?>" min="2020" max="<?= date('Y') ?>" style="width: 100px;">
                    <div class="input-group-append">
                        <button class="btn btn-primary btn-sm" type="submit">Lihat</button>
                    </div>
                </div>
            </form>
            <a href="<?= site_url('dashboard/posbindu') ?>" class="btn btn-secondary btn-sm ml-2">
                <i class="fas fa-arrow-left mr-2"></i>Kembali
            </a>
        </div>
    </div>
    
    <!-- Statistik Utama -->
    <div class="row mb-4">
        <div class="col-xl-12 col-lg-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Statistik Posbindu Lansia Tahun <?= $tahun ?></h6>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-md-3 mb-4">
                            <div class="border p-3 rounded">
                                <h2 class="text-primary"><?= number_format($totalStatistik['total_lansia'] ?? 0) ?></h2>
                                <p class="mb-0">Total Lansia</p>
                                <small class="text-muted">Semua Dusun</small>
                            </div>
                        </div>
                        <div class="col-md-3 mb-4">
                            <div class="border p-3 rounded">
                                <h2 class="text-danger"><?= number_format($totalStatistik['total_hipertensi'] ?? 0) ?></h2>
                                <p class="mb-0">Hipertensi</p>
                                <small class="text-muted">Stage 1 & 2</small>
                            </div>
                        </div>
                        <div class="col-md-3 mb-4">
                            <div class="border p-3 rounded">
                                <h2 class="text-warning"><?= number_format($totalStatistik['total_diabetes'] ?? 0) ?></h2>
                                <p class="mb-0">Diabetes</p>
                                <small class="text-muted">Terkonfirmasi</small>
                            </div>
                        </div>
                        <div class="col-md-3 mb-4">
                            <div class="border p-3 rounded">
                                <h2 class="text-info"><?= number_format($totalStatistik['total_gemuk_obesitas'] ?? 0) ?></h2>
                                <p class="mb-0">Gemuk/Obesitas</p>
                                <small class="text-muted">IMT ≥ 25</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Distribusi Risiko -->
    <div class="row mb-4">
        <div class="col-xl-6 col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Distribusi Risiko Kesehatan</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="bg-light">
                                <tr>
                                    <th>Parameter</th>
                                    <th class="text-center">Normal</th>
                                    <th class="text-center">Berisiko</th>
                                    <th class="text-center">% Berisiko</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Tekanan Darah</td>
                                    <td class="text-center"><?= number_format($riskDistribution['tekanan_normal'] ?? 0) ?></td>
                                    <td class="text-center"><?= number_format($riskDistribution['tekanan_tinggi'] ?? 0) ?></td>
                                    <td class="text-center">
                                        <?php 
                                        $totalTekanan = ($riskDistribution['tekanan_normal'] ?? 0) + ($riskDistribution['tekanan_tinggi'] ?? 0);
                                        $percentTekanan = $totalTekanan > 0 ? round(($riskDistribution['tekanan_tinggi'] ?? 0) / $totalTekanan * 100, 1) : 0;
                                        echo $percentTekanan . '%';
                                        ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Gula Darah</td>
                                    <td class="text-center"><?= number_format($riskDistribution['gula_normal'] ?? 0) ?></td>
                                    <td class="text-center"><?= number_format($riskDistribution['gula_tinggi'] ?? 0) ?></td>
                                    <td class="text-center">
                                        <?php 
                                        $totalGula = ($riskDistribution['gula_normal'] ?? 0) + ($riskDistribution['gula_tinggi'] ?? 0);
                                        $percentGula = $totalGula > 0 ? round(($riskDistribution['gula_tinggi'] ?? 0) / $totalGula * 100, 1) : 0;
                                        echo $percentGula . '%';
                                        ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>IMT</td>
                                    <td class="text-center"><?= number_format($riskDistribution['imt_normal'] ?? 0) ?></td>
                                    <td class="text-center"><?= number_format($riskDistribution['imt_tidak_normal'] ?? 0) ?></td>
                                    <td class="text-center">
                                        <?php 
                                        $totalIMT = ($riskDistribution['imt_normal'] ?? 0) + ($riskDistribution['imt_tidak_normal'] ?? 0);
                                        $percentIMT = $totalIMT > 0 ? round(($riskDistribution['imt_tidak_normal'] ?? 0) / $totalIMT * 100, 1) : 0;
                                        echo $percentIMT . '%';
                                        ?>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-6 col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Statistik per Dusun</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="bg-light">
                                <tr>
                                    <th>Dusun</th>
                                    <th class="text-center">Lansia</th>
                                    <th class="text-center">Hipertensi</th>
                                    <th class="text-center">Diabetes</th>
                                    <th class="text-center">Rujukan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(empty($statistikDusun)): ?>
                                <tr>
                                    <td colspan="5" class="text-center py-3 text-muted">
                                        Tidak ada data
                                    </td>
                                </tr>
                                <?php else: ?>
                                <?php foreach($statistikDusun as $stat): ?>
                                <tr>
                                    <td>
                                        <?php 
                                        $dusunNames = [
                                            'semboja_barat' => 'Semboja Barat',
                                            'semboja_timur' => 'Semboja Timur',
                                            'kaligenteng' => 'Kaligenteng',
                                            'silemud' => 'Silemud'
                                        ];
                                        echo $dusunNames[$stat['dusun']] ?? $stat['dusun'];
                                        ?>
                                    </td>
                                    <td class="text-center"><?= number_format($stat['total_lansia']) ?></td>
                                    <td class="text-center"><?= number_format($stat['total_hipertensi']) ?></td>
                                    <td class="text-center"><?= number_format($stat['total_diabetes']) ?></td>
                                    <td class="text-center"><?= number_format($stat['total_rujukan']) ?></td>
                                </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Informasi Penting -->
    <div class="row">
        <div class="col-xl-12 col-lg-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3 bg-warning">
                    <h6 class="m-0 font-weight-bold text-white">
                        <i class="fas fa-exclamation-triangle mr-2"></i>Informasi Penting
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="card border-left-danger mb-3">
                                <div class="card-body">
                                    <h6 class="card-title text-danger">
                                        <i class="fas fa-heartbeat mr-2"></i>Hipertensi
                                    </h6>
                                    <p class="card-text small">Tekanan darah ≥140/90 mmHg. Faktor risiko utama penyakit jantung dan stroke.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card border-left-warning mb-3">
                                <div class="card-body">
                                    <h6 class="card-title text-warning">
                                        <i class="fas fa-tint mr-2"></i>Diabetes
                                    </h6>
                                    <p class="card-text small">Gula darah ≥200 mg/dL. Dapat menyebabkan komplikasi ginjal, mata, dan saraf.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card border-left-info mb-3">
                                <div class="card-body">
                                    <h6 class="card-title text-info">
                                        <i class="fas fa-weight mr-2"></i>Obesitas
                                    </h6>
                                    <p class="card-text small">IMT ≥30. Meningkatkan risiko berbagai penyakit kronis dan menurunkan kualitas hidup.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->section('page-scripts') ?>
<script>
$(document).ready(function() {
    // Tambahkan script untuk grafik jika diperlukan
});
</script>
<?= $this->endSection() ?>
<?= $this->endSection() ?>