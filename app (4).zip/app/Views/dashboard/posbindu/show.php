<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?= $title ?></h1>
        <div>
            <a href="<?= site_url('dashboard/posbindu') ?>" class="btn btn-secondary btn-sm">
                <i class="fas fa-arrow-left mr-2"></i>Kembali
            </a>
        </div>
    </div>
    
    <div class="row">
        <div class="col-lg-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">Detail Data Posbindu Lansia</h6>
                    <div>
                        <a href="<?= site_url('dashboard/posbindu/edit/' . $posbindu['id']) ?>" class="btn btn-sm btn-warning mr-2">
                            <i class="fas fa-edit mr-1"></i> Edit
                        </a>
                        <button onclick="confirmDelete(<?= $posbindu['id'] ?>)" class="btn btn-sm btn-danger">
                            <i class="fas fa-trash mr-1"></i> Hapus
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <!-- Informasi Dasar -->
                    <div class="row mb-4">
                        <div class="col-md-12">
                            <h5 class="text-primary mb-3">
                                <i class="fas fa-info-circle mr-2"></i>Informasi Dasar
                            </h5>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="fw-bold">Dusun</label>
                            <p><?= $dusunList[$posbindu['dusun']] ?? $posbindu['dusun'] ?></p>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="fw-bold">Bulan</label>
                            <p><?= date('F Y', strtotime($posbindu['bulan'] . '-01')) ?></p>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="fw-bold">Tahun</label>
                            <p><?= $posbindu['tahun'] ?></p>
                        </div>
                    </div>
                    
                    <!-- Data Lansia -->
                    <div class="row mb-4">
                        <div class="col-md-12">
                            <h5 class="text-primary mb-3">
                                <i class="fas fa-user-md mr-2"></i>Data Lansia
                            </h5>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="fw-bold">Lansia Laki-laki</label>
                            <p><?= number_format($posbindu['jumlah_lansia_l']) ?></p>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="fw-bold">Lansia Perempuan</label>
                            <p><?= number_format($posbindu['jumlah_lansia_p']) ?></p>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="fw-bold">Total Lansia</label>
                            <p class="h4"><?= number_format($posbindu['jumlah_lansia_total']) ?></p>
                        </div>
                    </div>
                    
                    <!-- Tekanan Darah -->
                    <div class="row mb-4">
                        <div class="col-md-12">
                            <h5 class="text-primary mb-3">
                                <i class="fas fa-heartbeat mr-2"></i>Tekanan Darah
                            </h5>
                        </div>
                        
                        <div class="col-md-3 mb-3">
                            <label class="fw-bold text-success">Normal</label>
                            <p><?= number_format($posbindu['tekanan_darah_normal']) ?></p>
                        </div>
                        
                        <div class="col-md-3 mb-3">
                            <label class="fw-bold text-warning">Prahipertensi</label>
                            <p><?= number_format($posbindu['tekanan_darah_tingkat1']) ?></p>
                        </div>
                        
                        <div class="col-md-3 mb-3">
                            <label class="fw-bold text-danger">Hipertensi Stage 1</label>
                            <p><?= number_format($posbindu['tekanan_darah_tingkat2']) ?></p>
                        </div>
                        
                        <div class="col-md-3 mb-3">
                            <label class="fw-bold text-danger">Hipertensi Stage 2</label>
                            <p><?= number_format($posbindu['tekanan_darah_tingkat3']) ?></p>
                        </div>
                    </div>
                    
                    <!-- Data Lainnya -->
                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <h5 class="text-warning mb-3">
                                <i class="fas fa-tint mr-2"></i>Gula Darah
                            </h5>
                            <div class="row">
                                <div class="col-md-4">
                                    <label class="fw-bold text-success">Normal</label>
                                    <p><?= number_format($posbindu['gula_darah_normal']) ?></p>
                                </div>
                                <div class="col-md-4">
                                    <label class="fw-bold text-warning">Pradiabetes</label>
                                    <p><?= number_format($posbindu['gula_darah_pradiabetes']) ?></p>
                                </div>
                                <div class="col-md-4">
                                    <label class="fw-bold text-danger">Diabetes</label>
                                    <p><?= number_format($posbindu['gula_darah_diabetes']) ?></p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-4">
                            <h5 class="text-info mb-3">
                                <i class="fas fa-weight mr-2"></i>IMT (Indeks Massa Tubuh)
                            </h5>
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="fw-bold">Kurus</label>
                                    <p><?= number_format($posbindu['imt_kurus']) ?></p>
                                </div>
                                <div class="col-md-3">
                                    <label class="fw-bold text-success">Normal</label>
                                    <p><?= number_format($posbindu['imt_normal']) ?></p>
                                </div>
                                <div class="col-md-3">
                                    <label class="fw-bold text-warning">Gemuk</label>
                                    <p><?= number_format($posbindu['imt_gemuk']) ?></p>
                                </div>
                                <div class="col-md-3">
                                    <label class="fw-bold text-danger">Obesitas</label>
                                    <p><?= number_format($posbindu['imt_obesitas']) ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Keterangan -->
                    <?php if(!empty($posbindu['keterangan'])): ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="alert alert-info">
                                <h6><i class="fas fa-sticky-note mr-2"></i>Keterangan</h6>
                                <p class="mb-0"><?= nl2br(esc($posbindu['keterangan'])) ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Info Tambahan -->
                    <div class="row mt-4">
                        <div class="col-md-6">
                            <small class="text-muted">
                                <i class="fas fa-calendar-plus mr-1"></i>
                                Dibuat: <?= date('d F Y H:i', strtotime($posbindu['created_at'])) ?>
                            </small>
                        </div>
                        <div class="col-md-6 text-right">
                            <small class="text-muted">
                                <i class="fas fa-calendar-check mr-1"></i>
                                Diperbarui: <?= date('d F Y H:i', strtotime($posbindu['updated_at'])) ?>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Konfirmasi Hapus</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Apakah Anda yakin ingin menghapus data ini?</p>
                <p class="text-danger"><small>Tindakan ini tidak dapat dibatalkan!</small></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                <form id="deleteForm" method="post" style="display: inline;">
                    <button type="submit" class="btn btn-danger">Hapus</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?= $this->section('page-scripts') ?>
<script>
function confirmDelete(id) {
    $('#deleteForm').attr('action', '<?= site_url('dashboard/posbindu/delete/') ?>' + id);
    $('#deleteModal').modal('show');
}
</script>
<?= $this->endSection() ?>
<?= $this->endSection() ?>