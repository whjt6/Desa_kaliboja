<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?= $title ?></h1>
        <div>
            <a href="<?= site_url('dashboard/posyandu') ?>" class="btn btn-secondary btn-sm">
                <i class="fas fa-arrow-left mr-2"></i>Kembali
            </a>
        </div>
    </div>
    
    <div class="row">
        <div class="col-lg-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">Detail Data Posyandu</h6>
                    <div>
                        <a href="<?= site_url('dashboard/posyandu/edit/' . $posyandu['id']) ?>" 
                           class="btn btn-sm btn-warning mr-2">
                            <i class="fas fa-edit mr-1"></i> Edit
                        </a>
                        <button onclick="confirmDelete(<?= $posyandu['id'] ?>)" 
                                class="btn btn-sm btn-danger">
                            <i class="fas fa-trash mr-1"></i> Hapus
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <!-- Informasi Dasar -->
                    <div class="row mb-4">
                        <div class="col-md-12">
                            <h5 class="text-primary mb-3 border-bottom pb-2">
                                <i class="fas fa-info-circle mr-2"></i>Informasi Dasar
                            </h5>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="fw-bold text-gray-700">Dusun</label>
                            <p class="h5">
                                <span class="badge badge-primary">
                                    <?= $dusunList[$posyandu['dusun']] ?? $posyandu['dusun'] ?>
                                </span>
                            </p>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="fw-bold text-gray-700">Bulan</label>
                            <p class="h5"><?= date('F Y', strtotime($posyandu['bulan'] . '-01')) ?></p>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="fw-bold text-gray-700">Tahun</label>
                            <p class="h5"><?= $posyandu['tahun'] ?></p>
                        </div>
                    </div>
                    
                    <!-- Data Balita -->
                    <div class="row mb-4">
                        <div class="col-md-12">
                            <h5 class="text-primary mb-3 border-bottom pb-2">
                                <i class="fas fa-baby mr-2"></i>Data Balita
                            </h5>
                        </div>
                        
                        <div class="col-md-3 mb-3">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Balita Laki-laki</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?= number_format($posyandu['jumlah_balita_l']) ?>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-male fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-3 mb-3">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                                Balita Perempuan</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?= number_format($posyandu['jumlah_balita_p']) ?>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-female fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-3 mb-3">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Total Balita</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?= number_format($posyandu['jumlah_balita_l'] + $posyandu['jumlah_balita_p']) ?>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-baby fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Status Gizi -->
                    <div class="row mb-4">
                        <div class="col-md-12">
                            <h5 class="text-primary mb-3 border-bottom pb-2">
                                <i class="fas fa-weight-scale mr-2"></i>Status Gizi Balita
                            </h5>
                        </div>
                        
                        <?php 
                        $totalBalita = $posyandu['jumlah_balita_l'] + $posyandu['jumlah_balita_p'];
                        $percentGiziBuruk = $totalBalita > 0 ? 
                            round($posyandu['balita_gizi_buruk'] / $totalBalita * 100, 1) : 0;
                        $percentGiziKurang = $totalBalita > 0 ? 
                            round($posyandu['balita_gizi_kurang'] / $totalBalita * 100, 1) : 0;
                        $percentGiziBaik = $totalBalita > 0 ? 
                            round($posyandu['balita_gizi_baik'] / $totalBalita * 100, 1) : 0;
                        $percentGiziLebih = $totalBalita > 0 ? 
                            round($posyandu['balita_gizi_lebih'] / $totalBalita * 100, 1) : 0;
                        ?>
                        
                        <div class="col-md-3 mb-3">
                            <div class="card border-left-danger shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                                Gizi Buruk</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?= number_format($posyandu['balita_gizi_buruk']) ?>
                                            </div>
                                            <div class="text-xs text-danger">
                                                <?= $percentGiziBuruk ?>%
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-3 mb-3">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Gizi Kurang</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?= number_format($posyandu['balita_gizi_kurang']) ?>
                                            </div>
                                            <div class="text-xs text-warning">
                                                <?= $percentGiziKurang ?>%
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-3 mb-3">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Gizi Baik</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?= number_format($posyandu['balita_gizi_baik']) ?>
                                            </div>
                                            <div class="text-xs text-success">
                                                <?= $percentGiziBaik ?>%
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-3 mb-3">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                                Gizi Lebih</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?= number_format($posyandu['balita_gizi_lebih']) ?>
                                            </div>
                                            <div class="text-xs text-info">
                                                <?= $percentGiziLebih ?>%
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Data Ibu -->
                    <div class="row mb-4">
                        <div class="col-md-12">
                            <h5 class="text-primary mb-3 border-bottom pb-2">
                                <i class="fas fa-female mr-2"></i>Data Ibu
                            </h5>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Ibu Hamil</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?= number_format($posyandu['jumlah_ibu_hamil']) ?>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-person-pregnant fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                                Ibu Menyusui</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?= number_format($posyandu['jumlah_ibu_menyusui']) ?>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-child fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Data Kelahiran -->
                    <div class="row mb-4">
                        <div class="col-md-12">
                            <h5 class="text-primary mb-3 border-bottom pb-2">
                                <i class="fas fa-baby-carriage mr-2"></i>Data Kelahiran
                            </h5>
                        </div>
                        
                        <div class="col-md-3 mb-3">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Kelahiran Laki-laki</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?= number_format($posyandu['kelahiran_l']) ?>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-male fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-3 mb-3">
                            <div class="card border-left-pink shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-pink text-uppercase mb-1">
                                                Kelahiran Perempuan</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?= number_format($posyandu['kelahiran_p']) ?>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-female fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-3 mb-3">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Total Kelahiran</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?= number_format($posyandu['kelahiran_l'] + $posyandu['kelahiran_p']) ?>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-baby-carriage fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-3 mb-3">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                BBLR (< 2500g)</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?= number_format($posyandu['kelahiran_bb_rendah']) ?>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-weight fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Data Imunisasi -->
                    <div class="row mb-4">
                        <div class="col-md-12">
                            <h5 class="text-primary mb-3 border-bottom pb-2">
                                <i class="fas fa-syringe mr-2"></i>Data Imunisasi
                            </h5>
                        </div>
                        
                        <?php 
                        $percentImunisasi = $totalBalita > 0 ? 
                            round($posyandu['imunisasi_dasar_lengkap'] / $totalBalita * 100, 1) : 0;
                        $percentCampak = $totalBalita > 0 ? 
                            round($posyandu['imunisasi_campak'] / $totalBalita * 100, 1) : 0;
                        ?>
                        
                        <div class="col-md-6 mb-3">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Imunisasi Dasar Lengkap</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?= number_format($posyandu['imunisasi_dasar_lengkap']) ?>
                                            </div>
                                            <div class="text-xs text-success">
                                                <?= $percentImunisasi ?>% dari <?= number_format($totalBalita) ?> balita
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-shield-virus fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Imunisasi Campak</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?= number_format($posyandu['imunisasi_campak']) ?>
                                            </div>
                                            <div class="text-xs text-warning">
                                                <?= $percentCampak ?>% dari <?= number_format($totalBalita) ?> balita
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-virus fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Progress Imunisasi -->
                    <div class="row mb-4">
                        <div class="col-md-12">
                            <div class="card shadow">
                                <div class="card-header bg-success text-white">
                                    <h6 class="m-0 font-weight-bold">
                                        <i class="fas fa-chart-line mr-2"></i>Cakupan Imunisasi
                                    </h6>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <h6>Imunisasi Dasar Lengkap</h6>
                                            <div class="progress mb-3" style="height: 25px;">
                                                <div class="progress-bar bg-success progress-bar-striped" 
                                                     role="progressbar" 
                                                     style="width: <?= min(100, $percentImunisasi) ?>%"
                                                     aria-valuenow="<?= $percentImunisasi ?>" 
                                                     aria-valuemin="0" 
                                                     aria-valuemax="100">
                                                    <?= $percentImunisasi ?>%
                                                </div>
                                            </div>
                                            <small class="text-muted">
                                                <?= number_format($posyandu['imunisasi_dasar_lengkap']) ?> dari <?= number_format($totalBalita) ?> balita
                                            </small>
                                        </div>
                                        <div class="col-md-6">
                                            <h6>Imunisasi Campak</h6>
                                            <div class="progress mb-3" style="height: 25px;">
                                                <div class="progress-bar bg-warning progress-bar-striped" 
                                                     role="progressbar" 
                                                     style="width: <?= min(100, $percentCampak) ?>%"
                                                     aria-valuenow="<?= $percentCampak ?>" 
                                                     aria-valuemin="0" 
                                                     aria-valuemax="100">
                                                    <?= $percentCampak ?>%
                                                </div>
                                            </div>
                                            <small class="text-muted">
                                                <?= number_format($posyandu['imunisasi_campak']) ?> dari <?= number_format($totalBalita) ?> balita
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Keterangan -->
                    <?php if(!empty($posyandu['keterangan'])): ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card border-left-info shadow">
                                <div class="card-body">
                                    <h6 class="text-info">
                                        <i class="fas fa-sticky-note mr-2"></i>Keterangan / Catatan
                                    </h6>
                                    <p class="mb-0"><?= nl2br(esc($posyandu['keterangan'])) ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Timestamps -->
                    <div class="row mt-4">
                        <div class="col-md-6">
                            <small class="text-muted">
                                <i class="fas fa-calendar-plus mr-1"></i>
                                Dibuat: <?= date('d F Y H:i', strtotime($posyandu['created_at'])) ?>
                            </small>
                        </div>
                        <div class="col-md-6 text-right">
                            <small class="text-muted">
                                <i class="fas fa-calendar-check mr-1"></i>
                                Diperbarui: <?= date('d F Y H:i', strtotime($posyandu['updated_at'])) ?>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Konfirmasi Hapus</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Apakah Anda yakin ingin menghapus data ini?</p>
                <p class="text-danger"><small>Tindakan ini tidak dapat dibatalkan!</small></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                <form id="deleteForm" method="post" style="display: inline;">
                    <button type="submit" class="btn btn-danger">Hapus</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?= $this->section('page-scripts') ?>
<script>
function confirmDelete(id) {
    $('#deleteForm').attr('action', '<?= site_url('dashboard/posyandu/delete/') ?>' + id);
    $('#deleteModal').modal('show');
}
</script>
<?= $this->endSection() ?>
<?= $this->endSection() ?>