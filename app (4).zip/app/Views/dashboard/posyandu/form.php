<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?= $title ?></h1>
        <a href="<?= site_url('dashboard/posyandu') ?>" class="btn btn-secondary btn-sm">
            <i class="fas fa-arrow-left mr-2"></i>Kembali
        </a>
    </div>
    
    <div class="row">
        <div class="col-lg-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Form Data Posyandu</h6>
                </div>
                <div class="card-body">
                    <?php if(session()->getFlashdata('errors')): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach(session()->getFlashdata('errors') as $error): ?>
                                <li><?= $error ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    
                    <?php if(session()->getFlashdata('error')): ?>
                    <div class="alert alert-danger">
                        <?= session()->getFlashdata('error') ?>
                    </div>
                    <?php endif; ?>
                    
                    <form action="<?= isset($posyandu['id']) ? site_url('dashboard/posyandu/update/' . $posyandu['id']) : site_url('dashboard/posyandu/store') ?>" 
                          method="post">
                        <?= csrf_field() ?>
                        
                        <!-- Informasi Dasar -->
                        <div class="row mb-4">
                            <div class="col-md-12">
                                <h5 class="text-primary mb-3">
                                    <i class="fas fa-info-circle mr-2"></i>Informasi Dasar
                                </h5>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="dusun">Dusun <span class="text-danger">*</span></label>
                                    <select name="dusun" id="dusun" class="form-control" required>
                                        <option value="">Pilih Dusun</option>
                                        <?php foreach($dusunList as $key => $name): ?>
                                        <option value="<?= $key ?>" 
                                            <?= (isset($posyandu['dusun']) && $posyandu['dusun'] == $key) ? 'selected' : '' ?>>
                                            <?= $name ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="bulan">Bulan <span class="text-danger">*</span></label>
                                    <input type="month" name="bulan" id="bulan" class="form-control" 
                                           value="<?= isset($posyandu['bulan']) ? $posyandu['bulan'] : $bulanSekarang ?>" required>
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="tahun">Tahun <span class="text-danger">*</span></label>
                                    <input type="number" name="tahun" id="tahun" class="form-control" 
                                           value="<?= isset($posyandu['tahun']) ? $posyandu['tahun'] : date('Y') ?>" 
                                           min="2020" max="<?= date('Y') + 1 ?>" required>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Data Balita -->
                        <div class="row mb-4">
                            <div class="col-md-12">
                                <h5 class="text-primary mb-3">
                                    <i class="fas fa-baby mr-2"></i>Data Balita
                                </h5>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="jumlah_balita_l">Jumlah Balita Laki-laki</label>
                                    <input type="number" name="jumlah_balita_l" id="jumlah_balita_l" class="form-control" 
                                           value="<?= $posyandu['jumlah_balita_l'] ?? 0 ?>" min="0">
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="jumlah_balita_p">Jumlah Balita Perempuan</label>
                                    <input type="number" name="jumlah_balita_p" id="jumlah_balita_p" class="form-control" 
                                           value="<?= $posyandu['jumlah_balita_p'] ?? 0 ?>" min="0">
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="balita_gizi_buruk">Gizi Buruk</label>
                                            <input type="number" name="balita_gizi_buruk" id="balita_gizi_buruk" class="form-control" 
                                                   value="<?= $posyandu['balita_gizi_buruk'] ?? 0 ?>" min="0">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="balita_gizi_kurang">Gizi Kurang</label>
                                            <input type="number" name="balita_gizi_kurang" id="balita_gizi_kurang" class="form-control" 
                                                   value="<?= $posyandu['balita_gizi_kurang'] ?? 0 ?>" min="0">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="balita_gizi_baik">Gizi Baik</label>
                                            <input type="number" name="balita_gizi_baik" id="balita_gizi_baik" class="form-control" 
                                                   value="<?= $posyandu['balita_gizi_baik'] ?? 0 ?>" min="0">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="balita_gizi_lebih">Gizi Lebih</label>
                                            <input type="number" name="balita_gizi_lebih" id="balita_gizi_lebih" class="form-control" 
                                                   value="<?= $posyandu['balita_gizi_lebih'] ?? 0 ?>" min="0">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Data Ibu -->
                        <div class="row mb-4">
                            <div class="col-md-12">
                                <h5 class="text-primary mb-3">
                                    <i class="fas fa-female mr-2"></i>Data Ibu
                                </h5>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="jumlah_ibu_hamil">Jumlah Ibu Hamil</label>
                                    <input type="number" name="jumlah_ibu_hamil" id="jumlah_ibu_hamil" class="form-control" 
                                           value="<?= $posyandu['jumlah_ibu_hamil'] ?? 0 ?>" min="0">
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="jumlah_ibu_menyusui">Jumlah Ibu Menyusui</label>
                                    <input type="number" name="jumlah_ibu_menyusui" id="jumlah_ibu_menyusui" class="form-control" 
                                           value="<?= $posyandu['jumlah_ibu_menyusui'] ?? 0 ?>" min="0">
                                </div>
                            </div>
                        </div>
                        
                        <!-- Data Kelahiran -->
                        <div class="row mb-4">
                            <div class="col-md-12">
                                <h5 class="text-primary mb-3">
                                    <i class="fas fa-baby-carriage mr-2"></i>Data Kelahiran
                                </h5>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="kelahiran_l">Kelahiran Laki-laki</label>
                                    <input type="number" name="kelahiran_l" id="kelahiran_l" class="form-control" 
                                           value="<?= $posyandu['kelahiran_l'] ?? 0 ?>" min="0">
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="kelahiran_p">Kelahiran Perempuan</label>
                                    <input type="number" name="kelahiran_p" id="kelahiran_p" class="form-control" 
                                           value="<?= $posyandu['kelahiran_p'] ?? 0 ?>" min="0">
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="kelahiran_bb_rendah">BBLR <small>(< 2500g)</small></label>
                                    <input type="number" name="kelahiran_bb_rendah" id="kelahiran_bb_rendah" class="form-control" 
                                           value="<?= $posyandu['kelahiran_bb_rendah'] ?? 0 ?>" min="0">
                                </div>
                            </div>
                        </div>
                        
                        <!-- Data Imunisasi -->
                        <div class="row mb-4">
                            <div class="col-md-12">
                                <h5 class="text-primary mb-3">
                                    <i class="fas fa-syringe mr-2"></i>Data Imunisasi
                                </h5>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="imunisasi_dasar_lengkap">Imunisasi Dasar Lengkap</label>
                                    <input type="number" name="imunisasi_dasar_lengkap" id="imunisasi_dasar_lengkap" class="form-control" 
                                           value="<?= $posyandu['imunisasi_dasar_lengkap'] ?? 0 ?>" min="0">
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="imunisasi_campak">Imunisasi Campak</label>
                                    <input type="number" name="imunisasi_campak" id="imunisasi_campak" class="form-control" 
                                           value="<?= $posyandu['imunisasi_campak'] ?? 0 ?>" min="0">
                                </div>
                            </div>
                        </div>
                        
                        <!-- Keterangan -->
                        <div class="row mb-4">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="keterangan">Keterangan / Catatan</label>
                                    <textarea name="keterangan" id="keterangan" class="form-control" rows="3"><?= $posyandu['keterangan'] ?? '' ?></textarea>
                                    <small class="form-text text-muted">Tambahkan catatan penting jika diperlukan</small>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Tombol Submit -->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group text-right">
                                    <button type="reset" class="btn btn-secondary mr-2">
                                        <i class="fas fa-redo mr-2"></i>Reset
                                    </button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save mr-2"></i>Simpan Data
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->section('page-scripts') ?>
<script>
$(document).ready(function() {
    // Auto-fill tahun dari bulan yang dipilih
    $('#bulan').on('change', function() {
        var bulan = $(this).val();
        if (bulan) {
            var tahun = bulan.split('-')[0];
            $('#tahun').val(tahun);
        }
    });
    
    // Validasi form
    $('form').submit(function(e) {
        var bulan = $('#bulan').val();
        var tahun = $('#tahun').val();
        var dusun = $('#dusun').val();
        
        if (!dusun || !bulan || !tahun) {
            alert('Harap isi semua field yang wajib diisi!');
            e.preventDefault();
            return false;
        }
    });
});
</script>
<?= $this->endSection() ?>
<?= $this->endSection() ?>