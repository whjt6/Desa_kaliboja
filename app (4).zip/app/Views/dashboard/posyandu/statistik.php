<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?= $title ?></h1>
        <div>
            <form method="get" class="d-inline-block">
                <div class="input-group">
                    <input type="number" name="tahun" class="form-control form-control-sm" 
                           value="<?= $tahun ?>" min="2020" max="<?= date('Y') ?>" style="width: 100px;">
                    <div class="input-group-append">
                        <button class="btn btn-primary btn-sm" type="submit">Lihat</button>
                    </div>
                </div>
            </form>
            <a href="<?= site_url('dashboard/posyandu') ?>" class="btn btn-secondary btn-sm ml-2">
                <i class="fas fa-arrow-left mr-2"></i>Kembali
            </a>
        </div>
    </div>
    
    <!-- Statistik Utama -->
    <div class="row mb-4">
        <div class="col-xl-12 col-lg-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Statistik Posyandu Tahun <?= $tahun ?></h6>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-md-3 mb-4">
                            <div class="border p-3 rounded">
                                <h2 class="text-primary"><?= number_format($totalStatistik['total_balita'] ?? 0) ?></h2>
                                <p class="mb-0">Total Balita</p>
                                <small class="text-muted">Semua Dusun</small>
                            </div>
                        </div>
                        <div class="col-md-3 mb-4">
                            <div class="border p-3 rounded">
                                <h2 class="text-success"><?= number_format($totalStatistik['total_ibu_hamil'] ?? 0) ?></h2>
                                <p class="mb-0">Ibu Hamil</p>
                                <small class="text-muted">Dalam perawatan</small>
                            </div>
                        </div>
                        <div class="col-md-3 mb-4">
                            <div class="border p-3 rounded">
                                <h2 class="text-info"><?= number_format($totalStatistik['total_ibu_menyusui'] ?? 0) ?></h2>
                                <p class="mb-0">Ibu Menyusui</p>
                                <small class="text-muted">0-6 bulan</small>
                            </div>
                        </div>
                        <div class="col-md-3 mb-4">
                            <div class="border p-3 rounded">
                                <h2 class="text-warning"><?= number_format($totalStatistik['total_kelahiran'] ?? 0) ?></h2>
                                <p class="mb-0">Kelahiran</p>
                                <small class="text-muted">Tahun <?= $tahun ?></small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Statistik per Dusun -->
    <div class="row mb-4">
        <div class="col-xl-6 col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Distribusi Balita per Dusun</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="bg-light">
                                <tr>
                                    <th>Dusun</th>
                                    <th class="text-center">Balita</th>
                                    <th class="text-center">Ibu Hamil</th>
                                    <th class="text-center">Kelahiran</th>
                                    <th class="text-center">Imunisasi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(empty($statistikDusun)): ?>
                                <tr>
                                    <td colspan="5" class="text-center py-3 text-muted">
                                        Tidak ada data
                                    </td>
                                </tr>
                                <?php else: ?>
                                <?php foreach($statistikDusun as $stat): ?>
                                <tr>
                                    <td>
                                        <?php 
                                        $dusunNames = [
                                            'semboja_barat' => 'Semboja Barat',
                                            'semboja_timur' => 'Semboja Timur',
                                            'kaligenteng' => 'Kaligenteng',
                                            'silemud' => 'Silemud'
                                        ];
                                        echo $dusunNames[$stat['dusun']] ?? $stat['dusun'];
                                        ?>
                                    </td>
                                    <td class="text-center"><?= number_format($stat['total_balita']) ?></td>
                                    <td class="text-center"><?= number_format($stat['total_ibu_hamil']) ?></td>
                                    <td class="text-center"><?= number_format($stat['total_kelahiran']) ?></td>
                                    <td class="text-center"><?= number_format($stat['total_imunisasi']) ?></td>
                                </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-6 col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Trend Bulanan</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="bg-light">
                                <tr>
                                    <th>Bulan</th>
                                    <th class="text-center">Balita</th>
                                    <th class="text-center">Ibu Hamil</th>
                                    <th class="text-center">Kelahiran</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(empty($monthlyData)): ?>
                                <tr>
                                    <td colspan="4" class="text-center py-3 text-muted">
                                        Tidak ada data
                                    </td>
                                </tr>
                                <?php else: ?>
                                <?php foreach($monthlyData as $data): ?>
                                <tr>
                                    <td>
                                        <?= date('F Y', strtotime($data['bulan'] . '-01')) ?>
                                    </td>
                                    <td class="text-center">
                                        <?= number_format($data['jumlah_balita_l'] + $data['jumlah_balita_p']) ?>
                                    </td>
                                    <td class="text-center">
                                        <?= number_format($data['jumlah_ibu_hamil']) ?>
                                    </td>
                                    <td class="text-center">
                                        <?= number_format($data['kelahiran_l'] + $data['kelahiran_p']) ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Grafik (placeholder) -->
    <div class="row">
        <div class="col-xl-12 col-lg-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Visualisasi Data</h6>
                </div>
                <div class="card-body">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle mr-2"></i>
                        Fitur grafik dan visualisasi data akan segera tersedia.
                        Untuk saat ini, data dapat dilihat dalam bentuk tabel di atas.
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->section('page-scripts') ?>
<script>
$(document).ready(function() {
    // Tambahkan script untuk grafik jika diperlukan
});
</script>
<?= $this->endSection() ?>
<?= $this->endSection() ?>