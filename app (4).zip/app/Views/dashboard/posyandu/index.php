<?= $this->extend('layout/dashboard_layout') ?>

<?= $this->section('content') ?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?= $title ?></h1>
        <div>
            <a href="<?= site_url('dashboard/posyandu/statistik') ?>" class="btn btn-info btn-sm mr-2">
                <i class="fas fa-chart-bar mr-2"></i>Statistik
            </a>
            <a href="<?= site_url('dashboard/posyandu/create') ?>" class="btn btn-primary btn-sm">
                <i class="fas fa-plus-circle mr-2"></i>Tambah Data
            </a>
        </div>
    </div>
    
    <!-- Filter -->
    <div class="card mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Filter Data</h6>
        </div>
        <div class="card-body">
            <form method="get" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Tahun</label>
                    <input type="number" name="tahun" class="form-control" value="<?= $tahun ?>" 
                           min="2020" max="<?= date('Y') ?>" placeholder="Tahun">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Dusun</label>
                    <select name="dusun" class="form-control">
                        <option value="">Semua Dusun</option>
                        <?php foreach($dusunList as $key => $name): ?>
                        <option value="<?= $key ?>" <?= $dusun == $key ? 'selected' : '' ?>><?= $name ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">&nbsp;</label><br>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter mr-2"></i>Filter
                    </button>
                    <a href="<?= site_url('dashboard/posyandu') ?>" class="btn btn-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Quick Stats -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Total Balita</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= number_format($statistik['total_balita'] ?? 0) ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-baby fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Ibu Hamil</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= number_format($statistik['total_ibu_hamil'] ?? 0) ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-female fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Ibu Menyusui</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= number_format($statistik['total_ibu_menyusui'] ?? 0) ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-child fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Kelahiran</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= number_format($statistik['total_kelahiran'] ?? 0) ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-baby-carriage fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Data Table -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">Data Posyandu Tahun <?= $tahun ?></h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead class="bg-light">
                        <tr>
                            <th width="5%">#</th>
                            <th width="15%">Dusun</th>
                            <th width="15%">Bulan/Tahun</th>
                            <th width="10%">Balita (L)</th>
                            <th width="10%">Balita (P)</th>
                            <th width="10%">Ibu Hamil</th>
                            <th width="10%">Kelahiran</th>
                            <th width="15%">Imunisasi</th>
                            <th width="10%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($posyandu)): ?>
                        <tr>
                            <td colspan="9" class="text-center py-4">
                                <i class="fas fa-database fa-2x text-muted mb-3"></i><br>
                                <span class="text-muted">Belum ada data posyandu</span><br>
                                <a href="<?= site_url('dashboard/posyandu/create') ?>" class="btn btn-primary btn-sm mt-2">
                                    <i class="fas fa-plus mr-1"></i> Tambah Data
                                </a>
                            </td>
                        </tr>
                        <?php else: ?>
                        <?php $no = 1; foreach($posyandu as $p): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td>
                                <span class="badge badge-primary"><?= $dusunList[$p['dusun']] ?></span>
                            </td>
                            <td>
                                <?= date('F Y', strtotime($p['bulan'] . '-01')) ?><br>
                                <small class="text-muted"><?= $p['tahun'] ?></small>
                            </td>
                            <td class="text-center"><?= number_format($p['jumlah_balita_l']) ?></td>
                            <td class="text-center"><?= number_format($p['jumlah_balita_p']) ?></td>
                            <td class="text-center"><?= number_format($p['jumlah_ibu_hamil']) ?></td>
                            <td class="text-center">
                                <?= number_format($p['kelahiran_l'] + $p['kelahiran_p']) ?><br>
                                <small class="text-muted">L:<?= $p['kelahiran_l'] ?> P:<?= $p['kelahiran_p'] ?></small>
                            </td>
                            <td>
                                <?php 
                                $totalBalita = $p['jumlah_balita_l'] + $p['jumlah_balita_p'];
                                $imunisasiPercent = $totalBalita > 0 ? ($p['imunisasi_dasar_lengkap'] / $totalBalita * 100) : 0;
                                ?>
                                <div class="progress mb-1" style="height: 10px;">
                                    <div class="progress-bar bg-success" role="progressbar" 
                                         style="width: <?= min(100, $imunisasiPercent) ?>%">
                                    </div>
                                </div>
                                <small><?= number_format($p['imunisasi_dasar_lengkap']) ?>/<?= number_format($totalBalita) ?></small>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="<?= site_url('dashboard/posyandu/show/' . $p['id']) ?>" 
                                       class="btn btn-sm btn-info" title="Detail">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?= site_url('dashboard/posyandu/edit/' . $p['id']) ?>" 
                                       class="btn btn-sm btn-warning" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button onclick="confirmDelete(<?= $p['id'] ?>)" 
                                            class="btn btn-sm btn-danger" title="Hapus">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Konfirmasi Hapus</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Apakah Anda yakin ingin menghapus data ini?</p>
                <p class="text-danger"><small>Tindakan ini tidak dapat dibatalkan!</small></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                <form id="deleteForm" method="post" style="display: inline;">
                    <button type="submit" class="btn btn-danger">Hapus</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?= $this->section('page-scripts') ?>
<script>
function confirmDelete(id) {
    $('#deleteForm').attr('action', '<?= site_url('dashboard/posyandu/delete/') ?>' + id);
    $('#deleteModal').modal('show');
}

$(document).ready(function() {
    $('#dataTable').DataTable({
        "pageLength": 25,
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.25/i18n/Indonesian.json"
        }
    });
});
</script>
<?= $this->endSection() ?>
<?= $this->endSection() ?>