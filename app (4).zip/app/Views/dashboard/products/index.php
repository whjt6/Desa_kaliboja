<?= $this->extend('/layout/dashboard_layout'); ?>
<?= $this->section('content'); ?>
<div class="mb-2"></div>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
        </div>
    </div>
</div>

<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card card-primary card-outline">
                    <div class="card-header">
                        <div class="card-tools">
                            <a href="<?= site_url('dashboard/products/create') ?>" class="btn btn-sm btn-primary">
                                <i class="fas fa-plus-circle mr-1"></i> Tambah Produk
                            </a>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if (empty($products)): ?>
                        <div class="text-center py-5">
                            <i class="fas fa-box-open fa-4x text-muted mb-3"></i>
                            <h4 class="text-muted">Belum ada produk</h4>
                            <p class="text-muted">Silakan tambahkan produk pertama Anda</p>
                            <a href="<?= site_url('dashboard/products/create') ?>" class="btn btn-primary mt-2">
                                <i class="fas fa-plus-circle mr-1"></i> Tambah Produk
                            </a>
                        </div>
                        <?php else: ?>
                        <div class="row">
                            <?php foreach($products as $p): ?>
                            <div class="col-md-4 mb-4">
                                <div class="card product-card h-100">
                                    <div class="product-image-container">
                                        <?php if($p['image']): ?>
                                        <img src="<?= base_url('uploads/products/'.$p['image']) ?>" class="card-img-top" alt="<?= esc($p['name']) ?>">
                                        <?php else: ?>
                                        <div class="no-image">
                                            <i class="fas fa-image fa-3x"></i>
                                            <p>Tidak ada gambar</p>
                                        </div>
                                        <?php endif; ?>
                                        <div class="product-actions">
                                            <a href="<?= site_url('dashboard/products/edit/'.$p['id']) ?>" class="btn btn-sm btn-light" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="<?= site_url('dashboard/products/delete/'.$p['id']) ?>" class="btn btn-sm btn-light" title="Hapus" onclick="return confirm('Yakin ingin menghapus produk ini?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                        <?php if(isset($p['is_featured']) && $p['is_featured'] == 1): ?>
                                        <div class="featured-badge">
                                            <i class="fas fa-star"></i> Unggulan
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="card-body">
                                        <h5 class="card-title"><?= esc($p['name']) ?></h5>
                                        <div class="product-category mb-2">
                                            <span class="badge badge-info"><?= esc($p['category']) ?></span>
                                        </div>
                                        <?php if(isset($p['description']) && !empty($p['description'])): ?>
                                        <p class="card-text product-description">
                                            <?= esc(word_limiter($p['description'], 10)) ?>
                                        </p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="card-footer">
                                        <div class="row">
                                            <div class="col">
                                                <a href="<?= site_url('dashboard/products/edit/'.$p['id']) ?>" class="btn btn-sm btn-block btn-outline-primary">
                                                    <i class="fas fa-edit mr-1"></i> Edit
                                                </a>
                                            </div>
                                            <div class="col">
                                                <a href="<?= site_url('dashboard/products/delete/'.$p['id']) ?>" class="btn btn-sm btn-block btn-outline-danger" onclick="return confirm('Yakin ingin menghapus produk ini?')">
                                                    <i class="fas fa-trash mr-1"></i> Hapus
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php if (!empty($products)): ?>
                    <div class="card-footer">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="dataTables_info">
                                Menampilkan <?= count($products) ?> produk
                            </div>
                            <div class="dataTables_paginate">
                                <!-- Pagination would go here -->
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
.product-card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    border: 1px solid #e3e6f0;
    border-radius: 8px;
    overflow: hidden;
}

.product-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

.product-image-container {
    position: relative;
    height: 200px;
    overflow: hidden;
}

.product-image-container img {
    height: 100%;
    width: 100%;
    object-fit: cover;
    transition: transform 0.3s ease;
}

.product-card:hover .product-image-container img {
    transform: scale(1.05);
}

.no-image {
    height: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background-color: #f8f9fa;
    color: #6c757d;
}

.product-actions {
    position: absolute;
    top: 10px;
    right: 10px;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.product-card:hover .product-actions {
    opacity: 1;
}

.product-actions .btn {
    margin-left: 5px;
    border-radius: 50%;
    width: 35px;
    height: 35px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.featured-badge {
    position: absolute;
    top: 10px;
    left: 10px;
    background: linear-gradient(45deg, #FFD700, #FFA500);
    color: #000;
    padding: 5px 10px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: bold;
}

.product-price {
    font-size: 1.25rem;
    font-weight: bold;
    color: #28a745;
}

.product-description {
    color: #6c757d;
    font-size: 0.9rem;
}

.card-footer .btn {
    border-radius: 5px;
}

@media (max-width: 768px) {
    .product-actions {
        opacity: 1; /* Always show on mobile */
    }
    
    .col-md-4 {
        flex: 0 0 100%;
        max-width: 100%;
    }
}
</style>

<?= $this->endSection(); ?>