<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Error - Desa Kaliboja</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            padding: 20px;
            line-height: 1.6;
        }
        .error-container {
            background: white;
            max-width: 800px;
            margin: 50px auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        h1 {
            color: #dc3545;
            border-bottom: 2px solid #eee;
            padding-bottom: 10px;
        }
        .error-details {
            background: #f8f9fa;
            padding: 15px;
            border-left: 4px solid #dc3545;
            margin: 20px 0;
            font-family: monospace;
            font-size: 14px;
            overflow-x: auto;
        }
        .home-link {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background: #4A6C6F;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .home-link:hover {
            background: #3a5659;
        }
    </style>
</head>
<body>
    <div class="error-container">
        <h1>⚠️ Terjadi Kesalahan</h1>
        
        <p><strong>Pesan Error:</strong><br>
        <?= isset($message) ? nl2br(htmlspecialchars($message)) : 'Tidak diketahui' ?>
        </p>
        
        <?php if (isset($exception) && ENVIRONMENT !== 'production'): ?>
        <div class="error-details">
            <strong><?= htmlspecialchars($exception->getMessage()) ?></strong><br>
            File: <?= htmlspecialchars($exception->getFile()) ?>:<?= $exception->getLine() ?>
        </div>
        <?php endif; ?>
        
        <a href="/" class="home-link">← Kembali ke Beranda</a>
    </div>
</body>
</html>