<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>404 - Halaman Tidak Ditemukan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #4A6C6F 0%, #3a5659 100%);
            color: white;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            margin: 0;
        }
        .error-box {
            max-width: 600px;
            padding: 40px;
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        h1 {
            font-size: 120px;
            margin: 0;
            line-height: 1;
        }
        h2 {
            margin: 20px 0;
            font-weight: 300;
        }
        .home-link {
            display: inline-block;
            margin-top: 30px;
            padding: 12px 30px;
            background: white;
            color: #4A6C6F;
            text-decoration: none;
            border-radius: 25px;
            font-weight: bold;
            transition: transform 0.3s;
        }
        .home-link:hover {
            transform: translateY(-3px);
        }
    </style>
</head>
<body>
    <div class="error-box">
        <h1>404</h1>
        <h2>Halaman Tidak Ditemukan</h2>
        <p>Halaman yang Anda cari tidak tersedia atau telah dipindahkan.</p>
        <a href="/" class="home-link">Kembali ke Beranda</a>
    </div>
</body>
</html>