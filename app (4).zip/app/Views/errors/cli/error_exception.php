ERROR: <?= $message ?>

<?php if (isset($exception)): ?>
File: <?= $exception->getFile() ?>:<?= $exception->getLine() ?>

<?php endif; ?>