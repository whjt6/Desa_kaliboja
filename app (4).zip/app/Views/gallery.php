<?= $this->extend('layout/main_layout') ?>

<?= $this->section('content') ?>
<section class="py-5 mt-5">
    <div class="container">
        <h1 class="text-center mb-5">Galeri Desa Kaliboja</h1>

        <!-- Filter Kategori -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="gallery-filter text-center">
                    <a href="<?= site_url('gallery') ?>" 
                       class="btn btn-sm <?= empty($selectedCategory) || $selectedCategory === 'all' ? 'btn-primary' : 'btn-outline-primary' ?> me-2 mb-2">
                        Semua
                    </a>
                    <?php foreach ($categories as $cat): ?>
                    <a href="<?= site_url('gallery?category=' . urlencode($cat['category'])) ?>" 
                       class="btn btn-sm <?= $selectedCategory === $cat['category'] ? 'btn-primary' : 'btn-outline-primary' ?> me-2 mb-2">
                        <?= esc($cat['category']) ?>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Galeri Grid -->
        <div class="row">
            <?php if (!empty($galleries)): ?>
                <?php foreach ($galleries as $gallery): ?>
                    <div class="col-md-4 col-lg-3 mb-4">
                        <div class="card h-100 shadow-sm">
                            <?php 
                            $imagePath = 'uploads/gallery/' . esc($gallery['image']);
                            $imageExists = !empty($gallery['image']) && file_exists(ROOTPATH . 'public/' . $imagePath);
                            ?>
                            <img src="<?= $imageExists ? base_url($imagePath) : 'https://via.placeholder.com/300x200?text=Gambar+Tidak+Tersedia' ?>" 
                                 alt="<?= esc($gallery['title']) ?>" 
                                 class="card-img-top"
                                 style="height: 200px; object-fit: cover;"
                                 onerror="this.src='https://via.placeholder.com/300x200?text=Gambar+Tidak+Tersedia'">
                            <div class="card-body">
                                <h6 class="card-title"><?= esc($gallery['title']) ?></h6>
                                <span class="badge bg-primary"><?= esc($gallery['category']) ?></span>
                                <?php if ($gallery['description']): ?>
                                    <p class="card-text small mt-2"><?= character_limiter($gallery['description'], 80) ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="card-footer bg-transparent">
                                <small class="text-muted">
                                    <i class="fas fa-calendar me-1"></i>
                                    <?= date('d M Y', strtotime($gallery['created_at'])) ?>
                                </small>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-12 text-center py-5">
                    <i class="fas fa-images fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">Belum ada galeri</h5>
                    <?php if(!empty($selectedCategory) && $selectedCategory !== 'all'): ?>
                        <p class="text-muted">Tidak ada gambar dalam kategori <?= esc($selectedCategory) ?></p>
                        <a href="<?= site_url('gallery') ?>" class="btn btn-primary mt-2">Lihat Semua Galeri</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?= $this->endSection() ?>

<?= $this->section('page-scripts') ?>
<script>
// Filter galeri dengan AJAX untuk pengalaman lebih baik
document.addEventListener('DOMContentLoaded', function() {
    const filterButtons = document.querySelectorAll('.gallery-filter .btn');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            // Hapus class active dari semua button
            filterButtons.forEach(btn => {
                btn.classList.remove('btn-primary');
                btn.classList.add('btn-outline-primary');
            });
            
            // Tambah class active ke button yang diklik
            this.classList.remove('btn-outline-primary');
            this.classList.add('btn-primary');
            
            // Tampilkan loading indicator
            const galleryGrid = document.querySelector('.row');
            galleryGrid.innerHTML = `
                <div class="col-12 text-center py-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-2">Memuat galeri...</p>
                </div>
            `;
        });
    });
});
</script>
<?= $this->endSection() ?>