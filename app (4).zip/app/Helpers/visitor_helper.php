<?php

if (!function_exists('track_visitor')) {
    function track_visitor()
    {
        $session = \Config\Services::session();
        $visitorModel = new \App\Models\VisitorModel();
        
        // Cek apakah sudah track hari ini
        $today = date('Y-m-d');
        $trackedKey = 'visitor_tracked_' . $today;
        
        if (!$session->get($trackedKey)) {
            // Track kunjungan
            $visitorModel->addVisit();
            
            // Set session untuk menghindari double track
            $session->set($trackedKey, true);
            
            // Set cookie untuk pengunjung unik (30 hari)
            $visitorCookie = 'unique_visitor_' . md5($_SERVER['REMOTE_ADDR'] . $_SERVER['HTTP_USER_AGENT']);
            
            if (!isset($_COOKIE[$visitorCookie])) {
                $visitorModel->addUniqueVisitor();
                setcookie($visitorCookie, '1', time() + (30 * 24 * 60 * 60), '/');
            }
        }
        
        // Selalu track pageview
        $visitorModel->addPageview();
        
        // Track halaman yang dikunjungi
        $pageModel = new \App\Models\VisitorPageModel();
        $currentPage = current_url();
        $pageTitle = 'Halaman ' . uri_string();
        
        $page = $pageModel->where('date', $today)
                          ->where('page_url', $currentPage)
                          ->first();
        
        if ($page) {
            $pageModel->update($page['id'], ['visits' => $page['visits'] + 1]);
        } else {
            $pageModel->insert([
                'date' => $today,
                'page_url' => $currentPage,
                'page_title' => $pageTitle,
                'visits' => 1
            ]);
        }
        
        // Track per jam
        $hourlyModel = new \App\Models\VisitorHourlyModel();
        $currentHour = date('H');
        
        $hourly = $hourlyModel->where('date', $today)
                              ->where('hour', $currentHour)
                              ->first();
        
        if ($hourly) {
            $hourlyModel->update($hourly['id'], ['visits' => $hourly['visits'] + 1]);
        } else {
            $hourlyModel->insert([
                'date' => $today,
                'hour' => $currentHour,
                'visits' => 1
            ]);
        }
    }
}