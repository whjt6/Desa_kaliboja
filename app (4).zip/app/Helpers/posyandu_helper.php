<?php
if (!function_exists('calculateAge')) {
    function calculateAge($birthDate) {
        if (!$birthDate || $birthDate == '0000-00-00') return 'Data tidak valid';
        
        try {
            $birth = new DateTime($birthDate);
            $today = new DateTime();
            $diff = $today->diff($birth);
            
            if ($diff->y > 0) {
                return $diff->y . ' tahun ' . $diff->m . ' bulan';
            } else {
                return $diff->m . ' bulan ' . $diff->d . ' hari';
            }
        } catch (Exception $e) {
            return 'Data tanggal tidak valid';
        }
    }
}

if (!function_exists('formatTanggal')) {
    function formatTanggal($date, $format = 'd M Y') {
        if (!$date || $date == '0000-00-00') return '-';
        
        try {
            $datetime = new DateTime($date);
            return $datetime->format($format);
        } catch (Exception $e) {
            return 'Invalid date';
        }
    }
}

if (!function_exists('getStatusBadge')) {
    function getStatusBadge($status) {
        switch ($status) {
            case 'berlaku':
                return '<span class="badge badge-success">Berlaku</span>';
            case 'dicabut':
                return '<span class="badge badge-danger">Dicabut</span>';
            case 'perubahan':
                return '<span class="badge badge-warning">Perubahan</span>';
            case 'akan_datang':
                return '<span class="badge badge-info">Akan Datang</span>';
            case 'selesai':
                return '<span class="badge badge-success">Selesai</span>';
            case 'dibatalkan':
                return '<span class="badge badge-secondary">Dibatalkan</span>';
            default:
                return '<span class="badge badge-light">Unknown</span>';
        }
    }
}