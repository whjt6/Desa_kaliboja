# Workspace Index Diagnostics
Tracked file count: 0

## All tracked files
