<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateJdihTables extends Migration
{
    public function up()
    {
        // Tabel kategori
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true
            ],
            'nama_kategori' => [
                'type' => 'VARCHAR',
                'constraint' => 255
            ],
            'deskripsi' => [
                'type' => 'TEXT',
                'null' => true
            ],
            'created_at' => [
                'type' => 'DATETIME'
            ],
            'updated_at' => [
                'type' => 'DATETIME'
            ]
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('kategori');

        // Tabel peraturan
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true
            ],
            'judul' => [
                'type' => 'VARCHAR',
                'constraint' => 500
            ],
            'nomor' => [
                'type' => 'VARCHAR',
                'constraint' => 100
            ],
            'tahun' => [
                'type' => 'YEAR',
                'constraint' => 4
            ],
            'kategori_id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true
            ],
            'tanggal_penetapan' => [
                'type' => 'DATE'
            ],
            'status' => [
                'type' => 'ENUM',
                'constraint' => ['berlaku', 'tidak_berlaku', 'dicabut']
            ],
            'file_path' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
                'null' => true
            ],
            'abstrak' => [
                'type' => 'TEXT',
                'null' => true
            ],
            'isi' => [
                'type' => 'LONGTEXT',
                'null' => true
            ],
            'created_at' => [
                'type' => 'DATETIME'
            ],
            'updated_at' => [
                'type' => 'DATETIME'
            ]
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('kategori_id', 'kategori', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('peraturan');

        // Tabel riwayat peraturan
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true
            ],
            'peraturan_id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true
            ],
            'perubahan' => [
                'type' => 'VARCHAR',
                'constraint' => 255
            ],
            'tanggal_perubahan' => [
                'type' => 'DATE'
            ],
            'keterangan' => [
                'type' => 'TEXT'
            ],
            'created_at' => [
                'type' => 'DATETIME'
            ],
            'updated_at' => [
                'type' => 'DATETIME'
            ]
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('peraturan_id', 'peraturan', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('riwayat_peraturan');
    }

    public function down()
    {
        $this->forge->dropTable('riwayat_peraturan');
        $this->forge->dropTable('peraturan');
        $this->forge->dropTable('kategori');
    }
}