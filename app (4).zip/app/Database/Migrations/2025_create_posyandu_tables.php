<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreatePosyanduTables extends Migration
{
    public function up()
    {
        // Tabel balita
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true
            ],
            'nama' => [
                'type' => 'VARCHAR',
                'constraint' => 255
            ],
            'tanggal_lahir' => [
                'type' => 'DATE'
            ],
            'jenis_kelamin' => [
                'type' => 'ENUM',
                'constraint' => ['L', 'P']
            ],
            'nama_ortu' => [
                'type' => 'VARCHAR',
                'constraint' => 255
            ],
            'alamat' => [
                'type' => 'TEXT'
            ],
            'berat_lahir' => [
                'type' => 'DECIMAL',
                'constraint' => '4,2'
            ],
            'tinggi_lahir' => [
                'type' => 'DECIMAL',
                'constraint' => '5,2'
            ],
            'gambar' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
                'null' => true
            ],
            'created_at' => [
                'type' => 'DATETIME'
            ],
            'updated_at' => [
                'type' => 'DATETIME'
            ]
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('balita');

        // Tabel imunisasi
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true
            ],
            'nama_imunisasi' => [
                'type' => 'VARCHAR',
                'constraint' => 255
            ],
            'deskripsi' => [
                'type' => 'TEXT'
            ],
            'usia_rekomendasi' => [
                'type' => 'VARCHAR',
                'constraint' => 100
            ],
            'manfaat' => [
                'type' => 'TEXT'
            ],
            'efek_samping' => [
                'type' => 'TEXT'
            ],
            'gambar' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
                'null' => true
            ],
            'created_at' => [
                'type' => 'DATETIME'
            ],
            'updated_at' => [
                'type' => 'DATETIME'
            ]
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('imunisasi');

        // Tabel jadwal_posyandu
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true
            ],
            'nama_kegiatan' => [
                'type' => 'VARCHAR',
                'constraint' => 255
            ],
            'tanggal' => [
                'type' => 'DATE'
            ],
            'waktu' => [
                'type' => 'TIME'
            ],
            'lokasi' => [
                'type' => 'VARCHAR',
                'constraint' => 255
            ],
            'penanggung_jawab' => [
                'type' => 'VARCHAR',
                'constraint' => 255
            ],
            'status' => [
                'type' => 'ENUM',
                'constraint' => ['aktif', 'selesai', 'dibatalkan']
            ],
            'created_at' => [
                'type' => 'DATETIME'
            ],
            'updated_at' => [
                'type' => 'DATETIME'
            ]
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('jadwal_posyandu');
    }

    public function down()
    {
        $this->forge->dropTable('balita');
        $this->forge->dropTable('imunisasi');
        $this->forge->dropTable('jadwal_posyandu');
    }
}